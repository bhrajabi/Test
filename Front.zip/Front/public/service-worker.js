const CACHE_NAME =  "ikco-250506@1321";
const urlsToCache = ["/appmon.html","/asset-manifest.json","/data/materials-template.xlsx","/data/products-price.xlsx","/data/suppliers-template.xlsx","/fonts/iranyekan-fonts/iranyekanwebbold.ttf","/fonts/iranyekan-fonts/iranyekanwebbold.woff","/fonts/iranyekan-fonts/iranyekanweblight.ttf","/fonts/iranyekan-fonts/iranyekanweblight.woff","/fonts/iranyekan-fonts/iranyekanwebregular.ttf","/fonts/iranyekan-fonts/iranyekanwebregular.woff","/fonts/iranyekan.css","/fonts/iranyekanwebregular.ttf","/fonts/iranyekanwebregular.woff","/help/AUC.pptx","/help/Help-IPN-Answer-to-Event.pdf","/help/Help-IPN-External-Event-A.pdf","/help/Help-IPN-External-Event-A.pptx","/help/Help-IPN-Internal-Event.pdf","/help/Help-IPN-Internal-Event.pptx","/help/IPN-Register-Haqiqi.pdf","/help/IPN-Register-Hoqoqi.pdf","/help/IPN.pptx","/help/login.pdf","/help/login.pptx","/help/SRC.pptx","/help/SRM.pptx","/help/TM.pptx","/help/user-management.pdf","/icons/android-chrome-192x192.png","/icons/android-chrome-512x512.png","/icons/apple-touch-icon.png","/icons/favicon-16x16.png","/icons/favicon-32x32.png","/images/avatar/user1.jpg","/images/bg/banner.jpg","/images/bg/bg-home.jpg","/images/bg/bg-home2.jpg","/images/bg/bg-home3.jpg","/images/bg/bg-home4.jpg","/images/bg/bg-home5.jpg","/images/bg/bg-home6.jpg","/images/bg/bg-map.png","/images/bg/bg1.jpg","/images/bg/bg1_original.jpg","/images/bg/bg2.jpg","/images/bg/bg2.png","/images/bg/bg3.jpg","/images/bg/bg4.jpg","/images/bg/blob-1.svg","/images/bg/cloud1.jpg","/images/bg/cloud3.jpg","/images/bg/default-banner.jpg","/images/bg/dots.png","/images/bg/Feed-cloud.jpg","/images/bg/Feed-Flower.jpg","/images/bg/Feed-Ikco.jpg","/images/bg/Feed-News.jpg","/images/bg/Feed-Sea.jpg","/images/bg/Feed-Speaker.jpg","/images/bg/Feed-Speaker2.jpg","/images/bg/Feed-SRM.jpg","/images/bg/Feed-Table.jpg","/images/bg/Feed-TM.jpg","/images/bg/Feed=Network.jpg","/images/bg/ikco.png","/images/bg/network.jpg","/images/bg/srm.jpg","/images/contact-us/address.png","/images/contact-us/call.png","/images/contact-us/email.png","/images/empty-page.svg","/images/home/banner1-old.png","/images/home/banner1.png","/images/home/banner1_old.png","/images/home/blob-1.svg","/images/home/increase-sales.jpg","/images/home/network.png","/images/home/procurement.jpg","/images/home/risk-management.jpg","/images/logo/header-logo-en.png","/images/logo/header-logo.jpg","/images/logo/header-logo.png","/images/logo/logo-fill-new.png","/images/logo/logo-fill-old.png","/images/logo/logo-fill.png","/images/logo/logo-outline.png","/images/logo/logo.png","/index.html","/js/Dastine-Config.js","/js/Dastine.js","/manifest.json","/static/css/main.dba39691.css","/static/css/main.dba39691.css.map","/static/js/main.5ce5c3e6.js","/static/js/main.5ce5c3e6.js.map","/static/media/logo.37141d962f7ea9f12111.png","/static/media/slick.2630a3e3eab21c607e21.svg","/static/media/slick.295183786cd8a1389865.woff","/static/media/slick.a4e97f5a2a64f0ab1323.eot","/static/media/slick.c94f7671dcc99dce43e2.ttf"];

const addResourcesToCache = async (resources) => {
    const has = await caches.has(CACHE_NAME);
    if (!has) return await reportVersion();
    else {
        const x = await caches.open(CACHE_NAME);
        await x.addAll(resources);
    }
};

const putInCache = async (request, response) => {
    const cache = await caches.open(CACHE_NAME);
    await cache.put(request, response);
};

const cacheFirst = async ({ request, preloadResponsePromise }) => {
    if (!isAllowed(request)) {
        return await fetch(request).catch((err) => {
            return new Response(JSON.stringify({ result: null, isSuccess: false, errorMessage: translateError(err), errorCode: "408" }));
        });
    }

    const responseFromCache = await caches.match(request);
    if (responseFromCache) return responseFromCache;

    const preloadResponse = await preloadResponsePromise;
    if (preloadResponse) {
        putInCache(request, preloadResponse.clone());
        return preloadResponse;
    }

    try {
        const responseFromNetwork = await fetch(request.clone());
        putInCache(request, responseFromNetwork.clone());
        return responseFromNetwork;
    } catch (error) {
        return new Response(JSON.stringify({ result: null, isSuccess: false, errorMessage: "network-error", errorCode: "408" }));
    }
};

const reportVersion = () =>
    new Promise((resolve, reject) =>
        self.clients
            .matchAll()
            .then(function (clientList) {
                clientList.forEach(function (client) {
                    client.postMessage(
                        JSON.stringify({
                            type: "version",
                            version: CACHE_NAME,
                        })
                    );
                });
                resolve();
            })
            .catch(reject)
    );

const deleteOtherCaches = () =>
    caches.keys().then(function (cacheNames) {
        cacheNames.map(function (cacheName) {
            if (cacheName !== CACHE_NAME) {
                return caches.delete(cacheName);
            }
        });
    });

const enableNavigationPreload = () => (self.registration.navigationPreload ? self.registration.navigationPreload.enable() : Promise.all());

self.addEventListener("activate", (event) => {
    event.waitUntil(Promise.all([self.clients.claim(), enableNavigationPreload(), deleteOtherCaches(), reportVersion()]));
});

self.oninstall = function (event) {
    event.waitUntil(addResourcesToCache(urlsToCache).then(self.skipWaiting.bind(self)));
};

self.addEventListener("fetch", (event) => {
    event.respondWith(
        cacheFirst({
            request: event.request,
            preloadResponsePromise: event.preloadResponse,
        })
    );
});

const isAllowed = (request) => {
    if (request.method != "GET") return false;
    return urlsToCache.some((url) => request.url.includes(url));
};

function translateError(ex) {
    if (!ex) return "unknown-error";

    if (ex.response) {
        if (ex.response.status === 401) return "401-unauthorized-access";
        if (ex.response.status === 403) return "403-forbidden-access";
        if (ex.response.status === 404) return "404-resource-not-found";
        if (ex.response.status === 405) return "405-method-not-allowed";
        if (ex.response.status === 500) return "500-server-error";
    }
    if (ex instanceof Error) {
        if (ex.name === "401" || ex.name === "403") return ex;
    }

    var message = ex.message ? ex.message : ex.toString ? ex.toString() : ex;

    if (message === "Network Error" || message === "Failed to fetch") {
        message = "service-is-not-available";
    }
    if (message.startsWith("Failed to execute 'open' on 'XMLHttpRequest': Invalid URL")) message = "invalid-url";
    return message;
}
