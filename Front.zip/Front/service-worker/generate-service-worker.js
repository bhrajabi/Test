// generate-service-worker.js
const fs = require("fs");
const path = require("path");
require("dotenv").config();

const templatePath = path.resolve(__dirname, "./service-worker.js.template");
const outputPath = path.resolve(__dirname, "../build/service-worker.js");
const cacheName = process.env.REACT_APP_VERSION;
const permittedExtentions = ["ttf", "eot", "woff", "svg", "png", "map", "js", "css", "json", "jpg", "ico,", "pptx", "pdf", "html", "xlsx"];
const forbiddenFiles = ["service-worker.js"];

const filesInTheFolder = getFiles("./build/");

fs.readFile(templatePath, "utf8", (err, data) => {
    if (err) {
        console.error("Error reading service worker template:", err);
        return;
    }

    const modifiedData = data.replace("version", cacheName).replace("%caches%", filesInTheFolder.join(","));

    fs.writeFile(outputPath, modifiedData, "utf8", (err) => {
        if (err) {
            console.error("Error writing service worker:", err);
            return;
        }
        console.log("Service worker generated successfully.");
    });
});

// Recursive function to get files
function getFiles(dir, files = []) {
    // Get an array of all files and directories in the passed directory using fs.readdirSync
    if (!fs.existsSync(dir)) return [];

    const fileList = fs.readdirSync(dir);
    // Create the full path of the file/directory by concatenating the passed directory and file/directory name
    for (const file of fileList) {
        let name = `${dir}/${file}`;
        // Check if the current file/directory is a directory using fs.statSync
        if (fs.statSync(name).isDirectory()) {
            // If it is a directory, recursively call the getFiles function with the directory path and the files array
            getFiles(name, files);
        } else {
            var splited = name.split(".");
            var ext = splited[splited.length - 1];

            if (!forbiddenFiles.filter((x) => name.includes(x)).length && permittedExtentions.filter((x) => x == ext).length > 0) {
                name = name.replace("//", "/");
                name = name.replace("./build/", "/");
                files.push(`"${name}"`);
            }
        }
    }
    return files;
}
