// import { render } from "react-dom"
// import { App } from "./app"

// test('my test 1', ()=>{
//     render(<App/>)
// })
