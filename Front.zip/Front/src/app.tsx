import { useEffect, useState } from "react";
import * as bd from "react-basic-design";
import { Modal } from "react-bootstrap";
import { Route, Routes, useNavigate } from "react-router-dom";
import { useAccount } from "./app/account-context";
import { ThemeProvider } from "./app/theme-context";
import { T } from "./components/basic/text";
import { CommodityApp } from "./components/commodities/commodity-app";
import { ScrollToTop } from "./components/scroll-to-top/scroll-to-top";
import { SMCreateVendorApp } from "./components/sm/sm-create-vendor-app";
import useServiceWorker from "./hooks/use-service-worker";
import { TProvider } from "./i18n";
import { AccountSetPasswordApp } from "./pages/account/account-set-password-app";
import { ForgotPasswordApp } from "./pages/account/forgot-password/forgot-password-app";
import { LoginApp } from "./pages/account/login/login-app";
import { RegisterApp } from "./pages/account/register/register-app";
import { RegisterRelationApp } from "./pages/account/register/register-relation-app";
import { TowFactorAuthenticationApp } from "./pages/account/user-profile/tow-factor-authentication-app";
import { UserProfileApp } from "./pages/account/user-profile/user-profile-app";
import { AdminChatsApp } from "./pages/admin-chats/admin-chats-app";
import { AuctionAttributeApp } from "./pages/auction/auction-attribute/auction-attribute-app";
import { AuctionListApp } from "./pages/auction/auction-list/auction-list-app";
import { CreateAuctionApp } from "./pages/auction/create/create-auction-app";
import { AuctionProjectInfoApp } from "./pages/auction/edit/auction-project-info-app";
import { AuctionHomeApp } from "./pages/auction/home/auction-home-app";
import { AuctionMonitorApp } from "./pages/auction/monitor/auction-monitor-app";
import { ProjectAuctionRulesApp } from "./pages/auction/rules/project-auction-rules-app";
import { AuctionSendSMSApp } from "./pages/auction/send-sms/auction-send-sms-app";
import { AuctionTeamApp } from "./pages/auction/team/auciton-team-app";
import { ChatLinkRouterApp } from "./pages/chat-link-router/chat-link-router-app";
import { CnfMeetingCreateApp } from "./pages/cnf-meeting/cnf-meeting-create-app";
import { CnfMeetingEditApp } from "./pages/cnf-meeting/cnf-meeting-edit-app";
import { CnfMeetingMonitoringApp } from "./pages/cnf-meeting/cnf-meeting-monitoring-app";
import { CnfMeetingsApp } from "./pages/cnf-meeting/cnf-meetings-app";
import { CompanyAuthenticationApp } from "./pages/company/authentication/company-authentication-app";
import { ConnectionsApp } from "./pages/company/connections/connections-app";
import { CustomizingApp } from "./pages/company/customizing/customizing-app";
import { UploadMaterialsApp } from "./pages/company/customizing/upload-materials-app";
import { ExchangeRateApp } from "./pages/company/exchange-rate/exchange-rate-app";
import { OrganizationChartsApp } from "./pages/company/organization-charts/organization-charts-app";
import { ProductPricesApp } from "./pages/company/products/product-prices-app";
import { CompanyProfileApp } from "./pages/company/profile/company-profile-app";
import { PublicProfileApp } from "./pages/company/public-profile/public-profile-app";
import { CompanyUserApp } from "./pages/company/users/company-user-app";
import { CompanyUsersApp } from "./pages/company/users/company-users-app";
import { ConfirmationFormApp } from "./pages/confirmations/confirmation-form-app";
import { ConfirmationMonitorApp } from "./pages/confirmations/view/confirmation-view-app";
import { CreateContentDocumentApp } from "./pages/content/create/create-content-document-app";
import { EditContentDocumentApp } from "./pages/content/edit/edit-content-document-app";
import { ContentMonitorApp } from "./pages/content/monitor/content-monitor-app";
import { EventCycleTimeApp } from "./pages/cycle-times/event-cycle-time-app";
import { RequestCycleTimeApp } from "./pages/cycle-times/request-cycle-time-app";
import { Db2CodeApp } from "./pages/db2code/db2code-app";
import { CreateDiscoveryApp } from "./pages/discovery/create/create-discovery-app";
import { CreateQuickDiscoveryApp } from "./pages/discovery/create/create-quick-discovery-app";
import { DiscoverySendSMS } from "./pages/discovery/messaging/send-sms";
import { DiscoveryMonitorApp } from "./pages/discovery/monitor/discovery-monitor-app";
import { SearchDiscoveries } from "./pages/discovery/search/search-discoveries";
import { SearchDocumentApp } from "./pages/document/search/serach-document-app";
import { ErrorReportApp } from "./pages/error-report/error-report-app";
import { CreateEventApp } from "./pages/event/create/create-event-app";
import { CreateEventsBySpqApp } from "./pages/event/create/create-event-by-spq-app";
import { CreateQuickRFPEventApp } from "./pages/event/create/create-quick-event-rfp-app";
import { EditEventApp } from "./pages/event/edit/edit-event-app";
import { EventMonitorApp } from "./pages/event/monitor/event-monitor-app";
import { OpenEventBySmsApp } from "./pages/event/send-sms/open-event-by-sms";
import { SendSMSApp } from "./pages/event/send-sms/send-sms-app";
import { ExternalEventSourcingApp } from "./pages/event/sourcing/external-event-sourcing-app";
import { FaqsApp } from "./pages/home/dashboard/faq/faq-app";
import { HomeApp } from "./pages/home/dashboard/home-app";
import { IkcoIpgInquiryTestApp } from "./pages/home/dashboard/ikco-ipg/ikco-ipg-inquiry/ikco-ipg-inquiry-test-app";
import { IkcoIpgTerminalsApp } from "./pages/home/dashboard/ikco-ipg/ikco-ipg-terminals/ikco-ipg-terminals-app";
import { IkcoIpgTestPaymentApp } from "./pages/home/dashboard/ikco-ipg/ikco-ipg-test-payment/ipg-test-payment-app";
import { IkcoIpgTestPaymentResultApp } from "./pages/home/dashboard/ikco-ipg/ikco-ipg-test-payment/ipg-test-payment-result-app";
import { IkcoIpgSalesReportApp } from "./pages/home/dashboard/ikco-ipg/ikco-ipg-transactions/ikco-ipg-sales-report-app";
import { IkcoIPGTransactionsApp } from "./pages/home/dashboard/ikco-ipg/ikco-ipg-transactions/ikco-ipg-transactions-app";
import { JobLogsApp } from "./pages/home/dashboard/job-logs/job-log-app";
import { SysLogApp } from "./pages/home/dashboard/sys-logs/sys-log-app";
import { SysLogInfoApp } from "./pages/home/dashboard/sys-logs/sys-log-info-app";
import { QuartzThemeApp } from "./pages/home/dashboard/sys-menu/quartz-theme";
import { TileIconsApp } from "./pages/home/dashboard/sys-menu/tile-icons-app";
import { UserLogApp } from "./pages/home/dashboard/user-logs/user-log-app";
import { VisitLogsApp } from "./pages/home/dashboard/visit-logs/visit-log-app";
import { PublicCompanyApp } from "./pages/home/startup/companies/public-company-app";
import { PublicCompanySearchApp } from "./pages/home/startup/companies/public-company-search-app";
import { ContactUsApp } from "./pages/home/startup/contact-us/contact-us-app";
import StartupApp from "./pages/home/startup/startup-app";
import { SupplierDiscoveriesApp } from "./pages/home/startup/supplier-discoveries/supplier-discoveries-app";
import { SupplierDiscoveryApp } from "./pages/home/startup/supplier-discoveries/supplier-discovery-app";
import { ImportSellerApp } from "./pages/import-seller/import-seller-app";
import { LinkShortenerApp } from "./pages/link-shortener/link-shortener-app";
import { AdminMessageApp } from "./pages/messaging/admin-messaging-app";
import { MessagingApp } from "./pages/messaging/messaging-app";
import { InviteCompanyApp } from "./pages/messaging/reffer-user/invite-company-app";
import { SendMessageApp } from "./pages/messaging/send-sms/send-message-app";
import { AdminCompanySerachApp } from "./pages/network/admin-company-search-app";
import { InitBuyerApp } from "./pages/network/init-buyer/init-buyer-app";
import { NetworkAdminApp } from "./pages/network/network-admin-app";
import { RefreshSysMenuApp } from "./pages/network/refresh-sys-menu-app";
import { UserListApp } from "./pages/network/search-user/user-lists-app";
import { UserNotificationsApp } from "./pages/notification/user-notifications-app";
import { UserTasksApp } from "./pages/notification/user-tasks-app";
import { CreateOrderApp } from "./pages/order/create/create-order-app";
import { EditOrderApp } from "./pages/order/edit/edit-order-app";
import { ViewOrderApp } from "./pages/order/review/view-order-app";
import { SearchOrderApp } from "./pages/order/search/search-order-app";
import { ReportOrdersWithoutSLApp } from "./pages/order/sl/report-orders-without-sl-app";
import { SearchSLApp } from "./pages/order/sl/serch-sl-app";
import { CreateProjectApp } from "./pages/project/create/create-project-app";
import { EditProjectApp } from "./pages/project/edit/edit-project-app";
import { ExpiringProjectsApp } from "./pages/project/maturity-projects/expiring-projects-app";
import { ProjectDashboardApp } from "./pages/project/monitoring/project-monitor-app";
import { ProjectContactsApp } from "./pages/project/project-contact/porject-contacts-app";
import { TemplatesApp } from "./pages/project/templates/templates-app";
import { RasmioApp } from "./pages/rasmio/rasmio-app";
import { RedirectApp } from "./pages/redirect/redirect-app";
import { RegReqListApp } from "./pages/reg-req/reg-req-list-app";
import { RegReqViewApp } from "./pages/reg-req/reg-req-view-app";
import { EventsReportApp } from "./pages/report/events-report/events-report-app";
import { OrdersReport } from "./pages/report/orders/orders-report";
import { SourcingReport } from "./pages/report/sourcing-report/sourcing-report";
import { SrmReportApp } from "./pages/report/srm-report/srm-report-app";
import { CreateRequestApp } from "./pages/req/create/create-request-app";
import { EditRequestApp } from "./pages/req/edit/edit-request-app";
import { ReqMonitorApp } from "./pages/req/monitor/req-monitor-app";
import { SearchReqItemsApp } from "./pages/req/search-items-app";
import { SearchRequestsApp } from "./pages/req/search-requests-app";
import { ViewSourcingRequestApp } from "./pages/req/view/view-request-app";
import { DiscoveryListApp } from "./pages/seller/discovery/discovery-list-app";
import { EventListApp } from "./pages/seller/event/event-list-app";
import { PublicEventListApp } from "./pages/seller/event/public-event-list-app";
import { ViewPublicEventApp } from "./pages/seller/event/view-public-event-app";
import { SellerHomeApp } from "./pages/seller/home/seller-home-app";
import { ConfirmedOrderListApp } from "./pages/seller/order/confirmed-order-list-app";
import { OrderListApp } from "./pages/seller/order/order-list-app";
import { ReviewOrderApp } from "./pages/seller/order/review-order-app";
import { SellerConfirmOrdersApp } from "./pages/seller/order/seller-confirm-orders-app";
import { RespondToEventApp } from "./pages/seller/respond/respond-to-event-app";
import { ShipNoticeApp } from "./pages/seller/ship-notice/ship-notice-app";
import { ShipNoticeListApp } from "./pages/seller/ship-notice/ship-notice-list-app";
import { SellerUsersApp } from "./pages/seller/users/seller-users-app";
import { NotFound } from "./pages/shared/not-found";
import { Protected } from "./pages/shared/protected";
import { PublicLayout } from "./pages/shared/public-layout";
import { ExpiredQuestionnairesApp } from "./pages/sm/questionaries/expired-questionnaires";
import { SearchSupplierApp } from "./pages/sm/search/supplier-search-app";
import { SuppliersUploadApp } from "./pages/sm/suppliers-upload/suppliers-upload-app";
import { SUPWSApp } from "./pages/sm/supws/supws-app";
import { SourcingReportApp } from "./pages/sourcing-report/sourcing-report-app";
import { CreateSpqDocumentApp } from "./pages/spq/views/spq-create-document-app";
import { SPQManageEventApp } from "./pages/spq/views/spq-manage-event-app";
import { SpqMonitorApp } from "./pages/spq/views/spq-monitor-app";
import { TasksApp } from "./pages/tasks/tasks-app";
import { MaterialPackagingApp } from "./pages/tm/packaging/material-packaging-app";
import { UserLogsApp } from "./pages/user-logs/user-logs-app";
import { EvaluationRequestsApp } from "./pages/vendors/evaluation-requests/evaluation-requests-app";
import { ManageEvaluationAccessApp } from "./pages/vendors/manage-evaluation-access/manage-evaluation-access-app";
import { WafApp } from "./pages/waf/waf-app";
import { WFManageApp } from "./pages/wf/wf-manage/wf-manage-app";
import { WorkflowListApp } from "./pages/wf/workflow-list-app";

import { DesignFormApp } from "./pages/forms/design/design-form-app";
import { FormsListApp } from "./pages/forms/list/forms-list-app";

import { useChats } from "./components/chat/use-chats";
import { OtpTestApp } from "./otp-test-app";
import { OtpTestApp2 } from "./otp-test-app2";
import { EventSummaryApp } from "./pages/event/summary/event-summary-app";
import { FormsInstanceListApp } from "./pages/forms/instance/form-instance-list-app";
import { IkcoIpgTransactionsLogsApp } from "./pages/home/dashboard/ikco-ipg/ikco-ipg-transactions-logs/ikco-ipg-transactions-log-app";
import { OrderItemsApp } from "./pages/report/order-item-report/order-item-app";
import { OrderScheduleLineReportApp } from "./pages/report/order-schedule-line-report/order-schedule-line-report-app";
import { ShipmentItemsReportApp } from "./pages/report/shipment-item-report/shipment-item-report-app";
import { FUCreateApp } from "./pages/tm/fu-create/fu-create-app";
import { FUEditApp } from "./pages/tm/fu-edit/fu-edit-app";
import { TMMonitorApp } from "./pages/tm/monitor/tm-monitor-app";

//-- ikco ipg pages (end)

export function App() {
    const [availableUpdate, setAvailableUpdate] = useState<{ show: boolean }>({ show: false });
    useServiceWorker(() => setAvailableUpdate({ show: true }));

    return (
        <TProvider>
            <ThemeProvider>
                <ScrollToTop />

                <Routes>
                    <Route path="/">
                        <Route path="/otp" element={<OtpTestApp />} />
                        <Route path="/otp2" element={<OtpTestApp2 />} />
                        <Route path="/" element={<StartupApp />} />
                        <Route path="/waf" element={<WafApp />} />
                        <Route path="/login" element={<LoginApp />} />
                        <Route path="/account/forgot-password" element={<ForgotPasswordApp />} />
                    </Route>

                    {/* + NavBar + Chat */}
                    <Route path="/" element={<PublicLayout showNavBar />}>
                        <Route element={<Protected />}>
                            <Route path="/seller/" element={<SellerHomeApp />} />
                            <Route path="/seller/users" element={<SellerUsersApp />} />
                            <Route path="/seller/events" element={<EventListApp />} />
                            <Route path="/seller/public-events" element={<PublicEventListApp />} />
                            <Route path="/seller/orders" element={<OrderListApp />} />
                            <Route path="/seller/released-orders" element={<SellerConfirmOrdersApp />} />
                            <Route path="/seller/confirmed-orders" element={<ConfirmedOrderListApp />} />
                            <Route path="/seller/shipments" element={<ShipNoticeListApp />} />
                            <Route path="/seller/order-review" element={<ReviewOrderApp />} />
                            <Route path="/seller/ship-notice" element={<ShipNoticeApp />} />
                            <Route path="/seller/search-discovery" element={<DiscoveryListApp />} />
                            <Route path="/company/profile" element={<CompanyProfileApp />} />

                            <Route path="/view/public-event" element={<ViewPublicEventApp />} />

                            <Route path="/redirect" element={<RedirectApp />} />
                            <Route path="/chat-link-router" element={<ChatLinkRouterApp />} />
                            <Route path="/home" element={<HomeApp />} />
                            <Route path="/create-admin-chat" element={<HomeApp command="create-admin-chat" />} />
                            <Route path="/saved-messages" element={<HomeApp command="saved-message" />} />
                            <Route path="/chats/admin-chats" element={<AdminChatsApp />} />
                            <Route path="/tasks" element={<TasksApp />} />
                            <Route path="/wf/list" element={<WorkflowListApp />} />
                            <Route path="/supplier-discovery" element={<SupplierDiscoveryApp />} />
                            <Route path="/account/user-profile" element={<UserProfileApp />} />
                            <Route path="/account/two-factor" element={<TowFactorAuthenticationApp />} />
                            {/* <Route path="/account/change-password" element={<UserChangePasswordApp />} /> */}

                            <Route path="/network-admin" element={<NetworkAdminApp />} />
                            <Route path="/network/error-report" element={<ErrorReportApp />} />
                            <Route path="/network/commodities" element={<CommodityApp />} />
                            <Route path="/network/refresh-sys-menu" element={<RefreshSysMenuApp />} />
                            <Route path="/network/search-company" element={<AdminCompanySerachApp />} />
                            <Route path="/network/sys-logs" element={<SysLogApp />} />
                            <Route path="/network/sys-log" element={<SysLogInfoApp />} />
                            <Route path="/network/sys-log" element={<SysLogInfoApp />} />
                            <Route path="/network/user-lists" element={<UserListApp />} />

                            <Route path="/forms/list" element={<FormsInstanceListApp />} />
                            <Route path="/company/forms" element={<FormsListApp />} />
                            <Route path="/company/design-form" element={<DesignFormApp />} />

                            <Route path="/network/user-logs" element={<UserLogApp />} />
                            <Route path="/network/job-logs" element={<JobLogsApp />} />
                            <Route path="/network/visit-logs" element={<VisitLogsApp />} />

                            <Route path="/messaging/send" element={<SendMessageApp />} />
                            <Route path="/messaging/critic" element={<MessagingApp messageTypeId="critic" />} />
                            <Route path="/messaging/suggestion" element={<MessagingApp messageTypeId="suggestion" />} />
                            <Route path="/messaging/invite-company" element={<InviteCompanyApp />} />
                            <Route path="/admin/messaging/critic" element={<AdminMessageApp typeId="critic" />} />
                            <Route path="/admin/messaging/suggestion" element={<AdminMessageApp typeId="suggestion" />} />
                            <Route path="/project/create" element={<CreateProjectApp />} />
                            <Route path="/project/create-template" element={<CreateProjectApp />} />
                            <Route path="/project/monitor" element={<ProjectDashboardApp />} />
                            <Route path="/project/edit" element={<EditProjectApp />} />
                            <Route path="/project/search-items" element={<SearchReqItemsApp />} />
                            <Route path="/project/search-requests" element={<SearchRequestsApp />} />
                            <Route path="/project/templates" element={<TemplatesApp />} />
                            <Route path="/project/expiring-projects" element={<ExpiringProjectsApp />} />

                            <Route path="/event/sourcing" element={<ExternalEventSourcingApp />} />
                            <Route path="/event/summary" element={<EventSummaryApp />} />
                            <Route path="/event/monitor" element={<EventMonitorApp />} />
                            <Route path="/event/create" element={<CreateEventApp />} />
                            <Route path="/event/create-quick-rfp" element={<CreateQuickRFPEventApp />} />
                            <Route path="/event/edit" element={<EditEventApp />} />
                            <Route path="/event/create-event-by-spq" element={<CreateEventsBySpqApp />} />
                            <Route path="/event/respond" element={<RespondToEventApp />} />
                            <Route path="/event/send-sms" element={<SendSMSApp />} />
                            <Route path="/go" element={<OpenEventBySmsApp />} />
                            <Route path="/cnf-meeting" element={<CnfMeetingsApp />} />
                            <Route path="/cnf-meeting/monitor" element={<CnfMeetingMonitoringApp />} />
                            <Route path="/cnf-meeting/edit" element={<CnfMeetingEditApp />} />
                            <Route path="/cnf-meeting/create" element={<CnfMeetingCreateApp />} />
                            <Route path="/content/monitor" element={<ContentMonitorApp />} />
                            <Route path="/content/edit" element={<EditContentDocumentApp />} />
                            <Route path="/content/create" element={<CreateContentDocumentApp />} />
                            <Route path="/spq/event" element={<SPQManageEventApp />} />
                            <Route path="/spq/monitor" element={<SpqMonitorApp />} />
                            <Route path="/spq/create" element={<CreateSpqDocumentApp />} />
                            <Route path="/discovery/create" element={<CreateDiscoveryApp />} />
                            <Route path="/discovery/create-quick-disc" element={<CreateQuickDiscoveryApp />} />
                            <Route path="/discovery/monitor" element={<DiscoveryMonitorApp />} />
                            <Route path="/discovery/search" element={<SearchDiscoveries />} />
                            <Route path="/discovery/send-sms" element={<DiscoverySendSMS />} />
                            <Route path="/suppliers/upload" element={<SuppliersUploadApp />} />
                            <Route path="/sm/supws" element={<SUPWSApp />} />
                            <Route path="/sm/expired-questionnaires" element={<ExpiredQuestionnairesApp />} />

                            <Route path="/document/search" element={<SearchDocumentApp />} />
                            <Route path="/sm/search" element={<SearchSupplierApp />} />
                            <Route path="/event-cycle-times" element={<EventCycleTimeApp />} />
                            <Route path="/request-cycle-times" element={<RequestCycleTimeApp />} />
                            <Route path="/exeptions/sys-log" element={<SysLogInfoApp />} />
                            <Route path="/company/customizing" element={<CustomizingApp />} />
                            <Route path="/company/upload-materials" element={<UploadMaterialsApp />} />
                            <Route path="/company/users" element={<CompanyUsersApp />} />
                            <Route path="/company/user" element={<CompanyUserApp />} />
                            <Route path="/company/product-prices" element={<ProductPricesApp />} />
                            <Route path="/company/create-company" element={<SMCreateVendorApp />} />
                            <Route path="/company/connections" element={<ConnectionsApp />} />
                            <Route path="/company/public-profile" element={<PublicProfileApp />} />
                            <Route path="/company/authentication" element={<CompanyAuthenticationApp />} />
                            <Route path="/company/organization-chart" element={<OrganizationChartsApp />} />
                            <Route path="/company/exchange-rate" element={<ExchangeRateApp />} />

                            <Route path="/order/create" element={<CreateOrderApp />} />
                            <Route path="/order/edit" element={<EditOrderApp />} />
                            <Route path="/order/search" element={<SearchOrderApp />} />
                            <Route path="/order/view" element={<ViewOrderApp />} />
                            <Route path="/order/create-sl" element={<SearchSLApp />} />
                            <Route path="/order/sl-report" element={<ReportOrdersWithoutSLApp />} />
                            <Route path="/order/order-items" element={<OrderItemsApp />} />
                            <Route path="/order/order-schedule-line-report" element={<OrderScheduleLineReportApp />} />

                            <Route path="/req/monitor" element={<ReqMonitorApp />} />
                            <Route path="/req/view" element={<ViewSourcingRequestApp />} />
                            <Route path="/req/create" element={<CreateRequestApp />} />
                            <Route path="/req/edit" element={<EditRequestApp />} />
                            <Route path="/vendors/evaluation-requests" element={<EvaluationRequestsApp />} />
                            <Route path="/vendors/manage-evaluation-access" element={<ManageEvaluationAccessApp />} />

                            <Route path="/report/source-report" element={<SourcingReportApp />} />

                            <Route path="/notification/user-notifications" element={<UserNotificationsApp />} />
                            <Route path="/notification/user-tasks" element={<UserTasksApp />} />

                            <Route path="/logs/user-logs" element={<UserLogsApp />} />
                            <Route path="/auction/home" element={<AuctionHomeApp />} />
                            <Route path="/auction/create" element={<CreateAuctionApp />} />
                            <Route path="/auction/monitor" element={<AuctionMonitorApp />} />
                            <Route path="/auction/send-sms" element={<AuctionSendSMSApp />} />
                            <Route path="/auction/attributes" element={<AuctionAttributeApp />} />
                            <Route path="/auction/contacts" element={<ProjectContactsApp />} />
                            <Route path="/auction/rules" element={<ProjectAuctionRulesApp />} />
                            <Route path="/auction/edit" element={<AuctionProjectInfoApp />} />
                            <Route path="/auction/team" element={<AuctionTeamApp />} />
                            <Route path="/auction/list" element={<AuctionListApp />} />

                            <Route path="/tm/monitor" element={<TMMonitorApp />} />
                            <Route path="/tm/fu-create" element={<FUCreateApp />} />
                            <Route path="/tm/fu-edit" element={<FUEditApp />} />
                            <Route path="/tm/material-packaging" element={<MaterialPackagingApp />} />

                            <Route path="/report/srm-report" element={<SrmReportApp />} />
                            <Route path="/report/sourcing-report" element={<SourcingReport />} />
                            <Route path="/report/orders-report" element={<OrdersReport />} />
                            <Route path="/report/events-report" element={<EventsReportApp />} />
                            <Route path="/shipment/shipment-item-report" element={<ShipmentItemsReportApp />} />

                            <Route path="/confirmation/create" element={<ConfirmationFormApp />} />
                            <Route path="/confirmation/edit" element={<ConfirmationFormApp />} />
                            <Route path="/confirmation/view" element={<ConfirmationMonitorApp />} />

                            <Route path="/wf/wf-manage" element={<WFManageApp />} />
                            <Route path="/registration/request-list" element={<RegReqListApp />} />
                            <Route path="/regreq/view" element={<RegReqViewApp />} />
                            <Route path="/import/import-seller" element={<ImportSellerApp />} />
                            <Route path="/db2code" element={<Db2CodeApp />} />

                            <Route path="/help/faqs" element={<FaqsApp />} />

                            {/* ipg */}
                            <Route path="/ipg/ikco-transactions" element={<IkcoIPGTransactionsApp />} />
                            <Route path="/ipg/payment-test" element={<IkcoIpgTestPaymentApp />} />
                            <Route path="/ipg/inquiry-job-test" element={<IkcoIpgInquiryTestApp />} />
                            <Route path="/ipg/payment-test-result" element={<IkcoIpgTestPaymentResultApp />} />
                            <Route path="/ipg/ipg-sales-report" element={<IkcoIpgSalesReportApp />} />
                            <Route path="/ipg/acceptors" element={<IkcoIpgTerminalsApp />} />
                            <Route path="/ipg/transaction-logs" element={<IkcoIpgTransactionsLogsApp />} />
                            {/* ipg */}
                        </Route>
                    </Route>

                    {/* Without NavBar */}
                    <Route path="/" element={<PublicLayout hideChat />}>
                        <Route path="/tile-icons" element={<TileIconsApp />} />
                        <Route path="/quartz-theme" element={<QuartzThemeApp />} />
                        <Route path="/supplier-discoveries" element={<SupplierDiscoveriesApp />} />
                        <Route path="/logout" element={<Logout />} />

                        <Route path="/network/init-buyer" element={<InitBuyerApp />} />

                        <Route path="/company" element={<PublicCompanyApp />} />
                        <Route path="/company-search" element={<PublicCompanySearchApp />} />

                        <Route path="/contact/contact-us" element={<ContactUsApp />} />

                        <Route path="/register" element={<RegisterApp />} />
                        <Route path="/register-relation" element={<RegisterRelationApp />} />
                        <Route path="/account/create-company" element={<RegisterApp />} />

                        <Route path="/account/activate" element={<AccountSetPasswordApp />} />

                        <Route path="/go/:serial" element={<LinkShortenerApp />} />

                        <Route element={<Protected />}>
                            <Route path="/rasmio" element={<RasmioApp />} />
                        </Route>

                        <Route path="*" element={<NotFound />} />
                    </Route>
                </Routes>
            </ThemeProvider>

            <Modal show={availableUpdate.show} centered>
                <Modal.Header>
                    <bd.Flex vertical gap={1}>
                        <T>an-update-is-available</T>
                        <div>
                            <T append=":">version-number</T>
                            {localStorage.version}
                        </div>
                    </bd.Flex>
                </Modal.Header>
                <Modal.Body>
                    <bd.Flex content="end">
                        <bd.Button size="sm" variant="contained" onClick={() => window.location.reload()}>
                            <T>update-app</T>
                        </bd.Button>
                    </bd.Flex>
                </Modal.Body>
            </Modal>
        </TProvider>
    );
}

const Logout = () => {
    const account = useAccount();
    const chats = useChats(false);
    const navigate = useNavigate();

    useEffect(() => {
        account.logout();
        chats.onDispose();
        navigate("/");
    }, []);

    return <></>;
};
