import classNames from "classnames";
import * as bd from "react-basic-design";
import { T } from "../basic/text";
import { ChatFileIcon } from "./chat-file-icon";

export const ChatFilePreview = ({
    hideFileName = false,
    file,
    className,
    width,
    height,
    disableDownload,
}: {
    hideFileName?: boolean;
    file: File;
    className?: string;
    width?: number | string;
    height?: number;
    disableDownload?: boolean;
}) => {
    const handleDownloadFile = () => {
        if (disableDownload) return;

        const url = URL.createObjectURL(file);
        const a = document.createElement("a");
        a.href = url;
        a.download = file.name;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    };

    if (file.type.includes("image")) {
        const url = URL.createObjectURL(file);
        return (
            <>
                <bd.Flex vertical className={className}>
                    <img className={className} src={url} width={width ?? "100%"} height={height} />
                    {!hideFileName && (
                        <div className="w-100 bg-gray-50 p-2">
                            <T append={`: ${file.name}`} className="text-light small">
                                file-name
                            </T>
                        </div>
                    )}
                </bd.Flex>
            </>
        );
    }

    return <AnyFilePreview file={file} className={className} onDownloadRequest={handleDownloadFile} />;
};

const AnyFilePreview = ({
    file,
    hideFileName = false,
    className,
    onDownloadRequest,
}: {
    file: File;
    hideFileName?: boolean;
    className?: string;
    onDownloadRequest: VoidFunction;
}) => {
    return (
        <bd.Flex className={classNames("px-2 text-muted", className)} content="start" align="center" style={{ height: 50 }} gap={2}>
            <bd.Button variant="icon" disableRipple className="text-danger p-1 bg-white cur-pointer" onClick={onDownloadRequest}>
                <ChatFileIcon file={file} height={36} width={36} />
            </bd.Button>
            {!hideFileName && <div>{file.name}</div>}
        </bd.Flex>
    );
};
