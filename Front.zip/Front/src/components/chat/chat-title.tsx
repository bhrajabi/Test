import * as bd from "react-basic-design";
import SvgArrowBackIos from "../../assets/icons/ArrowBackIos";
import { ChatAvatar } from "./chat-avatar";
import { ChatNS } from "./types";
import { T, translate } from "../basic/text";

type ChatTitleProps = {
    service: ChatNS.Service;
};

export const ChatTitle = ({ service }: ChatTitleProps) => {
    const selectedChat = service.getSelectedChat();
    return (
        <div className="flex-grow-1">
            <bd.Flex gap={1} align="center" content="start">
                {!!selectedChat && (
                    <bd.Button
                        variant="icon"
                        size="md"
                        className="rtl-rotate-180 my-n3 m-e-1"
                        onClick={service.clearChatSerial}
                        disableRipple
                        style={{ height: "auto" }}
                        edge="start">
                        <SvgArrowBackIos />
                    </bd.Button>
                )}
                {!selectedChat && <T>messaging</T>}
                {!!selectedChat && (
                    <bd.Flex align="center" gap={2}>
                        <ChatAvatar chat={selectedChat} />
                        <span>{selectedChat.isSavedMessageChat ? translate(selectedChat.title) : selectedChat.title}</span>
                    </bd.Flex>
                )}
            </bd.Flex>
        </div>
    );
};
