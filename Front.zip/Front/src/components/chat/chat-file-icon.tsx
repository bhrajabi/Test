import classNames from "classnames";
import SvgExcel from "../../assets/icons/Excel";
import SvgJSON from "../../assets/icons/JSON";
import SvgPDF from "../../assets/icons/PDF";
import SvgSummarize from "../../assets/icons/Summarize";
import SvgWord from "../../assets/icons/Word";
import SvgZip from "../../assets/icons/Zip";
import SvgDraft from "../../assets/icons/Draft";

export const ChatFileIcon = ({
    file,
    className,
    height,
    width,
}: {
    file: File;
    className?: string;
    height?: number;
    width: number | string;
}) => {
    switch (file.type) {
        case "application/pdf":
            return <SvgPDF className={classNames("text-danger", className)} style={{ width, height }} />;
        case "application/json":
            return <SvgJSON className={classNames("text-muted", className)} style={{ width, height }} />;
        case "application/zip":
        case "application/vnd.rar":
            return <SvgZip className={classNames("text-warning", className)} style={{ width, height }} />;
        case "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet":
        case "application/vnd.ms-excel":
            return <SvgExcel className={classNames("text-success", className)} style={{ width, height }} />;

        case "application/vnd.openxmlformats-officedocument.wordprocessingml.document":
        case "application/msword":
            return <SvgWord className={classNames("text-info", className)} style={{ width, height }} />;

        case "text/plain":
            return <SvgDraft className={classNames("text-muted", className)} style={{ width, height }} />;
        case "image/png":
        case "image/jpeg":
        case "image/jpg":
        case "image/gif":
            return <img className={className} width={width} height={height} src={URL.createObjectURL(file)} />;

        default:
            return <SvgSummarize className={classNames("text-muted", className)} style={{ width, height }} />;
    }
};
