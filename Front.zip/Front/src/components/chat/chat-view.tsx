import { useRef, useState } from "react";
import { TProvider } from "../../i18n";
import { InitFailed } from "../basic/init-failed";
import Clipboard, { ClipboardRow } from "../clipboard/clipboard";
import { ChatContent } from "../event-chats/chat-content";
import { ChatInput } from "./chat-input";
import { ChatSendMessageModal } from "./chat-send-message-modal";
import { ChatSendMultiFileMessageModal } from "./chat-send-multi-file-message-modal";
import { ChatNS } from "./types";
import classNames from "classnames";

type ChatViewProps = {
    service: ChatNS.Service;
    className?: string;
    isReadOnly?: boolean;
};

export const ChatView = ({ service, className, isReadOnly = false }: ChatViewProps) => {
    const [showSendMessageModal, setShowSendMessageModal] = useState<{ row?: ClipboardRow; show: boolean }>({ show: false });
    const [showMultiFileMessageModal, setShowMultiFileMessageModal] = useState<{
        rows: ClipboardRow[];
        show: boolean;
    }>({
        show: false,
        rows: [],
    });
    const minHeight = 600;
    const chat = service.chats.find((x) => x.serial === service.selectedChatSerial);

    const onSendMessage = async (chatSerial: number, message: string) => service.sendMessage(chatSerial, message, (messages) => {});

    const OnPastFile = (row: ClipboardRow) => setShowSendMessageModal({ show: true, row });

    const OnPastFiles = (rows: ClipboardRow[]) => setShowMultiFileMessageModal({ show: true, rows });

    if (service.error) return <InitFailed ex={service.error} onRetry={service.getChats} />;

    return (
        <TProvider>
            <div className={classNames("bg-default d-flex h-100", className)} style={{ minHeight }}>
                <Clipboard.Container className="d-flex flex-column w-100" OnPastFile={OnPastFile} OnPastFiles={OnPastFiles}>
                    <ChatContent className="conversation flex-grow-1 h-100" service={service} />
                    {chat && (
                        <ChatInput
                            visible={isReadOnly ? false : chat ? !chat.isLoadingMessages : false}
                            onSendMessage={(message) => onSendMessage(chat.serial, message)}
                            OnPastFile={OnPastFile}
                        />
                    )}
                    <ChatSendMessageModal
                        show={showSendMessageModal.show}
                        onHide={() => setShowSendMessageModal({ show: false })}
                        targetFile={showSendMessageModal.row?.file}
                        onSendMessage={(file: File, message?: string) =>
                            service.selectedChatSerial && service.uploadAttachment(file, service.selectedChatSerial, message)
                        }
                    />

                    <ChatSendMultiFileMessageModal
                        show={showMultiFileMessageModal.show}
                        rows={showMultiFileMessageModal.rows}
                        onHide={() => setShowMultiFileMessageModal({ show: false, rows: [] })}
                        uploadAttachment={service.uploadFile}
                    />
                </Clipboard.Container>
            </div>
        </TProvider>
    );
};
