import { useEffect, useState } from "react";
import * as bd from "react-basic-design";
import SvgUpload from "../../assets/icons/Upload";
import { BasicModal } from "../basic/basic-modal";
import { T, translate } from "../basic/text";
import ImageTools from "../image-tools";
import { ChatFilePreview } from "./chat-file-preview";

export const ChatSendMessageModal = ({
    targetFile,
    readOnly = false,
    show,
    onHide,
    onSendMessage,
}: {
    targetFile?: File;
    readOnly?: boolean;
    show: boolean;
    onHide: VoidFunction;
    onSendMessage: (file: File, message: string) => void;
}) => {
    const [message, setMessage] = useState<string>("");

    useEffect(() => {
        if (show) return;
        setMessage("");
    }, [show]);

    if (!targetFile) return <></>;

    return (
        <BasicModal
            show={show}
            onHide={onHide}
            title={
                <div className="d-flex align-items-center gap-1">
                    <SvgUpload />
                    <T>confirm-send-file</T>
                </div>
            }>
            <bd.Flex vertical gap={2}>
                <div className="border rounded overflow-hidden" style={{ width: 450, minHeight: 100 }}>
                    <ChatFilePreview file={targetFile} />
                    <div className="border-bottom" />
                    <bd.TextField
                        autoFocus
                        type="textarea"
                        rows={2}
                        className="p-1"
                        inputStyle={{ border: 0, borderRadius: 0 }}
                        readOnly={readOnly}
                        value={message}
                        placeholder={translate("write-your-message")}
                        onChange={(ev) => setMessage(ev.target.value)}
                    />
                </div>
                {!readOnly && (
                    <bd.Flex content="end" gap={2}>
                        <bd.Button
                            variant="contained"
                            onClick={() => {
                                ImageTools.resize(targetFile, { width: 1000, height: 1000 }, function (blob: any) {
                                    const file = new File([blob], targetFile.name, { type: targetFile.type });
                                    onSendMessage(file, message);
                                    onHide();
                                });
                            }}>
                            <T>send</T>
                        </bd.Button>
                        <bd.Button variant="outline" onClick={onHide}>
                            <T>cancel</T>
                        </bd.Button>
                    </bd.Flex>
                )}
            </bd.Flex>
        </BasicModal>
    );
};
