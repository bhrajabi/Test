import classNames from "classnames";
import * as bd from "react-basic-design";
import { N } from "../basic/n";
import { translate } from "../basic/text";
import { DateCell } from "../table/table-cells";
import { ChatAvatar } from "./chat-avatar";
import { TruncateText } from "./truncate-text";
import { ChatNS } from "./types";

export const ChatItemRow = ({
    chat,
    onSelectChat,
}: {
    chat: ChatNS.ChatInfo;

    onSelectChat: (chatSerial: number) => void;
}) => {
    return (
        <bd.ListItem
            key={chat.serial}
            className="cur-pointer"
            icon={<ChatAvatar chat={chat} />}
            primary={<TruncateText className="small" wordCount={3} value={chat.isSavedMessageChat ? translate(chat.title) : chat.title} />}
            secondary={
                <TruncateText
                    className="overflow-hidden opacity-75 small"
                    wordCount={3}
                    value={!chat.isSavedMessageChat && chat.isChatGroup ? chat.subTitle : chat.lastMessage?.message}
                />
            }
            controls={
                <div className="py-3">
                    <div
                        className={classNames({
                            "text-ind4": !!chat.newMessageCount,
                            "opacity-50": !chat.newMessageCount,
                        })}>
                        <DateCell className="small" value={chat.lastMessage?.createdAt} />
                    </div>

                    <div className="text-end">
                        <div
                            className={classNames("text-bg bg-ind4 border-1 mt-1 pt-1 rounded rounded-pill d-inline-block px-2", {
                                invisible: !chat.newMessageCount,
                            })}>
                            <N>{chat.newMessageCount}</N>
                        </div>
                    </div>
                </div>
            }
            onClick={() => onSelectChat(chat.serial)}
        />
    );
};
