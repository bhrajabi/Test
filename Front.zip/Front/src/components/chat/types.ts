import { AxiosProgressEvent } from "axios";

export namespace SpeechRecognitionTypes {
    // Extend the Window interface to include SpeechRecognition and webkitSpeechRecognition
    export interface WindowWithSpeechRecognition extends Window {
        SpeechRecognition: new () => any;
        webkitSpeechRecognition: new () => any;
    }

    // Type for the recognition instance
    export type RecognitionInstance = any;

    // Props for the useSpeechRecognition hook
    export type UseSpeechRecognition = {
        onResult: (result: RecognizedSpeech[]) => void;
        onError: (error: string) => void;
        onEnd: () => void;
    };

    // Options for the listen function
    export type ListenOptions = {
        lang?: string;
        interimResults?: boolean;
        continuous?: boolean;
        maxAlternatives?: number;
        grammars?: any;
    };

    // Event callback utility type
    export type EventCallback<T extends any[] = any[], R = void> = (...args: T) => R;

    export interface RecognizedSpeech {
        isFinal: boolean;
        transcript: string;
    }

    interface SpeechRecognitionAlternative {
        transcript: string;
        confidence: number;
    }

    interface SpeechRecognitionResult {
        isFinal: boolean;
        length: number;
        item(index: number): SpeechRecognitionAlternative;
        [index: number]: SpeechRecognitionAlternative;
    }

    interface SpeechRecognitionResultList {
        length: number;
        item(index: number): SpeechRecognitionResult;
        [index: number]: SpeechRecognitionResult;
    }

    export interface SpeechRecognitionEvent extends Event {
        resultIndex: number;
        results: SpeechRecognitionResultList;
        target: SpeechRecognition;
    }

    interface SpeechRecognition extends EventTarget {
        grammars: any;
        lang: string;
        continuous: boolean;
        interimResults: boolean;
        maxAlternatives: number;
    }
}
export namespace ChatNS {
    export type Service = {
        initialized: boolean;
        isBusy: boolean;
        error?: Error;
        chats: ChatInfo[];
        selectedChatSerial?: number;
        unreadCount: number;
        //
        getSelectedChat: () => ChatInfo | null | undefined;
        inviteNewChatMember: (userName: string) => Promise<any>;
        getChats: VoidFunction;
        selectChat: (chatSerial: number) => void;
        clearChatSerial: VoidFunction;
        setChatSerial: (serial: number) => void;
        sendMessage: (chatSerial: number, message: string, onSuccess: (messages: ChatMessageInfo[]) => void) => void;
        leftFromChat: (chatSerial: number) => void;
        removeChatMessage: (chatSerial: number, messageSerial: number) => void;
        uploadFile: (
            file: File,
            onProgressChanged: (progressEvent: AxiosProgressEvent, file: File) => void,
            onFailed?: (error: string, file: File) => void
        ) => void;
        uploadAttachment: (file: File, chatSerial: number, message?: string) => void;
        downloadChatImage: (chatSerial: number, messageSerial: number) => void;
        isChatOffCanvasVisible?: boolean;
        openChatOffCanvas?: VoidFunction;
        closeChatOffCanvas?: VoidFunction;
        onDispose: VoidFunction;
    };

    export type ChatMessageInfo = {
        serial: number;
        message: string;
        thumbnail?: string;
        replyTo: number;
        forwardedFrom: number;
        attachmentId: number;
        messageTypeId: string;
        isDelivered: boolean;
        isRead: boolean;
        isSystemMessage: boolean;
        senderSerial: number;
        attachmentUrl: string;
        createdAt: Date;
    };

    export type ChatInfo = {
        serial: number;
        title: string;
        key: string;
        subTitle: string;
        linkUrl: string;
        imageUrl: string;
        isChatGroup: boolean;
        isClosed: boolean;
        lastMessage?: ChatMessageInfo;
        lastMessageCreatedAt: any;
        newMessageCount: number;
        currentUserSerial: number;
        isArchived: boolean;
        messages?: ChatMessageInfo[];
        isLoadingMessages: boolean;
        isSavedMessageChat: boolean;
        createdAt: Date;
    };
}
