import { useCallback, useEffect, useRef, useState } from "react";
import { SpeechRecognitionTypes } from "./types";

const useEventCallback = <T extends any[] = any[], R = void>(
    fn: SpeechRecognitionTypes.EventCallback<T, R>,
    dependencies: any[]
): SpeechRecognitionTypes.EventCallback<T, R> => {
    const ref = useRef<SpeechRecognitionTypes.EventCallback<T, R>>(() => {
        throw new Error("Cannot call an event handler while rendering.");
    });

    useEffect(() => {
        ref.current = fn;
    }, [fn, ...dependencies]);

    return useCallback((...args: T) => ref.current(...args), [ref]);
};

export const useSpeechRecognition = (props: SpeechRecognitionTypes.UseSpeechRecognition) => {
    const { onEnd, onResult, onError } = props;
    const recognition = useRef<SpeechRecognitionTypes.RecognitionInstance | null>(null);
    const [listening, setListening] = useState(false);
    const [supported, setSupported] = useState(false);
    const [error, setError] = useState<string>();

    const processResult = (event: SpeechRecognitionTypes.SpeechRecognitionEvent) => {
        setError(undefined);
        onResult(
            Array.from(event.results)
                .map((result) => ({ isFinal: result.isFinal, transcript: result[0].transcript }))
                .map((result) => result)
        );
    };

    const handleError = (event: any) => {
        //console.log(event.error);
        if (!recognition.current) return;
        if (event.error === "not-allowed") {
            recognition.current.onend = () => {};
            setListening(false);
        }
        if (event.error != error) onError(event.error);
        setError(event.error);
    };
    const restart = (args: SpeechRecognitionTypes.ListenOptions) => {
        setError("");
        if (listening) stop();
        listen(args);
    };
    const listen = useEventCallback(
        (args: SpeechRecognitionTypes.ListenOptions) => {
            if (listening || !supported || !recognition.current) return;

            const { lang = "", interimResults = true, continuous = false, maxAlternatives = 1, grammars } = args;
            setListening(true);

            recognition.current.lang = lang;
            recognition.current.interimResults = interimResults;
            recognition.current.continuous = continuous;
            recognition.current.maxAlternatives = maxAlternatives;
            if (grammars) {
                recognition.current.grammars = grammars;
            }
            recognition.current.start();
        },
        [listening, supported]
    );

    const stop = useEventCallback(() => {
        if (!listening || !supported || !recognition.current) return;
        recognition.current.stop();
        setListening(false);

        onEnd();
    }, [listening, supported, onEnd]);

    useEffect(() => {
        if (typeof window === "undefined") return;
        const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
        if (SpeechRecognition) {
            setSupported(true);
            recognition.current = new SpeechRecognition();
        }

        return () => {
            if (recognition.current) {
                recognition.current.stop();
                recognition.current.onresult = null;
                recognition.current.onerror = null;
                recognition.current.onend = null;
            }
        };
    }, []);

    useEffect(() => {
        if (recognition.current) {
            recognition.current.onresult = processResult;
            recognition.current.onerror = handleError;
            recognition.current.onend = () => {
                if (listening) {
                    recognition.current?.start();
                }
            };
        }
    }, [onResult, listening]);

    return {
        listen,
        stop,
        restart,
        listening,
        supported,
        error,
    };
};
