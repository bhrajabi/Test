import { useEffect, useState } from "react";
import * as bd from "react-basic-design";
import SvgChat from "../../assets/chat";
import { notify } from "../basic/notify";
import { useChatHelper } from "./use-chat-helper";
import { useChats } from "./use-chats";

export const ChatButton = ({ userName }: { userName: string }) => {
    const [isLoading, setIsLoading] = useState(false);
    const [autoOpenChatSerial, setAutoOpenChatSerial] = useState(0);

    const service = useChats(false);
    const chatHelper = useChatHelper();

    useEffect(() => {
        if (autoOpenChatSerial < 1 || service.isBusy) return;
        service.selectChat(autoOpenChatSerial);
        setAutoOpenChatSerial(0);
    }, [service, autoOpenChatSerial]);

    const handleStartChat = (userName: string) => {
        setIsLoading(true);
        chatHelper
            .initPeerToPeerChat(userName)
            .then((result: any) => {
                service.getChats();
                service.openChatOffCanvas && service.openChatOffCanvas();
                setAutoOpenChatSerial(result.chatSerial);
            })
            .catch(notify.error)
            .finally(() => setIsLoading(false));
    };

    return (
        <bd.Button variant="icon" className="chat-button" size="sm" onClick={() => handleStartChat(userName)}>
            {isLoading && <div className="spinner-border spinner-border-sm"></div>}
            {!isLoading && <SvgChat />}
        </bd.Button>
    );
};
