import * as bd from "react-basic-design";
import classNames from "classnames";
import SvgUser from "../../assets/user";
import { code } from "../basic/code";
import { apiConfig } from "../../api/config";
import SvgBookmark from "../../assets/icons/Bookmark";
import { ChatNS } from "./types";

export const ChatAvatar = ({ chat }: { chat: ChatNS.ChatInfo }) => {
    const isLoading = chat.isLoadingMessages;
    const isSavedMessage = chat.isSavedMessageChat;
    const width = 46;
    const height = 46;

    return (
        <bd.Flex
            align="center"
            content="center"
            style={{ width, height }}
            className={classNames("position-relative rounded-circle ", {
                "bg-gray-10 text-info": !isSavedMessage,
                "bg-primary text-white": isSavedMessage,
            })}>
            {isLoading && (
                <span className="position-absolute spinner-border spinner-border-sm" style={{ width: width + 1, height: height + 1 }} />
            )}
            <ChatImage chat={chat} />
        </bd.Flex>
    );
};

const ChatImage = ({ chat }: { chat: ChatNS.ChatInfo }) => {
    if (chat.isSavedMessageChat) return <SvgBookmark style={{ fontSize: 32, color: "#fff" }} />;
    if (!chat.imageUrl) return <SvgUser style={{ fontSize: 30 }} className="text-muted" />;
    return (
        <img
            loading="lazy"
            style={{ maxWidth: "100%" }}
            className="rounded-circle"
            src={code.calcImageUrl(apiConfig.baseUrl, chat.imageUrl)}
        />
    );
};
