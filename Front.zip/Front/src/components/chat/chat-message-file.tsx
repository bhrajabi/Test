import React, { useState } from "react";
import * as bd from "react-basic-design";
import { Modal } from "react-bootstrap";
import { Link } from "react-router-dom";
import { apiConfig } from "../../api/config";
import { enums } from "../../app/constatnts";
import SvgDraft from "../../assets/icons/Draft";
import SvgFolderOpen from "../../assets/icons/FolderOpen";
import SvgJSON from "../../assets/icons/JSON";
import SvgPDF from "../../assets/icons/PDF";
import SvgSummarize from "../../assets/icons/Summarize";
import { T } from "../basic/text";
import { ChatNS } from "./types";
import SvgDownload from "../../assets/icons/Download";
import SvgEye from "../../assets/icons/Eye";
import SvgZip from "../../assets/icons/Zip";
import SvgExcel from "../../assets/icons/Excel";
import SvgWord from "../../assets/icons/Word";

type SelectedImageModalProps = {
    url: string;
    show: boolean;
    onClose: VoidFunction;
};

const SelectedImageModal: React.FC<SelectedImageModalProps> = ({ url, show, onClose }) => {
    if (!url) return null;
    return (
        <Modal show={show} size="lg" onHide={onClose}>
            <Modal.Body style={{ padding: 3 }}>
                <img style={{ width: "100%", maxHeight: 2048 }} src={url} />
            </Modal.Body>
        </Modal>
    );
};

export const ChatMessageFile = ({
    message,
    chatSerial,
    downloadFile,
}: {
    message: ChatNS.ChatMessageInfo;
    chatSerial: number;
    downloadFile: (chatSerial: number, messageSerial: number) => void;
}) => {
    const IMG_WIDTH = 100;
    const IMG_HEIGHT = 100;

    const ICON_HEIGHT = 36;
    const ICON_WIDTH = 36;

    const [selectedImageUrl, setSelectedImageUrl] = useState<string | null>(null);

    const downloadImage = (messageSerial: number) => {
        chatSerial && downloadFile(chatSerial, messageSerial);
        setSelectedImageUrl(`${apiConfig.ChatImageDownloadUrl}?messageSerial=${messageSerial}`);
    };

    const viewImage = (messageSerial: number) => {
        setSelectedImageUrl(`${apiConfig.ChatImageDownloadUrl}?messageSerial=${messageSerial}`);
    };

    const IS_IMG = enums.messageTypes.isIMG(message.messageTypeId);
    const is_downloaded = !!message.attachmentUrl;

    if (IS_IMG)
        return (
            <>
                <bd.Flex
                    align="center"
                    content="center"
                    className="download-button-container position-relative"
                    style={{ width: IMG_WIDTH }}>
                    <img
                        className="rounded"
                        width={IMG_WIDTH}
                        src={message.thumbnail || message.attachmentUrl}
                        style={{ minHeight: IMG_HEIGHT }}
                    />
                    {!is_downloaded && message.thumbnail && (
                        <bd.Button
                            onClick={() => downloadImage(message.serial)}
                            disableRipple
                            size="sm"
                            variant="icon"
                            className="d-none download-button position-absolute border shadow bg-gray-50 opacity-75"
                            active>
                            <SvgDownload className="text-light" />
                        </bd.Button>
                    )}
                    {is_downloaded && (
                        <bd.Button
                            onClick={() => viewImage(message.serial)}
                            disableRipple
                            size="sm"
                            variant="icon"
                            className="d-none download-button position-absolute border shadow bg-gray-50 opacity-75"
                            active>
                            <SvgEye className="text-light" />
                        </bd.Button>
                    )}
                </bd.Flex>
                <SelectedImageModal
                    url={selectedImageUrl ?? ""}
                    show={Boolean(selectedImageUrl)}
                    onClose={() => setSelectedImageUrl(null)}
                />
            </>
        );

    return (
        <bd.Flex className="text-muted" content="start" align="center" gap={2}>
            <Icon typeId={message.messageTypeId} width={ICON_WIDTH} height={ICON_HEIGHT} />
            <bd.Flex vertical gap={1}>
                <Link to={`${apiConfig.ChatImageDownloadUrl}?messageSerial=${message.serial}`} target="_blank" className="text-link">
                    <T>download</T>
                </Link>
            </bd.Flex>
        </bd.Flex>
    );
};

const Icon = ({ typeId, width, height }: { typeId: string; width: number; height: number }) => {
    const IS_JSON = enums.messageTypes.isJSON(typeId);
    const IS_PDF = enums.messageTypes.isPDF(typeId);
    const IS_ZIP = enums.messageTypes.isZIP(typeId);
    const IS_TXT = enums.messageTypes.isTXT(typeId);
    const IS_XLSX = enums.messageTypes.isXLSX(typeId);
    const IS_WORD = enums.messageTypes.isWORD(typeId);

    if (IS_JSON) return <SvgJSON style={{ width, height }} />;
    if (IS_PDF) return <SvgPDF className="text-danger" style={{ width, height }} />;
    if (IS_TXT) return <SvgDraft className="text-muted" style={{ width, height }} />;
    if (IS_ZIP) return <SvgZip className="text-warning" style={{ width, height }} />;
    if (IS_XLSX) return <SvgExcel className="text-success" style={{ width, height }} />;
    if (IS_WORD) return <SvgWord className="text-info" style={{ width, height }} />;
    return <SvgSummarize style={{ width, height }} />;
};
