import { useEffect } from "react";
import * as bd from "react-basic-design";
import { Offcanvas } from "react-bootstrap";
import { useLocation } from "react-router-dom";
import settings from "../../app/settings";
import SvgSms from "../../assets/icons/Sms";
import { ChatBody } from "./chat-body";
import { ChatHeader } from "./chat-header";
import { ChatTitle } from "./chat-title";
import { useChats } from "./use-chats";

export function ChatOffcanvas() {
    const chatSidebarPlacement = bd.helper.isRTL() ? "start" : "end";
    const service = useChats(true);
    const location = useLocation();
    useEffect(() => {
        if (service.selectedChatSerial) service.clearChatSerial();
    }, [location]);

    const updateInterval = () => {
        let intervalId: NodeJS.Timeout;

        let shouldSetInterval = true;

        const handleVisibilityChange = () => {
            if (document.visibilityState === "visible") {
                if (shouldSetInterval) {
                    intervalId = setInterval(() => service.getChats(), settings.getChatRefreshDuration());
                    shouldSetInterval = false;
                }
            } else {
                clearInterval(intervalId);
                shouldSetInterval = true;
            }
        };

        handleVisibilityChange();
        document.addEventListener("visibilitychange", handleVisibilityChange);

        return () => {
            document.removeEventListener("visibilitychange", handleVisibilityChange);
            clearInterval(intervalId);
        };
    };

    useEffect(() => updateInterval(), []);

    const onOpen = () => service.openChatOffCanvas && service.openChatOffCanvas();
    const onHide = () => service.closeChatOffCanvas && service.closeChatOffCanvas();

    return (
        <>
            <bd.Button variant="fab" position="bottom-end" disableRipple onClick={onOpen}>
                <bd.Badge className="unread-messages-indicator text-blink" overlapCircle position="top-end" value={service.unreadCount}>
                    <bd.Flex align="center" content="center" className="rounded-circle" style={{ width: 60, height: 60 }}>
                        <SvgSms style={{ fontSize: "2rem" }} />
                    </bd.Flex>
                </bd.Badge>
            </bd.Button>
            <Offcanvas
                show={service.isChatOffCanvasVisible}
                onHide={onHide}
                className="chat-offcanvas shadow-10 bg-default"
                placement={chatSidebarPlacement}>
                <Offcanvas.Header className="mb-0 bg-secondary border-bottom shadow-sm">
                    <Offcanvas.Title className="flex-grow-1">
                        <ChatTitle service={service} />
                    </Offcanvas.Title>
                    <ChatHeader service={service} />
                </Offcanvas.Header>

                <Offcanvas.Body className="p-0 d-flex flex-column">
                    <ChatBody service={service} />
                </Offcanvas.Body>
            </Offcanvas>
        </>
    );
}
