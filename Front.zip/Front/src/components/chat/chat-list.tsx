import * as bd from "react-basic-design";
import { ChatItemRow } from "./chat-item-row";
import { useChats } from "./use-chats";

export const ChatList = () => {
    const service = useChats(false);

    const savedChats = () => service.chats.filter((x) => x.isSavedMessageChat);
    const notSavedChats = () => service.chats.filter((x) => !x.isSavedMessageChat);

    return (
        <bd.List compact small variant="menu" className="p-0">
            {[...savedChats(), ...notSavedChats()]
                .filter((chat) => !chat.isArchived)
                .map((chat) => (
                    <ChatItemRow chat={chat} onSelectChat={service.selectChat} />
                ))}
        </bd.List>
    );
};
