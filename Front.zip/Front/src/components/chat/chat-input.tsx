import classNames from "classnames";
import { useRef, useState } from "react";
import * as bd from "react-basic-design";
import SvgMic from "../../assets/icons/Mic";
import SvgMicAlert from "../../assets/icons/MicAlert";
import SvgMicOff from "../../assets/icons/MicOff";
import SvgMoreVert from "../../assets/icons/MoreVert";
import SvgSend from "../../assets/icons/Send";
import { T, translate } from "../../components/basic/text";
import { useSpeechRecognition } from "../../components/chat/use-speech-recognition";
import { code } from "../basic/code";
import { notify } from "../basic/notify";
import { ClipboardRow } from "../clipboard/clipboard";
import { useClipboard } from "../clipboard/use-clipboard";
import { ChatInputAutoGrowTextArea } from "./chat-input-auto-grow-text-area";
import { SpeechRecognitionTypes } from "./types";

type ChatInputProps = {
    onSendMessage: (message: string) => void;
    OnPastFile: (row: ClipboardRow) => void;
    visible: boolean;
};

export const ChatInput = ({ onSendMessage, OnPastFile, visible }: ChatInputProps) => {
    const [message, setMessage] = useState("");
    const [liveSpeechText, setLiveSpeech] = useState<string | undefined>(undefined);

    const upl = useRef<HTMLInputElement>(null);
    const clipboard = useClipboard();

    const maxTextMessageSize = 1024 * 7; //ex: 1024 byte * 100 unit == 100 Kb
    const messageSize = code.calcStringSize(message);
    const isOverMaxSize = messageSize > maxTextMessageSize;

    const handleSpeechRecognitionError = (error: string) => {
        switch (error) {
            case "no-speech": {
                notify.info(translate("no-speech-detected"));
                break;
            }
            case "not-allowed": {
                notify.error(translate("mic-use-not-allowed"));
                break;
            }
            case "network": {
                notify.error(translate("network-error-trying-to-connect"));
                break;
            }
            default:
                notify.error(error);
                break;
        }
        safeStop();
    };

    const handleSpeechRecognitionResult = (results: SpeechRecognitionTypes.RecognizedSpeech[]) => {
        const finalTranscript = results.find((x) => x.isFinal);
        if (finalTranscript && finalTranscript.transcript) {
            setMessage(`${message} ${finalTranscript.transcript}`);
            setLiveSpeech("");
        } else {
            let text = "";
            results
                .filter((x) => !x.isFinal)
                .forEach((result) => {
                    text = `${text} ${result.transcript}`;
                });
            setLiveSpeech(text);
        }
    };

    const {
        listen,
        restart,
        stop,
        listening,
        supported,
        error: speechRecognitionError,
    } = useSpeechRecognition({
        onError: handleSpeechRecognitionError,
        onResult: handleSpeechRecognitionResult,
        onEnd: () => {},
    });

    const safeStop = () => listening && stop();

    if (!visible) return <></>;

    const handleSendMessage = () => {
        if (!message.trim()) {
            setMessage("");
            return;
        }

        if (isOverMaxSize)
            OnPastFile({
                kind: "file",
                type: "text/plain",
                supported: true,
                text: "",
                file: new File([new Blob([message], { type: "text/plain" })], "message.txt", {
                    type: "text/plain",
                    lastModified: Date.now(),
                }),
            });
        else onSendMessage(message.trim());
        setMessage("");
        safeStop();
    };

    const handleKeyDown = (event: KeyboardEvent) => {
        if (!message.trim()) return;

        if (event.key == "Enter") {
            if (event.shiftKey) {
                setMessage(`${message.trim()} \n`);
            } else handleSendMessage();
            event.preventDefault();
            event.stopPropagation();
        }
    };

    const networkError = speechRecognitionError == "network";

    const getMicIcon = () => {
        if (speechRecognitionError) return <SvgMicAlert />;
        if (listening) return <SvgMic />;
        //if (noSpeech || notAllowed || !listening)
        return <SvgMicOff />;
    };

    const handlePaste = () => {
        clipboard.read(
            (file) => OnPastFile({ kind: "file", file, supported: true, type: file.type }),
            (text) => text && setMessage((msg) => `${msg} ${text}`),
            notify.error
        );
    };

    const handleOnSpeech = () => {
        const args = { lang: "fa-IR", interimResults: true, continuous: false };
        if (speechRecognitionError) restart(args);
        else listen(args);
    };

    return (
        <bd.Flex align="start" className="w-100 mb-2 px-1" gap={1}>
            <ChatInputAutoGrowTextArea
                value={liveSpeechText ? message + " " + liveSpeechText : message}
                onChange={setMessage}
                placeholder={translate("write-your-message")}
                OnPastFile={OnPastFile}
                onKeyDown={handleKeyDown}
            />

            {!!message && (
                <bd.Button variant="icon" size="md" onClick={handleSendMessage}>
                    <SvgSend className="rtl-rotate-180" />
                </bd.Button>
            )}

            {!message && supported && (
                <bd.Button
                    title={networkError && "network error"}
                    //disabled={networkError}
                    variant="icon"
                    size="md"
                    color={!speechRecognitionError && listening ? "secondary" : "primary"}
                    className={classNames(`mic-btn`, {
                        "listening bg-danger": listening,
                        "text-muted": speechRecognitionError,
                    })}
                    onClick={handleOnSpeech}>
                    {getMicIcon()}
                </bd.Button>
            )}

            {/* <bd.Button type="button" variant="icon" size="md" onClick={() => upl.current?.click()}>
                <SvgAttachFile className="rtl-rotate-180" />
            </bd.Button> */}

            {!message && (
                <bd.Button
                    type="button"
                    size="md"
                    className="p-0"
                    variant="icon"
                    menu={
                        <bd.Menu>
                            <bd.MenuItem onClick={handlePaste}>
                                <T>paste-from-clipboard</T>
                            </bd.MenuItem>
                            <bd.MenuItem onClick={() => upl.current?.click()}>
                                <T>attach-image</T>
                            </bd.MenuItem>
                        </bd.Menu>
                    }>
                    <SvgMoreVert />
                </bd.Button>
            )}
            {/* <ChatInput
                lastMessage={message}
                show={showRecordModal}
                onHide={() => setShowRecordModal(false)}
                onSubmit={(text) => {
                    if (text.length > 50) setInputRows(3);
                    setMessage(text);
                    setShowRecordModal(false);
                }}
            /> */}
            <input
                ref={upl}
                type="file"
                style={{ display: "none" }}
                onChange={(e) => {
                    if (!e.target.files || !e.target.files.length) return;
                    const file = e.target.files[0];
                    OnPastFile({ kind: "file", file, supported: true, type: file.type });
                }}
            />
        </bd.Flex>
    );
};
