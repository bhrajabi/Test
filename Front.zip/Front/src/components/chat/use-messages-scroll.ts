import { useCallback, useEffect, useRef, useState } from "react";
import { ChatNS } from "./types";

export default function useMessagesScroll(chat: ChatNS.ChatInfo | null | undefined) {
    const [currentChatInfo, setCurrentChatInfo] = useState<ChatNS.ChatInfo | null | undefined>(chat);
    const messagesListRef = useRef<HTMLDivElement>(null);

    const scrollMessagesToBottom = useCallback(() => {
        if (!messagesListRef.current) return;
        messagesListRef.current.scrollTop = messagesListRef.current.scrollHeight;
    }, [chat]);

    useEffect(() => {
        if (!chat) setCurrentChatInfo(undefined);
    }, [chat]);

    useEffect(() => {
        if (!messagesListRef.current) return;
        if (!chat || !chat.messages || !chat.messages.length) return;

        if (currentChatInfo && currentChatInfo.messages?.length === chat.messages.length) return;
        setCurrentChatInfo(chat);
        scrollMessagesToBottom();
    }, [currentChatInfo, chat]);

    return {
        messagesListRef,
    };
}
