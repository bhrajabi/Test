import { OverlayTrigger, Tooltip } from "react-bootstrap";

export const TruncateText = ({ value, className, wordCount = 3 }: { value?: string; className?: string; wordCount?: number }) => {
    if (!value) return <></>;

    const items = value.split(" ");

    const isOver = items.length > wordCount;
    const toolTip = <Tooltip>{value}</Tooltip>;

    if (!isOver) return <span className={className}>{value}</span>;

    return (
        <OverlayTrigger delay={5} flip overlay={toolTip}>
            <span className={className}>{`${items.slice(0, wordCount).join(" ")} ...`}</span>
        </OverlayTrigger>
    );
};
