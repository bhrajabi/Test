import { useEffect, useState } from "react";
import * as bd from "react-basic-design";
import SvgClose from "../../assets/icons/Close";
import SvgPeople from "../../assets/icons/People";
import SvgSearch from "../../assets/icons/Search";
import { Loading } from "../basic/loading";
import { T, translate } from "../basic/text";
import { ChatItemRow } from "./chat-item-row";
import { ChatNS } from "./types";

export const Chats = ({
    service,
    chatTitle,
    participants_max_height,
}: {
    service: ChatNS.Service;
    chatTitle: string;
    participants_max_height: number;
}) => {
    const toolbarHeight = 60;
    const [showSearchbar, setShowSearchBar] = useState(false);
    const [query, setQuery] = useState<string>();

    const _chats = service.chats.filter((chat) => !chat.isArchived);

    const [filteredChats, setFilteredChats] = useState<ChatNS.ChatInfo[]>(_chats);

    useEffect(() => {
        setFilteredChats(service.chats.filter((chat) => !chat.isArchived));
    }, [service.chats]);

    const handleCancelQuery = () => {
        setQuery(undefined);
        setShowSearchBar(false);
        setFilteredChats(_chats);
    };

    const handleOnKeyDown = (key: KeyboardEvent) => {
        switch (key.code.toLocaleLowerCase()) {
            case "numpadenter":
            case "enter":
                handleQuery(query);
                break;
            case "escape":
                handleCancelQuery();
                break;
        }
    };

    const handleQuery = (query: string | undefined) => {
        setQuery(query);

        if (!query) {
            setFilteredChats(_chats);
            return;
        }

        query
            ? setFilteredChats(
                  _chats.filter((cu) =>
                      (cu.title + " " + +" " + cu.subTitle + (cu.lastMessage ? cu.lastMessage.message : ""))
                          .toLowerCase()
                          .includes(query.toLowerCase())
                  )
              )
            : setFilteredChats(_chats);
    };

    if (!service.initialized) return <Loading />;

    return (
        <bd.List
            compact
            small
            variant="menu"
            className="p-0"
            header={
                <div
                    className="border-bottom text-primary d-flex align-items-center justify-content-between w-100 gap-3 p-2"
                    style={{ height: toolbarHeight }}>
                    <div>
                        <SvgPeople style={{ fontSize: 24 }} />
                        <T as="b" className="m-s-2">
                            {chatTitle}
                        </T>
                    </div>
                    {!showSearchbar && (
                        <bd.Button size="sm" onClick={() => setShowSearchBar(true)}>
                            <SvgSearch />
                        </bd.Button>
                    )}
                    {!!showSearchbar && (
                        <bd.TextField
                            className="flex-grow-1"
                            value={query}
                            onChange={(e) => handleQuery(e.target.value)}
                            onKeyDown={handleOnKeyDown}
                            buttonIcon={<SvgClose className="text-danger" />}
                            buttonOnClick={handleCancelQuery}
                            placeholder={`${translate("search")} ...`}
                        />
                    )}
                </div>
            }>
            <div
                style={{
                    overflowY: "auto",
                    overflowX: "hidden",
                    maxHeight: participants_max_height - toolbarHeight - 10,
                    height: participants_max_height - toolbarHeight,
                }}>
                {filteredChats
                    .filter((chat) => !chat.isArchived)
                    .sort((a, b) => new Date(b.lastMessageCreatedAt).getTime() - new Date(a.lastMessageCreatedAt).getTime())
                    .map((chat) => (
                        <ChatItemRow chat={chat} onSelectChat={service.selectChat} />
                    ))}
            </div>
        </bd.List>
    );
};
