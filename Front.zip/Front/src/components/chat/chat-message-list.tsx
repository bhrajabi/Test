import classNames from "classnames";
import * as bd from "react-basic-design";
import { Link } from "react-router-dom";
import { enums } from "../../app/constatnts";
import SvgContentCopy from "../../assets/icons/ContentCopy";
import SvgDelete from "../../assets/icons/Delete";
import SvgDoneAll from "../../assets/icons/DoneAll";
import SvgMoreVert from "../../assets/icons/MoreVert";
import { notify } from "../basic/notify";
import { T, translate } from "../basic/text";
import { DateCell, TimeCell } from "../table/table-cells";
import { ChatMessageFile } from "./chat-message-file";
import { ChatMessageText } from "./chat-message-text";
import { ChatNS } from "./types";
import { useClipboard } from "../clipboard/use-clipboard";

export const ChatMessageList = ({
    chat,
    downloadFile,
    removeChatMessage,
}: {
    chat: ChatNS.ChatInfo;
    downloadFile: (chatSerial: number, messageSerial: number) => void;
    removeChatMessage: (chatSerial: number, messageSerial: number) => void;
}) => {
    const { write: writeClipboard } = useClipboard();

    const confirmDeleteChatMessage = (messageSerial: number) => {
        bd.msgbox(
            <T>delete-chat</T>,
            <T>are-you-sure-to-delete-chat-message</T>,
            (hide: any) => (
                <bd.Flex content="end" gap={2}>
                    <bd.Button
                        variant="contained"
                        className="min-w-80"
                        onClick={() => {
                            removeChatMessage(chat.serial, messageSerial);
                            hide();
                        }}>
                        {translate("yes")}
                    </bd.Button>
                    <bd.Button
                        variant="outline"
                        className="m-e-2 min-w-80"
                        onClick={() => {
                            hide();
                        }}>
                        {translate("no")}
                    </bd.Button>
                </bd.Flex>
            ),
            { backdropClassName: "modal-n", className: "modal-n" }
        );
    };

    const parseJSONMessage = (message: ChatNS.ChatMessageInfo) => {
        try {
            var jsonString = message.message;
            var jsonObject = JSON.parse(jsonString);
            if (jsonObject.messageType == "PROFILE_CHAT")
                return (
                    <div className="my-3 w-100 p-2 text-muted small">
                        <div className="d-flex align-items-center gap-1 justify-content-center mb-2">
                            <T username={jsonObject.fromUser}>conversation-started-by-@username</T>
                            <span>
                                (
                                {
                                    <Link
                                        className="text-link"
                                        target="_blank"
                                        to={`/company/public-profile?id=${jsonObject.fromCompanyUniqueId}`}>
                                        {jsonObject.fromCompanyName}
                                    </Link>
                                }
                                )
                            </span>
                        </div>
                        <div className="d-flex align-items-center gap-1 justify-content-center">
                            <T username={jsonObject.toUser}>with-@username</T>
                            <span>
                                (
                                {
                                    <Link
                                        className="text-link"
                                        target="_blank"
                                        to={`/company/public-profile?id=${jsonObject.toCompanyUniqueId}`}>
                                        {jsonObject.toCompanyName}
                                    </Link>
                                }
                                )
                            </span>
                        </div>
                    </div>
                );
        } catch (error) {
            return <></>;
        }
        return <span>{message.message}</span>;
    };

    const renderSystemMessage = (message: ChatNS.ChatMessageInfo) => {
        switch (message.messageTypeId) {
            case "JSON":
                return parseJSONMessage(message);

            default: {
                const texts = message.message.split(`@`);
                if (!texts.length) return "";

                return (
                    <div className="my-3 text-center w-100">
                        <span className="p-1 px-2 bg-shade-10 small border rounded-5">
                            {texts
                                .map((text, i) => (i == 0 ? translate(texts[0]) : text))
                                .join(" ")
                                .toString()}
                        </span>
                    </div>
                );
            }
        }
    };

    const showDate = (index: number) => {
        if (!chat.messages) return false;
        if (index == 0) return true;

        var current_message = chat.messages[index];
        var last_message = chat.messages[index - 1];

        if (!current_message || !last_message) return false;
        if (!current_message.createdAt || !last_message.createdAt) return false;

        const diff = new Date(current_message.createdAt).getTime() - new Date(last_message.createdAt).getTime();
        const dayDiff = Math.floor(diff / (1000 * 60 * 60 * 24));
        return dayDiff > 0;
    };

    return (
        <div className="d-flex flex-column align-items-start">
            {chat.messages?.map((x, Xindex) => {
                const is_received = x.senderSerial !== chat.currentUserSerial;
                const isText = enums.messageTypes.isTEXT(x.messageTypeId);
                if (x.isSystemMessage)
                    return (
                        <>
                            <div className="text-center text-muted w-100 " style={{ position: "sticky", top: 5, zIndex: 1 }}>
                                <span className="py-1 px-4 border rounded-5 bg-gray-4 small">
                                    <DateCell value={x.createdAt} />
                                </span>
                            </div>
                            <div className="text-center text-muted w-100 my-1">{renderSystemMessage(x)}</div>
                        </>
                    );

                return (
                    <>
                        {showDate(Xindex) && (
                            <div className="text-center text-muted w-100 " style={{ position: "sticky", top: 5, zIndex: 1 }}>
                                <span className="py-1 px-4 border rounded-5 bg-gray-4 small">
                                    <DateCell value={x.createdAt} />
                                </span>
                            </div>
                        )}

                        <div key={x.serial} className={classNames("message", { sent: !is_received, received: is_received })}>
                            <bd.Flex content="start" align="start" gap={1} className="ps-5">
                                {(isText || !is_received) && (
                                    <bd.Button
                                        size="sm"
                                        variant="icon"
                                        className="p-0 m-e-1"
                                        menu={
                                            <bd.Menu>
                                                {!is_received && (
                                                    <bd.MenuItem className="px-2" onClick={() => confirmDeleteChatMessage(x.serial)}>
                                                        <bd.Flex content="between" align="center" className="w-100 px-1">
                                                            <T>delete</T>
                                                            <SvgDelete className="text-muted" style={{ fontSize: 20 }} />
                                                        </bd.Flex>
                                                    </bd.MenuItem>
                                                )}
                                                {isText && (
                                                    <bd.MenuItem
                                                        className="px-2"
                                                        onClick={() => {
                                                            writeClipboard(x.message);
                                                            notify.dark(translate("message-copied"));
                                                        }}>
                                                        <bd.Flex content="between" align="center" className="w-100 px-1">
                                                            <T>copy</T>
                                                            <SvgContentCopy className="text-muted small" style={{ fontSize: 20 }} />
                                                        </bd.Flex>
                                                    </bd.MenuItem>
                                                )}
                                            </bd.Menu>
                                        }>
                                        <SvgMoreVert className="text-muted small" />
                                    </bd.Button>
                                )}

                                <bd.Flex vertical gap={1} className="w-100">
                                    {!enums.messageTypes.isTEXT(x.messageTypeId) && (
                                        <ChatMessageFile message={x} chatSerial={chat.serial} downloadFile={downloadFile} />
                                    )}
                                    <ChatMessageText className="pre-wrap" message={x.message} />

                                    {is_received && <TimeCell className="text-muted small " value={x.createdAt.toString()} />}
                                </bd.Flex>
                            </bd.Flex>
                            {!is_received && (
                                <div className="d-flex alig-items-center gap-2">
                                    <SvgDoneAll
                                        className={classNames("small size-sm pt-1", {
                                            "text-read": x.isRead,
                                            "text-unread": !x.isRead,
                                        })}
                                    />
                                    <TimeCell className="text-muted small" value={x.createdAt.toString()} />
                                </div>
                            )}
                        </div>
                    </>
                );
            })}
        </div>
    );
};
