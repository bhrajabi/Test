import { AxiosProgressEvent } from "axios";
import classNames from "classnames";
import { useEffect, useMemo, useState } from "react";
import * as bd from "react-basic-design";
import { ProgressBar } from "react-bootstrap";
import SvgCheck from "../../assets/icons/Check";
import SvgClose from "../../assets/icons/Close";
import SvgUpload from "../../assets/icons/Upload";
import { BasicModal } from "../basic/basic-modal";
import { LoadingButton } from "../basic/loading-button";
import { N } from "../basic/n";
import { notify } from "../basic/notify";
import { T, translate } from "../basic/text";
import { ChatFileIcon } from "./chat-file-icon";
import { ClipboardRow } from "../clipboard/clipboard";

export const ChatSendMultiFileMessageModal = ({
    rows,
    readOnly = false,
    show,
    uploadAttachment,
    onHide,
}: {
    rows: ClipboardRow[];
    readOnly?: boolean;
    show: boolean;
    uploadAttachment: (
        file: File,
        onProgressChanged: (progressEvent: AxiosProgressEvent, file: File) => void,
        onFailed: (error: string, file: File) => void
    ) => void;
    onHide: VoidFunction;
}) => {
    const [items, setItems] = useState<{ file: File; supported: boolean; progress: number; status: string; error?: string }[]>([]);
    const [isUploading, setIsUploading] = useState(false);

    useEffect(() => {
        if (!show) setItems([]);
        if (!!items.length) return;

        const new_list = rows
            .filter((item) => item.file != undefined)
            .map(
                (item) =>
                    ({
                        ...item,
                        progress: 0,
                        status: "pending",
                    } as any)
            );

        setItems(new_list);
    }, [rows]);

    const columns: any[] = useMemo<any[]>(
        () => [
            {
                title: translate("file"),
                accessor: "file",
                Cell: ({ row }: any) => {
                    if (row.status == "uploading")
                        return (
                            <div className="my-1 rounded" style={{ position: "relative", width: 36, height: 36, overflow: "hidden" }}>
                                <bd.Flex
                                    style={{ position: "absolute", top: 0, left: 0 }}
                                    className="w-100 h-100 small px-1 "
                                    align="center"
                                    content="center">
                                    <ProgressBar
                                        max={row.file.size}
                                        style={{ height: 3 }}
                                        min={0}
                                        now={(row.file.size * row.progress) / 100}
                                        className="w-100 mb-1"
                                    />
                                </bd.Flex>
                                <ChatFileIcon file={row.file} width={36} height={36} className="opacity-50" />
                            </div>
                        );
                    return <ChatFileIcon className="my-1 rounded" file={row.file} width={36} height={36} />;
                },
                width: 50,
            },
            {
                title: translate("name"),
                accessor: "name",
                Cell: ({ row }: any) => (
                    <bd.Flex align="center" gap={2}>
                        <span>{row.file.name}</span>
                        {row.error && (
                            <span className="text-danger small">
                                ( <TruncateText value={row.error} /> )
                            </span>
                        )}
                        {!row.supported && (
                            <span className="text-danger small">
                                (<T>not-supported</T>)
                            </span>
                        )}
                    </bd.Flex>
                ),
            },
            {
                title: translate("type"),
                Cell: ({ row }: any) => <MimeType file={row.file} />,
                width: 120,
            },
            {
                title: translate("size"),
                Cell: ({ row }: any) => (
                    <div>
                        <N className="ms-1 text-muted">{Number((row.file.size / 1000).toFixed(2))}</N>
                        <small style={{ opacity: 0.5 }}>
                            (<T>kb</T>)
                        </small>
                    </div>
                ),
            },
        ],
        []
    );

    useEffect(() => {
        if (isUploading) return;

        const notUploadedFiles = items.filter((item) => item.status != "uploaded").length;
        if (notUploadedFiles > 0) notify.error(translate("@count-item-not-uploaded", { count: notUploadedFiles }));
        else onHide();
    }, [isUploading]);

    const maxProgress = items.length * 100;
    const uploadedProgress = items.reduce((sum, file) => sum + file.progress, 0);

    const uploadFiles = async (index: number): Promise<boolean> => {
        const item = items[index];
        if (!item) {
            setIsUploading(false);
            return true;
        }

        if (!item.supported || item.status == "uploaded") return uploadFiles(index + 1);

        uploadAttachment(
            item.file,
            (progressEvent, f) => {
                const progress = Math.round((progressEvent.loaded / (progressEvent.total ?? 1)) * 100);
                setItems((oldItems) =>
                    oldItems.map((i) =>
                        i.file.name == f.name ? { ...i, status: progress == 100 ? "uploaded" : "uploading", progress } : i
                    )
                );

                if (progress == 100) {
                    return uploadFiles(index + 1);
                }
            },
            (error: string, f) => {
                setItems((oldItems) =>
                    oldItems.map((i) => (i.file.name == f.name ? { ...i, status: "failed", progress: 0, error: translate(error) } : i))
                );
            }
        );

        return false;
    };

    if (!show || !rows.length) return <></>;
    return (
        <BasicModal
            size="lg"
            show={show}
            closeButton
            onHide={onHide}
            title={
                <div className="d-flex align-items-center gap-1">
                    <SvgUpload />
                    <T>confirm-send-files</T>
                </div>
            }>
            <>
                <bd.Flex vertical gap={2}>
                    <bd.BasicTable
                        columns={columns}
                        data={items}
                        className="mx-n3"
                        cellCSS={({ row }: any) => {
                            if (!row.supported) return "alert-danger opacity-50";
                            if (row.status == "uploaded") return "alert-success";
                            if (row.status == "uploading") return "alert-warning";
                            if (row.status == "failed") return "alert-danger";
                            return "";
                        }}>
                        <T as="div" className="nothing-found">
                            nothing-found
                        </T>
                    </bd.BasicTable>
                </bd.Flex>
                {!readOnly && (
                    <>
                        <bd.Flex className="mt-3" content="end">
                            <LoadingButton
                                className="min-w-80 ms-2"
                                variant="contained"
                                loading={isUploading}
                                isValid={!!items.filter((x) => x.supported && x.status != "uploaded").length}
                                onClick={() => {
                                    setIsUploading(true);
                                    uploadFiles(0);
                                }}
                                label={<T>send</T>}
                            />
                            <bd.Button variant="outline" onClick={onHide}>
                                <T>cancel</T>
                            </bd.Button>
                        </bd.Flex>
                    </>
                )}
            </>
        </BasicModal>
    );
};

const MimeType = ({ file }: { file: File }) => {
    const extention = file.name.split(".");
    const type = file.type || (extention ? extention[extention.length - 1] : "unknown");

    const translateMimeType = (type: string) => {
        switch (type) {
            case "application/pdf":
                return "Pdf";
            case "application/json":
                return "Json";
            case "application/zip":
            case "application/vnd.rar":
            case "rar":
                return "Compressed";
            case "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet":
            case "application/vnd.ms-excel":
                return "Microsoft Excel";

            case "application/vnd.openxmlformats-officedocument.wordprocessingml.document":
            case "application/msword":
                return "Microsoft World";

            case "text/plain":
                return "Text";

            case "image/png":
            case "image/jpeg":
            case "image/jpg":
            case "image/gif":
                return "Image";
        }
        return type;
    };

    return <div className="text-muted text-right small">{translateMimeType(type)}</div>;
};

const TruncateText = ({ value }: { value: string }) => {
    if (!value) return <></>;
    const wordCount = 8;
    const items = value.split(" ");
    return <span>{items.length > wordCount ? `${items.slice(0, wordCount).join(" ")} ...` : value}</span>;
};
