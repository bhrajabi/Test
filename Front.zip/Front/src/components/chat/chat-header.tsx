import * as bd from "react-basic-design";
import { T, translate } from "../basic/text";
import { ChatNS } from "./types";
import SvgExternalLink from "../../assets/icons/ExternalLink";
import SvgDelete from "../../assets/icons/Delete";
import SvgMoreVert from "../../assets/icons/MoreVert";

type ChatHeaderProps = {
    service: ChatNS.Service;
};

export const ChatHeader = ({ service }: ChatHeaderProps) => {
    const selectedChat = service.getSelectedChat();
    const onHide = () => service.closeChatOffCanvas && service.closeChatOffCanvas();
    const confirmDeleteChat = () => {
        bd.msgbox(
            <T>delete-chat</T>,
            <T>are-you-sure-to-delete-chat</T>,
            (hide: any) => (
                <bd.Flex content="end" gap={2}>
                    <bd.Button
                        variant="contained"
                        className="min-w-80"
                        onClick={() => {
                            selectedChat && service.leftFromChat(selectedChat.serial);
                            hide();
                        }}>
                        {translate("yes")}
                    </bd.Button>
                    <bd.Button
                        variant="outline"
                        className="m-e-2 min-w-80"
                        onClick={() => {
                            hide();
                        }}>
                        {translate("no")}
                    </bd.Button>
                </bd.Flex>
            ),
            { backdropClassName: "modal-n", className: "modal-n" }
        );
    };
    return (
        <>
            {!selectedChat && <button type="button" className="btn-close" aria-label="Close" onClick={onHide}></button>}
            {!!selectedChat && (
                <div>
                    {selectedChat.linkUrl && (
                        <bd.Button
                            href={selectedChat.linkUrl}
                            variant="icon"
                            className="my-n3"
                            size="md"
                            style={{ height: "auto" }}
                            edge="end">
                            <SvgExternalLink />
                        </bd.Button>
                    )}
                    <bd.Button
                        variant="icon"
                        size="md"
                        edge="end"
                        disableRipple
                        menu={
                            <bd.Menu className="">
                                <bd.MenuItem className="px-2" onClick={confirmDeleteChat}>
                                    <bd.Flex content="between" align="center" className="w-100 p-s-2" gap={2}>
                                        <T>delete-chat</T>
                                        <SvgDelete className="text-muted " style={{ fontSize: 20 }} />
                                    </bd.Flex>
                                </bd.MenuItem>
                            </bd.Menu>
                        }>
                        <SvgMoreVert />
                    </bd.Button>
                </div>
            )}
        </>
    );
};
