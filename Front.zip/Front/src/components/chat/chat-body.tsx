import { InitFailed } from "../basic/init-failed";
import { Loading } from "../basic/loading";
import { ChatDetail } from "./chat-detail";
import { ChatList } from "./chat-list";
import { ChatNS } from "./types";

type ChatProps = {
    service: ChatNS.Service;
};

export const ChatBody = ({ service }: ChatProps) => {
    const selectedChat = service.getSelectedChat();
    if (service.error) return <InitFailed ex={service.error} hideGoBack onRetry={service.getChats} />;
    if (!service.initialized) return <Loading />;

    if (!selectedChat) return <ChatList />;
    return <ChatDetail />;
};
