import { FormikProps } from "formik";
import { useRef, useState } from "react";
import { T } from "../basic/text";
import Clipboard, { ClipboardRow } from "../clipboard/clipboard";
import { ChatInput } from "./chat-input";
import { ChatMessageList } from "./chat-message-list";
import { ChatSendMessageModal } from "./chat-send-message-modal";
import { ChatSendMultiFileMessageModal } from "./chat-send-multi-file-message-modal";
import { useChats } from "./use-chats";
import useMessagesScroll from "./use-messages-scroll";

export const ChatDetail = () => {
    const [showSendMessageModal, setShowSendMessageModal] = useState<{ file?: File; show: boolean }>({ show: false });
    const [showMultiFileMessageModal, setShowMultiFileMessageModal] = useState<{ rows: ClipboardRow[]; show: boolean }>({
        show: false,
        rows: [],
    });

    const chats = useChats(false);
    const chat = chats.getSelectedChat();

    const formikRef = useRef<FormikProps<any>>(null);
    const { messagesListRef } = useMessagesScroll(chat);

    const isValidMessage = (message?: string) => {
        if (message == null || message == undefined) return false;
        if (!message.trim().length) return false;
        return true;
    };

    const onSendMessage = async (message: string) => {
        if (!isValidMessage(message)) {
            formikRef.current?.setFieldValue("inputRows", 1);
            formikRef.current?.setFieldValue("message", "");
            return;
        }
        var chatSerial = chat?.serial;
        if (chatSerial)
            chats.sendMessage(chatSerial, message.trim(), () => {
                formikRef.current?.setFieldValue("inputRows", 1);
            });
    };

    if (!chat) return <></>;

    if (chat.isLoadingMessages)
        return (
            <div className="my-3 text-center w-100">
                <T append=" ...">loading</T>
            </div>
        );

    const OnPastFile = (row: ClipboardRow) => {
        if (row.kind != "file") return;
        setShowSendMessageModal({ show: true, file: row.file });
    };

    const OnPastFiles = (rows: ClipboardRow[]) => setShowMultiFileMessageModal({ show: true, rows });

    const OnPastText = (row: ClipboardRow) => {
        if (!row.text) return;
        formikRef.current?.setFieldValue("message", formikRef.current?.values["message"] + row.text);
    };

    return (
        <Clipboard.Container
            OnPastFile={OnPastFile}
            OnPastFiles={OnPastFiles}
            OnPasteText={OnPastText}
            className="d-flex flex-column align-items-start h-100">
            <div className="conversation flex-grow-1 w-100" ref={messagesListRef}>
                <ChatMessageList chat={chat} downloadFile={chats.downloadChatImage} removeChatMessage={chats.removeChatMessage} />
            </div>
            {!chat.isClosed && <ChatInput OnPastFile={OnPastFile} onSendMessage={onSendMessage} visible />}
            <ChatSendMessageModal
                show={showSendMessageModal.show}
                onHide={() => setShowSendMessageModal({ show: false })}
                targetFile={showSendMessageModal.file}
                onSendMessage={(file: File, message?: string) =>
                    chats.selectedChatSerial && chats.uploadAttachment(file, chats.selectedChatSerial, message)
                }
            />

            <ChatSendMultiFileMessageModal
                show={showMultiFileMessageModal.show}
                rows={showMultiFileMessageModal.rows}
                onHide={() => setShowMultiFileMessageModal({ show: false, rows: [] })}
                uploadAttachment={chats.uploadFile}
            />
        </Clipboard.Container>
    );
};
