import { useState } from "react";
import { T } from "../basic/text";
import { TruncateText } from "./truncate-text";

type ChatMessageText = {
    message?: string;
    className?: string;
};

export const ChatMessageText = ({ message, className }: ChatMessageText) => {
    const message_words_count = (message || "")?.split(" ").length;
    const [maxWord, setMaxWord] = useState<number>(20);

    return (
        <>
            <TruncateText className={className} value={message} wordCount={maxWord} />
            {message_words_count >= maxWord && (
                <T as="div" className="text-link" onClick={() => setMaxWord(maxWord * 2)}>
                    read-more
                </T>
            )}
        </>
    );
};
