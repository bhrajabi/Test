import { useRef, useState } from "react";
import { TProvider } from "../../i18n";
import { AdminSelectedChat } from "../../pages/admin-chats/admin-selected-chat";
import { InitFailed } from "../basic/init-failed";
import Clipboard, { ClipboardRow } from "../clipboard/clipboard";
import { ChatContent } from "../event-chats/chat-content";
import { ChatInput } from "./chat-input";
import { ChatSendMessageModal } from "./chat-send-message-modal";
import { ChatSendMultiFileMessageModal } from "./chat-send-multi-file-message-modal";
import { Chats } from "./chats";
import { ChatNS } from "./types";
import classNames from "classnames";

type ChatContainerProps = {
    service: ChatNS.Service;
    controls?: any;
    className?: any;
};

export const ChatContainer = ({ service, className, controls }: ChatContainerProps) => {
    const chatContainerRef = useRef<HTMLDivElement>(null);
    const [showSendMessageModal, setShowSendMessageModal] = useState<{ row?: ClipboardRow; show: boolean }>({ show: false });
    const [showMultiFileMessageModal, setShowMultiFileMessageModal] = useState<{
        rows: ClipboardRow[];
        show: boolean;
    }>({
        show: false,
        rows: [],
    });
    const minHeight = 600;
    const chat = service.chats.find((x) => x.serial === service.selectedChatSerial);

    const onSendMessage = async (chatSerial: number, message: string) => service.sendMessage(chatSerial, message, (messages) => {});

    const OnPastFile = (row: ClipboardRow) => setShowSendMessageModal({ show: true, row });

    const OnPastFiles = (rows: ClipboardRow[]) => setShowMultiFileMessageModal({ show: true, rows });

    if (service.error) return <InitFailed ex={service.error} onRetry={service.getChats} />;

    return (
        <TProvider>
            <div className={classNames("container-fluid h-100", className)} ref={chatContainerRef}>
                <div className="row h-100 p-0 pb-2" style={{ minHeight }}>
                    <div className="col-3 d-flex flex-column p-s-0 p-e-2" style={{ minHeight }}>
                        <div className="d-flex flex-column h-100 bg-default shadow-sm">
                            <Chats
                                service={service}
                                chatTitle="suppliers"
                                participants_max_height={chatContainerRef.current ? chatContainerRef.current.scrollHeight : 0}
                            />
                        </div>
                    </div>
                    <div className="col-9 bg-default d-flex shadow-sm h-100" style={{ minHeight }}>
                        <Clipboard.Container className="d-flex flex-column w-100" OnPastFile={OnPastFile} OnPastFiles={OnPastFiles}>
                            <AdminSelectedChat chat={chat} leftFromChat={service.leftFromChat} controls={controls} />
                            <ChatContent className="conversation flex-grow-1 h-100" service={service} />
                            {chat && (
                                <ChatInput
                                    visible={chat ? !chat.isLoadingMessages : false}
                                    onSendMessage={(message) => onSendMessage(chat.serial, message)}
                                    OnPastFile={OnPastFile}
                                />
                            )}
                            <ChatSendMessageModal
                                show={showSendMessageModal.show}
                                onHide={() => setShowSendMessageModal({ show: false })}
                                targetFile={showSendMessageModal.row?.file}
                                onSendMessage={(file: File, message?: string) =>
                                    service.selectedChatSerial && service.uploadAttachment(file, service.selectedChatSerial, message)
                                }
                            />

                            <ChatSendMultiFileMessageModal
                                show={showMultiFileMessageModal.show}
                                rows={showMultiFileMessageModal.rows}
                                onHide={() => setShowMultiFileMessageModal({ show: false, rows: [] })}
                                uploadAttachment={service.uploadFile}
                            />
                        </Clipboard.Container>
                    </div>
                </div>
            </div>
        </TProvider>
    );
};
