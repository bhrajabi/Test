import { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { chatApi } from "../../api/chat-api";
import { chatActions } from "../../app/stores/chat-slice";
import { RootState } from "../../app/stores/store";
import { notify } from "../basic/notify";
import { attachmentApi } from "../../api/attachment-api";
import { apiConfig } from "../../api/config";
import { AxiosProgressEvent } from "axios";
import { code } from "../basic/code";
import { ChatNS } from "./types";
import { translate } from "../basic/text";

export const useChats = (isPrimary: boolean): ChatNS.Service => {
    const chatState = useSelector((state: RootState) => state.chat);
    const dispatch = useDispatch();

    useEffect(() => {
        if (!chatState.isChatFormVisible || chatState.initialized || chatState.isBusy) return;
        getChats();
    }, [chatState.isChatFormVisible]);

    useEffect(() => {
        const should_load_unread_count = isPrimary && chatState.unreadCount == 0;
        if (!should_load_unread_count) return;
        getChats();
    }, [isPrimary]);

    const getChats = () => {
        dispatch(chatActions.setIsBusy(true));
        chatApi
            .initMyChats()
            .then(({ chats }: { chats: ChatNS.ChatInfo[] }) => {
                var unReadCount = 0;
                chats.forEach((chat) => (unReadCount += chat.newMessageCount));
                if (chatState.selectedChatSerial) {
                    dispatch(chatActions.setSelectedChatSerial(chatState.selectedChatSerial));
                }
                dispatch(chatActions.setUnreadCount(unReadCount));
                dispatch(chatActions.init(chats));
            })
            .catch((err) => dispatch(chatActions.setError(err)))
            .finally(() => dispatch(chatActions.setIsBusy(false)));
    };

    const getChat = (serial?: number) => {
        if (!serial) return null;
        return chatState.chats.find((x) => x.serial == serial);
    };

    const selectChat = (chatSerial?: number, justForAdmin: boolean = false) => {
        if (chatState.selectedChatSerial == chatSerial) return;

        if (chatState.isBusy) {
            notify.info("system is busy");
            return;
        }

        //remove chat
        if (!chatSerial) {
            dispatch(chatActions.setSelectedChatSerial(chatSerial));
            return;
        }

        const chat = getChat(chatSerial);
        if (!chat) return;

        // if (!!chat.messages) {
        //     dispatch(chatActions.setSelectedChatSerial(chatSerial));
        //     return;
        // }

        dispatch(chatActions.setIsBusy(true));

        dispatch(chatActions.setIsLoadingMessages({ chatSerial, isLoadingMessages: true }));

        chatApi
            .initMyChatMessages(chat.serial)
            .then((result: { messages: ChatNS.ChatMessageInfo[] }) =>
                dispatch(chatActions.initChatMessages({ chatSerial, messages: result.messages, justForAdmin }))
            )
            .catch(notify.error)
            .finally(() => {
                dispatch(chatActions.setIsBusy(false));
                dispatch(chatActions.setIsLoadingMessages({ chatSerial, isLoadingMessages: false }));
            });
    };

    const sendMessage = (chatSerial: number, message: string) => {
        const dto = { chatSerial, message: code.utf8ToBase64(message), justForAdmin: chatState.justForAdmin };
        chatApi
            .sendMessage(dto)
            .then((result: { message: ChatNS.ChatMessageInfo }) =>
                dispatch(chatActions.addNewMessage({ chatSerial, message: result.message }))
            )
            .catch(notify.error);
    };

    const downloadChatImage = (chatSerial: number, messageSerial: number) => {
        dispatch(chatActions.downloadFile({ chatSerial, messageSerial }));
    };

    const leftFromChat = (chatSerial: number) => {
        chatApi
            .leftFromChat(chatSerial)
            .then((result: any) => dispatch(chatActions.removeChat({ chatSerial })))
            .catch(notify.error);
    };

    const removeChatMessage = (chatSerial: number, messageSerial: number) => {
        chatApi
            .removeChatMessage(chatSerial, messageSerial)
            .then(() => dispatch(chatActions.removeChatMessage({ messageSerial, chatSerial })))
            .catch(notify.error);
    };

    const uploadFile = (
        file: File,
        onProgressChanged: (progressEvent: AxiosProgressEvent, file: File) => void,
        onFailed?: (error: string, file: File) => void
    ) => {
        const chatSerial = chatState.selectedChatSerial;
        if (!chatSerial) return;

        dispatch(chatActions.setIsBusy(true));
        attachmentApi
            .attach(
                apiConfig.chatUrl + `/upload-attachment?chatSerial=${chatSerial}`,
                null,
                { message: "" },
                file,
                (progressEvent: AxiosProgressEvent) => onProgressChanged(progressEvent, file)
            )
            .then((result) => dispatch(chatActions.addNewMessage({ chatSerial, message: result.message })))
            .catch((err: any) => {
                if (onFailed) onFailed(err.message || err, file);
                else notify.error(err);
            })
            .finally(() => dispatch(chatActions.setIsBusy(false)));
    };

    const uploadAttachment = (file: File, chatSerial: number, message?: string) => {
        dispatch(chatActions.setIsBusy(true));
        attachmentApi
            .attach(apiConfig.chatUrl + `/upload-attachment?chatSerial=${chatSerial}`, null, { message }, file)
            .then((result) => dispatch(chatActions.addNewMessage({ chatSerial, message: result.message })))
            .catch(notify.error)
            .finally(() => dispatch(chatActions.setIsBusy(false)));
    };

    return {
        initialized: chatState.initialized,
        isBusy: chatState.isBusy,
        error: chatState.error,
        chats: chatState.chats,
        selectedChatSerial: chatState.selectedChatSerial,
        unreadCount: chatState.unreadCount,

        getSelectedChat: () => getChat(chatState.selectedChatSerial),

        getChats,
        selectChat,

        isChatOffCanvasVisible: chatState.isChatFormVisible,
        openChatOffCanvas: () => dispatch(chatActions.setChatFormVisible(true)),
        closeChatOffCanvas: () => dispatch(chatActions.setChatFormVisible(false)),
        clearChatSerial: () => dispatch(chatActions.setSelectedChatSerial(undefined)),
        onDispose: () => dispatch(chatActions.onDispose()),
        inviteNewChatMember: (userName: string): Promise<any> => {
            if (!chatState.selectedChatSerial) return Promise.reject(translate("no-chat-has-been-selected"));
            dispatch(chatActions.setIsBusy(true));
            return chatApi
                .inviteNewChatMember({
                    chatSerial: chatState.selectedChatSerial,
                    userName,
                })
                .finally(() => dispatch(chatActions.setIsBusy(false)));
        },
        setChatSerial: (serial: number) => {
            dispatch(chatActions.setSelectedChatSerial(serial));
            return chatState.selectedChatSerial;
        },
        sendMessage,
        leftFromChat,
        removeChatMessage,
        uploadAttachment,
        uploadFile,
        downloadChatImage,
    };
};
