import { messagingApi } from "../../api/messaging-api";
import { useAccount } from "../../app/account-context";

export const useChatHelper = () => {
    const initAdminMessage = messagingApi.initAdminMessage;
    const account = useAccount();

    const initProfileChat = (userUniqueId: string, companyUniqueId: string) =>
        new Promise((resolve, reject) => {
            var dto = { userUniqueId, companyUniqueId };
            messagingApi.initProfileChat(dto).then(resolve).catch(reject);
        });

    const initPeerToPeerChat = (userName: string) =>
        account.userName == userName ? messagingApi.createSavedMessage() : messagingApi.initPeerToPeerChat({ userName });

    const createSavedMessage = messagingApi.createSavedMessage.bind(this);

    const createEventChat = (documentSerial: number) => messagingApi.createEventChat(documentSerial);

    return {
        initAdminMessage,
        initProfileChat,
        initPeerToPeerChat,
        createEventChat,
        createSavedMessage,
    };
};
