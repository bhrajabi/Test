import classNames from "classnames";
import { useRef } from "react";
import * as bd from "react-basic-design";
import SvgAttachFile from "../../assets/icons/AttachFile";
import SvgDoneAll from "../../assets/icons/DoneAll";
import SvgSend from "../../assets/icons/Send";
import { T, translate } from "../basic/text";
import { DateTimeCell } from "../table/table-cells";

export const ChatMessages = ({ messages, buildMessage, disabled, onSendTextMessage, onSendFileMessage, onDownloadAttachment, loading }) => {
    const refText = useRef();
    const refFile = useRef();

    const onSendTextClickHandler = () => {
        onSendTextMessage(refText.current.value);
        refText.current.value = "";
    };

    const onChangeFileHandler = (e) => {
        onSendFileMessage(e);
    };

    const onDownloadAttachmentHandler = (m) => {
        onDownloadAttachment && onDownloadAttachment(m);
    };

    let maxHeight = (window.innerHeight * 3) / 4;
    if (isNaN(maxHeight)) maxHeight = 500;

    return (
        <>
            {!messages?.length && <T className="nothing-found">nothing-found</T>}

            {!!messages?.length && (
                <div className="conversation flex-grow-1" style={{ maxHeight }} id="conversation-div">
                    <bd.Flex content="end" align="start" reverse vertical>
                        {messages?.map((msg, msgIndex) => {
                            const m = buildMessage(msg, msgIndex);
                            return (
                                <div key={m.serial} className={classNames("message", { sent: m.is_received, received: !m.is_received })}>
                                    {!!m.message && <div>{m.message}</div>}

                                    {!!m.attachmentId && (
                                        <bd.Chip
                                            label={<T>download-attached-file</T>}
                                            className="alert-info border border-primary mx-3"
                                            onClick={() => onDownloadAttachmentHandler(m)}
                                        />
                                    )}

                                    {m.is_received && (
                                        <div className={classNames("size-sm pt-1", { "text-read": m.read, "text-unread": !m.read })}>
                                            <SvgDoneAll />
                                        </div>
                                    )}

                                    <div className={classNames("size-sm pt-1", { "text-read": m.read, "text-unread": !m.read })}>
                                        <div>
                                            <DateTimeCell value={m.createdAt} />
                                        </div>
                                    </div>
                                </div>
                            );
                        })}
                    </bd.Flex>
                </div>
            )}

            {!disabled && (
                <div className="p-2 py0-3 border-top shadow-lg">
                    <bd.Flex align="center" gap={2}>
                        <input type="file" ref={refFile} className="d-none" onChange={onChangeFileHandler} />
                        <bd.TextField
                            className="flex-grow-1"
                            placeholder={translate("write-your-message")}
                            inputRef={refText}
                            disabled={loading}
                            onKeyDown={(ev) => {
                                if (ev.keyCode == 13) onSendTextClickHandler && onSendTextClickHandler();
                            }}
                        />

                        <bd.Button variant="icon" size="md" className="h-auto" onClick={onSendTextClickHandler} disabled={loading}>
                            <SvgSend className="rtl-rotate-180" />
                        </bd.Button>

                        <bd.Button variant="icon" size="md" className="h-auto" onClick={() => refFile.current.click()} disabled={loading}>
                            <SvgAttachFile />
                        </bd.Button>
                    </bd.Flex>
                </div>
            )}
        </>
    );
};
