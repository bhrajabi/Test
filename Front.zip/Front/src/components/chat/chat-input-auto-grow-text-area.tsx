import { useCallback, useEffect, useRef, useState } from "react";
import * as bd from "react-basic-design";
import { useScreenSize } from "../../app/theme-context";
import { ClipboardRow } from "../clipboard/clipboard";

type AutoGrowTextAreaProps = {
    value: string;
    onKeyDown: (ev: any) => void;
    OnPastFile: (row: ClipboardRow) => void;
    onChange: (text: string) => void;
    placeholder: string;
};

export const ChatInputAutoGrowTextArea = ({ value, placeholder, onKeyDown, onChange, OnPastFile }: AutoGrowTextAreaProps) => {
    const inputRef = useRef<HTMLTextAreaElement | null>(null);
    const screen = useScreenSize();
    const [inputRows, setInputRows] = useState(1);

    function calcRows(dom: HTMLTextAreaElement) {
        const measureDom = getOrCreateMeasureDom("__measure");
        const singleLineDom = getOrCreateMeasureDom("__single_measure", (dom) => {
            dom.innerText = "TEXT_FOR_MEASURE";
        });

        const width = getDomContentWidth(dom);
        measureDom.style.width = width + "px";
        measureDom.innerText = dom.value !== "" ? dom.value : "1";
        measureDom.style.fontSize = dom.style.fontSize;
        measureDom.style.fontFamily = dom.style.fontFamily;
        const endWithEmptyLine = dom.value.endsWith("\n");
        const height = parseFloat(window.getComputedStyle(measureDom).height);
        const singleLineHeight = parseFloat(window.getComputedStyle(singleLineDom).height);

        const rows = Math.round(height / singleLineHeight) + (endWithEmptyLine ? 1 : 0);

        return rows;
    }

    function getOrCreateMeasureDom(id: string, init?: (dom: HTMLElement) => void) {
        let dom = document.getElementById(id);

        if (!dom) {
            dom = document.createElement("span");
            dom.style.position = "absolute";
            dom.style.wordBreak = "break-word";
            dom.style.fontSize = "14px";
            dom.style.transform = "translateY(-100vh)";
            dom.style.pointerEvents = "none";
            dom.style.opacity = "0";
            dom.id = id;
            document.body.appendChild(dom);
            init?.(dom);
        }

        return dom!;
    }

    function getDomContentWidth(dom: HTMLElement) {
        const style = window.getComputedStyle(dom);
        const paddingWidth = parseFloat(style.paddingLeft) + parseFloat(style.paddingRight);
        const width = dom.clientWidth - paddingWidth;
        return width;
    }

    const measure = useCallback(() => {
        const rows = inputRef.current ? calcRows(inputRef.current) : 1;
        const basedOnUiRows = Math.max(1 + Number(!screen.isMobile), rows);
        const inputRows = Math.min(8, basedOnUiRows);
        setInputRows(inputRows);
    }, [value]);

    useEffect(measure, [value]);

    return (
        <bd.TextField
            inputRef={inputRef}
            width="100%"
            type="textarea"
            rows={inputRows}
            name="message"
            inputClassName="chat-input"
            value={value}
            onKeyDown={onKeyDown}
            placeholder={placeholder}
            onPaste={OnPastFile}
            onChange={(e) => onChange(e.target.value)}
        />
    );
};
