import { useState } from "react";
import * as bd from "react-basic-design";

import { enums } from "../../app/constatnts";
import SvgAdd from "../../assets/icons/Add";
import SvgArrowBack from "../../assets/icons/ArrowBack";
import SvgArrowDownward from "../../assets/icons/ArrowDownward";
import SvgArrowForward from "../../assets/icons/ArrowForward";
import SvgArrowUpward from "../../assets/icons/ArrowUpward";
import SvgContentCopy from "../../assets/icons/ContentCopy";
import SvgDelete from "../../assets/icons/Delete";
import SvgEdit from "../../assets/icons/Edit";
import SvgMoreVert from "../../assets/icons/MoreVert";
import { TProvider } from "../../i18n";
import { code } from "../basic/code";
import { InitFailed } from "../basic/init-failed";
import { Loading } from "../basic/loading";
import { N } from "../basic/n";
import { notify } from "../basic/notify";
import { T } from "../basic/text";
import { BaseContents } from "./base-contents";
import { ConditionContentModal } from "./modals/condition-content-modal";
import { ItemContentModal } from "./modals/item-content-modal";
import { QuestionContentModal } from "./modals/question-content-modal";
import { RequirementContentModal } from "./modals/requirement-content-modal";
import { SectionContentModal } from "./modals/section-content-modal";
import { SrcLibContentModal } from "./modals/src-lib-content-modal";
import { useContentEditor } from "./use-content-editor";
import { commodityApi } from "../../api/commodity-api";
import { useSelector } from "react-redux";

export const ContentsEditor = ({
    documentSerial,
    customColumns,
    titleMinWidth = 500,
    isRowVisible,
    rowHeaderTitles,
    rowFooterTitles,
    multiSelect,
    actionBarControls,
    hideActionButtons,
    className,
    style,
    display,
    toolbarControls,
    maxHeight = "500px",
    footerControls,
    onSelectionChanged,
    title = "",
}) => {
    const eventData = useSelector((state) => state.eventData);
    const [selectedSerials, setSelectedSerials] = useState([]);
    const [modalState, setModalState] = useState({ render: false, show: false, content: null });
    const onShowModalState = (content) => setModalState({ render: true, show: true, content });
    const onHideModalState = () => setModalState({ ...modalState, show: false });
    const editorService = useContentEditor({ documentSerial });

    const selectedContent =
        selectedSerials?.length > 0 ? editorService.model?.contents?.find((c) => c.serial === selectedSerials[0]) : null;

    const model = editorService.model;
    const isItemLine = selectedContent?.contentTypeId === "LINE";
    const ScoreTextField = ({ row }) => {
        const [value, setValue] = useState(row.scoreImportance ? row.scoreImportance : 0);

        if (!row.scoreImportance) {
            let content = model.contents.filter((x) => x.serial == row.serial)[0];
            if (content) content.scoreImportance = 0;
        }

        return (
            <bd.TextField
                variant="outline"
                type="select"
                className="py-0 min-w-80 input-warning"
                height={"2em"}
                inputStyle={{ width: "4.5rem" }}
                items={[0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]}
                value={value}
                onChange={(e) => {
                    setValue(e.target.value);
                    let content = model.contents.filter((x) => x.serial == row.serial)[0];
                    if (content) content.scoreImportance = e.target.value;
                    onSaveContentScoreHandler(content);
                }}
            />
        );
    };

    if (!!editorService.error) return <InitFailed ex={editorService.error} onRetry={() => editorService.setError(null)} hideGoBack />;
    if (!model) return <Loading />;

    const isContentDisplayMode = display == "contents";
    let columns = customColumns;

    switch (display) {
        case "contents":
            columns = [
                {
                    title: <T>initial-price</T>,
                    minWidth: 150,
                    width: 150,
                    Cell: ({ row }) => <N>{row.content.initialPrice}</N>,
                },

                {
                    title: <T>quantity</T>,
                    minWidth: 100,
                    Cell: ({ row }) => <N>{row.content.quantity}</N>,
                },
            ];
            break;

        case "scores":
            columns = [
                {
                    title: <T>importance</T>,
                    minWidth: 100,
                    Cell: ({ row }) => {
                        return (
                            <div className="p-s-2 d-flex">
                                {row.level > 0 && <span className="d-inline-block" style={{ width: row.level * 30 }}></span>}
                                <ScoreTextField row={row.content} />
                            </div>
                        );
                    },
                },
                {
                    title: <T>score</T>,
                    minWidth: 100,
                    Cell: ({ row }) => {
                        const indentionSize = 25;
                        if (row.content.scoreOveral == 0) return "";
                        let x = row.content.scoreOveral * 100;
                        if (x % 1 != 0) x = x.toFixed(1);
                        x = code.localNumbers(code.numberWithCommas(x)) + " %";
                        return (
                            <div className="p-s-2">
                                {row.level > 0 && <span className="d-inline-block" style={{ width: row.level * indentionSize }}></span>}
                                {x}
                            </div>
                        );
                    },
                },
            ];
            break;
    }

    const onMoveHorizontalHandler = (delta) => editorService.onMoveHorizontal(selectedContent.serial, delta);
    const onMoveVerticalHandler = (delta) => editorService.onMoveVertical(selectedContent.serial, delta);
    const onCloneHandler = () => editorService.onCloneContent(selectedContent.serial);
    const onDeleteHandler = () => {
        var hasChild = model.contents.filter((c) => c.parentSerial === selectedContent.serial);
        if (hasChild.length > 0) notify.dark(<T>it-is-not-possible-to-delete</T>);
        else {
            bd.msgbox(<T>deleting-selected-content</T>, null, [
                {
                    title: <T>delete</T>,
                    action: (hide) => {
                        editorService.onDeleteContent(selectedContent.serial, hide);
                    },
                },
                {
                    title: <T>cancel</T>,
                },
            ]);
        }
    };

    const onSaveContentScoreHandler = (content) => editorService.onSaveContentScore(content);

    const onSaveContentHandler = (values) => {
        const insertMode = !values.serial;
        if (insertMode) editorService.onAddContent(values, onHideModalState);
        else editorService.onUpdateContent(values, onHideModalState);
    };

    const EditorToolbar = () => {
        return (
            <>
                <bd.ButtonGroup variant="outline">
                    <bd.Button onClick={() => onMoveHorizontalHandler(-1)} disabled={isItemLine}>
                        <SvgArrowBack className="rtl-rotate-180" />
                    </bd.Button>
                    <bd.Button onClick={() => onMoveHorizontalHandler(1)} disabled={isItemLine}>
                        <SvgArrowForward className="rtl-rotate-180" />
                    </bd.Button>
                    <bd.Button onClick={() => onMoveVerticalHandler(-1)} disabled={isItemLine}>
                        <SvgArrowUpward />
                    </bd.Button>
                    <bd.Button onClick={() => onMoveVerticalHandler(1)} disabled={isItemLine}>
                        <SvgArrowDownward />
                    </bd.Button>
                </bd.ButtonGroup>

                <bd.Button variant="outline" disabled={isItemLine} onClick={() => onShowModalState(selectedContent)}>
                    <T>edit</T>
                    <SvgEdit />
                </bd.Button>

                <bd.Button
                    className="m-e-2"
                    variant="icon"
                    size="sm"
                    disabled={isItemLine}
                    menu={
                        <bd.Menu>
                            <bd.MenuItem onClick={onDeleteHandler}>
                                <SvgDelete className="size-sm m-e-2" />
                                <T>delete</T>
                            </bd.MenuItem>

                            {selectedContent && selectedContent.contentTypeId !== "ITEM" && (
                                <bd.MenuItem onClick={onCloneHandler}>
                                    <SvgContentCopy className="size-sm m-e-2" />
                                    <T>clone</T>
                                </bd.MenuItem>
                            )}
                        </bd.Menu>
                    }
                >
                    <SvgMoreVert />
                </bd.Button>
            </>
        );
    };

    const getParentSerial = () => {
        if (!selectedContent) return null;
        if (enums.contentTypes.isSEC(selectedContent)) return selectedContent.serial;
        return selectedContent.parentSerial;
    };

    const getSortOrder = () => {
        if (!selectedContent) return 0;
        if (enums.contentTypes.isSEC(selectedContent)) return 0;
        return -selectedContent.sortOrder - 1;
    };

    const addSectionHandler = () => {
        const c = {
            parentSerial: getParentSerial(),
            sortOrder: getSortOrder(),
            visibility: "ALL",
            contentTypeId: "SEC",
        };
        onShowModalState(c);
    };

    const addRequirementHandler = () => {
        const c = {
            parentSerial: getParentSerial(),
            sortOrder: getSortOrder(),
            visibility: "ALL",
            contentTypeId: "REQ",
        };
        onShowModalState(c);
    };

    const addQuestionHandler = () => {
        const c = {
            title: "",
            parentSerial: getParentSerial(),
            sortOrder: getSortOrder(),
            answerTypeId: "TXT",
            answerRequired: false,
            visibility: "ALL",
            participantCanAttach: true,
            contentTypeId: "QN",
            contentChoices: [],
        };
        onShowModalState(c);
    };

    const addConditionHandler = () => {
        const c = {
            parentSerial: getParentSerial(),
            sortOrder: getSortOrder(),
            visibility: "ALL",
            conditionCode: "",
            answerRequired: false,
            participantCanAttach: true,
            contentTypeId: "COND",
        };
        onShowModalState(c);
    };

    const addSrcLibHandler = () => {
        const c = {
            parentSerial: getParentSerial(),
            sortOrder: getSortOrder(),
            visibility: "ALL",
            contentTypeId: "SRC",
        };
        onShowModalState(c);
    };

    const addItemHandler = (item) => {
        const c = {
            parentSerial: getParentSerial(),
            sortOrder: getSortOrder(),
            contentTypeId: "ITEM",
            visibility: "ALL",
            title: item?.materialText,
            description: item?.materialTextEn,
            quantity: item.qty - item?.orderQty,
            initialPrice: null,
            answerTypeId: null,
            answerRequired: true,
            participantCanAttach: true,
            prSerial: item.serial,
            materialNo: item.materialNo,
            unit: item.unit,
            contentTerms: [],
        };

        commodityApi
            .getMaterialCommodities(c.materialNo)
            .then((result) => {
                c.commodities = result.commodities;
                onShowModalState(c);
            })
            .catch(notify.error);
    };

    const ContentActionButtons = () => {
        const getPurReqs = model.purReqs?.filter((x) => !model.contents.map((c) => c.prSerial).includes(x.serial));

        return (
            <>
                {getPurReqs && getPurReqs.length > 0 && !model.isTemplate && !model.isLibrary && (
                    <bd.Button
                        variant="outline"
                        align="end"
                        color="primary"
                        menu={
                            <bd.Menu>
                                {getPurReqs.map((x) => (
                                    <bd.MenuItem key={x.materialNo} variant="contained" onClick={() => addItemHandler(x)}>
                                        {x.materialText} - {x.materialNo}
                                    </bd.MenuItem>
                                ))}
                            </bd.Menu>
                        }
                        disableRipple
                    >
                        <T className="px-2">add-item</T>
                    </bd.Button>
                )}

                <bd.Button
                    variant="outline"
                    align="end"
                    color="primary"
                    menu={
                        <bd.Menu>
                            <>
                                <bd.MenuItem variant="contained" onClick={addSectionHandler}>
                                    <SvgAdd className="text-primary p-e-2" />
                                    <T>section</T>
                                </bd.MenuItem>
                                <bd.MenuItem variant="contained" onClick={addQuestionHandler}>
                                    <SvgAdd className="text-primary p-e-2" />
                                    <T>question</T>
                                </bd.MenuItem>
                                <bd.MenuItem variant="contained" onClick={addConditionHandler}>
                                    <SvgAdd className="text-primary p-e-2" />
                                    <T>condition</T>
                                </bd.MenuItem>

                                {model.projectNumber != "SYS-SRLIB" && model.projectNumber != "SYS-SKNA" && (
                                    <>
                                        <bd.MenuItem variant="contained" onClick={addRequirementHandler}>
                                            <SvgAdd className="text-primary p-e-2" />
                                            <T>requirement</T>
                                        </bd.MenuItem>
                                        <bd.MenuDivider />

                                        <bd.MenuItem variant="contained" onClick={addSrcLibHandler}>
                                            <SvgAdd className="text-primary p-e-2" />
                                            <T>from-sourcing-library</T>
                                        </bd.MenuItem>
                                    </>
                                )}
                            </>
                        </bd.Menu>
                    }
                    disableRipple
                >
                    <T className="px-2">add-content</T>
                </bd.Button>
            </>
        );
    };

    return (
        <TProvider>
            <bd.Flex content="between" align="center" className="py-2 position-sticky top-0 bg-gray-3 shadow-1" style={{ zIndex: 10 }}>
                <div className="px-3">{title} </div>
                <bd.Flex content="end" align="center" gap={2} style={{ zIndex: 100 }}>
                    {isContentDisplayMode && selectedContent && <EditorToolbar />}
                    {isContentDisplayMode && !hideActionButtons && <ContentActionButtons />}
                    {toolbarControls}
                </bd.Flex>
            </bd.Flex>

            <BaseContents
                documentSerial={documentSerial}
                contents={model.contents}
                conditions={model.conditions}
                attachments={model.attachments}
                customColumns={columns}
                titleMinWidth={titleMinWidth}
                isRowVisible={isRowVisible}
                rowHeaderTitles={rowHeaderTitles}
                rowFooterTitles={rowFooterTitles}
                actionBarControls={actionBarControls}
                displayContentPreview
                className={className + (multiSelect ? "" : " table-hide-col1")}
                style={style}
                minHeight={isContentDisplayMode ? 250 : 100}
                singleSelect
                multiSelect={multiSelect}
                selectedSerials={selectedSerials}
                setSelectedSerials={(serials) => {
                    setSelectedSerials(serials);
                    onSelectionChanged && onSelectionChanged(serials);
                }}
                disableToggleOnClick={display !== "contents"}
                onRowDoubleClick={(content) => onShowModalState(content)}
                maxHeight={maxHeight == "" ? undefined : maxHeight}
            />

            <bd.Flex content="end" align="center" gap={2}>
                {footerControls}
            </bd.Flex>

            {!!modalState.render && (
                <>
                    <SectionContentModal
                        show={modalState.show && modalState.content.contentTypeId === "SEC"}
                        onHide={onHideModalState}
                        documentSerial={documentSerial}
                        content={modalState.content}
                        parent={selectedContent}
                        onSaveContent={(values) => onSaveContentHandler(values)}
                        envelopes={eventData.envelopes}
                        enableEnvelop={eventData.eventRules?.enableEnvelop}
                    />

                    <QuestionContentModal
                        show={modalState.show && modalState.content.contentTypeId === "QN"}
                        onHide={onHideModalState}
                        documentSerial={documentSerial}
                        content={modalState.content}
                        parent={selectedContent}
                        onSaveContent={(values) => onSaveContentHandler(values)}
                        envelopes={eventData.envelopes}
                        enableEnvelop={eventData.eventRules?.enableEnvelop}
                    />

                    <ConditionContentModal
                        show={modalState.show && modalState.content.contentTypeId === "COND"}
                        onHide={onHideModalState}
                        documentSerial={documentSerial}
                        content={modalState.content}
                        parent={selectedContent}
                        conditions={model.conditions}
                        onSaveContent={(values) => onSaveContentHandler(values)}
                        envelopes={eventData.envelopes}
                        enableEnvelop={eventData.eventRules?.enableEnvelop}
                    />

                    <RequirementContentModal
                        show={modalState.show && modalState.content.contentTypeId === "REQ"}
                        onHide={onHideModalState}
                        documentSerial={documentSerial}
                        content={modalState.content}
                        parent={selectedContent}
                        onSaveContent={(values) => onSaveContentHandler(values)}
                    />

                    <SrcLibContentModal
                        show={modalState.show && modalState.content.contentTypeId === "SRC"}
                        onHide={onHideModalState}
                        documentSerial={documentSerial}
                        content={modalState.content}
                        parent={selectedContent}
                        onSaveContents={(values) => {
                            editorService.onAddContents(selectedContent?.serial, values.serials);
                            onHideModalState();
                        }}
                    />

                    <ItemContentModal
                        show={modalState.show && modalState.content.contentTypeId === "ITEM"}
                        onHide={onHideModalState}
                        documentSerial={documentSerial}
                        content={modalState.content}
                        parent={selectedContent}
                        requestItem={modalState.item}
                        onSaveContent={(values) => onSaveContentHandler(values)}
                        purReqs={model.purReqs}
                        envelopes={eventData.envelopes}
                        enableEnvelop={eventData.eventRules?.enableEnvelop}
                    />
                </>
            )}
        </TProvider>
    );
};
