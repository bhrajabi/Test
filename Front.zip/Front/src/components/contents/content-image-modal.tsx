import { useEffect, useRef, useState } from "react";
import "swiper/css";
import "swiper/css/free-mode";
import "swiper/css/navigation";
import "swiper/css/thumbs";
import * as bd from "react-basic-design";
import { FreeMode, Navigation, Thumbs } from "swiper/modules";
import { Swiper, SwiperSlide } from "swiper/react";
import { MaterialAttachmentDTO } from "../../pages/req/monitor/material-images-modal";
import { BasicModal } from "../basic/basic-modal";
import { T } from "../basic/text";
import { ContentAttachmentIcon } from "./content-attachment-icon";

type ContentImageModalProps = {
    show: boolean;
    onHide: VoidFunction;
    images: MaterialAttachmentDTO[];
    curr: number;
};
export const ContentImageModal = ({ show, onHide, images, curr }: ContentImageModalProps) => {
    const [thumbsSwiper, setThumbsSwiper] = useState<any>(null);
    const slideRef = useRef<any>(null);
    useEffect(() => {
        if (slideRef.current) {
            slideRef.current.slideTo(curr);
        }
    }, [curr]);

    return (
        <BasicModal show={show} onHide={onHide} title={<T>attachments</T>} closeButton size="lg">
            <div className="w-100">
                <Swiper
                    spaceBetween={10}
                    modules={[Navigation, FreeMode, Thumbs]}
                    thumbs={{ swiper: thumbsSwiper }}
                    onSwiper={(s: any) => (slideRef.current = s)}
                    style={{ height: "calc(100vh - 300px)" }}
                >
                    {images.map((c) => {
                        return (
                            <SwiperSlide>
                                <ContentAttachmentIcon attachment={c} width="100%" height={500} className="rounded mb-3" />
                            </SwiperSlide>
                        );
                    })}
                </Swiper>
                <div className="mt-auto">
                    <Swiper
                        onSwiper={setThumbsSwiper}
                        slidesPerView={5}
                        spaceBetween={10}
                        freeMode
                        watchSlidesProgress
                        navigation
                        modules={[Navigation, FreeMode, Thumbs]}
                        className="thumbs-swiper"
                        breakpoints={{ 320: { slidesPerView: 2 }, 768: { slidesPerView: 5 } }}
                    >
                        {images.map((c) => (
                            <SwiperSlide>
                                <ContentAttachmentIcon
                                    attachment={c}
                                    width={80}
                                    height={80}
                                    className="rounded border cur-pointer"
                                    disableDownload
                                />
                            </SwiperSlide>
                        ))}
                    </Swiper>
                </div>
            </div>
        </BasicModal>
    );
};
