import * as bd from "react-basic-design";
import { contentApi } from "../../api/content-api";
import SvgArrowDownward from "../../assets/icons/ArrowDownward";
import { T } from "../basic/text";

export const ContentAttachment = ({ documentSerial, attachmentId }) => {
    return (
        <bd.Chip
            size="sm"
            className="m-e-1 border-1 alert-info"
            label={
                <bd.Flex align="center">
                    <SvgArrowDownward className="m-e-2" style={{ fontSize: 15 }} />
                    <T as="small">download-attachment</T>
                </bd.Flex>
            }
            onClick={(event) => {
                event.stopPropagation();
                event.preventDefault();
                contentApi.downloadFile(documentSerial, attachmentId);
            }}
        />
    );
};
