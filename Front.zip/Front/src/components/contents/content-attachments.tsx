import { useState } from "react";
import * as bd from "react-basic-design";
import { Link } from "react-router-dom";
import { MaterialAttachmentDTO } from "../../pages/req/monitor/material-images-modal";
import { code } from "../basic/code";
import { ContentImageModal } from "./content-image-modal";
import { ContentAttachmentIcon } from "./content-attachment-icon";

export const ContentAttachments = ({ attachments }: { attachments: MaterialAttachmentDTO[] }) => {
    const [imageModal, setImageModal] = useState<{ show: boolean; curr: number }>({ show: false, curr: 0 });
    return (
        <div className="">
            <bd.Flex gap={1} align="center">
                {attachments
                    .filter((x, xi) => xi < 2)
                    .map((c, idx) => (
                        <div key={c.id} className="rtl">
                            <Link
                                to=""
                                onClick={(e) => {
                                    code.stopPropagationFunc(e);
                                    setImageModal({ show: true, curr: idx });
                                }}
                            >
                                <ContentAttachmentIcon attachment={c} width={60} className="border rounded" disableDownload />
                            </Link>
                        </div>
                    ))}
                {attachments.length > 2 && (
                    <bd.Button
                        className="my-1 rounded border p-1"
                        style={{ width: 60, height: 43 }}
                        onClick={() => setImageModal({ show: true, curr: 2 })}
                    >
                        {attachments.length - 2}+
                    </bd.Button>
                )}
            </bd.Flex>

            {imageModal.show && (
                <ContentImageModal
                    show={imageModal.show}
                    onHide={() => setImageModal({ ...imageModal, show: false })}
                    curr={imageModal.curr}
                    images={attachments}
                />
            )}
        </div>
    );
};
