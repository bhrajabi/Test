import classNames from "classnames";
import { CSSProperties, ReactNode, useEffect, useState } from "react";
import * as bd from "react-basic-design";
import { contentApi } from "../../api/content-api";
import { code } from "../basic/code";
import { InitFailed } from "../basic/init-failed";
import { Loading } from "../basic/loading";
import { N } from "../basic/n";
import { T } from "../basic/text";
import { BaseContents } from "./base-contents";
import { ContentType } from "./types";

export const ContentsView = ({
    contents,
    documentSerial,
    customColumns,
    titleMinWidth = 400,
    isRowVisible,
    rowHeaderTitles,
    rowFooterTitles,
    singleSelect,
    actionBarControls,
    onSelectionChanged,
    className,
    style,
    display,
    toolbarControls,
    isInMobile,
}: {
    documentSerial: number;
    contents?: ContentType[];
    customColumns?: any[];
    titleMinWidth?: number | string;
    rowHeaderTitles?: string[];
    rowFooterTitles?: string[];
    singleSelect?: boolean;
    actionBarControls?: ReactNode;
    className?: string;
    style?: CSSProperties;
    display?: string;
    toolbarControls?: ReactNode;
    isInMobile?: boolean;
    isRowVisible?: (row: ContentType) => boolean;
    onSelectionChanged?: (serial: number[]) => void;
}) => {
    if (!customColumns) customColumns = [];

    const [selectedSerials, setSelectedSerials] = useState<any>([]);
    const [model, setModel] = useState<any>();
    const [initialized, setInitialized] = useState(false);

    useEffect(() => {
        if (initialized) return;
        if (contents && contents.length > 0) {
            setModel({ ...model, contents });

            return;
        }
        contentApi.initContents(documentSerial).then(setModel).catch(setModel);

        setInitialized(true);
    }, [initialized, contents]);

    if (!model) return <Loading />;
    if (model instanceof Error) return <InitFailed ex={model} onRetry={() => setModel(null)} />;

    let columns: any[] = [];
    switch (display) {
        case "contents":
            columns = [
                {
                    title: <T>initial-price</T>,
                    minWidth: 150,
                    width: 150,
                    Cell: ({ row }: any) => <N>{row.content.initialPrice}</N>,
                },

                {
                    title: <T>quantity</T>,
                    minWidth: 120,
                    Cell: ({ row }: any) => {
                        return (
                            <>
                                <N>{row.content.quantity}</N>
                                <span className="m-e-1">{row.content.unit}</span>
                            </>
                        );
                    },
                },
            ];
            break;

        case "scores":
            columns = [
                {
                    title: <T>importance</T>,
                    Cell: ({ row }: any) => {
                        var x = code.localNumbers(row.content.scoreImportance);
                        return (
                            <div className="p-s-2">
                                {row.level > 0 && <span className="d-inline-block" style={{ width: row.level * 30 }}></span>}
                                {x}
                            </div>
                        );
                    },
                },
                {
                    title: <T>score</T>,
                    Cell: ({ row }: any) => {
                        let x: any = row.content.scoreOveral * 100;
                        if (x % 1 != 0) x = x.toFixed(1);
                        x = code.localNumbers(code.numberWithCommas(x)) + " %";
                        return (
                            <div className="p-s-2">
                                {row.level > 0 && <span className="d-inline-block" style={{ width: row.level * 30 }}></span>}
                                {x}
                            </div>
                        );
                    },
                },
            ];
            break;
    }
    return (
        <>
            {toolbarControls && (
                <bd.Flex
                    className="py-2 position-sticky top-0 bg-gray-3 shadow-1"
                    content="end"
                    align="center"
                    gap={2}
                    style={{ zIndex: 100 }}
                >
                    {toolbarControls}
                </bd.Flex>
            )}

            <BaseContents
                documentSerial={documentSerial}
                contents={model.contents}
                customColumns={customColumns ? columns.concat(customColumns) : columns}
                titleMinWidth={titleMinWidth}
                isRowVisible={isRowVisible}
                rowHeaderTitles={rowHeaderTitles}
                rowFooterTitles={rowFooterTitles}
                actionBarControls={actionBarControls}
                singleSelect={singleSelect}
                className={className}
                style={style}
                selectedSerials={selectedSerials}
                setSelectedSerials={setSelectedSerials}
                onSelectionChanged={onSelectionChanged}
                isInMobile={isInMobile}
                onGetCustomTitleInfo={(content, level, number, width) => {
                    return (
                        <>
                            {!!content.contentChoices?.length && display == "scores" && (
                                <div className="d-flex">
                                    {level > 0 && <span style={{ width: width }}></span>}

                                    <div className={classNames("p-e-3", { invisible: number === "0" })} style={{ visibility: "hidden" }}>
                                        <N>{number}</N>
                                    </div>

                                    {content.contentChoices?.map((x) => (
                                        <bd.Chip
                                            size="sm"
                                            className="m-e-2"
                                            label={
                                                <>
                                                    {x.title} - <N>{x.score}</N>
                                                </>
                                            }
                                        />
                                    ))}
                                </div>
                            )}
                        </>
                    );
                }}
            />
        </>
    );
};
