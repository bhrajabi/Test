import * as bd from "react-basic-design";
import { useTranslation } from "react-i18next";
import SvgKey from "../../assets/icons/Key";
import { calendar } from "../basic/calendar";
import { DateInput } from "../basic/date-input";
import { NumberInput } from "../basic/number-input";
import { T } from "../basic/text";

export const ContentPreview = ({ row, inEditMode }) => {
    return (
        <>
            <span
                onClick={(e) => {
                    e.preventDefault();
                    e.stopPropagation();
                }}
            >
                <RenderContentPreview row={row} inEditMode={inEditMode} />
            </span>

            {row.envelopNumber && <SvgKey className="text-muted m-s-1" style={{ fontSize: "1rem" }} />}
        </>
    );
};

const RenderContentPreview = ({ row, inEditMode }) => {
    if (inEditMode) {
        return row.answerRequired && <span className="text-danger mx-1">*</span>;
    }

    const { t } = useTranslation();
    let answerRequired = row.answerRequired === "YES" || row.answerRequired === true ? true : false;
    if (row.contentTypeId == "QN") {
        let answerType = null;

        switch (row.answerTypeId) {
            case "CMB":
                answerType = <bd.TextField type="select" className="d-inline-block" items={row.contentChoices.map((x) => x.title)} />;
                break;
            case "NUM":
                answerType = <NumberInput placeholder={t("an-example-number")} />;
                break;
            case "DATE":
                answerType = <DateInput value={calendar.dateToString(new Date())} />;
                break;
            case "TXT":
                answerType = <bd.TextField type="text" placeholder={t("an-example-text")} />;
                break;
            case "MEMO":
                answerType = <bd.TextField type="textarea" width={200} height={100} placeholder={t("an-example-text")} />;
                break;
            case "YESNO":
                answerType = <bd.TextField type="select" width={80} items={["", t("yes"), t("no")]}></bd.TextField>;
                break;
            case "UPL":
                answerType = <T className="text-muted m-s-3">upload</T>;
                break;
        }
        return (
            <>
                <div className="d-inline-block">{answerType}</div>
                {answerRequired == true && <span className="text-danger m-s-1">*</span>}
            </>
        );
    } else {
        if (row.contentTypeId == "REQ") {
            return (
                <>
                    <bd.TextField type="select" className="d-inline-block m-e-1" maxWidth={100} items={[t("yes"), t("no")]} />
                    <div className="d-inline-block fs-3 text-danger m-s-1">*</div>
                </>
            );
        } else if (row.contentTypeId == "ITEM") {
            return answerRequired == true && <span className="text-danger m-s-1">*</span>;
        } else return null;
    }
};
