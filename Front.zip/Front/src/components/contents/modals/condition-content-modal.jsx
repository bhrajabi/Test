import * as bd from "react-basic-design";
import { Modal, ModalBody, ModalHeader, ModalTitle } from "react-bootstrap";
import * as yup from "yup";

import { Form, Formik } from "formik";
import { contentVisibilities } from "../../../app/constatnts";
import { T, translate } from "../../basic/text";
import { FormikTextField } from "../../formik/formik-text-field";
import { ContentPositionEditor } from "./content-position-editor";
import { ContentAttachmentEditor } from "./content-attachment-editor";
import { FormikCellToggle } from "../../formik/formik-cell-toggle";
import { FormikToggle } from "../../formik/formik-toggle";
import { useEffect, useRef, useState } from "react";
import SvgDelete from "../../../assets/icons/Delete";

export const ConditionContentModal = ({
    show,
    onHide,
    documentSerial,
    content,
    parent,
    conditions,
    onSaveContent,
    envelopes,
    enableEnvelop,
}) => {
    const insertMode = !content?.serial;
    const [idxs, setIdxs] = useState([]);

    const formRef = useRef();

    const getvalidValuesAsChoices = (validValues) => {
        var choices = [];
        const lines = validValues.split(/\r\n|\r|\n/).filter((line) => line.trim() !== "");

        choices = lines?.map((x) => ({
            score: 0,
            setDefault: false,
            title: x.split("=")[0],
        }));

        return choices;
    };

    const setContentChoices = (formik, conditionCode) => {
        const condition = conditions.find((x) => x.code === conditionCode);
        if (!condition || !condition.validValues) return;

        formik.setFieldValue("contentChoices", getvalidValuesAsChoices(condition.validValues));
    };

    const getChoices = () => {
        if (!!content.contentChoices?.length) return content;

        var condition = conditions.find((c) => c.code === content.conditionCode);
        if (!condition) return content;
        var choices = [];
        if (!!condition.validValues) choices = getvalidValuesAsChoices(condition.validValues);
        return { ...content, contentChoices: [...choices] };
    };

    const addChoice = (formik) => {
        const newValue = { title: "", score: 0, setDefault: false };
        formik.setFieldValue("contentChoices", [...formik.values.contentChoices, newValue]);
    };

    const toggleDefault = (formik, choice) => {
        const isDefault = choice.setDefault;
        let choices = [...formik.values.contentChoices];
        choices.forEach((x) => (x.setDefault = false));
        choice.setDefault = !isDefault;
        formik.setFieldValue("contentChoices", choices);
    };

    const deleteChoice = (formik, index) => {
        const choices = formik.values.contentChoices;
        formik.setFieldValue("contentChoices", [...choices.filter((x, xIndex) => xIndex != index)]);
    };

    const onSubmit = (values) => {
        var condition = conditions.find((c) => c.code === values.conditionCode);
        values.title = condition?.title;

        onSaveContent(values);
    };

    return (
        <Modal show={show} onHide={onHide} fullscreen={false} size="lg">
            <ModalHeader closeButton>
                <ModalTitle>
                    <T>{!insertMode ? `edit-condition` : `add-condition`}</T>
                </ModalTitle>
            </ModalHeader>

            <ModalBody>
                <div className="container p-1">
                    <Formik
                        initialValues={getChoices()}
                        validationSchema={yup.object({
                            conditionCode: yup.string().nullable().required(" "),
                        })}
                        onSubmit={onSubmit}
                        innerRef={formRef}
                    >
                        {(formik) => (
                            <Form>
                                {parent && insertMode && parent.contentTypeId == "SEC" && (
                                    <ContentPositionEditor
                                        title={parent.title}
                                        onChange={(pos) => formik.setFieldValue("sortOrder", pos)}
                                    />
                                )}

                                <FormikTextField
                                    type="select"
                                    name="conditionCode"
                                    variant="outline"
                                    items={[{ id: "", title: "" }, ...conditions]}
                                    label={<T>condition</T>}
                                    labelWidth={3}
                                    inputStyle={{ width: "15rem" }}
                                    postfixLabel={
                                        <>
                                            <FormikCellToggle label={<T>response-required</T>} className="m-s-3" name="answerRequired" />
                                        </>
                                    }
                                    onChange={(e) => setContentChoices(formik, e.target.value)}
                                />
                                <FormikTextField label={<T>code</T>} labelWidth="3" name="code" inputMaxWidth={200} />
                                {enableEnvelop && envelopes && envelopes.length > 0 && (
                                    <FormikTextField
                                        type="select"
                                        name="envelopNumber"
                                        items={[
                                            { id: "", title: "" },
                                            ...envelopes.map((x) => {
                                                return { ...x, id: x.seq };
                                            }),
                                        ]}
                                        label={<T>envelope-number</T>}
                                        labelWidth={3}
                                        inputStyle={{ width: "10rem" }}
                                    />
                                )}

                                <FormikToggle
                                    name="participantCanAttach"
                                    title={<T>participants-can-add-comment-and-attachment</T>}
                                    labelWidth={3}
                                    className="m-s-n2"
                                />

                                <bd.FormRow label={<T>reference-documents</T>} labelWidth="3">
                                    <ContentAttachmentEditor
                                        documentSerial={documentSerial}
                                        content={formik.values}
                                        onChange={(id) => formik.setFieldValue("attachmentId1", id)}
                                    />
                                </bd.FormRow>

                                <FormikTextField
                                    labelWidth="3"
                                    label={<T>visibility</T>}
                                    type="select"
                                    items={contentVisibilities.map((x) => ({ id: x.id, title: translate(x.id) }))}
                                    inputStyle={{ width: "10rem" }}
                                    name="visibility"
                                />

                                {!!conditions.find((x) => x.code === formik.values.conditionCode)?.validValues && (
                                    <>
                                        <div className="d-inline-block">
                                            <T as="h5">values</T>
                                        </div>

                                        <div className="border mb-3">
                                            <bd.BasicTable
                                                className="border-0"
                                                hover
                                                selectedIndices={idxs}
                                                onSelectionChanged={(idxs) => setIdxs(idxs)}
                                                columns={[
                                                    {
                                                        name: "",
                                                        Cell: ({ rowIndex }) => (
                                                            <bd.Button
                                                                variant="icon"
                                                                size="sm"
                                                                color="secondary"
                                                                type="button"
                                                                onClick={() => deleteChoice(formik, rowIndex)}
                                                            >
                                                                <SvgDelete />
                                                            </bd.Button>
                                                        ),
                                                        width: 45,
                                                    },
                                                    {
                                                        name: "value",
                                                        Header: <T>value</T>,
                                                        Cell: ({ rowIndex }) => (
                                                            <FormikTextField name={`contentChoices.${rowIndex}.title`} className="my-1" />
                                                        ),
                                                    },
                                                    {
                                                        name: "setDefault",
                                                        Header: <T>default</T>,
                                                        width: 100,
                                                        Cell: ({ row, value }) => (
                                                            <bd.Toggle
                                                                title={<T>participants-can-add-comment-and-attachment</T>}
                                                                labelWidth={3}
                                                                className="m-s-n2"
                                                                checked={value}
                                                                onChange={() => toggleDefault(formik, row)}
                                                            />
                                                        ),
                                                    },
                                                    {
                                                        name: "score",
                                                        Header: <T>score</T>,
                                                        width: 100,
                                                        Cell: ({ rowIndex }) => (
                                                            <FormikTextField
                                                                name={`contentChoices.${rowIndex}.score`}
                                                                className="my-1"
                                                                type="select"
                                                                items={[0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]}
                                                            />
                                                        ),
                                                    },
                                                ]}
                                                data={formik.values.contentChoices}
                                                actions={
                                                    <bd.Button
                                                        size="sm"
                                                        variant="outline"
                                                        className="min-w-80"
                                                        type="button"
                                                        onClick={() => addChoice(formik)}
                                                    >
                                                        <T>add</T>
                                                    </bd.Button>
                                                }
                                            >
                                                <T as="div" className="nothing-found">
                                                    nothing-found
                                                </T>
                                            </bd.BasicTable>
                                        </div>
                                    </>
                                )}
                                <bd.FormRow labelWidth={3} className="py-1">
                                    <bd.Button variant="contained" className="m-s-auto m-e-2" disabled={!formik.isValid}>
                                        <T>save-changes</T>
                                    </bd.Button>

                                    <bd.Button variant="outline" className="min-w-80" onClick={onHide} type="button">
                                        <T>cancel</T>
                                    </bd.Button>
                                </bd.FormRow>
                            </Form>
                        )}
                    </Formik>
                </div>
            </ModalBody>
        </Modal>
    );
};
