import { useRef } from "react";
import * as bd from "react-basic-design";
import SvgAttachFile from "../../../assets/icons/AttachFile";
import { T } from "../../basic/text";
import { useWaiting } from "../../basic/use-waiting";
import { apiConfig } from "../../../api/config";
import { attachmentApi } from "../../../api/attachment-api";
import { notify } from "../../basic/notify";
import { contentApi } from "../../../api/content-api";

export const ContentAttachmentEditor = ({ documentSerial, content, onChange }) => {
    const uploadRef = useRef();
    const waiting = useWaiting();

    const onAddAttachment = (event) => {
        if (event.target.files.length == 0) return;
        const url = apiConfig.contentUrl + `/upload-content-attachment?documentSerial=${documentSerial}`;
        waiting.start();
        attachmentApi
            .attach(url, event.target)
            .then((result) => onChange(result.id))
            .catch(notify.error)
            .finally(waiting.stop);
    };

    return (
        <>
            <input id="input" type="file" style={{ display: "none" }} onChange={onAddAttachment} ref={uploadRef} />

            {!content.attachmentId1 && (
                <bd.Button type="button" onClick={() => uploadRef.current.click()}>
                    <SvgAttachFile className="m-s-n1" />
                    <T className="p-s-1">upload</T>
                </bd.Button>
            )}

            <>
                {!!content.attachmentId1 && (
                    <bd.Chip
                        label={<T>download-attachment</T>}
                        size="sm"
                        className="m-e-2 border-1 alert-info"
                        onDelete={() => onChange(null)}
                        onClick={() => contentApi.downloadFile(documentSerial, content.attachmentId1)}
                    />
                )}
            </>
        </>
    );
};
