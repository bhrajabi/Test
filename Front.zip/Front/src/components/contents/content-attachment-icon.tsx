import classNames from "classnames";
import { useEffect, useState } from "react";
import * as bd from "react-basic-design";
import { apiConfig } from "../../api/config";
import SvgDownload from "../../assets/icons/Download";
import { MaterialAttachmentDTO } from "../../pages/req/monitor/material-images-modal";
import { code } from "../basic/code";
import { T } from "../basic/text";
import { ChatFileIcon } from "../chat/chat-file-icon";

export const ContentAttachmentIcon = ({
    disableDownload,
    attachment,
    width,
    height,
    className,
    inCell,
    size,
}: {
    attachment: MaterialAttachmentDTO;
    width?: number | string;
    height?: number;
    disableDownload?: boolean;
    inCell?: boolean;
    className?: string;
    size?: number;
}) => {
    const handleDownloadFile = () => {
        if (disableDownload && !inCell) return;

        const url = URL.createObjectURL(file);
        const a = document.createElement("a");
        a.href = url;
        a.download = file.name;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    };

    const [blob, setBlob] = useState<Blob>();
    const fetchAttachment = async () => {
        const response = await fetch(
            apiConfig.materialUrl +
                `/get-material-attachment?requestItemSerial=${attachment.requestItemSerial ?? 0}&seed=${
                    attachment.seed ?? 0
                }&attachmentId=${attachment.id}&objectKey=${attachment.objectKey ?? ""}`
        );
        setBlob(await response.blob());
    };

    useEffect(() => {
        fetchAttachment();
    }, [attachment.id]);

    if (!blob) return <></>;
    const file = new File([blob], "", { type: blob.type });
    const isImage = attachment.mimeType.includes("image");

    return (
        <bd.Flex align="center" content="center" className={`p-1 ${className}`} style={{ height: height }}>
            {isImage && <img src={URL.createObjectURL(file)} width={width ?? "100%"} />}
            {!isImage && (
                <div>
                    <bd.Flex
                        className={classNames("px-2 text-muted")}
                        content="start"
                        align="center"
                        style={{ height: 50 }}
                        gap={2}
                        vertical
                    >
                        <bd.Button
                            variant="icon"
                            disableRipple
                            className="text-danger p-1 bg-white cur-pointer"
                            onClick={handleDownloadFile}
                        >
                            <ChatFileIcon file={file} height={36} width={36} />
                        </bd.Button>
                        {!disableDownload && (
                            <>
                                <div>
                                    {attachment.title}
                                    <bd.Button
                                        variant="outline"
                                        size="sm"
                                        onClick={(e) => {
                                            code.stopPropagationFunc(e);
                                            handleDownloadFile();
                                        }}
                                        className="m-s-2"
                                    >
                                        <T>download</T> <SvgDownload />
                                    </bd.Button>
                                </div>
                            </>
                        )}
                    </bd.Flex>
                </div>
            )}
        </bd.Flex>
    );
};
