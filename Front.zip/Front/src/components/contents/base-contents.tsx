// Added by ashkan farmanbar in 2022-4-11

import classNames from "classnames";
import { CSSProperties, ReactNode, useRef } from "react";
import * as bd from "react-basic-design";
import SvgMail from "../../assets/icons/Mail";
import { N } from "../basic/n";
import { T, translate } from "../basic/text";
import { ContentAttachment } from "./content-attachment";
import { ContentAttachments } from "./content-attachments";
import { RenderContentPreview } from "./render-content-preview";
import { BasicTableColumnProps, ConditionType, ContentType, CustomContentColumn } from "./types";
import { useContent } from "./use-content";

type BaseContentsProps = {
    documentSerial?: number;
    contents: ContentType[];
    customColumns: CustomContentColumn[];
    conditions?: ConditionType[];

    titleWidth?: number | string;
    titleMinWidth?: number | string;

    isRowVisible?: (row: ContentType) => boolean;
    rowHeaderTitles?: string[];
    rowFooterTitles?: string[];

    selectedSerials?: number[];
    setSelectedSerials?: (serial: number[]) => void;
    onSelectionChanged?: (serial: number[]) => void;

    actionBarControls?: ReactNode;

    singleSelect?: boolean;
    multiSelect?: boolean;
    displayContentPreview?: boolean;

    className?: string;
    style?: CSSProperties;
    minHeight?: number;
    disableToggleOnClick?: boolean;
    maxHeight?: number;
    isInMobile?: boolean;
    hover?: boolean;

    onGetCustomTitleInfo?: (content: ContentType, level: number, number: string, width: string | number) => void;
    onRowDoubleClick?: (content: ContentType) => void;
};

export const BaseContents = ({
    documentSerial,
    contents,
    customColumns = [],
    conditions = [],
    titleWidth,
    titleMinWidth = 300,

    isRowVisible,
    rowHeaderTitles,
    rowFooterTitles,

    selectedSerials,
    setSelectedSerials,

    actionBarControls,

    singleSelect,
    multiSelect,
    displayContentPreview,

    className,
    style,
    minHeight = 100,
    disableToggleOnClick,
    maxHeight,
    isInMobile,
    hover,

    onSelectionChanged,
    onGetCustomTitleInfo,
    onRowDoubleClick,
}: BaseContentsProps) => {
    customColumns = customColumns ?? [];
    // tree content
    const contentService = useContent(contents);
    const tree = contentService.makeTree({
        rowHeaderTitles: rowHeaderTitles ?? [],
        rowFooterTitles: rowFooterTitles ?? [],
        isRowVisible,
    });

    // columns
    const columns = useRef<BasicTableColumnProps[]>([]);
    columns.current = [];

    if (!isInMobile) {
        columns.current.push({
            name: "title",
            title: <T>title</T>,
            width: titleWidth,
            minWidth: titleMinWidth,
            Cell: ({ row }) => {
                var content = row.content;
                var level = row.level;
                var number = row.number;
                const width = level * 30;
                if (row.isFooter) {
                    return (
                        <div className="opacity-50 my-1">
                            <T>{content.title}</T>:
                        </div>
                    );
                }

                return (
                    <>
                        <div className={classNames("d-flex align-items-center my-2")}>
                            {level > 0 && <span style={{ width: width }}></span>}
                            <div className={classNames("p-e-3", { invisible: number === "0" })}>
                                <N>{number}</N>
                            </div>

                            <div className={classNames({ "fw-bold": content.contentTypeId === "SEC" })}>
                                <div className="d-flex align-items-center">
                                    {content.title}
                                    {(content.answerRequired == true || content.answerRequired === "YES") && (
                                        <div className="text-danger p-1 m-n2 m-s-2 size-lg fw-bold" title={translate("required")}>
                                            *
                                        </div>
                                    )}
                                </div>
                                {content.itemNo && (
                                    <div className="text-muted small">
                                        <T>item-no</T> : {+content.itemNo}
                                    </div>
                                )}
                                {content.materialNo && (
                                    <div className="text-muted small">
                                        <T>material-no</T> : {content.materialNo}
                                    </div>
                                )}
                                {content.partNumber && (
                                    <div className="text-muted small">
                                        <T>part-number</T> : {content.partNumber}
                                    </div>
                                )}
                            </div>

                            {content.envelopNumber > 0 && (
                                <bd.Flex
                                    align="center"
                                    gap={1}
                                    className="small p-1 my-n1 m-s-2 hover-shade-5 text-success rounded cur-default"
                                    //title={translate("envelope-number") + ": " + content.envelopNumber}
                                    title={`پاسخ به اين سوال محرمانه بوده \r\n و در پاكت شماره ${content.envelopNumber} قرار مي گيرد`}
                                >
                                    <SvgMail /> {content.envelopNumber}
                                </bd.Flex>
                            )}

                            <div className="m-s-3">
                                {displayContentPreview && (
                                    <RenderContentPreview
                                        validValues={["", ...content.contentChoices.map((c: any) => c.title)]}
                                        content={content}
                                        width="100%"
                                        className="flex-grow-1"
                                        uploadDisabled
                                        conditions={conditions}
                                    />
                                )}
                            </div>
                        </div>
                        {content.description && (
                            <div className={classNames("d-flex")}>
                                {level > 0 && <span style={{ width: width }}></span>}

                                <div className={classNames("p-e-3", { invisible: number === "0" })} style={{ visibility: "hidden" }}>
                                    <N>{number}</N>
                                </div>

                                <div
                                    className={classNames("small text-muted text-wrap text-justify", !content.description ? "d-none" : "")}
                                    style={{ whiteSpace: "pre", lineHeight: 1.5 }}
                                >
                                    <div className="py-1 pre-wrap">{content.description}</div>
                                </div>
                            </div>
                        )}
                        {onGetCustomTitleInfo && onGetCustomTitleInfo(content, level, number, width)}
                        {content.attachmentId1 && (
                            <div className="d-flex mb-2">
                                {level > 0 && <span style={{ width: width }}></span>}

                                <div className={classNames("p-e-3", { invisible: number === "0" })} style={{ visibility: "hidden" }}>
                                    <N>{number}</N>
                                </div>
                                {content.attachmentId1 && (
                                    <ContentAttachment documentSerial={documentSerial} attachmentId={content.attachmentId1} />
                                )}
                            </div>
                        )}
                        {!!content.attachments?.length && (
                            <bd.Flex gap={2} className="mb-3">
                                {level > 0 && <span style={{ width: width }}></span>}
                                <div className={classNames("", { invisible: number === "0" })} style={{ visibility: "hidden" }}>
                                    <N>{number}</N>
                                </div>

                                <ContentAttachments
                                    attachments={content.attachments.map((x: any) => {
                                        return { ...x, id: x.attachmentId };
                                    })}
                                />
                            </bd.Flex>
                        )}
                    </>
                );
            },
        });
    }

    customColumns.forEach((cc) => columns.current.push(cc));

    // selection
    const all_serials = tree.map((x) => x.content.serial);
    const selectedIndices = selectedSerials ? selectedSerials.map((serial) => all_serials.indexOf(serial)).filter((x) => x >= 0) : [];

    const onSelectionChangedHandler = (indices: any[]) => {
        const selected_serials = indices
            .filter((x) => x >= 0)
            .sort((a, b) => a - b)
            .map((i) => tree[i].content.serial);
        setSelectedSerials && setSelectedSerials(selected_serials);
        onSelectionChanged && onSelectionChanged(selected_serials);
    };
    return (
        <bd.BasicTable
            hover={hover}
            disableToggleOnClick={disableToggleOnClick}
            singleSelect={singleSelect}
            multiSelect={multiSelect}
            columns={columns.current as any}
            data={tree}
            selectedIndices={selectedIndices}
            onSelectionChanged={onSelectionChangedHandler}
            className={className}
            style={{ ...style, minHeight }}
            maxHeight={maxHeight}
            actions={actionBarControls}
            onRowDoubleClick={({ row }) => {
                onRowDoubleClick && onRowDoubleClick(row.content);
            }}
            cellCSS={({ row }) => (row.isHeader || row.isFooter ? "bg-gray-3" : "")}
        />
    );
};
