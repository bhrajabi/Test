import { Form, Formik } from "formik";
import * as bd from "react-basic-design";
import * as yup from "yup";
import { T } from "../../basic/text";
import { FormikShebaInput } from "../../formik/formik-sheba-input";
import { FormikTextField } from "../../formik/formik-text-field";

interface FormValues {
    shebaCode: string;
    bankName: string;
    accountHolderName: string;
}

type AnswerTypeProps = {
    value: any;
    readOnly: boolean;
    answerRequired: boolean;
    onChange: (e: any) => void;
};
export const AnswerTypeBank = ({ value, readOnly, answerRequired, onChange }: AnswerTypeProps) => {
    var defaultValue = value && value.split(",");

    const getDefaultValue = (index: number) => (defaultValue && defaultValue[index] ? defaultValue[index] : "");

    const initialValues: FormValues = {
        shebaCode: getDefaultValue(0),
        bankName: getDefaultValue(1),
        accountHolderName: getDefaultValue(2),
    };

    const getValue = (data: FormValues) => {
        const values = Object.values(data);
        if (values.every((value) => !value)) return "";
        const combined = values.map((value) => (value !== undefined && value !== null ? value : "")).join(",");
        return combined;
    };

    const validationSchema = () => {
        if (!answerRequired) return yup.object({});
        else {
            const schema: any = {};
            Object.keys(initialValues).forEach((field) => (schema[field] = yup.string().required(" ")));
            return yup.object(schema);
        }
    };

    return (
        <div>
            <Formik initialValues={initialValues} onSubmit={() => {}} validationSchema={validationSchema()}>
                {({ values }) => {
                    const handleInputChange = () => {
                        if (!answerRequired) onChange({ target: { value: getValue(values) } });
                        else {
                            var value = getValue(values);
                            var nullsValues = Object.values(values).filter((value) => value === undefined || value === "");
                            if (nullsValues.length > 0) value = "";
                            onChange({ target: { value } });
                        }
                    };
                    return (
                        <Form>
                            <bd.Flex wrap gap={2}>
                                <FormikShebaInput
                                    label={<T>sheba-code</T>}
                                    name="shebaCode"
                                    width="19rem"
                                    maxLength={32}
                                    inputStyle={{ maxWidth: "22rem" }}
                                    placeholder="xx-xxxx-xxxx-xxxx-xxxx-xxxx-xx"
                                    handleEnter
                                    className="m-0"
                                    readOnly={readOnly}
                                    inputMaxWidth={250}
                                    onBlur={handleInputChange}
                                />
                                <FormikTextField
                                    label={"bank-name"}
                                    name="bankName"
                                    className="m-0"
                                    readOnly={readOnly}
                                    inputMaxWidth={250}
                                    maxLength={50}
                                    handleEnter
                                    onBlur={handleInputChange}
                                />
                                <FormikTextField
                                    label="account-holder-name"
                                    name="accountHolderName"
                                    className="m-0"
                                    readOnly={readOnly}
                                    inputMaxWidth={250}
                                    maxLength={50}
                                    handleEnter
                                    onBlur={handleInputChange}
                                />
                            </bd.Flex>
                        </Form>
                    );
                }}
            </Formik>
        </div>
    );
};
