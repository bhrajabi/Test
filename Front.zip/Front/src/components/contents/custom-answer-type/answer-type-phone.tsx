import { Form, Formik } from "formik";
import * as bd from "react-basic-design";
import * as yup from "yup";
import { FormikTextField } from "../../formik/formik-text-field";

interface FormValues {
    tel1: string;
    tel2: string;
    fax: string;
}

type AnswerTypeProps = {
    value: any;
    readOnly: boolean;
    answerRequired: boolean;
    onChange: (e: any) => void;
};

export const AnswerTypePhone = ({ value, readOnly, answerRequired, onChange }: AnswerTypeProps) => {
    var defaultValue = value && value.split(",");
    const getDefaultValue = (index: number) => (defaultValue && defaultValue[index] ? defaultValue[index] : "");

    const initialValues: FormValues = {
        tel1: getDefaultValue(0),
        tel2: getDefaultValue(1),
        fax: getDefaultValue(2),
    };

    const getValue = (data: FormValues) => {
        const values = Object.values(data);
        if (values.every((value) => !value)) return "";
        const combined = values.map((value) => (value !== undefined && value !== null ? value : "")).join(",");
        return combined;
    };

    const validationSchema = () => {
        if (!answerRequired) return yup.object({});
        else {
            const schema: any = {};
            Object.keys(initialValues).forEach((field) => (schema[field] = yup.string().required(" ")));
            return yup.object(schema);
        }
    };

    return (
        <div>
            <Formik
                initialValues={initialValues}
                onSubmit={() => {}}
                validationSchema={yup.object({
                    tel1: yup.string().required(" "),
                })}
            >
                {({ values }) => {
                    const handleInputChange = () => {
                        if (!answerRequired) onChange({ target: { value: getValue(values) } });
                        else {
                            var value = getValue(values);
                            if (!values.tel1) value = "";
                            onChange({ target: { value } });
                        }
                    };
                    return (
                        <Form>
                            <bd.Flex wrap gap={2}>
                                <FormikTextField
                                    label="tel1"
                                    name="tel1"
                                    className="m-0"
                                    onBlur={handleInputChange}
                                    readOnly={readOnly}
                                    inputMaxWidth={250}
                                    maxLength={16}
                                    type="tel"
                                    handleEnter
                                />
                                <FormikTextField
                                    label="tel2"
                                    name="tel2"
                                    className="m-0"
                                    onBlur={handleInputChange}
                                    readOnly={readOnly}
                                    inputMaxWidth={250}
                                    maxLength={16}
                                    type="tel"
                                    handleEnter
                                />
                                <FormikTextField
                                    label="fax"
                                    name="fax"
                                    className="m-0"
                                    onBlur={handleInputChange}
                                    readOnly={readOnly}
                                    inputMaxWidth={250}
                                    maxLength={16}
                                    type="tel"
                                    handleEnter
                                />
                            </bd.Flex>
                        </Form>
                    );
                }}
            </Formik>
        </div>
    );
};
