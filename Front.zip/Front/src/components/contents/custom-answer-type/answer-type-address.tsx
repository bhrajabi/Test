import { Form, Formik } from "formik";
import * as bd from "react-basic-design";
import * as yup from "yup";
import { useCSC } from "../../csc/use-csc";
import { FormikTextField } from "../../formik/formik-text-field";

interface FormValues {
    countryId: string;
    stateId: string;
    city: string;
    postalCode: string;
    address: string;
}

type AnswerTypeProps = {
    value: any;
    readOnly: boolean;
    answerRequired: boolean;
    onChange: (e: any) => void;
};
export const AnswerTypeAddress = ({ value, readOnly, answerRequired, onChange }: AnswerTypeProps) => {
    const csc = useCSC();

    var defaultValue = value && value.split(",");
    const getDefaultValue = (index: number) => (defaultValue && defaultValue[index] ? defaultValue[index] : "");

    const initialValues: FormValues = {
        countryId: "IR" /*getDefaultValue(0)*/,
        stateId: getDefaultValue(1),
        city: getDefaultValue(2),
        postalCode: getDefaultValue(3),
        address: getDefaultValue(4),
    };

    const getValue = (data: FormValues) => {
        const values = Object.values(data);
        if (values.every((value) => !value)) return "";
        const combined = values.map((value) => (value !== undefined && value !== null ? value : "")).join(",");
        return combined;
    };

    const validationSchema = () => {
        if (!answerRequired) return yup.object({});
        else {
            const schema: any = {};
            Object.keys(initialValues).forEach((field) => (schema[field] = yup.string().required(" ")));
            return yup.object(schema);
        }
    };

    return (
        <div>
            <Formik initialValues={initialValues} onSubmit={() => {}} validationSchema={validationSchema()}>
                {({ values }) => {
                    const isIran = values.countryId === "IR";
                    const handleInputChange = () => {
                        if (!answerRequired) onChange({ target: { value: getValue(values) } });
                        else {
                            var value = getValue(values);
                            var nullsValues = Object.values(values).filter((value) => value === undefined || value === "");
                            if (nullsValues.length > 0) value = "";
                            onChange({ target: { value } });
                        }
                    };
                    return (
                        <Form>
                            <bd.Flex wrap gap={2}>
                                {/* <FormikTextField
                                    label="country"
                                    name="countryId"
                                    type="select"
                                    className="m-0"
                                    items={[{ id: "", title: "" }, ...csc.countries]}
                                    onBlur={handleInputChange}
                                    readOnly
                                /> */}
                                <FormikTextField
                                    label="province"
                                    name="stateId"
                                    className="m-0"
                                    type={isIran ? "select" : "text"}
                                    items={isIran ? ["", ...csc.getStates("IR").map((x) => x.title)] : []}
                                    onBlur={handleInputChange}
                                    readOnly={readOnly}
                                    inputMaxWidth={250}
                                    maxLength={50}
                                    handleEnter
                                />
                                <FormikTextField
                                    label="city"
                                    name="city"
                                    className="m-0"
                                    onBlur={handleInputChange}
                                    readOnly={readOnly}
                                    maxLength={50}
                                    handleEnter
                                />
                                <FormikTextField
                                    label="postal-code"
                                    name="postalCode"
                                    className="m-0"
                                    onBlur={handleInputChange}
                                    readOnly={readOnly}
                                    maxLength={15}
                                    handleEnter
                                />
                                <FormikTextField
                                    label="address"
                                    name="address"
                                    className="m-0 flex-grow-1 w-100"
                                    onBlur={handleInputChange}
                                    readOnly={readOnly}
                                    maxLength={300}
                                    handleEnter
                                />
                            </bd.Flex>
                        </Form>
                    );
                }}
            </Formik>
        </div>
    );
};
