import React, { CSSProperties, forwardRef } from "react";
import * as bd from "react-basic-design";
import SvgDownload from "../../assets/icons/Download";
import { code } from "../basic/code";
import { notify } from "../basic/notify";
import { translate } from "../basic/text";

type ClipboardContainerProps = {
    onCopy?: (data: DataTransfer) => void;
    OnPastFile?: (row: ClipboardRow) => void;
    OnPastFiles?: (rows: ClipboardRow[]) => void;
    OnPasteText?: (row: ClipboardRow) => void;
    className?: string;
    style?: CSSProperties;
    children: React.ReactElement | React.ReactNode;
};

type ClipboardViewProps = {
    text: string | undefined;
    className?: string;
    style?: CSSProperties;
};

export type ClipboardRow = {
    file?: File;
    text?: string;
    type: string;
    kind: string;
    supported: boolean;
};

const ClipboardContainer = forwardRef<HTMLDivElement, ClipboardContainerProps>(
    ({ onCopy, OnPastFile, OnPastFiles, OnPasteText, className, style, children }, ref) => {
        const validTypes = [
            "text/plain",
            "image/png",
            "image/jpeg",
            "application/pdf",
            "application/zip",
            "application/vnd.rar",
            "application/json",
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            "application/vnd.ms-excel",
            "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            "application/msword",
        ];

        const isValidEvent = (event: React.ClipboardEvent<HTMLDivElement>): boolean => {
            if (!OnPastFile && !OnPasteText) return false;
            if (!event.clipboardData.items.length) return false;
            return true;
        };

        const handlePastMultiFiles = (items: DataTransferItemList) => {
            if (!OnPastFiles) return;

            const files: ClipboardRow[] = [];
            for (let i = 0; i < items.length; i++) {
                const item = items[i];

                const type = item.type;

                const supported = validTypes.includes(type);

                var file = item.getAsFile();
                if (file) files.push({ file, kind: "file", type, supported });
            }

            OnPastFiles(files);
        };

        const handlePastSingleFile = (event: React.ClipboardEvent<HTMLDivElement>, item: DataTransferItem) => {};

        const handleOnPast = (event: React.ClipboardEvent<HTMLDivElement>) => {
            if (!isValidEvent(event)) return;

            var itemList = Array.from(event.clipboardData.items);
            const items: ClipboardRow[] = [];

            const files = itemList.filter((x) => x.kind == "file");
            const strings = itemList.filter((x) => x.kind == "string");

            for (let i = 0; i < files.length; i++) {
                const obj = files[i];
                const type = obj.type;
                const kind = obj.kind;

                const supported = validTypes.includes(type);
                var file = obj.getAsFile();
                if (file) items.push({ type, kind, file, supported });
            }

            for (let i = 0; i < strings.length; i++) {
                const string = strings[i];
                const type = string.type;
                const kind = string.kind;
                const format = type.split("/")[1];
                if (type.startsWith("text")) {
                    if (format == "plain") {
                        if (event.target instanceof HTMLInputElement) return;
                        var text = event.clipboardData.getData("text");
                        items.push({ type, kind, text, supported: true });
                    } else if (format == "html") {
                        var text = event.clipboardData.getData("text/html");
                        const regex = /blob:https:\/\/[^\s"]+/i;
                        const matches = text.match(regex);
                        if (!matches || !matches.length) {
                            continue;
                        }

                        const supported = validTypes.includes(type);

                        fetch(matches[0])
                            .then((response) => {
                                if (!response.ok) return;
                                return response;
                            })
                            .then((response: any) => {
                                response.blob().then((blob: Blob) => {
                                    if (!blob) return notify.error(translate("file-not-found"));
                                    if (!validTypes.includes(blob.type))
                                        return notify.error(translate("file-type-@type-not-supported", { type: format }));

                                    const file = new File([blob], `${new Date().getTime()}.${blob.type.split("image/")[1]}`, {
                                        type: blob.type,
                                    });

                                    if (file) items.push({ type, kind: "file", file, supported });
                                });
                            })
                            .catch((err) => {
                                code.isDevelopmentEnv() && console.log(err);
                                return;
                            });
                    }
                }
            }

            const has_files = !!files.length;
            const is_multi_file = files.length > 1;
            const has_text = !!strings.length;

            if (has_files) {
                if (is_multi_file) {
                    OnPastFiles && OnPastFiles(items);
                } else {
                    OnPastFile && OnPastFile(items[0]);
                }
            } else if (has_text && OnPasteText) OnPasteText(items[0]);
        };

        return (
            <div
                ref={ref}
                className={className}
                style={style}
                onCopy={(event) => onCopy && onCopy(event.clipboardData)}
                onPaste={handleOnPast}>
                <React.Fragment>{children}</React.Fragment>
            </div>
        );
    }
);

const ClipboardView = forwardRef<HTMLDivElement, ClipboardViewProps>(({ text, style, className }, ref) => {
    const handleOnCopy = async () => {
        if (!text) return;

        await window.navigator.clipboard.writeText(text);
        notify.success("text-copied");
    };

    if (!text) return <></>;
    return (
        <span style={style} className={className} ref={ref}>
            <bd.Button variant="icon" onClick={handleOnCopy}>
                <SvgDownload className="small" />
            </bd.Button>
            <div className="text-muted">{text}</div>
        </span>
    );
});

export default {
    Container: ClipboardContainer, //ex : <Clipboard.Container OnPasteFile={OnPastImage} OnPasteText={OnPastText}></Clipboard.Container>
    View: ClipboardView, //ex : <Clipboard.View text="text to copy" />
};
