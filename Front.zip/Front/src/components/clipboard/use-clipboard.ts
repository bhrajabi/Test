import { useEffect, useMemo, useState } from "react";
import { translate } from "../basic/text";

export interface IUseClipboard {
    clipboard: string;
    read: (onPasteImage: (file: File) => void, onPasteText: (text: string) => void, onFailed: (err: string) => void) => void;
    write: (text: string) => Promise<boolean>;
}

export const useClipboard = (): IUseClipboard => {
    const supported = useMemo(() => !!window.navigator.clipboard, []);
    const [clipboard, setClipboard] = useState("");

    const read = async (onPasteImage: (file: File) => void, onPasteText: (text: string) => void, onFailed: (err: string) => void) => {
        window.navigator.clipboard.read().then(async (clipboard_items) => {
            if (!clipboard_items) return onFailed(translate("clipboard-is-empty"));

            for (const item of clipboard_items) {
                for (const type of item.types) {
                    if (type.startsWith("image/")) {
                        const blob = await item.getType(type);
                        const file = new File([blob], "pasted-image.png", { type });
                        onPasteImage(file);
                        return;
                    } else if (type.startsWith("text/")) {
                        const text = await navigator.clipboard.readText();
                        return onPasteText(text);
                    }
                }
            }

            return onFailed(translate("clipboard-is-empty"));
        });
    };

    const write = async (text: string): Promise<boolean> => {
        if (!supported) return false;
        setClipboard(text);
        await window.navigator.clipboard.writeText(text);
        return true;
    };

    return {
        clipboard,
        read,
        write,
    };
};
