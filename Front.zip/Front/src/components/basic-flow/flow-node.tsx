import { Handle, Position, useStoreApi } from "@xyflow/react";
import classNames from "classnames";
import { Handle as HandleType, INode } from "./types";

export const BasicFlowNode = (_node: any) => {
    const store = useStoreApi();
    const { nodes } = store.getState();
    const node = nodes.find((x) => x.id == _node.id) as INode;

    const getLocation = (h: HandleType) => {
        switch (h.edge) {
            case "left":
                return { left: 0, top: h.loc + "%" };
            case "right":
                return { right: 0, top: h.loc + "%" };
            case "top":
                return { left: h.loc + "%", top: 0 };
            case "bottom":
                return { left: h.loc + "%", bottom: 0 };
        }
        return {};
    };

    return (
        <>
            <div className={classNames({ "wf-animated-border": node._isSelected })}>
                {node._component}
                {node._handles.map((h: HandleType) => {
                    return (
                        <Handle
                            key={h.id}
                            id={h.id}
                            type={h.isTarget ? "target" : "source"}
                            position={h.edge as Position}
                            style={{
                                background: h.isTarget ? "#fff" : "#777",
                                border: h.isTarget ? "1px solid #333" : "1px solid #777",
                                // background: "transparent",
                                // border: "transparent" ,
                                ...getLocation(h),
                                width: 3,
                                height: 3,
                            }}
                        />
                    );
                })}
            </div>
        </>
    );
};
