import { Edge, Node, Position, XYPosition } from "@xyflow/react";
import { ReactNode } from "react";

export interface IComponent {
    id: string;
    element: HTMLDivElement;
}

export type DiagramSelection = { nodeId?: string; edgeId?: string };

export interface INode extends Node {
    _handles: Handle[];
    _component: ReactNode;
    _size: { width: number; height: number };
    _isSelected: boolean;
}

export interface IEdge extends Edge {}

export type Handle = {
    id: string;
    isTarget: boolean;
    edge: Position;
    link: IEdge;
    targetNode: INode;
    index: number;
    sortIndex: number;
    pos: XYPosition;
    loc: string;
};

export interface IHandle {
    id: string;
    type: string;
    edge: any;
    source: string;
    target: string;
}

export interface IEdgeStyle {
    stroke?: string;
    strokeWidth?: number;
}
