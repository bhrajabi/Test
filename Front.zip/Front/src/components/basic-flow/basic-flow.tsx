import { Background, Controls, Panel, Position, ReactFlow, useEdgesState, useNodesState } from "@xyflow/react";
import dagre from "dagre";
import { KeyboardEvent, ReactNode, useCallback, useEffect } from "react";

import "@xyflow/react/dist/style.css";
import { BasicFlowEdge } from "./flow-edge";
import { BasicFlowNode } from "./flow-node";
import { IEdge, INode } from "./types";
import { getEdge } from "./utils";

type BasicFlowProps = {
    autolayoutSensor?: number;
    vertical?: boolean;
    initialEdges: any[];
    initialNodes: any[];
    readOnly?: boolean;
    rankSep: number;
    nodeSep: number;
    selection: { nodeId?: string; edgeId?: string };
    panel: ReactNode;

    onClickNode?: (id: string, ev: MouseEvent) => void;
    onDoubleClickNode?: (id: string, ev: MouseEvent) => void;
    onClickEdge?: (id: string, ev: MouseEvent) => void;
    onDoubleClickEdge?: (id: string, ev: MouseEvent) => void;

    onClickPane?: (ev: MouseEvent) => void;
    onKeyDown?: (ev: KeyboardEvent<HTMLDivElement>) => void;
    onKeyUp?: (ev: KeyboardEvent<HTMLDivElement>) => void;
};

export const BasicFlow = ({
    autolayoutSensor,
    vertical,
    initialNodes,
    initialEdges,
    readOnly,
    rankSep,
    nodeSep,
    selection,
    panel,

    onClickNode,
    onDoubleClickNode,
    onClickEdge,
    onDoubleClickEdge,
    onClickPane,
    onKeyDown,
    onKeyUp,
}: BasicFlowProps) => {
    const [nodes, setNodes, onNodesChange] = useNodesState<INode>([]);
    const [edges, setEdges, onEdgesChange] = useEdgesState<IEdge>([]);

    useEffect(() => {
        const data = autoLayout(initialNodes, initialEdges, vertical ?? false, rankSep, nodeSep);
        setNodes(data.nodes);
        setEdges(data.edges);
    }, [initialEdges, initialNodes, autolayoutSensor, vertical]);

    // useEffect(() => {
    //     if (!nodes.length || !edges.length) return;
    //     const _nodes = initialNodes.map((x) => nodes.find((n) => n.id == x.id) ?? x);
    //     const _edges = initialEdges.map((x) => edges.find((e) => e.id == x.id) ?? x);
    //     const data = calculateHandles(_nodes, _edges);
    //     setNodes(data.nodes);
    //     setEdges(data.edges);
    // }, [initialEdges.length, initialNodes.length]);

    useEffect(() => {
        if (nodes.length == 0) return;
        setNodes(nodes.map((x) => ({ ...x, _isSelected: x.id == selection.nodeId })));
        setEdges(edges.map((x) => ({ ...x, animated: x.id == selection.edgeId })));
    }, [selection]);

    return (
        <>
            <ReactFlow
                nodes={nodes}
                edges={edges}
                nodesConnectable={false}
                draggable={!readOnly}
                elementsSelectable
                //elementsSelectable={!readOnly}

                nodeTypes={{ basicFlowNode: BasicFlowNode }}
                edgeTypes={{ basicFlowEdge: BasicFlowEdge }}
                connectionLineStyle={{ stroke: "#fff" }}
                snapToGrid={true}
                snapGrid={[4, 4]}
                defaultViewport={{ x: 0, y: 0, zoom: 1 }}
                fitView
                attributionPosition="bottom-left"
                //
                onEdgeClick={(ev, edge) => onClickEdge && onClickEdge(edge.id, ev as any)}
                onEdgeDoubleClick={(ev, edge) => onDoubleClickEdge && onDoubleClickEdge(edge.id, ev as any)}
                onNodeClick={(ev, node) => onClickNode && onClickNode(node.id, ev as any)}
                onNodeDoubleClick={(ev, node) => onDoubleClickNode && onDoubleClickNode(node.id, ev as any)}
                onPaneClick={(ev) => onClickPane && onClickPane(ev as any)}
                onKeyDown={onKeyDown}
                onKeyUp={onKeyUp}
                onNodesChange={(changes) => {
                    if (changes.some((x) => x.type == "position")) calculateHandles(nodes, edges);
                    onNodesChange(changes);
                }}
                onEdgesChange={onEdgesChange}
            >
                <Panel>{panel}</Panel>

                <Controls
                    // className="mt-5 pt-3"
                    // position="top-left"
                    showInteractive={false}
                    // showFitView={false}
                    // showZoom={false}
                    // style={{ boxShadow: "none" }}
                >
                    {/* <ControlButton onClick={onAddNode} className="btn btn-contained btn-primary mb-2 rounded-0" title="Add node">
                        <SvgAdd style={{ maxWidth: "unset", maxHeight: "unset", fontSize: 24 }} />
                    </ControlButton>

                    <ControlButton
                        onClick={onDeleteSelection}
                        className="btn btn-contained btn-secondary text-bg rounded-0"
                        title="Delete selected element"
                    >
                        <SvgDelete style={{ maxWidth: "unset", maxHeight: "unset", fontSize: 24 }} />
                    </ControlButton> */}
                </Controls>

                <Background />
            </ReactFlow>
        </>
    );
};

const autoLayout = (nodes: INode[], edges: IEdge[], vertical: boolean, rankSep: number, nodeSep: number) => {
    const dagreGraph = new dagre.graphlib.Graph();
    dagreGraph.setDefaultEdgeLabel(() => ({}));
    dagreGraph.setGraph({ rankdir: vertical ? "TB" : "LR", ranksep: rankSep, nodesep: nodeSep });
    nodes.forEach((node) => dagreGraph.setNode(node.id, node._size));
    edges.forEach((edge) => dagreGraph.setEdge(edge.source, edge.target));
    dagre.layout(dagreGraph);

    nodes = nodes.map((node) => ({ ...node, position: dagreGraph.node(node.id) }));

    return calculateElements(nodes, edges);
};

const calculateElements = (nodes: INode[], edges: IEdge[]) => {
    edges = edges.map((x) => ({ ...x }));
    nodes = nodes.map((node) => ({ ...node }));
    return calculateHandles(nodes, edges);
};

const calculateHandles = (nodes: INode[], edges: IEdge[]) => {
    nodes.forEach((node) => {
        node._handles = [];
    });

    // calculate node handles
    edges.forEach((link) => {
        const createHandle = (isTarget: boolean, sourceNode: INode, targetNode: INode) => {
            const h = {
                id: `${sourceNode.id}-${link.id}`,
                isTarget,
                edge: Position.Left,
                link,
                targetNode,
                sortIndex: 0,
                index: 0,
                loc: "0",
                pos: { x: 0, y: 0 },
            };
            if (isTarget) link.targetHandle = h.id;
            else link.sourceHandle = h.id;
            return h;
        };

        const sourceNode = nodes.find((node) => node.id == link.source);
        const targetNode = nodes.find((node) => node.id == link.target);
        if (sourceNode && targetNode) {
            sourceNode._handles.push(createHandle(false, sourceNode, targetNode));
            targetNode._handles.push(createHandle(true, targetNode, sourceNode));
        }
    });

    // calculate handle-index
    nodes.forEach((node) => {
        adjustFlowNodeEdges(node);
    });
    return { nodes, edges };
};

const adjustFlowNodeEdges = (node: INode) => {
    node._handles.forEach((h) => (h.edge = getEdge(node, h.targetNode).position));

    setHandleSortIndex(Position.Top, node);
    setHandleSortIndex(Position.Right, node);
    setHandleSortIndex(Position.Bottom, node);
    setHandleSortIndex(Position.Left, node);

    node._handles = node._handles.sort((a, b) => a.sortIndex - b.sortIndex);
};

const setHandleSortIndex = (edge: Position, node: INode) => {
    const _handles = node._handles.filter((x) => x.edge == edge);

    _handles.forEach((h, hIndex) => {
        const frac = (hIndex + 1) / (_handles.length + 1);
        h.index = hIndex;
        h.loc = (100 * frac).toFixed(1);
        const delta = -3;
        switch (edge) {
            case Position.Left:
                h.sortIndex = h.targetNode.position.y * 10 + hIndex;
                h.pos = {
                    x: node.position.x + delta,
                    y: node.position.y + node._size.height * frac,
                };
                break;

            case Position.Right:
                h.sortIndex = h.targetNode.position.y * 10 + hIndex;
                h.pos = {
                    x: node.position.x + node._size.width - delta,
                    y: node.position.y + node._size.height * frac,
                };
                break;

            case "top":
                h.sortIndex = h.targetNode.position.x * 10 + hIndex;
                h.pos = {
                    x: node.position.x + node._size.width * frac,
                    y: node.position.y + delta,
                };
                break;

            case "bottom":
                h.sortIndex = h.targetNode.position.x * 10 + hIndex;
                h.pos = {
                    x: node.position.x + node._size.width * frac,
                    y: node.position.y + node._size.height - delta,
                };
                break;
        }
    });
};
