import { useEffect, useState } from "react";

export const MousePositionCircle = () => {
    const [mousePos, setMousePos] = useState({ x: 0, y: 0 });

    useEffect(() => {
        const handleMouseMove = (event: any) => {
            setMousePos({ x: event.clientX, y: event.clientY });
        };

        window.addEventListener("mousemove", handleMouseMove);
        return () => {
            window.removeEventListener("mousemove", handleMouseMove);
        };
    }, []);

    return (
        <div>
            <p>
                Mouse Position: X: {mousePos.x}, Y: {mousePos.y}
            </p>
            <svg style={{ position: "absolute", left: mousePos.x, top: mousePos.y }}>
                <circle cx="0" cy="0" r="20" fill="red" />
            </svg>
        </div>
    );
};
