// this helper function returns the intersection point

import { Position } from "@xyflow/react";

// of the line between the center of the intersectionNode and the target node
function getNodeIntersection(source: any, target: any) {
    // https://math.stackexchange.com/questions/1724792/an-algorithm-for-finding-the-intersection-point-between-a-center-of-vision-and-a
    const { width: sourceNodeWidth, height: sourceNodeHeight } = source._size;
    const intersectionNodePosition = source.position;
    const targetPosition = target.position;

    const w = sourceNodeWidth / 2;
    const h = sourceNodeHeight / 2;

    const x2 = intersectionNodePosition.x + w;
    const y2 = intersectionNodePosition.y + h;
    const x1 = targetPosition.x + target._size.width / 2;
    const y1 = targetPosition.y + target._size.height / 2;

    const xx1 = (x1 - x2) / (2 * w) - (y1 - y2) / (2 * h);
    const yy1 = (x1 - x2) / (2 * w) + (y1 - y2) / (2 * h);
    const a = 1 / (Math.abs(xx1) + Math.abs(yy1));
    const xx3 = a * xx1;
    const yy3 = a * yy1;
    const x = w * (xx3 + yy3) + x2;
    const y = h * (-xx3 + yy3) + y2;

    return { x, y };
}

// returns the position (top,right,bottom or right) passed node compared to the intersection point
export function getEdge(node: any, target: any) {
    const intersectionPoint = getNodeIntersection(node, target);
    const n = { ...node.position, ...node };
    const nx = Math.round(n.x);
    const ny = Math.round(n.y);
    const px = Math.round(intersectionPoint.x);
    const py = Math.round(intersectionPoint.y);

    if (px <= nx + 1) {
        return { position: Position.Left, intersectionPoint };
    }
    if (px >= nx + n._size.width - 1) {
        return { position: Position.Right, intersectionPoint };
    }
    if (py <= ny + 1) {
        return { position: Position.Top, intersectionPoint };
    }
    if (py >= n.y + n._size.height - 1) {
        return { position: Position.Bottom, intersectionPoint };
    }

    return { position: Position.Top, intersectionPoint };
}
