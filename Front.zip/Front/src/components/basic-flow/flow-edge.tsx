import { BaseEdge, Edge, EdgeLabelRenderer, EdgeProps, getBezierPath, Position, useStoreApi } from "@xyflow/react";
import { Handle, INode } from "./types";
import SvgChat from "../../assets/chat";

export const BasicFlowEdge = (edge: EdgeProps<Edge<{ label: string }>>) => {
    const store = useStoreApi();
    const { nodes } = store.getState();
    const sNode = nodes.find((x) => x.id == edge.source) as INode;
    const tNode = nodes.find((x) => x.id == edge.target) as INode;

    const sh = sNode._handles.find((x) => x.link.id == edge.id) as Handle;
    const th = tNode._handles.find((x) => x.link.id == edge.id) as Handle;
    if (!sh || !th) return <>EDGE ERROR #{edge.id}</>;

    // bezier path
    const par = {
        sourceX: sh.pos.x,
        sourceY: sh.pos.y,
        sourcePosition: sh.edge as Position,
        targetX: th.pos.x,
        targetY: th.pos.y,
        targetPosition: th.edge as Position,
    };
    const [edgePath, labelX, labelY] = getBezierPath(par);

    // Adjust label position
    const labelOffsetX = 0;
    const labelOffsetY = 15;
    const adjustedLabelX = labelX + (par.sourceX > par.targetX ? -labelOffsetX : labelOffsetX);
    const adjustedLabelY = labelY + (par.sourceY > par.targetY ? -labelOffsetY : labelOffsetY);

    let style = edge.style;
    if (edge.animated) style = { ...style, strokeWidth: 2 };

    return (
        <>
            <BaseEdge id={edge.id} path={edgePath} style={style} markerEnd={edge.markerEnd} />
            <EdgeLabelRenderer>
                <div
                    style={{
                        position: "absolute",
                        transform: `translate(-50%, -50%) translate(${adjustedLabelX}px, ${adjustedLabelY}px)`,
                    }}
                    className="nodrag nopan"
                >
                    {edge.label}
                </div>
            </EdgeLabelRenderer>
        </>
    );
};
