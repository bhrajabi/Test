import { apiConfig } from "../../api/config";

export function CompanyLogo({ uniqueId, className, size }: { uniqueId: string; className?: string; size?: number }) {
    if (!size || size <= 0) size = 64;
    return (
        <div className={className}>
            <img loading="lazy" src={`${apiConfig.companyLogoUrl}?companyId=${uniqueId}&h=${size}`} style={{ width: size, height: size }} />
        </div>
    );
}
