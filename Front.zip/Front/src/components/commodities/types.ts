import { ReactElement } from "react";

export type ICommodityType = {
    id: string;
    title: string;
    isExpanded?: boolean;
};

export interface ICommodity {
    code: string;
    title: string;
    titleEN: string;
}

export interface INodeCommodity extends ICommodity {
    parentCode?: string;
    typeId?: string;
    level?: number;

    lastUsedAt?: string;

    parentTitle1?: string;
    parentTitleEN1?: string;
    parentTitle2?: string;
    parentTitleEN2?: string;
    parentTitle3?: string;
    parentTitleEN3?: string;
    parentTitle4?: string;
    parentTitleEN4?: string;

    isFavorite?: boolean;
    isRecent?: boolean;

    isLeaf?: boolean;
    isLoaded?: boolean;
    isLoading: boolean;
    isExpanded?: boolean;
}

export type SearchCommodity = {
    text?: string;
    textEN?: string;

    code: string;
    title: string;
    titleEN: string;

    parentCode?: string;
    typeId?: string;

    lastUsedAt?: string;

    parentTitle1?: string;
    parentTitleEN1?: string;
    parentTitle2?: string;
    parentTitleEN2?: string;
    parentTitle3?: string;
    parentTitleEN3?: string;
    parentTitle4?: string;
    parentTitleEN4?: string;

    isFavorite?: boolean;
    isLoading?: boolean;
    isRecent?: boolean;

    isLeaf?: boolean;
    loadedChildren?: boolean;
    isSelected?: boolean;
};

export interface ICommodityBase {
    disabled?: boolean;
    commodities?: INodeCommodity[];
    hideFavorite?: boolean;

    onCommoditiesSelected?: (commodities: ICommodity[]) => void;
    onCommoditySelected?: (commodity: ICommodity) => void;
}

export interface CommodityProviderProps extends ICommodityBase {
    children:
        | React.ReactNode
        | ((modal: {
              modalIsOpen: boolean;
              openModal: VoidFunction;
              closeModal: VoidFunction;
          }) => React.ReactNode | ReactElement | React.JSX.Element);
}
