import { Form, Formik } from "formik";
import React from "react";
import * as bd from "react-basic-design";
import * as yup from "yup";
import SvgArrowRightAlt from "../../assets/icons/ArrowRightAlt";
import SvgFolderOpen from "../../assets/icons/FolderOpen";
import { code } from "../basic/code";
import { LoadingButton } from "../basic/loading-button";
import { T, translate } from "../basic/text";
import { FormikTextField } from "../formik/formik-text-field";
import { CheckBoxView } from "./commodity-tree-item";
import { ICommodity, SearchCommodity } from "./types";
import { useCommodities } from "./use-commodities";

export const CommoditySearchView = ({
    disabled,
    selectedCommodities,
    onLookup,
}: {
    disabled: boolean;
    selectedCommodities: ICommodity[];
    onLookup: (code: string) => void;
}) => {
    const service = useCommodities();

    const onSubmit = ({ title }: { title: string }) => {
        if (!title || title.trim().length < 2) return;
        service.search(title);
    };

    return (
        <>
            <bd.Flex vertical className="p-3" gap={2}>
                <Formik
                    initialValues={{ title: "" }}
                    validationSchema={yup.object({
                        title: yup.string().min(2, translate("at-least-enter-2-letters")).required(" "),
                    })}
                    onSubmit={onSubmit}
                >
                    {(formik) => (
                        <Form>
                            <bd.Flex align="center" content="start" gap={1}>
                                <FormikTextField
                                    className="m-0"
                                    name="title"
                                    placeholder={translate("commodity-title")}
                                    width="22rem"
                                    maxLength={100}
                                />

                                <LoadingButton
                                    variant="contained"
                                    loading={service.isLoadingResult}
                                    label={<T>search</T>}
                                    isValid={formik.isValid}
                                />
                            </bd.Flex>
                        </Form>
                    )}
                </Formik>

                <bd.TreeView compact>
                    <SearchResultTree
                        disabled={disabled}
                        title="search-in-commodities"
                        list={service.searchResult}
                        selectedCommodities={selectedCommodities}
                        onLookup={onLookup}
                    />

                    <SearchResultTree
                        isMaterial
                        disabled={disabled}
                        title="search-in-material-base"
                        list={service.materialBaseResult}
                        selectedCommodities={selectedCommodities}
                        onLookup={onLookup}
                    />

                    <SearchResultTree
                        isMaterial
                        disabled={disabled}
                        title="search-in-materials"
                        list={service.materialsResult}
                        selectedCommodities={selectedCommodities}
                        onLookup={onLookup}
                    />
                </bd.TreeView>
            </bd.Flex>
        </>
    );
};

const SearchResultTree = ({
    isMaterial,
    title,
    disabled,
    list,
    selectedCommodities,
    onLookup,
}: {
    isMaterial?: boolean;
    disabled: boolean;
    title: string;
    list: SearchCommodity[];
    selectedCommodities: ICommodity[];
    onLookup: (code: string) => void;
}) => {
    return (
        <>
            <bd.TreeViewItem
                title={
                    <>
                        <T>{title}</T>

                        <small className="text-muted m-s-2">
                            ({list.length} <T>item</T>)
                        </small>
                    </>
                }
                className="mt-4 text-primary"
                expanded
                compact
            >
                {list.length == 0 && <bd.TreeViewItem variant="text" compact title={<T className="text-muted">nothing-found</T>} />}
                {list.length > 0 &&
                    list.map((c, cIndex) => (
                        <React.Fragment key={cIndex + "-" + c.code}>
                            {!isMaterial && (
                                <CommoditySearchResultItem
                                    disabled={disabled}
                                    commodity={c}
                                    selectedCommodities={selectedCommodities}
                                    onLookup={onLookup}
                                />
                            )}
                            {isMaterial && <MaterialSearchResultItem material={c} onClick={(x: any) => onLookup(x.commodityCode)} />}
                        </React.Fragment>
                    ))}
            </bd.TreeViewItem>
        </>
    );
};

const CommoditySearchResultItem = ({
    isMaterial,
    disabled,
    commodity,
    selectedCommodities,
    onLookup,
}: {
    isMaterial?: boolean;
    disabled: boolean;
    commodity: SearchCommodity;
    selectedCommodities: ICommodity[];
    onLookup: (x: string) => void;
}) => {
    const is_checked = commodity.isLeaf && selectedCommodities?.some((x) => x.code == commodity.code);

    return (
        <bd.TreeViewItem
            title={
                <div>
                    <bd.Flex align="center" gap={1}>
                        {commodity.isLeaf && (
                            <div
                                onClick={(ev) => {
                                    ev.preventDefault();
                                    ev.stopPropagation();
                                    onLookup(commodity?.code);
                                }}
                            >
                                <CheckBoxView disabled={disabled} checked={is_checked} />
                            </div>
                        )}
                        {!commodity.isLeaf && <SvgFolderOpen className="text-warning" />}

                        {isMaterial && <span>{commodity.text}</span>}

                        {!isMaterial && (
                            <span>
                                {commodity.code} - {commodity.title}
                            </span>
                        )}
                    </bd.Flex>

                    <bd.Flex align="center" content="start" className="p-s-4 mb-2 text-muted small" wrap gap={2}>
                        <T append=":">in-group</T>
                        {commodity.parentTitle1 && <span>{commodity.parentTitle1}</span>}
                        {commodity.parentTitle2 && <>{">"}</>}
                        {commodity.parentTitle2 && <span>{commodity.parentTitle2}</span>}
                        {commodity.parentTitle3 && <>{">"}</>}
                        {commodity.parentTitle3 && <span>{commodity.parentTitle3}</span>}
                        {commodity.parentTitle4 && <>{">"}</>}
                        {commodity.parentTitle4 && <span>{commodity.parentTitle4}</span>}
                        {isMaterial && (
                            <>
                                <>{">"}</>
                                <span>{commodity.title}</span>
                            </>
                        )}
                    </bd.Flex>
                </div>
            }
            variant="text"
            compact
            onClick={() => onLookup(commodity?.code)}
            label={<></>}
        />
    );
};

const MaterialSearchResultItem = ({ material, onClick }: { material: any; onClick: (x: SearchCommodity) => void }) => {
    return (
        <bd.TreeViewItem
            title={
                <div>
                    <bd.Flex align="center" gap={1}>
                        <SvgArrowRightAlt className="text-primary rtl-rotate-180" />

                        <span>
                            {material.materialNo && <span>{material.materialNo} - </span>}
                            {code.ifRTL(material.title, material.titleEN)}
                        </span>
                    </bd.Flex>
                    <bd.Flex className="m-s-4 mb-2 small text-muted">
                        <T append=":">in-group</T>
                        <span>
                            {material.commodityCode} - {code.ifRTL(material.commodityTitle, material.commodityTitleEN)}
                        </span>
                    </bd.Flex>
                </div>
            }
            variant="text"
            compact
            onClick={() => onClick(material)}
        />
    );
};
