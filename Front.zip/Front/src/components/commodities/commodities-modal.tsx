import { ICommodity } from "./types";
import { CommoditiesModalView } from "./commodities-modal-view";

type CommoditiesModalProps = {
    show: boolean;
    hideFavorite?: boolean;
    singleSelect: boolean;
    disabled?: boolean;
    selectedCommodities: ICommodity[];
    onHide: VoidFunction;
    setSelectedCommodities: (selectedCommodity: ICommodity[]) => void;
};

export const CommoditiesModal = ({
    show,
    hideFavorite,
    singleSelect,
    disabled = false,
    selectedCommodities,

    onHide,
    setSelectedCommodities,
}: CommoditiesModalProps) => {
    return (
        <CommoditiesModalView
            show={show}
            onHide={onHide}
            hideFavorite={!!hideFavorite}
            singleSelect={singleSelect}
            disabled={disabled}
            selectedCommodities={selectedCommodities}
            setSelectedCommodities={setSelectedCommodities}
        />
    );
};
