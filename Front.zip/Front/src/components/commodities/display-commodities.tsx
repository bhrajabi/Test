import * as bd from "react-basic-design";
import { ICommodity } from "./types";
import { N } from "../basic/n";
import { getCommodityTitle } from "./utiles";

export const DisplayCommodities = ({ commodities }: { commodities: ICommodity[] }) => {
    return (
        <bd.Flex gap={2} wrap align="center">
            {commodities.map((x, index) => (
                <bd.Chip
                    key={index}
                    label={
                        <span>
                            <N>{x.code}</N>
                            <span> - {getCommodityTitle(x)}</span>
                        </span>
                    }
                    size="sm"
                    className="border"
                />
            ))}
        </bd.Flex>
    );
};
