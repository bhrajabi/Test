import { useState } from 'react';
import * as bd from 'react-basic-design';
import { CommoditiesButton } from './commodities-button';
import { CommoditiesView } from './commodities-view';
import { SelectCommodityModal } from './commodity-modal';
import { InlistCommoditiesButton } from './inlist-commodities-button';
import { SelectedCommoditiesView } from './selected-commodities-view';
import { ICommodity } from './types';
import { useCommodities } from './use-commodities';

export const Commodities = ({
    commodities,
    hideFavorite = false,
    singleSelect,
    isView = false,
    disabled = false,
    inList = false,
    hideButton,
    inListTitle,
    buttonTitle,
    buttonClassName,
    buttonVariant,
    buttonSize,
    hideRecentDropDownButton,
    hideSelectedCommodities,
    onCommoditiesSelected,
}: {
    isView?: boolean;
    hideFavorite?: boolean;
    isSelectable?: boolean;
    singleSelect?: boolean;
    disabled?: boolean;
    commodities?: ICommodity[];
    inList?: boolean;
    hideButton?: boolean;
    hideRecentDropDownButton?: boolean;
    inListTitle?: string | React.ReactNode;
    buttonTitle?: string | React.ReactNode;
    buttonClassName?: string;
    buttonVariant?: 'inherit' | 'contained' | 'flat' | 'icon' | 'text' | 'outline';
    buttonSize?: 'sm';
    hideSelectedCommodities?: boolean;
    onCommoditiesSelected?: (selectedCommodities: ICommodity[]) => void;
}) => {
    const service = useCommodities();
    const [showModal, setShowModal] = useState(false);

    const selection = commodities ?? [];

    const setSelection = (list: ICommodity[]) => {
        if (disabled) return;
        if (onCommoditiesSelected) {
            service.updateRecents(list);
            onCommoditiesSelected(list);
        }
    };

    const onRemoveCommodity = (c: ICommodity) => {
        if (!commodities) return;
        setSelection(commodities.filter((x) => x.code != c.code));
    };

    const onSelectRecent = (c: ICommodity) => {
        if (disabled) return;
        if (singleSelect) setSelection([c]);
        else {
            const is_selected = selection.some((x) => x.code == c.code);
            if (is_selected) {
                if (onCommoditiesSelected) service.updateRecents([c]);
            } else setSelection([...selection, c]);
        }
    };

    const onSubmitModal = (list: ICommodity[]) => {
        setSelection(list);
        setShowModal(false);
    };

    return (
        <>
            {!isView && showModal && (
                <>
                    <SelectCommodityModal
                        show={showModal}
                        onHide={() => setShowModal(false)}
                        selectedCommodities={selection}
                        onRemoveCommodity={onRemoveCommodity}
                        hideFavorite={hideFavorite}
                        singleSelect={!!singleSelect}
                        disabled={disabled}
                        onSubmit={onSubmitModal}
                    />
                </>
            )}
            {isView && (
                <CommoditiesView
                    hideFavorite={hideFavorite}
                    singleSelect={!!singleSelect}
                    disabled={disabled}
                    selectedCommodities={selection}
                    setSelectedCommodities={setSelection}
                />
            )}

            {!!commodities && !isView && (
                <bd.Flex vertical content="start" align="start" gap="2" className="w-100">
                    {!isView && !inList && !hideButton && (
                        <CommoditiesButton
                            disabled={disabled}
                            hideFavorite={hideFavorite}
                            title={buttonTitle}
                            hideRecentDropDownButton={hideRecentDropDownButton}
                            buttonClassName={buttonClassName}
                            buttonVariant={buttonVariant}
                            buttonSize={buttonSize}
                            selectedCommodities={selection}
                            onSelectRecent={onSelectRecent}
                            onClick={() => setShowModal(true)}
                        />
                    )}
                    {!disabled && inList && <InlistCommoditiesButton title={inListTitle} onClick={() => setShowModal(true)} />}
                    {!inList && !hideSelectedCommodities && (
                        <SelectedCommoditiesView
                            disabled={disabled}
                            onRemoveCommodity={onRemoveCommodity}
                            selectedCommodities={selection}
                        />
                    )}
                </bd.Flex>
            )}
        </>
    );
};
