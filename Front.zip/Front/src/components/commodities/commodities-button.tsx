import { useEffect } from 'react';
import * as bd from 'react-basic-design';
import SvgAdd from '../../assets/icons/Add';
import SvgFavorite from '../../assets/icons/Favorite';
import SvgFavoriteBorder from '../../assets/icons/FavoriteBorder';
import { T } from '../basic/text';
import { ICommodity, SearchCommodity } from './types';
import { useCommodities } from './use-commodities';

export const CommoditiesButton = ({
    disabled,
    hideFavorite,
    hideRecentDropDownButton,
    title,
    buttonClassName,
    buttonVariant,
    buttonSize,
    selectedCommodities,
    onClick,
    onSelectRecent,
}: {
    disabled?: boolean;
    hideFavorite: boolean;
    hideRecentDropDownButton?: boolean;
    title?: string | React.ReactNode;
    buttonClassName?: string;
    buttonVariant?: 'inherit' | 'contained' | 'flat' | 'icon' | 'text' | 'outline';
    buttonSize?: 'sm';
    selectedCommodities: ICommodity[];
    onSelectRecent: (x: SearchCommodity) => void;
    onClick: VoidFunction;
}) => {
    const service = useCommodities();

    useEffect(() => {
        if (service.isInitialized || service.isInitializing || service.isBusy) return;
        service.init();
    }, []);

    // return (
    //     <div style={{ minHeight: 100, minWidth: 100, backgroundColor: service.isInitializing ? "red" : "blue" }}>
    //         service.isInitializing
    //     </div>
    // );

    return (
        <>
            {disabled && (
                <bd.Button
                    variant={buttonVariant ?? 'outline'}
                    size={buttonSize}
                    onClick={onClick}
                    type="button"
                    className={buttonClassName}>
                    {title ? (
                        <T>{title}</T>
                    ) : (
                        <>
                            <T>view</T>
                            <small className="m-s-1">
                                ({selectedCommodities.length} <T>item</T>)
                            </small>
                        </>
                    )}
                </bd.Button>
            )}

            {!disabled && (
                <bd.ButtonGroup variant={buttonVariant ?? 'outline'} size={buttonSize}>
                    <bd.Button onClick={onClick} type="button" className={buttonClassName}>
                        <SvgAdd />
                        <T>{title ?? 'select'}</T>
                    </bd.Button>

                    {!hideRecentDropDownButton && !hideFavorite && service.recent.length > 0 && (
                        <bd.Button
                            disabled={disabled}
                            type="button"
                            className="border-start-0"
                            menu={
                                <bd.Menu>
                                    {service.recent.map((r) => {
                                        const rcom = service.commodities.find((x) => x.code == r);
                                        if (!rcom) return <></>;
                                        return (
                                            <bd.MenuItem key={r} onClick={() => onSelectRecent(rcom)}>
                                                <bd.Flex content="between" align="center">
                                                    {service.favorites.includes(r) ? (
                                                        <SvgFavorite style={{ color: 'red', opacity: 0.8, fontSize: '1rem' }} />
                                                    ) : (
                                                        <SvgFavoriteBorder style={{ fontSize: '1rem' }} />
                                                    )}
                                                    <span className="m-s-2">{!bd.helper.isRTL() ? rcom.titleEN : rcom.title}</span>
                                                </bd.Flex>
                                            </bd.MenuItem>
                                        );
                                    })}
                                </bd.Menu>
                            }
                            disableRipple></bd.Button>
                    )}
                </bd.ButtonGroup>
            )}
        </>
    );
};
