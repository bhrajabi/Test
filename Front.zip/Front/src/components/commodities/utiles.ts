import { ICommodity, INodeCommodity } from "./types";
import * as bd from "react-basic-design";

export const loadLinearList = (node: INodeCommodity) => {
    const items: INodeCommodity[] = [];

    //-- add parent 4
    if (node.parentTitle4) {
        items.push({
            code: "",
            parentCode: "",
            title: node.parentTitle4,
            titleEN: node.parentTitleEN4 ?? "",
            isLeaf: false,
            isLoading: false,
            isFavorite: false,
            typeId: node.typeId,
            isLoaded: false,
        });
    }

    //-- add parent 3
    if (node.parentTitle3) {
        items.push({
            code: "",
            parentCode: "",
            title: node.parentTitle3,
            titleEN: node.parentTitleEN3 ?? "",
            isLeaf: false,
            isLoading: false,
            isFavorite: false,
            typeId: node.typeId,
            isLoaded: false,
        });
    }

    //-- add parent 2
    if (node.parentTitle2) {
        items.push({
            code: "",
            parentCode: "",
            title: node.parentTitle2,
            titleEN: node.parentTitleEN2 ?? "",
            isLeaf: false,
            isLoading: false,
            isFavorite: false,
            typeId: node.typeId,
            isLoaded: false,
        });
    }

    //-- add parent 1
    if (node.parentTitle1) {
        items.push({
            code: "",
            parentCode: "",
            title: node.parentTitle1,
            titleEN: node.parentTitleEN1 ?? "",
            isLeaf: false,
            isLoading: false,
            isFavorite: false,
            typeId: node.typeId,
            isLoaded: false,
        });
    }

    //-- add child
    items.push({
        code: node.code,
        parentCode: node.parentCode,
        title: node.title,
        titleEN: node.titleEN,
        isLeaf: node.isLeaf,
        isLoading: false,
        isFavorite: true,
        typeId: node.typeId,
        isLoaded: false,
    });

    return items;
};

export const getCommodityTitle = (commodity: ICommodity) => (bd.helper.isRTL() ? commodity.title : commodity.titleEN);
