import { useEffect, useState } from "react";
import * as bd from "react-basic-design";
import { Modal } from "react-bootstrap";
import SvgClose from "../../assets/icons/Close";
import SvgDelete from "../../assets/icons/Delete";
import { T } from "../basic/text";
import { ICommodity } from "./types";
import { CommoditiesView } from "./commodities-view";

export const SelectCommodityModal = ({
    show,
    onHide,
    onSubmit,
    selectedCommodities,
    onRemoveCommodity,
    hideFavorite,
    singleSelect,
    disabled,
}: {
    show: boolean;
    onHide: VoidFunction;
    onSubmit: (x: ICommodity[]) => void;
    selectedCommodities: ICommodity[];
    onRemoveCommodity: (c: ICommodity) => void;
    hideFavorite: boolean;
    singleSelect: boolean;
    disabled: boolean;
}) => {
    const [selectedList, setSelectedList] = useState(selectedCommodities);

    useEffect(() => {
        setSelectedList(singleSelect ? [] : selectedCommodities ?? []);
    }, [selectedCommodities]);

    return (
        <Modal show={show} onHide={onHide} size="xl" className="modal-n" backdropClassName="modal-n" fullscreen="xl-down">
            <Modal.Header>
                <Modal.Title>
                    <T>select-commodity</T>
                </Modal.Title>
                <bd.Flex gap={2} content="end" className="m-s-auto">
                    {!singleSelect && !disabled && (
                        <bd.ButtonGroup variant="contained">
                            <bd.Button className="min-w-80" onClick={() => onSubmit(selectedList)}>
                                <T>accept-and-continue</T>
                            </bd.Button>

                            <bd.Button
                                type="button"
                                variant="outline"
                                className="border-start-0"
                                menu={
                                    <bd.Menu>
                                        {selectedList.map((c, cIndex) => (
                                            <bd.MenuItem key={cIndex + c.code} onClick={() => onRemoveCommodity(c)}>
                                                <bd.Flex align="center" className="small0" gap={1}>
                                                    <SvgDelete style={{ color: "red", opacity: 0.8, fontSize: "1rem" }} />
                                                    <span>{c.code}</span>
                                                    <span>-</span>
                                                    <span>{bd.helper.isRTL() ? c.titleEN : c.title}</span>
                                                </bd.Flex>
                                            </bd.MenuItem>
                                        ))}
                                    </bd.Menu>
                                }
                                disableRipple
                            >
                                {selectedList.length} <T className="small">item</T>
                            </bd.Button>
                        </bd.ButtonGroup>
                    )}

                    <bd.Button onClick={onHide} color="default">
                        <SvgClose />
                    </bd.Button>
                </bd.Flex>
            </Modal.Header>

            <Modal.Body className="px-0">
                <CommoditiesView
                    hideFavorite={hideFavorite}
                    singleSelect={singleSelect}
                    disabled={disabled}
                    selectedCommodities={selectedList}
                    setSelectedCommodities={(list) => {
                        if (singleSelect) onSubmit(list);
                        else setSelectedList(list);
                    }}
                />
            </Modal.Body>
        </Modal>
    );
};
