import * as bd from "react-basic-design";
import SvgSearch from "../../assets/icons/Search";
import { T } from "../basic/text";

type InlistCommoditiesButtonProps = {
    title: string | React.ReactNode;
    onClick: bd.Void;
};

export const InlistCommoditiesButton = ({ title, onClick }: InlistCommoditiesButtonProps) => {
    return (
        <bd.Flex content="between" align="center" className="w-100">
            <T>{title}</T>

            <bd.Button variant="icon" onClick={onClick} className="p-2">
                <SvgSearch />
            </bd.Button>
        </bd.Flex>
    );
};
