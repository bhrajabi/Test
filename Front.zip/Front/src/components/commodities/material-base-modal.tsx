import * as bd from "react-basic-design";
import React, { useEffect, useRef } from "react";
import { BasicModal } from "../basic/basic-modal";
import { T } from "../basic/text";
import { RenderTableDiv } from "../table/render-table-div";
import { useReactTable } from "../table/use-react-table";
import { useCommodities } from "./use-commodities";
import { apiConfig } from "../../api/config";

type EventCategoryModalProps = {
    show: boolean;
    onHide: () => void;
    node: any;
};

export const MaterialBaseModal = ({ show, onHide, node }: EventCategoryModalProps) => {
    const service = useCommodities();

    useEffect(() => {
        service.getMaterialBase(node.code);
    }, []);

    return (
        <>
            <BasicModal
                show={show}
                onHide={onHide}
                size="lg"
                title={
                    <>
                        <T className="small text-muted p-e-2" append=":">
                            some-materials-in-this-group
                        </T>
                        <span>{node.title}</span>
                    </>
                }
                depth="n"
                closeButton
            >
                <bd.Flex className="material-base-list" gap={3} wrap content="center">
                    {service.materialBase.map((mb) => (
                        <React.Fragment key={mb.id}>
                            {(mb.imageSerials.length ? mb.imageSerials : [0]).map((imgSerial) => (
                                <React.Fragment key={imgSerial}>
                                    <bd.Paper className="border0">
                                        <img src={`${apiConfig.host}/commodity/get-material-base-image?serial=${imgSerial ?? 0}`} />
                                        <div className="p-2">{mb.title}</div>
                                    </bd.Paper>
                                </React.Fragment>
                            ))}
                        </React.Fragment>
                    ))}
                </bd.Flex>
            </BasicModal>
        </>
    );
};
