import { useEffect, useState } from "react";
import * as bd from "react-basic-design";
import { Tab } from "react-bootstrap";
import { ICommodity, INodeCommodity } from "./types";
import { useCommodities } from "./use-commodities";
import { Loading } from "../basic/loading";
import { T, translate } from "../basic/text";
import { CommodityTreeView } from "./commodity-tree-view";
import SvgMinus from "../../assets/icons/Minus";
import { CommoditySearchView } from "./commodity-search-view";
import { CommodityFavoriteView } from "./commodity-favorite-view";

export const CommoditiesView = ({
    hideFavorite,
    singleSelect,
    disabled,
    selectedCommodities,
    setSelectedCommodities,
}: {
    hideFavorite: boolean;
    singleSelect: boolean;
    disabled: boolean;
    selectedCommodities: ICommodity[];
    setSelectedCommodities: (selectedCommodities: ICommodity[]) => void;
}) => {
    const service = useCommodities();
    const allTabs = hideFavorite ? ["commodity-list", "search"] : ["commodity-list", "search", "favorites"];
    const [tab, setTab] = useState("commodity-list");
    const isSelected = (c: ICommodity) => selectedCommodities.some((x) => x.code == c?.code);

    const onRemoveCommodity = (c: ICommodity) => {
        if (!isSelected(c)) return;
        setSelectedCommodities(selectedCommodities.filter((x) => x.code != c.code));
    };

    const onToggleSelection = (c: ICommodity) => {
        const node = service.getNode(c.code);
        if (!node) return;
        if (!node.isLeaf) {
            service.loadAllChildren(node, (all) => {
                const leafs = all.filter((x) => x.isLeaf);
                const all_selected = leafs.every((x) => selectedCommodities.some((sel) => sel.code == x.code));
                if (all_selected) setSelectedCommodities(selectedCommodities.filter((sel) => !leafs.some((x) => x.code == sel.code)));
                else setSelectedCommodities([...selectedCommodities, ...leafs.filter((x) => x.isLeaf)]);
                //code.distinct()
            });
            // if (node.isLoaded) service.setNodeIsExpanded(node, !node.isExpanded);
            // else service.loadChildren(node);
        } else {
            if (isSelected(c)) onRemoveCommodity(c);
            else setSelectedCommodities([...selectedCommodities, c]);
        }
    };

    const onClickItem = (c: ICommodity) => {
        const node = service.getNode(c.code);
        if (!node) {
            service.loadAllParents(c.code, () => {
                //
            });
            return;
        }
        onSelectCommodity(node);
    };

    const onSelectCommodity = (node: INodeCommodity) => {
        if (!node) return;
        if (!node.isLeaf) {
            if (node.isLoaded) service.setNodeIsExpanded(node, !node.isExpanded);
            else service.loadChildren(node);
        } else {
            if (disabled) return;
            if (isSelected(node)) onRemoveCommodity(node);
            else setSelectedCommodities([...selectedCommodities, { code: node.code, title: node.title, titleEN: node.titleEN }]);
        }
    };

    const onLookup = (code: string) => {
        if (!code) return;
        setTab("commodity-list");

        service.loadAllParents(code, (newCommodities) => {
            service.lookup(code, newCommodities);
        });
    };

    useEffect(() => {
        if (service.isInitialized || service.isInitializing || service.isBusy) return;
        service.init();
    }, []);

    if (!service.isInitialized || service.isInitializing) return <Loading />;

    return (
        <>
            <Tab.Container activeKey={tab}>
                <bd.TabStrip className="container-fluid tabs-sm standard-tabstrip">
                    <T className="pt-1 mt-1 p-e-5 fw-bold" append=":">
                        commodity
                    </T>

                    {allTabs.map((t) => (
                        <bd.TabStripItem key={t} eventKey={t} onClick={() => setTab(t)}>
                            <T>{t}</T>
                        </bd.TabStripItem>
                    ))}

                    <bd.Button
                        variant="outline"
                        size="sm"
                        onClick={() => service.collapseAll()}
                        className="m-s-auto p-1"
                        title={translate("collapse-all")}
                    >
                        <SvgMinus />
                    </bd.Button>
                </bd.TabStrip>

                <Tab.Content>
                    <Tab.Pane eventKey="commodity-list" className="container-fluid p-1">
                        <CommodityTreeView
                            hideFavorite={hideFavorite}
                            singleSelect={singleSelect}
                            disabled={disabled}
                            selectedCommodities={selectedCommodities}
                            onClickItem={onClickItem}
                            onToggleSelection={onToggleSelection}
                        />
                    </Tab.Pane>

                    <Tab.Pane eventKey="search" className="container-fluid p-1">
                        <CommoditySearchView disabled={disabled} selectedCommodities={selectedCommodities} onLookup={onLookup} />
                    </Tab.Pane>

                    {!hideFavorite && (
                        <Tab.Pane eventKey="favorites" className="container-fluid p-1">
                            <CommodityFavoriteView onLookup={onLookup} disabled={disabled} selectedCommodities={selectedCommodities} />
                        </Tab.Pane>
                    )}
                </Tab.Content>
            </Tab.Container>
        </>
    );
};
