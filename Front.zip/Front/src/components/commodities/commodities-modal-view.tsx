import { Modal } from "react-bootstrap";
import { T } from "../basic/text";
import { ICommodity } from "./types";
import { CommoditiesView } from "./commodities-view";

export const CommoditiesModalView = ({
    show,
    disabled,
    hideFavorite,
    singleSelect,
    selectedCommodities,
    onHide,
    setSelectedCommodities,
}: {
    show: boolean;
    disabled: boolean;
    hideFavorite: boolean;
    singleSelect: boolean;
    selectedCommodities: ICommodity[];
    onHide: VoidFunction;
    setSelectedCommodities: (selectedCommodities: ICommodity[]) => void;
}) => {
    return (
        <Modal show={show} onHide={onHide} size="xl" className="modal-n" backdropClassName="modal-n" fullscreen="xl-down">
            <Modal.Header closeButton>
                <T>select-commodity</T>
            </Modal.Header>
            <Modal.Body>
                <CommoditiesView
                    hideFavorite={hideFavorite}
                    singleSelect={singleSelect}
                    disabled={disabled}
                    selectedCommodities={selectedCommodities}
                    setSelectedCommodities={setSelectedCommodities}
                />
            </Modal.Body>
        </Modal>
    );
};
