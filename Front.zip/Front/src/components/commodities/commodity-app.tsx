import * as bd from "react-basic-design";
import { Commodities } from "./commodities";

export const CommodityApp = () => {
    //const [selectedCommodities, setSelectedCommodities] = useState<ICommodity[]>([]);

    return (
        <div className="container-fluid pb-6">
            <bd.Paper className="mt-2">
                <Commodities
                    //hideFavorite
                    //singleSelect
                    isView
                    //inList
                    //inListTitle="select-a-commodity"
                    buttonTitle="commodity"
                    // commodities={selectedCommodities}
                    // onCommoditiesSelected={setSelectedCommodities}
                />
            </bd.Paper>
        </div>
    );
};
