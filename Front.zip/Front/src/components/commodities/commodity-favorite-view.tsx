import React from "react";
import * as bd from "react-basic-design";
import { DeleteButtonConfirm } from "../basic/delete-button-confirm";
import { T } from "../basic/text";
import { CheckBoxView } from "./commodity-tree-item";
import { ICommodity } from "./types";
import { useCommodities } from "./use-commodities";
import { getCommodityTitle } from "./utiles";

type CommodityFavoriteViewProps = {
    disabled: boolean;
    selectedCommodities: ICommodity[];
    onLookup: (code: string) => void;
};

export const CommodityFavoriteView = ({ disabled, selectedCommodities, onLookup }: CommodityFavoriteViewProps) => {
    const service = useCommodities();

    return (
        <bd.TreeView>
            <React.Fragment>
                {service.favorites.length == 0 ? (
                    <T className="text-muted">nothing-found</T>
                ) : (
                    service.favorites.map((f, cIndex) => {
                        const commodity = service.commodities.find((x) => x.code == f) as any;
                        return commodity ? (
                            <FavoriteItem
                                key={cIndex + "-" + f}
                                onClickItem={service.toggleFavorite}
                                commodity={commodity}
                                onLookup={onLookup}
                                selectedCommodities={selectedCommodities}
                                disabled={disabled}
                            />
                        ) : (
                            <></>
                        );
                    })
                )}
            </React.Fragment>
        </bd.TreeView>
    );
};

const FavoriteItem = ({
    commodity,
    selectedCommodities,
    disabled,
    onClickItem,
    onLookup,
}: {
    commodity: ICommodity;
    selectedCommodities: ICommodity[];
    disabled: boolean;
    onClickItem: (x: ICommodity) => void;
    onLookup: (x: string) => void;
}) => {
    if (!commodity) return <></>;
    const is_checked = selectedCommodities?.some((x) => x.code == commodity?.code);
    return (
        <bd.TreeViewItem
            title={
                <bd.Flex className="w-100 on-hover" align="center" gap={2}>
                    <div
                        onClick={(ev) => {
                            ev.preventDefault();
                            ev.stopPropagation();
                            onLookup(commodity?.code);
                        }}
                    >
                        <CheckBoxView disabled={disabled} checked={is_checked} />
                    </div>
                    <div className="cur-pointer" onClick={() => onLookup(commodity?.code)}>
                        {commodity?.code} - {getCommodityTitle(commodity)}
                    </div>
                    <div
                        className="flex-grow-1 mx-2"
                        style={{
                            background: "url(/images/bg/dots.png)",
                            backgroundPositionY: "bottom",
                            lineHeight: 1,
                        }}
                    >
                        &nbsp;
                    </div>
                    <DeleteButtonConfirm className="on-hover-show" onConfirm={() => onClickItem(commodity)} />
                </bd.Flex>
            }
            className="mt-1"
            expanded
            compact
        />
    );
};
