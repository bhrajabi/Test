import * as bd from "react-basic-design";
import { T } from "../basic/text";
import { CTreeView } from "../controlled-treeview/ctreeview";
import { CommodityTreeItem } from "./commodity-tree-item";
import { ICommodity } from "./types";
import { useCommodities } from "./use-commodities";

type CommodityTreeViewProps = {
    hideFavorite: boolean;
    singleSelect: boolean;
    disabled: boolean;
    selectedCommodities: ICommodity[];
    onClickItem: (x: ICommodity) => void;
    onToggleSelection: (x: ICommodity) => void;
};

export const CommodityTreeView = ({
    hideFavorite,
    singleSelect,
    disabled,
    selectedCommodities,
    onClickItem,
    onToggleSelection,
}: CommodityTreeViewProps) => {
    const service = useCommodities();

    return (
        <>
            <CTreeView>
                <bd.TreeViewItem
                    variant="menu"
                    //onClick={() => onClickItem(node)}
                    expanded
                    setExpanded={() => {}}
                    title={<T>goods</T>}
                    //isLoading={node.isLoading}
                    compact
                    lazyload
                >
                    {service.commodities
                        .filter((x) => !x.parentCode && x.typeId == "SUPPLY")
                        .map((x) => (
                            <>
                                <CommodityTreeItem
                                    key={x.code}
                                    selectedCommodities={selectedCommodities}
                                    hideFavorite={hideFavorite}
                                    singleSelect={singleSelect}
                                    disabled={disabled}
                                    node={x}
                                    onClickItem={onClickItem}
                                    onToggleSelection={onToggleSelection}
                                />
                            </>
                        ))}
                </bd.TreeViewItem>

                <bd.TreeViewItem
                    variant="menu"
                    //onClick={() => onClickItem(node)}
                    expanded
                    setExpanded={() => {}}
                    title={<T>services</T>}
                    //isLoading={node.isLoading}
                    compact
                    lazyload
                >
                    {service.commodities
                        .filter((x) => !x.parentCode && x.typeId == "SERVICE")
                        .map((x) => (
                            <>
                                <CommodityTreeItem
                                    key={x.code}
                                    selectedCommodities={selectedCommodities}
                                    hideFavorite={hideFavorite}
                                    singleSelect={singleSelect}
                                    disabled={disabled}
                                    node={x}
                                    onClickItem={onClickItem}
                                    onToggleSelection={onToggleSelection}
                                />
                            </>
                        ))}
                </bd.TreeViewItem>
            </CTreeView>
        </>
    );
};
