import * as bd from "react-basic-design";
import { N } from "../basic/n";
import { ICommodity } from "./types";
import { getCommodityTitle } from "./utiles";

type SelectedCommoditiesViewProps = {
    disabled: boolean;
    selectedCommodities: ICommodity[];
    onRemoveCommodity: (x: ICommodity) => void;
};

export const SelectedCommoditiesView = ({ disabled, selectedCommodities, onRemoveCommodity }: SelectedCommoditiesViewProps) => {
    if (!selectedCommodities) return <></>;

    return (
        <bd.Flex gap={2} wrap>
            {selectedCommodities.map((cmdty) => (
                <bd.Chip
                    key={cmdty.code}
                    label={
                        <>
                            <N>{cmdty.code}</N> - {getCommodityTitle(cmdty)}
                        </>
                    }
                    size="sm"
                    className="border"
                    onDelete={!disabled ? () => onRemoveCommodity(cmdty) : undefined}
                    deleteColor="secondary"
                />
            ))}
        </bd.Flex>
    );
};
