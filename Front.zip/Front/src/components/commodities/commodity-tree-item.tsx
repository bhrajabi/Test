import classNames from "classnames";
import { useState } from "react";
import * as bd from "react-basic-design";
import SvgCheckBoxFill from "../../assets/check-box-fill";
import SvgCheckBoxOutlineBlank from "../../assets/icons/CheckBoxOutlineBlank";
import SvgFavorite from "../../assets/icons/Favorite";
import SvgFavoriteBorder from "../../assets/icons/FavoriteBorder";
import SvgHelp from "../../assets/icons/Help";
import SvgRadioButtonChecked from "../../assets/icons/RadioButtonChecked";
import SvgRadioButtonUnchecked from "../../assets/icons/RadioButtonUnchecked";
import SvgIntermediateCheckBox from "../../assets/intermediate-check-box";
import { code } from "../basic/code";
import { CTreeViewItem } from "../controlled-treeview/ctreeview-item";
import { MaterialBaseModal } from "./material-base-modal";
import { ICommodity, INodeCommodity } from "./types";
import { useCommodities } from "./use-commodities";
import { getCommodityTitle } from "./utiles";

export const CommodityTreeItem = ({
    node,
    hideFavorite,
    singleSelect,
    disabled,
    selectedCommodities,

    onClickItem,
    onToggleSelection,
}: {
    hideFavorite: boolean;
    singleSelect: boolean;
    disabled: boolean;
    node: INodeCommodity;
    selectedCommodities: ICommodity[];

    onClickItem: (x: ICommodity) => void;
    onToggleSelection: (x: ICommodity) => void;
}) => {
    const service = useCommodities();
    const isFavorite = service.favorites.some((x) => x === node.code);
    const [showBaseMaterials, setShowBaseMaterials] = useState(false);

    return (
        <>
            <CTreeViewItem
                variant={!disabled ? "menu" : "text"}
                onClick={() => onClickItem(node)}
                expanded={node.isExpanded}
                setExpanded={() => {}}
                title={
                    <CommodityTreeViewTitle
                        selectedCommodities={selectedCommodities}
                        hideFavorite={hideFavorite}
                        disabled={disabled}
                        singleSelect={singleSelect}
                        node={node}
                        isFavorite={isFavorite}
                        onToggleSelection={onToggleSelection}
                        onShowBaseMaterials={() => setShowBaseMaterials(true)}
                    />
                }
                isLoading={node.isLoading}
                compact
                lazyload>
                {!node.isLeaf &&
                    service.commodities
                        .filter((x) => x.parentCode == node.code)
                        .map((child, childIndex) => (
                            <CommodityTreeItem
                                key={child.code + "-" + childIndex}
                                hideFavorite={hideFavorite}
                                singleSelect={singleSelect}
                                disabled={disabled}
                                node={child}
                                selectedCommodities={selectedCommodities}
                                onClickItem={onClickItem}
                                onToggleSelection={onToggleSelection}
                            />
                        ))}
            </CTreeViewItem>

            {showBaseMaterials && <MaterialBaseModal show={showBaseMaterials} onHide={() => setShowBaseMaterials(false)} node={node} />}
        </>
    );
};

const CommodityTreeViewTitle = ({
    node,
    disabled,
    singleSelect,
    hideFavorite,
    selectedCommodities,
    onToggleSelection,
    onShowBaseMaterials,
    isFavorite,
}: any) => {
    const service = useCommodities();
    let is_selected = false;
    let is_intermediate = false;

    if (selectedCommodities.length > 0) {
        if (node.isLeaf) is_selected = selectedCommodities.some((x: ICommodity) => x.code == node.code);
        else {
            const _all_children = service.getAllChildren(node);
            const all_loaded = _all_children.every((x) => x.isLeaf || x.isLoaded);
            if (all_loaded) {
                const _all_leaf = _all_children.filter((x) => x.isLeaf);
                if (_all_leaf.length > 0 && _all_leaf.length <= selectedCommodities.length) {
                    is_selected = _all_leaf.every((c) => selectedCommodities.some((sel: any) => sel.code == c.code));
                }
            }
            if (!is_selected) is_intermediate = selectedCommodities.some((sel: any) => sel.code.startsWith(node.code));
        }
    }

    return (
        <>
            <bd.Flex className="w-100 on-hover" align="center" gap={2} id={"commodity-" + node.code}>
                {!singleSelect && (
                    <CheckBoxView
                        checked={is_selected}
                        intermediate={is_intermediate}
                        singleSelect={singleSelect}
                        disabled={disabled}
                        onClick={(ev: any) => {
                            ev.preventDefault();
                            ev.stopPropagation();
                            onToggleSelection(node);
                        }}
                    />
                )}

                <>
                    {node.code} - {getCommodityTitle(node)}
                </>

                {node.mbCount > 0 && (
                    <bd.Button
                        variant="icon"
                        disableRipple
                        onClick={(ev) => {
                            code.stopPropagationFunc(ev);
                            onShowBaseMaterials();
                        }}
                        className="p-1 my-n1 m-s-2">
                        <SvgHelp className="text-info" />
                    </bd.Button>
                )}

                <div className="flex-grow-1 mx-2" style={{ background: disabled && node ? "url(/images/bg/dots.png)" : "" }}>
                    &nbsp;
                </div>

                {!hideFavorite && (
                    <>
                        <bd.Button
                            size="sm"
                            variant="icon"
                            className={classNames("p-0", { "on-hover-show": !isFavorite })}
                            onClick={(ev: any) => {
                                ev.preventDefault();
                                ev.stopPropagation();
                                service.toggleFavorite(node);
                            }}>
                            {isFavorite ? <SvgFavorite className="text-danger opacity-75" /> : <SvgFavoriteBorder />}
                        </bd.Button>
                    </>
                )}
            </bd.Flex>
        </>
    );
};

export const CheckBoxView = ({ disabled, checked, intermediate, singleSelect, onClick }: any) => {
    return (
        <div onClick={disabled ? null : onClick} className={disabled ? "opacity-50" : ""}>
            {checked ? (
                !singleSelect ? (
                    <SvgCheckBoxFill className="text-primary" />
                ) : (
                    <SvgRadioButtonChecked className="text-primary" />
                )
            ) : intermediate ? (
                <SvgIntermediateCheckBox className="text-primary opacity-75" />
            ) : !singleSelect ? (
                <SvgCheckBoxOutlineBlank className="text-muted" />
            ) : (
                <SvgRadioButtonUnchecked className="text-muted" />
            )}
        </div>
    );
};
