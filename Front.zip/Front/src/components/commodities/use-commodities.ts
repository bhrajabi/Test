import { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { commodityApi } from "../../api/commodity-api";
import { commoditiesActions } from "../../app/stores/commodities-slice";
import { RootState } from "../../app/stores/store";
import { code } from "../basic/code";
import { notify } from "../basic/notify";
import { useWaiting } from "../basic/use-waiting";
import { ICommodity, INodeCommodity } from "./types";

export const useCommodities = () => {
    const state = useSelector((x: RootState) => x.commodities);
    const waiting = useWaiting();
    const dispatch = useDispatch();
    const [loading, setLoading] = useState(false);
    const [materialBase, setMaterialBase] = useState<
        {
            id: number;
            title: string;
            imageSerials: number[];
        }[]
    >([]);

    const init = () => {
        if (state.isInitialized || state.isInitializing || state.isBusy) return;
        dispatch(commoditiesActions.setIsInitializing(true));
        dispatch(commoditiesActions.setIsBusy(true));

        commodityApi
            .initCommodities()
            .then((result: { commodities: INodeCommodity[]; favorites: string[]; recent: string[] }) => {
                const cl = result.commodities;
                cl.forEach((x) => (x.isLoaded = true));

                cl.forEach((c) => {
                    if (c.level == 2) {
                        const p = cl.find((x) => x.code == c.parentCode);
                        if (p) {
                            c.parentTitle1 = p.title;
                            c.parentTitleEN1 = p.titleEN;
                        }
                    }
                });

                cl.forEach((c) => {
                    if (c.level == 3) {
                        const p = cl.find((x) => x.code == c.parentCode);
                        if (p) {
                            c.parentTitle1 = p.parentTitle1;
                            c.parentTitleEN1 = p.parentTitleEN1;
                            c.parentTitle2 = p.title;
                            c.parentTitleEN2 = p.titleEN;
                        }
                    }
                });

                cl.forEach((c) => {
                    if (c.level == 4) {
                        const p = cl.find((x) => x.code == c.parentCode);
                        if (p) {
                            c.parentTitle1 = p.parentTitle1;
                            c.parentTitleEN1 = p.parentTitleEN1;
                            c.parentTitle2 = p.parentTitle2;
                            c.parentTitleEN2 = p.parentTitleEN2;
                            c.parentTitle3 = p.title;
                            c.parentTitleEN3 = p.titleEN;
                        }
                    }
                });

                cl.forEach((c) => {
                    if (c.level == 5) {
                        const p = cl.find((x) => x.code == c.parentCode);
                        if (p) {
                            c.parentTitle1 = p.parentTitle1;
                            c.parentTitleEN1 = p.parentTitleEN1;
                            c.parentTitle2 = p.parentTitle2;
                            c.parentTitleEN2 = p.parentTitleEN2;
                            c.parentTitle3 = p.parentTitle3;
                            c.parentTitleEN3 = p.parentTitleEN3;
                            c.parentTitle4 = p.title;
                            c.parentTitleEN4 = p.titleEN;
                        }
                    }
                });

                dispatch(commoditiesActions.init(result));
            })
            .catch((ex) => {
                notify.error(ex);
                dispatch(commoditiesActions.setError(ex.toString()));
            })
            .finally(() => {
                dispatch(commoditiesActions.setIsInitializing(false));
                dispatch(commoditiesActions.setIsInitialized(true));
                dispatch(commoditiesActions.setIsBusy(false));
            });
    };

    const setNodeIsExpanded = (type: INodeCommodity, isExpanded: boolean) => {
        dispatch(commoditiesActions.updateNode({ ...type, isExpanded }));
    };

    const loadChildren = (node: INodeCommodity) => {
        if (node.isLoaded || node.isLoading || node.isLeaf) return;
        dispatch(commoditiesActions.updateNode({ ...node, isLoading: true }));
        commodityApi
            .getChildren(node.code)
            .then((result: { commodities: INodeCommodity[] }) => {
                dispatch(
                    commoditiesActions.addNodes([
                        ...result.commodities,
                        {
                            ...node,
                            isLoading: false,
                            isLoaded: true,
                            isExpanded: true,
                        },
                    ])
                );
            })
            .catch((ex) => {
                notify.error(ex);
                dispatch(commoditiesActions.updateNode({ ...node, isLoading: false }));
            });
    };

    const getAllChildren = (node: INodeCommodity) => {
        let list = state.commodities.filter((x) => x.parentCode == node.code);
        [...list].forEach((n) => {
            if (!n.isLeaf) list = [...list, ...getAllChildren(n)];
        });
        return list;
    };

    const loadAllChildren = (node: INodeCommodity, onComplete: (x: INodeCommodity[]) => void) => {
        if (node.isLoading || node.isLeaf) return;

        const allChildren = getAllChildren(node);
        const parents = allChildren.filter((x) => !x.isLeaf && !x.isLoaded);

        if (!node.isLoaded) parents.push(node);

        if (parents.length == 0) {
            onComplete(allChildren);
            return;
        }
        dispatch(commoditiesActions.addNodes(parents.map((x) => ({ ...x, isLoading: true }))));

        commodityApi
            .getAllChildren(parents.map((x) => x.code))
            .then((result: { commodities: INodeCommodity[] }) => {
                const all = [...allChildren, ...result.commodities.filter((c) => !allChildren.some((a) => a.code == c.code)), node];

                dispatch(commoditiesActions.addNodes(all.map((x) => ({ ...x, isLoaded: !x.isLeaf, isLoading: false }))));
                onComplete(all);
            })
            .catch((ex) => {
                notify.error(ex);
                dispatch(commoditiesActions.updateNode({ ...node, isLoading: false }));
            });
    };

    const loadAllParents = (parentCode: string, onComplete?: (x: INodeCommodity[]) => void) => {
        const parents: INodeCommodity[] = [];
        let p = state.commodities.find((x) => x.code == parentCode);
        while (p) {
            parents.push({ ...p, isExpanded: true });
            p = state.commodities.find((x) => x.code == p?.parentCode);
        }
        if (parents.length == 0) return;

        dispatch(commoditiesActions.addNodes(parents));

        setTimeout(() => {
            onComplete && onComplete(parents);
        }, 100);

        return;
        /*
        const missed_codes = parentCodes.filter((pc) => !state.commodities.some((x) => x.code == pc));
        if (missed_codes.length == 0) {
            onComplete && onComplete(state.commodities);
            return;
        }
        waiting.start();
        commodityApi
            .getAllParents(missed_codes)
            .then((result: { commodities: INodeCommodity[] }) => {
                let pcodes = [...missed_codes];
                while (pcodes.length > 0) {
                    const _como = result.commodities.filter((x) => pcodes.includes(x.code));
                    pcodes = [];
                    _como.forEach((c) => {
                        if (!c.isLeaf) {
                            c.isLoaded = true;
                            c.isExpanded = true;
                        }
                        if (!!c.parentCode && !pcodes.includes(c.parentCode)) pcodes.push(c.parentCode);
                    });
                }

                const level1_parents = state.commodities
                    .filter((x) => !x.isLeaf && x.level == 1 && result.commodities.some((c) => c.parentCode == x.code))
                    .map((x) => ({ ...x, isLoaded: true, isExpanded: true }));

                dispatch(commoditiesActions.addNodes([...result.commodities, ...level1_parents]));
                onComplete && onComplete(result.commodities);
            })
            .catch(notify.error)
            .finally(() => waiting.stop());
        */
    };

    const search = (searchText: string) => {
        setLoading(true);
        commodityApi
            .search({ searchText })
            .then((result: { commodities: INodeCommodity[]; materialBase: INodeCommodity[]; materials: INodeCommodity[] }) => {
                dispatch(
                    commoditiesActions.setResult({
                        result: result.commodities,
                        materialBase: result.materialBase,
                        materials: result.materials,
                    })
                );
            })
            .catch(notify.error)
            .finally(() => setLoading(false));
    };

    const toggleFavorite = (commodity: ICommodity) => {
        commodityApi
            .toggleFavorite(commodity.code)
            .then((result: { favorites: string[] }) => {
                dispatch(commoditiesActions.updateFavorites(result.favorites));
            })
            .catch(notify.error);
    };

    const updateRecent = (commodityCode: string) => {
        commodityApi
            .saveMyRecentCommodity(commodityCode)
            .then((result: { recent: string[] }) => {
                dispatch(commoditiesActions.updateRecent(result.recent));
            })
            .catch(notify.error);
    };

    const updateRecents = (commodities: ICommodity[]) => {
        commodityApi
            .saveMyRecentCommodities(commodities.map((x) => x.code))
            .then((result: { recent: string[] }) => {
                dispatch(commoditiesActions.updateRecent(result.recent));
            })
            .catch(notify.error);
    };

    const getNode = (code: string, list1?: INodeCommodity[], list2?: INodeCommodity[]) => {
        if (!list1) list1 = state.commodities;
        const n = list1.find((x) => x.code == code);
        return n ?? list2?.find((x) => x.code == code);
    };

    const lookup = (ccode: string, newCommodities?: INodeCommodity[]) => {
        const _elem_id_ = "commodity-" + ccode;
        const plist: INodeCommodity[] = [];
        while (ccode) {
            const p = getNode(ccode, newCommodities, state.commodities);
            if (p) plist.push({ ...p, isExpanded: true, isLoaded: true });
            ccode = p?.parentCode ?? "";
        }
        if (plist.length == 0) return;
        dispatch(commoditiesActions.addNodes(plist));

        setTimeout(() => {
            const elem = document.getElementById(_elem_id_);
            if (!elem) return;
            code.blink(elem, true);
        }, 200);
    };

    const collapseAll = () => {
        dispatch(commoditiesActions.collapseAll());
    };

    const expandAll = () => {
        dispatch(commoditiesActions.expandAll());
    };

    const getMaterialBase = (code: string) => {
        waiting.start();
        commodityApi
            .getMaterialBase(code)
            .then((result) => {
                setMaterialBase(result.materialBase);
            })
            .catch(notify.error)
            .finally(waiting.stop);
    };

    return {
        isLoadingResult: loading,

        isBusy: state.isBusy,
        isInitialized: state.isInitialized,
        isInitializing: state.isInitializing,
        commodities: state.commodities,
        favorites: state.favorites,
        recent: state.recent,
        searchResult: state.result,
        materialBaseResult: state.materialBaseResult,
        materialsResult: state.materialsResult,
        materialBase,

        //
        init,
        loadChildren,
        loadAllChildren,
        loadAllParents,
        search,
        toggleFavorite,
        updateRecent,
        updateRecents,
        setNodeIsExpanded,

        getAllChildren,
        getNode,
        lookup,
        collapseAll,
        expandAll,
        getMaterialBase,
    };
};
