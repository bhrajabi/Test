import classNames from "classnames";
import { useEffect, useRef, useState } from "react";
import * as bd from "react-basic-design";
import { contentApi } from "../../api/content-api";
import SvgAttachFile from "../../assets/icons/AttachFile";
import { LoadingButton } from "../basic/loading-button";
import { notify } from "../basic/notify";
import { T } from "../basic/text";

export const ContentAttachments = ({ documentSerial, contentSerial, attachments, setAttachments, onRemove, maxFileCount = 3 }) => {
    const upload = useRef();
    const [files, setFiles] = useState(attachments ? attachments : []);
    const [postComplete, setPostComplete] = useState(false);
    const [pending, setPending] = useState(null);
    const [loading, setLoading] = useState(false);
    const [response, setResponse] = useState(null);

    const onChangeFile = (e) => {
        if (!files.map((f) => f.fileName).includes(e.target.files[0].name)) {
            let newFile = {
                file: e,
                fileName: e.target.files[0].name,
                size: e.target.files[0].size,
                type: e.target.files[0].type,
                status: "NEW",
            };
            setPending({ ...newFile });
            newFile.file = null;
            setFiles((files) => [...files, newFile]);
            setLoading(true);
        }
    };

    const onFileRemove = (fileName) => {
        let _files = [...files];
        let file = _files.filter((f) => f.fileName == fileName)[0];
        if (file && (file.status == "SAVED" || file.status == "DRAFT")) {
            file.file = null;
            setLoading(true);
            contentApi
                .DeleteFiles(documentSerial, [file])
                .then(() => {
                    _files = _files.filter((f) => f.fileName != fileName);
                    setFiles(_files);
                    setLoading(false);
                })
                .catch((e) => notify.error(e));
        } else _files = _files.filter((f) => f.fileName != fileName);
        setFiles(_files);
        onRemove(file);
    };

    useEffect(() => {
        if (files) {
            setAttachments([...files].filter((x) => x.status != "FAILED" || x.status != "NEW"));
        }
    }, [files]);

    useEffect(() => {
        if (postComplete) {
            let _files = [...files];
            let file = _files.filter((x) => x.fileName == pending.fileName)[0];
            file.status = "DRAFT";
            file.id = response.id;
            file.objectKey = contentSerial;
            setFiles(_files);
            setPending(null);
            setPostComplete(false);
        }
    }, [postComplete]);

    useEffect(() => {
        if (pending && !postComplete) {
            contentApi
                .uploadFile(documentSerial, pending.file.target.files[0])
                .then((res) => {
                    setResponse(res);
                    setPostComplete(true);
                    setLoading(false);
                })
                .catch((e) => {
                    notify.error(e);
                    setFiles(files.filter((x) => x.fileName !== pending.fileName));
                    setPending(null);
                    setLoading(false);
                });
        }
    }, [pending]);

    return (
        <>
            <div>{`${files.length}/${maxFileCount}`}</div>

            <>
                <input
                    id="input"
                    type="file"
                    ref={upload}
                    style={{ display: "none" }}
                    onChange={(e) => {
                        onChangeFile(e);
                    }}
                    onClick={(e) => {
                        e.target.value = null;
                    }}
                />

                <LoadingButton
                    variant="text"
                    type="button"
                    className="fw-bold"
                    icon={<SvgAttachFile />}
                    label={loading ? <T>please-wait-...</T> : <T>attach-file</T>}
                    loading={loading}
                    isValid={!loading && files.filter((x) => x.status == "SAVED" || x.status == "DRAFT").length < maxFileCount}
                    onClick={() => {
                        upload.current.click();
                    }}
                />
            </>
            <div>{showFiles(files, onFileRemove, loading)}</div>
        </>
    );
};

const showFiles = (files, onFileRemove, loading) => {
    return (
        <>
            {files && files.length > 0 && (
                <>
                    {files
                        .filter((c) => c.status !== "FAILED")
                        .map((file, fileIdx) => {
                            return (
                                <bd.Chip
                                    key={fileIdx}
                                    label={`${file.fileName}/${file.status}/${file.id}`}
                                    className={classNames(
                                        file.status == "SAVED" ? "text-success" : "",
                                        file.status == "FAILED" ? "text-danger" : "",
                                        "m-e-2"
                                    )}
                                    onDelete={() => {
                                        if (!loading) {
                                            onFileRemove(file.fileName);
                                        }
                                    }}
                                ></bd.Chip>
                            );
                        })}
                </>
            )}
        </>
    );
};
