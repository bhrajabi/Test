import { CSSProperties, ReactNode, useRef } from "react";
import * as bd from "react-basic-design";
import { attachmentApi } from "../../api/attachment-api";
import { notify } from "../basic/notify";
import { T } from "../basic/text";
import ImageTools from "../image-tools";
import { useWaiting } from "../basic/use-waiting";

type BDUploadProps = {
    imageOnly?: boolean;
    maxImageSize?: { width: number; height: number };
    attachmentId?: number;
    disabled?: boolean;
    mobile?: string;
    uploadUrl?: string;
    downloadUrl?: string;
    uploadData?: any;
    downloadLabel?: ReactNode;
    validType?: "image/*" | ".png, .jpg, .jpeg" | string;
    buttonVariant?: "" | "inherit" | "contained" | "flat" | "icon" | "text" | "outline" | "fab";
    style?: CSSProperties;
    error?: string;
    children: ReactNode;
    onUpload: (file: any) => void;
};

export const BDUpload = ({
    imageOnly,
    maxImageSize,
    attachmentId,
    disabled,
    mobile,
    uploadUrl,
    downloadUrl,
    uploadData,
    downloadLabel,
    validType,
    buttonVariant,
    style,
    error,
    children,
    onUpload,
}: BDUploadProps) => {
    const waiting = useWaiting();
    const upl = useRef<any>();

    const uploadHandler = (ev: any) => {
        if (!ev.target.files || !ev.target.files.length) return;
        const targetFile = ev.target.files[0];

        const image_resize_required = !!maxImageSize && targetFile.type.match(/image/);
        if (!image_resize_required) doUpload(ev);
        else {
            ImageTools.resize(ev.target.files[0], maxImageSize, function (blob: any) {
                const file = new File([blob], targetFile.name, { type: targetFile.type });
                doUpload(ev, file);
            });
        }
    };

    const doUpload = (ev: any, file?: any) => {
        waiting.start();
        attachmentApi
            .attach(uploadUrl, ev.target, uploadData, file)
            .then((result) => onUpload(result))
            .catch(notify.error)
            .finally(waiting.stop);
    };

    const downloadHandler = () => {
        if (imageOnly) attachmentApi.downloadImage(downloadUrl, mobile);
        else attachmentApi.download(downloadUrl, mobile);
    };

    return (
        <bd.Flex gap={1} style={style}>
            <bd.Button
                variant={!buttonVariant ? "outline" : buttonVariant}
                color={error ? "secondary" : "primary"}
                disableRipple={buttonVariant == "text"}
                type="button"
                disabled={disabled}
                onClick={() => {
                    if (disabled) return;
                    upl.current.click();
                }}
                title={!error ? undefined : error}
            >
                {children}
            </bd.Button>

            {!!attachmentId && (
                <bd.Button className="m-s-1" onClick={downloadHandler} type="button">
                    {!downloadLabel && (
                        <>
                            {imageOnly && <T>view</T>}
                            {!imageOnly && <T>download</T>}
                        </>
                    )}
                    {downloadLabel}
                </bd.Button>
            )}

            <input type="file" ref={upl} className="d-none" onChange={uploadHandler} accept={imageOnly ? "image/*" : validType} />
        </bd.Flex>
    );
};
