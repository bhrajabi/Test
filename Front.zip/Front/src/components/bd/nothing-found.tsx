import { T } from "../basic/text";

export const NothingFound = () => {
    return (
        <div className="text-muted small p-3">
            <T>nothing-found</T>
        </div>
    );
};
