import { t } from "i18next";
import { useState } from "react";
import * as bd from "react-basic-design";
import { useSelector } from "react-redux";
import { DOCUMENT_STATUSES } from "../../app/constatnts";
import { RootState } from "../../app/stores/store";
import { notify } from "../basic/notify";
import { T } from "../basic/text";
import { ActionPrepared, WFInstance } from "../wf/workflow-types";
import { ChangeStatusModal } from "./change-status-modal";
import { PrepareActionModal } from "./prepare-action-modal";
import { useBusinessEvents } from "./use-business-events";
import { documentsApi } from "../../api/document-api";
import { useWaiting } from "../basic/use-waiting";

type AwardEventProps = {
    onTriggered: (isTriggered: boolean) => void;
    existActiveAwardWorkfolw: boolean;
    instance?: WFInstance;
};

export const AwardEvent: React.FC<AwardEventProps> = ({ existActiveAwardWorkfolw, onTriggered }) => {
    //const [stepsModalState, setStepsModalState] = useState<boolean>(false);
    const eventData = useSelector((state: RootState) => state.eventData);
    const [modalState, setModalState] = useState<{ show: boolean; actions?: ActionPrepared[] }>({ show: false });
    const beService = useBusinessEvents();
    const waiting = useWaiting();

    const onAwardEvent = () => {
        beService.prepareAwardEvent(eventData.document.serial, (actions) => {
            setModalState({ show: true, actions });
        });
    };

    const onAwardEventWithoutWofkflow = () => {
        bd.msgbox(
            <T>change-document-status-to-award</T>,
            null,
            [
                {
                    title: <T>confirm</T>,
                    action: (hide) => {
                        waiting.start();
                        documentsApi
                            .awardDocument(eventData.document.serial ?? 0)
                            .then(() => {
                                notify.success(t("successfully-done"));
                                onTriggered(true);
                            })
                            .catch(notify.error)
                            .finally(waiting.stop);
                        hide();
                    },
                },
                { title: <T>close</T> },
            ],
            { backdropClassName: "modal-n", className: "modal-n" }
        );
    };

    return (
        <>
            {!eventData.eventRules.awardWFMandatory && !existActiveAwardWorkfolw && (
                <>
                    {/* convert to award without workflow */}

                    <bd.Button variant="contained" onClick={onAwardEventWithoutWofkflow} disabled={!eventData.allowEdit}>
                        <T>set-awarded</T>
                    </bd.Button>
                </>
            )}

            {eventData.eventRules.awardWFMandatory && !existActiveAwardWorkfolw && (
                <bd.Button variant="contained" onClick={onAwardEvent} disabled={!eventData.allowEdit || existActiveAwardWorkfolw}>
                    <T>start-award-workflow</T>
                </bd.Button>
            )}

            {/* {existActiveAwardWorkfolw && <T className="small text-link " onClick={onClickShowSteps}>workflow-is-running-error</T>} */}

            {modalState.actions && modalState.show && modalState?.actions?.length > 0 && (
                <PrepareActionModal
                    show={modalState.show}
                    onHide={() => setModalState({ ...modalState, show: false })}
                    actions={modalState.actions}
                    onCompleteAction={(actions) => {
                        beService.executeAwardEvent(
                            eventData.document.serial,
                            actions,
                            (isTriggered) => {
                                if (isTriggered) {
                                    notify.success(t("your-request-successfully-sent"));
                                    onTriggered(isTriggered);
                                } else {
                                    notify.warning(t("unknown-error"));
                                }
                                setModalState({ ...actions, show: false });
                            },
                            () => {
                                setModalState({ ...actions, show: false });
                            }
                        );
                    }}
                />
            )}

            {modalState.actions && modalState.show && modalState?.actions?.length == 0 && (
                <ChangeStatusModal
                    show={modalState.show}
                    onHide={() => setModalState({ ...modalState, show: false })}
                    destinationStatus={DOCUMENT_STATUSES.AWARD.toLowerCase()}
                    documentSerial={eventData.document.serial}                 
                />
            )}

            {/* {stepsModalState && instance && (
                <InstanceStepsModal
                    instance={instance}
                    show={stepsModalState}
                    onHide={() => setStepsModalState(false)}
                />
            )} */}
        </>
    );
};
