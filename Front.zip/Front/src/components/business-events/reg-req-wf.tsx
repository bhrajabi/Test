import { t } from "i18next";
import { useState } from "react";
import * as bd from "react-basic-design";
import { notify } from "../basic/notify";
import { T } from "../basic/text";
import { ActionPrepared, WFInstance } from "../wf/workflow-types";
import { InstanceStepsModal } from "./instance-steps-modal";
import { PrepareActionModal } from "./prepare-action-modal";
import { useBusinessEvents } from "./use-business-events";

type RegReqWfProps = {
    onTriggered: (isTriggered: boolean) => void;
    activeWfInstanceExists?: boolean;
    allowEdit?: boolean;
    state: any;
    instance?: WFInstance;
    Status?: string;
};

export const RegReqWf: React.FC<RegReqWfProps> = ({ activeWfInstanceExists, instance, onTriggered, state, allowEdit, Status }) => {
    const [stepsModalState, setStepsModalState] = useState<boolean>(false);
    const [modalState, setModalState] = useState<{ show: boolean; actions?: ActionPrepared[] }>({ show: false });
    const beService = useBusinessEvents();
    const Is_New = Status == "NEW";
    const Is_Updated = Status == "UPDATED";

    const onSendCNF = () => {
        beService.prepareRegReqWF(state?.serial ?? 0, (actions) => {
            setModalState({ show: true, actions });
        });
    };

    const onClickShowSteps = () => {
        setStepsModalState(true);
    };

    return (
        <>
            {!activeWfInstanceExists && (Is_New || Is_Updated) && (
                <bd.Button variant="contained" className="mt-2 mx-1" onClick={onSendCNF} disabled={!allowEdit || activeWfInstanceExists}>
                    <T>start-workflow</T>
                </bd.Button>
            )}

            {instance && (
                <T className={`small text-link ${activeWfInstanceExists && "blink"}`} onClick={onClickShowSteps}>
                    workflow
                </T>
            )}

            {modalState.actions && modalState.show && modalState?.actions?.length > 0 && (
                <PrepareActionModal
                    show={modalState.show}
                    onHide={() => setModalState({ ...modalState, show: false })}
                    actions={modalState.actions}
                    onCompleteAction={(actions) => {
                        beService.executeRegReqWF(
                            state?.serial || 0,
                            actions,
                            (isTriggered) => {
                                if (isTriggered) {
                                    notify.success(t("your-request-successfully-sent"));
                                    onTriggered(isTriggered);
                                    //window.location.reload();
                                } else {
                                    notify.warning(t("unknown-error"));
                                }
                                setModalState({ ...actions, show: false });
                            },
                            () => {
                                setModalState({ ...actions, show: false });
                            }
                        );
                    }}
                />
            )}
            {/* {modalState.actions && modalState.show && modalState?.actions?.length == 0 && (
                <ChangeStatusModal
                    show={modalState.show}
                    onHide={() => setModalState({ ...modalState, show: false })}
                    destinationStatus={DOCUMENT_STATUSES.AWARD.toLowerCase()}
                    documentSerial={eventData.document.serial}
                    onCompleteAction={(isTriggered) => {
                        onTriggered(isTriggered);
                        notify.success(t("successfully-done"));
                        setModalState({ show: false });
                    }}
                />
            )} */}
            {stepsModalState && instance && (
                <InstanceStepsModal instance={instance} show={stepsModalState} onHide={() => setStepsModalState(false)} />
            )}
        </>
    );
};
