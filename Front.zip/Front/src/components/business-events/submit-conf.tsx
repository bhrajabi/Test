import { useState } from "react";
import * as bd from "react-basic-design";
import { useSelector } from "react-redux";
import { RootState } from "../../app/stores/store";
import { T } from "../basic/text";
import { ActionPrepared } from "../wf/workflow-types";
import { PrepareActionModal } from "./prepare-action-modal";
import { useBusinessEvents } from "./use-business-events";
import { notify } from "../basic/notify";
import { t } from "i18next";
import { ChangeStatusModal } from "./change-status-modal";
import { DOCUMENT_STATUSES } from "../../app/constatnts";

type SubmitConfProps = {
    onTriggered: (isTriggered: boolean) => void;
    existActiveAwardWorkfolw: boolean;
};

export const SubmitConf: React.FC<SubmitConfProps> = ({ existActiveAwardWorkfolw, onTriggered }) => {
    const eventData = useSelector((state: RootState) => state.eventData);
    const [modalState, setModalState] = useState<{ show: boolean; actions?: ActionPrepared[] }>({ show: false });
    const beService = useBusinessEvents();

    const onSubmitConf = () => {
        beService.prepareSubmitConf(eventData.document.serial, (actions) => {
            setModalState({ show: true, actions });
        });
    };

    return (
        <>
            <bd.Button variant="contained" onClick={onSubmitConf} disabled={!eventData.allowEdit || existActiveAwardWorkfolw}>
                <T>set-awarded</T>
            </bd.Button>

            {modalState.actions && modalState.show && modalState?.actions?.length > 0 && (
                <PrepareActionModal
                    show={modalState.show}
                    onHide={() => setModalState({ ...modalState, show: false })}
                    actions={modalState.actions}
                    onCompleteAction={(actions) => {
                        beService.executeSubmitConf(
                            eventData.document.serial,
                            actions,
                            (isTriggered) => {
                                if (isTriggered) {
                                    notify.success(t("your-request-successfully-sent"));
                                    onTriggered(isTriggered);
                                } else {
                                    notify.warning(t("unknown-error"));
                                }
                                setModalState({ ...actions, show: false });
                            },
                            () => {
                                setModalState({ ...actions, show: false });
                            }
                        );
                    }}
                />
            )}

            {/* {modalState.actions && modalState.show && modalState?.actions?.length == 0 && (
                <ChangeStatusModal
                    show={modalState.show}
                    onHide={() => setModalState({ ...modalState, show: false })}
                    destinationStatus={DOCUMENT_STATUSES.AWARD.toLowerCase()}
                    documentSerial={eventData.document.serial}
                />
            )} */}
        </>
    );
};
