import { t } from "i18next";
import { useState } from "react";
import * as bd from "react-basic-design";
import { useSelector } from "react-redux";
import { DOCUMENT_STATUSES, enums } from "../../app/constatnts";
import { RootState } from "../../app/stores/store";
import { ConfirmationState } from "../../pages/confirmations/use-confirmation";
import { notify } from "../basic/notify";
import { T } from "../basic/text";
import { ActionPrepared, WFInstance } from "../wf/workflow-types";
import { ChangeStatusModal } from "./change-status-modal";
import { PrepareActionModal } from "./prepare-action-modal";
import { useBusinessEvents } from "./use-business-events";
import { InstanceStepsModal } from "./instance-steps-modal";

type SubmitCNFProps = {
    onTriggered: (isTriggered: boolean) => void;
    existActiveSubmitWorkfolw?: boolean;
    cnfState: ConfirmationState;
    instance?: WFInstance;
    supplierCnfWFMandatory?: boolean;
    Status?: string;
};

export const SubmitCNF: React.FC<SubmitCNFProps> = ({ existActiveSubmitWorkfolw, instance, onTriggered, cnfState, Status }) => {
    const [stepsModalState, setStepsModalState] = useState<boolean>(false);
    const eventData = useSelector((state: RootState) => state.eventData);
    const [modalState, setModalState] = useState<{ show: boolean; actions?: ActionPrepared[] }>({ show: false });
    const beService = useBusinessEvents();

    const IS_DRFT = enums.confirmationStatuses.isDRFT(Status);
    const IS_SUB = enums.confirmationStatuses.isSUBMIT(Status);
    const IS_APPROVE = enums.confirmationStatuses.isAPPROVE(Status);

    const onSendCNF = () => {
        beService.prepareSubmitConf(cnfState.confirmation?.serial ?? 0, (actions) => {
            setModalState({ show: true, actions });
        });
    };

    const onClickShowSteps = () => {
        setStepsModalState(true);
    };

    return (
        <>
            {!IS_APPROVE && (
                <bd.Button variant="contained" onClick={onSendCNF} disabled={!cnfState.canEdit || existActiveSubmitWorkfolw}>
                    <T>start-workflow</T>
                </bd.Button>
            )}

            {(existActiveSubmitWorkfolw || instance) && (
                <T className="small text-link " onClick={onClickShowSteps}>
                    workflow
                </T>
            )}

            {modalState.actions && modalState.show && modalState?.actions?.length > 0 && (
                <PrepareActionModal
                    show={modalState.show}
                    onHide={() => setModalState({ ...modalState, show: false })}
                    actions={modalState.actions}
                    onCompleteAction={(actions) => {
                        beService.executeSubmitConf(
                            cnfState.confirmation?.serial || 0,
                            actions,
                            (isTriggered) => {
                                if (isTriggered) {
                                    notify.success(t("your-request-successfully-sent"));
                                    onTriggered(isTriggered);
                                    window.location.reload();
                                } else {
                                    notify.warning(t("unknown-error"));
                                }
                                setModalState({ ...actions, show: false });
                            },
                            () => {
                                setModalState({ ...actions, show: false });
                            }
                        );
                    }}
                />
            )}

            {/* {modalState.actions && modalState.show && modalState?.actions?.length == 0 && (
                <ChangeStatusModal
                    show={modalState.show}
                    onHide={() => setModalState({ ...modalState, show: false })}
                    destinationStatus={DOCUMENT_STATUSES.AWARD.toLowerCase()}
                    documentSerial={eventData.document.serial}                   
                />
            )} */}

            {stepsModalState && instance && (
                <InstanceStepsModal instance={instance} show={stepsModalState} onHide={() => setStepsModalState(false)} />
            )}
        </>
    );
};
