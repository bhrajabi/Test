import { t } from "i18next";
import { useState } from "react";
import * as bd from "react-basic-design";
import { useSelector } from "react-redux";
import { DOCUMENT_STATUSES } from "../../app/constatnts";
import { RootState } from "../../app/stores/store";
import { notify } from "../basic/notify";
import { T } from "../basic/text";
import { ActionPrepared, WFInstance } from "../wf/workflow-types";
import { ChangeStatusModal } from "./change-status-modal";
import { InstanceStepsModal } from "./instance-steps-modal";
import { PrepareActionModal } from "./prepare-action-modal";
import { useBusinessEvents } from "./use-business-events";

type CloseEventProps = {
    onTriggered: (isTriggered: boolean) => void;
    changeStatusHandler: () => void;
    existActiveCloseEventInstance: boolean;
    existCloseEventWorkflow: boolean;
    instance?: WFInstance;
    closeEventWFInstance?: WFInstance;
};

export const WFCloseEvent: React.FC<CloseEventProps> = ({ existCloseEventWorkflow, existActiveCloseEventInstance, changeStatusHandler, instance, onTriggered }) => {
    const eventData = useSelector((state: RootState) => state.eventData);
    const [modalState, setModalState] = useState<{ show: boolean; actions?: ActionPrepared[] }>({ show: false });
    const [stepsModalState, setStepsModalState] = useState(false);
    const beService = useBusinessEvents();

    const startClosingWorkflow = () => {
        beService.prepareCloseEvent(eventData.document.serial, (actions) => {
            setModalState({ show: true, actions });
        });
    };

    return (
        <>
            {!existCloseEventWorkflow && !existActiveCloseEventInstance && (
                <bd.Button variant="contained" onClick={changeStatusHandler} disabled={!eventData.allowEdit}>
                    <T>close-event</T>
                </bd.Button>
            )}

            {!existActiveCloseEventInstance && existCloseEventWorkflow && (
                <bd.Button variant="contained" onClick={startClosingWorkflow} disabled={!eventData.allowEdit || existActiveCloseEventInstance}>
                    <T>close-event</T>
                </bd.Button>
            )}

            {existActiveCloseEventInstance && <T className="small">workflow-is-running-error</T>}

            {modalState.actions && modalState.show && modalState?.actions?.length > 0 && (
                <PrepareActionModal
                    show={modalState.show}
                    onHide={() => setModalState({ ...modalState, show: false })}
                    actions={modalState.actions}
                    onCompleteAction={(actions) => {
                        beService.executeCloseEvent(
                            eventData.document.serial,
                            actions,
                            (isTriggered) => {
                                if (isTriggered) {
                                    notify.success(t("your-request-successfully-sent"));
                                    onTriggered(isTriggered);
                                } else {
                                    notify.warning(t("unknown-error"));
                                }
                                setModalState({ ...actions, show: false });
                            },
                            () => {
                                setModalState({ ...actions, show: false });
                            }
                        );
                    }}
                />
            )}

            {modalState.actions && modalState.show && modalState?.actions?.length == 0 && (
                <ChangeStatusModal
                    show={modalState.show}
                    onHide={() => setModalState({ ...modalState, show: false })}
                    destinationStatus={DOCUMENT_STATUSES.CLOSE.toLowerCase()}
                    documentSerial={eventData.document.serial}
                />
            )}

            {stepsModalState && instance && (
                <InstanceStepsModal
                    instance={instance}
                    show={stepsModalState}
                    onHide={() => setStepsModalState(false)}
                />
            )}
        </>
    );
};
