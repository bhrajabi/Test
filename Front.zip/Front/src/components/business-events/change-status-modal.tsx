import * as bd from "react-basic-design";
import { Modal } from "react-bootstrap";
import { eventApi } from "../../api/event-api";
import { TProvider } from "../../i18n";
import { notify } from "../basic/notify";
import { T } from "../basic/text";
import { useWaiting } from "../basic/use-waiting";

type PrepareActionModalProps = {
    show: boolean;
    destinationStatus: string;
    onHide: bd.Void;
    documentSerial: number;
};

export const ChangeStatusModal = ({ show, onHide, destinationStatus, documentSerial }: PrepareActionModalProps) => {
    const waiting = useWaiting();

    const onClickSubmit = () => {
        waiting.start();
        eventApi
            .quickChangeStatus(documentSerial, destinationStatus)
            .then(() => {
                window.location.reload();
            })
            .catch(notify.error)
            .finally(waiting.stop);
    };

    return (
        <TProvider ns="process">
            <Modal show={show} onHide={onHide} size="lg">
                <Modal.Header closeButton>
                    <T className="h5">{`you-are-changing-status-to-${destinationStatus}`}</T>{" "}
                </Modal.Header>

                <Modal.Body className="pt-3">
                    <bd.FormRow labelWidth={2} className="py-1 m-e-0">
                        <bd.Button type="button" variant="contained" className="m-s-auto m-e-2" onClick={onClickSubmit}>
                            <T>submit</T>
                        </bd.Button>

                        <bd.Button variant="outline" className="min-w-80" onClick={onHide} type="button">
                            <T>cancel</T>
                        </bd.Button>
                    </bd.FormRow>
                </Modal.Body>
            </Modal>
        </TProvider>
    );
};
