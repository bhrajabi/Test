import { useEffect, useState } from "react";
import * as bd from "react-basic-design";
import { Modal } from "react-bootstrap";
import { Decorations, MessageStatuses } from "../../app/constatnts";
import { T } from "../../components/basic/text";
import { DateTimeCell } from "../../components/table/table-cells";
import { useWorkflow } from "../../components/wf/use-workflow";
import { WFInstance, WFMessage } from "../../components/wf/workflow-types";
import { notify } from "../basic/notify";

type IstanceStepsModalProps = {
    instance?: WFInstance;
    show: boolean;
    onHide: bd.Void;
};

export const InstanceStepsModal = ({ instance, show, onHide }: IstanceStepsModalProps) => {
    const wfService = useWorkflow("", "");
    const [loading, setLoading] = useState(false);
    const [steps, setSteps] = useState<WFMessage[]>([]);
    const [selectedIndices, setSelectedIndices] = useState([]);

    useEffect(() => {
        setLoading(true);
        wfService.getWorkflowSteps(instance?.serial ?? 0, (messages) => {
            setLoading(false);
            if (messages.length == 0) {
                notify.warning(<T>not-found-any-item</T>);
                onHide();
            }
            setSteps(messages);
        });
    }, []);

    //if (loading) return <Loading modal show={show} onHide={onHide} />;
    if (loading) return <></>;

    return (
        <>
            <Modal
                show={show}
                onHide={onHide}
                size="xl"
                fullscreen="xl-down"
                contentClassName="overflow-hidden shadow-5"
                className="modal-n"
                backdropClassName="modal-n"
            >
                <Modal.Header closeButton className="bg-gray-5 border-bottom">
                    <div>
                        <T as="h5" className="m-0">
                            workflow-steps
                        </T>
                        <small>{instance?.title}</small>
                    </div>
                </Modal.Header>

                <Modal.Body className="p-0 overflow-hidden">
                    <div className="overflow-auto" style={{ height: 450 }}>
                        <bd.BasicTable
                            hideCheckbox
                            hover
                            nowrap
                            compact
                            className="small"
                            data={steps}
                            //style={{ minHeight: 300 }}
                            singleSelect
                            selectedIndices={selectedIndices}
                            onSelectionChanged={setSelectedIndices}
                            columns={[
                                { Header: <T>serial</T>, accessor: "serial" },
                                {
                                    Header: <T>action-type</T>,
                                    accessor: "title",
                                    Cell: ({ row }: any) => (
                                        <>
                                            {row.decoration == Decorations.ERROR && (
                                                <div className="p-1 alert-warning">{`${row.title}`}</div>
                                            )}

                                            {row.decoration == Decorations.SUCCESS && (
                                                <div className="p-1 alert-success">{`${row.title}`}</div>
                                            )}

                                            {row.decoration == Decorations.INFO && <div className="p-1 alert-info">{`${row.title}`}</div>}
                                        </>
                                    ),
                                },
                                {
                                    Header: <T>sender</T>,
                                    accessor: "sender",
                                    Cell: ({ row }: any) =>
                                        row.fromFirstName ? (
                                            <>{`${row.fromFirstName ?? ""} ${row.fromLastName} (${row.fromChartTitle})`}</>
                                        ) : (
                                            <></>
                                        ),
                                },
                                {
                                    Header: <T>receiver</T>,
                                    accessor: "receiver",
                                    Cell: ({ row }: any) => <>{`${row.toFirstName} ${row.toLastName} (${row.toChartTitle})`}</>,
                                },
                                {
                                    Header: <T>status</T>,
                                    accessor: "statusId",
                                    Cell: ({ row }: any) => (
                                        <>
                                            {row.statusId == MessageStatuses.NEW && (
                                                <div className="p-1 alert-warning">
                                                    <T>unread</T>
                                                </div>
                                            )}

                                            {row.statusId == MessageStatuses.READ && (
                                                <div className="p-1">
                                                    <T>visited</T>
                                                </div>
                                            )}

                                            {row.statusId == MessageStatuses.COMPL && (
                                                <div className="p-1">
                                                    <T>completed</T>
                                                </div>
                                            )}
                                        </>
                                    ),
                                },
                                { Header: <T>send-date</T>, accessor: "createdAt", Cell: DateTimeCell },
                                { Header: <T>action-date</T>, accessor: "actionAt", Cell: DateTimeCell },
                            ]}
                        >
                            <T as="div" className="nothing-found">
                                nothing-found
                            </T>
                        </bd.BasicTable>
                    </div>
                    <div className="p-2 small bg-gray-5 border-top" style={{ height: 100, marginTop: 0 }}>
                        {selectedIndices.length == 1 ? steps[selectedIndices[0]].comment : ""}
                    </div>
                </Modal.Body>
            </Modal>
        </>
    );
};
