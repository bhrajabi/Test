import { Form, Formik } from "formik";
import * as bd from "react-basic-design";
import { Modal } from "react-bootstrap";
import { T } from "../basic/text";
import { FormikTextField } from "../formik/formik-text-field";
import { ActionPrepared, ActionPrepared_And_Receiver, ActionWF } from "../wf/workflow-types";
import { BasicModal } from "../basic/basic-modal";
import SvgSend from "../../assets/icons/Send";

type PrepareActionModalProps = {
    actions: ActionPrepared[];
    show: boolean;
    onHide: bd.Void;
    onCompleteAction: (actions: ActionWF[]) => void;
};

export const PrepareActionModal = ({ actions, show, onHide, onCompleteAction }: PrepareActionModalProps) => {
    const getUsers = (action: ActionPrepared) => {
        let users: any[] = action.toUsers.map((x) => ({
            id: x.chartUserRoleSerial,
            title: `${x.firstName} ${x.lastName} (${x.chartTitle})`,
        }));
        if (users.length > 1) users = [{ id: null, title: "انتخاب كنيد" }, ...users];
        return users;
    };

    function getDefaultReceiver(action: ActionPrepared) {
        var u = action.toUsers.length == 1 ? action.toUsers[0]?.chartUserRoleSerial ?? null : null;
        return u;
    }

    const onSubmit = (all_values: { actions: ActionPrepared_And_Receiver[] }) => {
        const actions = all_values.actions.map((values) => {
            var toChartUserRoleSerial = values.toUsers?.find(
                (x) => x.chartUserRoleSerial == values.toChartUserRoleSerial
            )?.chartUserRoleSerial;
            const newActionWF: ActionWF = {
                workflowSerial: values.workflowSerial,
                objectKey: values.objectKey,
                messageSerial: values.messageSerial,
                linkSerial: values.linkSerial,
                toChartUserRoleSerial: toChartUserRoleSerial ?? null,
                comment: values.comment,
            };
            return newActionWF;
        });

        onCompleteAction(actions);
    };

    const getActionClassName = (action: ActionPrepared) =>
        action.linkDecoration == "ERROR"
            ? "alert-danger p-1 rounded"
            : action.linkDecoration == "SUCCESS"
            ? "alert-success p-1 rounded"
            : action.linkDecoration == "INFO"
            ? "alert-info p-1 rounded"
            : "";

    return (
        <>
            <BasicModal
                show={show}
                onHide={onHide}
                size="lg"
                depth="10"
                title={
                    <T as="h5" className="m-0">
                        workflow-action
                    </T>
                }
                closeButton
            >
                <Formik
                    initialValues={{
                        actions: actions.map((action) => ({ ...action, toChartUserRoleSerial: getDefaultReceiver(action) })),
                    }}
                    onSubmit={onSubmit}
                >
                    {(formik) => (
                        <Form>
                            {formik.values.actions.map((action, aIndex) => (
                                <>
                                    {aIndex > 0 && <hr />}
                                    <h4 className={getActionClassName(action)}>
                                        {action.linkTitle}
                                        <div className="pt-2 opacity-75" style={{ fontSize: 12 }}>
                                            <T className="">workflow</T>: <span>{action.workflowTitle}</span>
                                        </div>
                                    </h4>

                                    {getUsers(action).length > 0 && (
                                        <FormikTextField
                                            name={`actions[${aIndex}].toChartUserRoleSerial`}
                                            label={<T>receiver</T>}
                                            labelWidth={2}
                                            type="select"
                                            items={getUsers(action)}
                                        />
                                    )}
                                    <FormikTextField
                                        name={`actions[${aIndex}].comment`}
                                        label={<T>description</T>}
                                        labelWidth={2}
                                        type="textarea"
                                        rows="5"
                                        maxLength={1000}
                                    />
                                </>
                            ))}

                            <bd.FormRow labelWidth={2} className="py-1 m-e-0">
                                <bd.Button type="submit" variant="contained" className="m-s-auto m-e-2" disabled={!formik.isValid}>
                                    <SvgSend />
                                    <T>send</T>
                                </bd.Button>

                                <bd.Button variant="outline" className="min-w-80" onClick={onHide} type="button">
                                    <T>cancel</T>
                                </bd.Button>
                            </bd.FormRow>
                        </Form>
                    )}
                </Formik>
            </BasicModal>
        </>
    );
};
