import { Void } from 'react-basic-design';
import { beApi } from '../../api/be-api';
import { useWaiting } from '../basic/use-waiting';
import { ActionPrepared, ActionWF } from '../wf/workflow-types';
import { notify } from '../basic/notify';

export const useBusinessEvents = () => {
    const waiting = useWaiting();

    const prepareAwardEvent = (serial: number, onSuccess: (actions: ActionPrepared[]) => void, onFail?: (err: any) => void) => {
        waiting.start();
        beApi
            .prepareAwardEvent(serial)
            .then((result) => {
                onSuccess(result.actions);
            })
            .catch((err) => {
                notify.error(err);
                onFail && onFail(err);
            })
            .finally(waiting.stop);
    };

    const executeAwardEvent = (
        serial: number,
        actions: ActionWF[],
        onSuccess: (isTriggred: boolean) => void,
        onFail?: (err: any) => void
    ) => {
        waiting.start();
        beApi
            .executeAwardEvent(serial, actions)
            .then((result) => {
                onSuccess(result.isTriggered);
            })
            .catch((err) => {
                notify.error(err);
                onFail && onFail(err);
            })
            .finally(waiting.stop);
    };

    const prepareSubmitConf = (serial: number, onSuccess: (actions: ActionPrepared[]) => void, onFail?: (err: any) => void) => {
        waiting.start();
        beApi
            .prepareSubmitConf(serial)
            .then((result) => {
                onSuccess(result.actions);
            })
            .catch((err) => {
                notify.error(err);
                onFail && onFail(err);
            })
            .finally(waiting.stop);
    };

    const executeSubmitConf = (
        serial: number,
        actions: ActionWF[],
        onSuccess: (isTriggred: boolean) => void,
        onFail?: (err: any) => void
    ) => {
        waiting.start();
        beApi
            .executeSubmitConf(serial, actions)
            .then((result) => {
                onSuccess(result.isTriggered);
            })
            .catch((err) => {
                notify.error(err);
                onFail && onFail(err);
            })
            .finally(waiting.stop);
    };

    const prepareRegReqWF = (serial: number, onSuccess: (actions: ActionPrepared[]) => void, onFail?: (err: any) => void) => {
        waiting.start();
        beApi
            .prepareRegReqWF(serial)
            .then((result) => {
                onSuccess(result.actions);
            })
            .catch((err) => {
                notify.error(err);
                onFail && onFail(err);
            })
            .finally(waiting.stop);
    };

    const executeRegReqWF = (
        serial: number,
        actions: ActionWF[],
        onSuccess: (isTriggred: boolean) => void,
        onFail?: (err: any) => void
    ) => {
        waiting.start();
        beApi
            .executeRegReqWF(serial, actions)
            .then((result) => {
                onSuccess(result.isTriggered);
            })
            .catch((err) => {
                notify.error(err);
                onFail && onFail(err);
            })
            .finally(waiting.stop);
    };

    const prepareRequestWF = (serial: number, onSuccess: (actions: ActionPrepared[]) => void, onFail?: (err: any) => void) => {
        waiting.start();
        beApi
            .prepareRequestWF(serial)
            .then((result) => {
                onSuccess(result.actions);
            })
            .catch((err) => {
                notify.error(err);
                onFail && onFail(err);
            })
            .finally(waiting.stop);
    };

    const executeRequestWF = (
        serial: number,
        actions: ActionWF[],
        onSuccess: (isTriggred: boolean) => void,
        onFail?: (err: any) => void
    ) => {
        waiting.start();
        beApi
            .executeRequestWF(serial, actions)
            .then((result) => {
                onSuccess(result.isTriggered);
            })
            .catch((err) => {
                notify.error(err);
                onFail && onFail(err);
            })
            .finally(waiting.stop);
    };

    const preparePublishEvent = (serial: number, onSuccess: (actions: ActionPrepared[]) => void, onFail?: (err: any) => void) => {
        waiting.start();
        beApi
            .preparePublishEvent(serial)
            .then((result) => {
                onSuccess(result.actions);
            })
            .catch((err) => {
                notify.error(err);
                onFail && onFail(err);
            })
            .finally(waiting.stop);
    };

    const executePublishEvent = (
        serial: number,
        actions: ActionWF[],
        onSuccess: (isTriggred: boolean) => void,
        onFail?: (err: any) => void
    ) => {
        waiting.start();
        beApi
            .executePublishEvent(serial, actions)
            .then((result) => {
                onSuccess(result.isTriggered);
            })
            .catch((err) => {
                notify.error(err);
                onFail && onFail(err);
            })
            .finally(waiting.stop);
    };

    const prepareCloseEvent = (serial: number, onSuccess: (actions: ActionPrepared[]) => void, onFail?: (err: any) => void) => {
        waiting.start();
        beApi
            .prepareCloseEvent(serial)
            .then((result) => {
                onSuccess(result.actions);
            })
            .catch((err) => {
                notify.error(err);
                onFail && onFail(err);
            })
            .finally(waiting.stop);
    };

    const executeCloseEvent = (
        serial: number,
        actions: ActionWF[],
        onSuccess: (isTriggred: boolean) => void,
        onFail?: (err: any) => void
    ) => {
        waiting.start();
        beApi
            .executeCloseEvent(serial, actions)
            .then((result) => {
                onSuccess(result.isTriggered);
            })
            .catch((err) => {
                notify.error(err);
                onFail && onFail(err);
            })
            .finally(waiting.stop);
    };

    const prepareGradeEvent = (serial: number, onSuccess: (actions: ActionPrepared[]) => void, onFail?: (err: any) => void) => {
        waiting.start();
        beApi
            .prepareGradeEvent(serial)
            .then((result) => {
                onSuccess(result.actions);
            })
            .catch((err) => {
                notify.error(err);
                onFail && onFail(err);
            })
            .finally(waiting.stop);
    };

    const executeGradeEvent = (
        serial: number,
        actions: ActionWF[],
        onSuccess: (isTriggred: boolean) => void,
        onFail?: (err: any) => void
    ) => {
        waiting.start();
        beApi
            .executeGradeEvent(serial, actions)
            .then((result) => {
                onSuccess(result.isTriggered);
            })
            .catch((err) => {
                notify.error(err);
                onFail && onFail(err);
            })
            .finally(waiting.stop);
    };

    const prepareFormWF = (serial: number, onSuccess: (actions: ActionPrepared[]) => void, onFail?: (err: any) => void) => {
        waiting.start();
        beApi
            .prepareFormWF(serial)
            .then((result) => {
                onSuccess(result.actions);
            })
            .catch((err) => {
                notify.error(err);
                onFail && onFail(err);
            })
            .finally(waiting.stop);
    };

    const executeFormWF = (serial: number, actions: ActionWF[], onSuccess: (isTriggred: boolean) => void, onFail?: (err: any) => void) => {
        waiting.start();
        beApi
            .executeFormWF(serial, actions)
            .then((result) => {
                onSuccess(result.isTriggered);
            })
            .catch((err) => {
                notify.error(err);
                onFail && onFail(err);
            })
            .finally(waiting.stop);
    };

    return {
        prepareAwardEvent,
        executeAwardEvent,

        prepareSubmitConf,
        executeSubmitConf,

        prepareRegReqWF,
        executeRegReqWF,

        prepareRequestWF,
        executeRequestWF,

        preparePublishEvent,
        executePublishEvent,

        prepareCloseEvent,
        executeCloseEvent,

        prepareGradeEvent,
        executeGradeEvent,

        prepareFormWF,
        executeFormWF,
    };
};
