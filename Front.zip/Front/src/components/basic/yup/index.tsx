import * as yup from "yup";
import { calendar } from "../calendar";
import { T } from "../text";
import { code } from "../code";
import { translate } from "../text";

declare module "yup" {
    interface Schema {
        validDate(date?: Date, errorMessage?: string): this;
        greaterThanDate(date?: Date, errorMessage?: string): this;
        greaterThanEqualDate(date?: Date, errorMessage?: string): this;
        lessThanDate(date?: Date, errorMessage?: string): this;
        lessThanEqualDate(date?: Date, errorMessage?: string): this;
        validPhone(phone?: string): this;
        isValidTimeString(time?: string): this;
        maxLength(maxLength: number): this;
        validRegisterationNationalCode(isIran: boolean, errorMessage: string): this;
        validRegisterationPhone(isIran: boolean, errorMessage: string): this;
        validRegisterationEmail(isIran: boolean, errorMessage: string): this;
        validRegisterationEmail(isIran: boolean, errorMessage: string): this;
    }
}

yup.addMethod(yup.string, "validRegisterationEmail", function (isIran, errorMessage) {
    if (!errorMessage) errorMessage = " ";
    return this.test("test-validRegisterationEmail", errorMessage, function (value) {
        if (isIran) return true;
        return code.validateEmail(value);
    });
});

yup.addMethod(yup.string, "validRegisterationNationalCode", function (isIran, errorMessage) {
    if (!errorMessage) errorMessage = " ";
    return this.test("test-validRegisterationNationalCode", errorMessage, function (value) {
        if (!isIran) return true;
        return code.isValidNationalCode(value);
    });
});

yup.addMethod(yup.string, "validRegisterationPhone", function (isIran, errorMessage) {
    if (!errorMessage) errorMessage = " ";
    return this.test("test-validRegisterationPhone", errorMessage, function (value) {
        if (!isIran) return true;
        return code.isValidPhoneNumber(value);
    });
});

yup.addMethod(yup.string, "validRegisterationEmail", function (isIran, errorMessage) {
    if (!errorMessage) errorMessage = " ";
    return this.test("test-validRegisterationEmail", errorMessage, function (value) {
        if (isIran) return true;
        return code.validateEmail(value);
    });
});

yup.addMethod(yup.string, "validPhone", function (errorMessage) {
    if (!errorMessage) errorMessage = "invalid-phone-number";
    return this.test("validPhone", errorMessage, function (value) {
        if (!value) return false;
        return code.isValidPhoneNumber(value);
    });
});

yup.addMethod(yup.string, "isValidTimeString", function (errorMessage) {
    if (!errorMessage) errorMessage = "time-must-be-in-format-HHMM";
    return this.test("isValidTimeString", errorMessage, function (value) {
        if (!value) return false;
        return code.isValidTime(value);
    });
});

yup.addMethod(yup.string, "maxLength", function (maxLength, errorMessage) {
    if (!errorMessage) errorMessage = translate("string-exceeds-maximum-length-of-@maxLength", { maxLength });
    return this.test("maxLength", errorMessage, function (value) {
        if (!value) return false;
        return value.length <= maxLength;
    });
});

//-- date custom functions
yup.addMethod(yup.string, "validDate", function (errorMessage) {
    if (!errorMessage) errorMessage = "invalid-date";
    return this.test("validDate", errorMessage, function (value) {
        if (!value) return false;
        return calendar.isValid(value);
    });
});

yup.addMethod(yup.date, "greaterThanDate", function (fromDate, errorMessage) {
    if (!errorMessage) errorMessage = <T date={calendar.dateToString(fromDate)}>must-be-greater-than-from-@date</T>;
    return this.test(`greaterThanDate`, errorMessage, function (value) {
        if (!value) return true;
        return calendar.dateToString(value) > calendar.dateToString(fromDate);
    });
});

yup.addMethod(yup.date, "greaterThanEqualDate", function (fromDate, errorMessage) {
    if (!errorMessage) errorMessage = <T date={calendar.dateToString(fromDate)}>must-be-greater-than-equal-from-@date</T>;
    return this.test(`greaterThanEqualDate`, errorMessage, function (value) {
        if (!value) return true;
        return calendar.dateToString(value) >= calendar.dateToString(fromDate);
    });
});

yup.addMethod(yup.date, "lessThanDate", function (toDate, errorMessage) {
    if (!errorMessage) errorMessage = <T date={calendar.dateToString(toDate)}>must-be-less-than-from-@date</T>;
    return this.test(`lessThanDate`, errorMessage, function (value) {
        if (!value) return true;
        return calendar.dateToString(value) < calendar.dateToString(toDate);
    });
});

yup.addMethod(yup.date, "lessThanEqualDate", function (toDate, errorMessage) {
    if (!errorMessage) errorMessage = <T date={calendar.dateToString(toDate)}>must-be-less-than-equal-from-@date</T>;
    return this.test(`lessThanEqualDate`, errorMessage, function (value) {
        if (!value) return true;
        return calendar.dateToString(value) <= calendar.dateToString(toDate);
    });
});

export { yup };
