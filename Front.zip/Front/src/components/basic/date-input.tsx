import classNames from "classnames";
import { useEffect, useRef, useState } from "react";
import * as bd from "react-basic-design";
import { Modal } from "react-bootstrap";
import MaskedInput from "react-text-mask";
import SvgChevronLeft from "../../assets/icons/ChevronLeft";
import SvgChevronRight from "../../assets/icons/ChevronRight";
import SvgEvent from "../../assets/icons/Event";
import { calendar } from "./calendar";
import { code } from "./code";
import { T } from "./text";

type DateInputProps = {
    name?: string;
    value: string;
    selectable?: boolean;
    variant?: string;
    autoComplete?: string;
    spellCheck?: boolean;
    autoFocus?: boolean;
    readOnly?: boolean;
    disabled?: boolean;
    inputClassName?: string;
    inputStyle: any;
    error?: string;
    showErrorLabel?: boolean;
    className?: string;
    height?: number;
    width?: number;
    maxWidth?: number;
    style?: any;
    onChange?: (e: TDateChangeEvent) => void;
    onKeyDown?: (event: any) => void;
    [x: string]: any;
};

export type TDateChangeEvent = { target: { value?: Date; name: string } };
export const DateInput = ({
    name = "",
    value = "",
    selectable,
    variant = "outline",
    autoComplete = "off",
    spellCheck,
    autoFocus,
    readOnly,
    disabled,
    inputClassName = "",
    inputStyle = {},
    error = "",
    showErrorLabel,
    className = "",
    height = undefined,
    width = undefined,
    maxWidth = undefined,
    style = {},

    onChange,
    onKeyDown,
}: DateInputProps) => {
    const DateMask = [/[1-2]/, /[0-4]/, /[0-9]/, /[0-9]/, "/", /[0-1]/, /[0-9]/, "/", /[0-3]/, /[0-9]/];
    const [showCalendar, setShowCalendar] = useState(false);
    const inpRef = useRef<MaskedInput>(null);
    const [valueState, setValueState] = useState<string>();
    const btnSelectDateOnClick = () => setShowCalendar(true);
    const btnRemoveDateOnClick = () => setValueState("");

    const cnInput = classNames("form-control has-1-btn text-start", inputClassName, {
        "bd-input-fill": variant === "fill",
        "bd-input-standard": variant === "standard",

        "bd-input-readonly": readOnly,
        "bd-input-disabled": disabled,
        "bd-border-error": error,
    });

    useEffect(() => {
        if (!autoFocus) return;
        // setTimeout(() => {
        //     if (inpRef.current) inpRef.current.focus();
        // }, 300);
    }, []);

    useEffect(() => {
        setValueState(calendar.dateToString(value));
    }, [value]);

    const onChangeHandler = (e: any) => {
        setValueState(e.target.value);
    };

    const doOnChange = (stringValue: string) => {
        if (!onChange) return;
        var dt = calendar.stringToDate(stringValue);
        onChange({ target: { value: dt, name } });
    };

    const onBlurHandler = (e: any) => {
        if (!e.target.value) {
            setValueState("");
            onChange && onChange({ target: { value: undefined, name } });
            return;
        }

        if (valueState && calendar.isValid(valueState)) doOnChange(valueState);
        else setValueState(calendar.dateToString(value));
    };

    const onSelect = (value: string) => {
        setValueState(value);
        doOnChange(value);
    };

    return (
        <div className={classNames("bd-input", className)} style={{ ...style, width, maxWidth }}>
            <MaskedInput
                mask={DateMask}
                name={name}
                type="text"
                className={cnInput}
                autoComplete={autoComplete}
                spellCheck={spellCheck}
                readOnly={readOnly}
                disabled={disabled}
                style={{ ...inputStyle, height, direction: "ltr" }}
                title={error}
                value={valueState}
                onChange={onChangeHandler}
                onKeyDown={(event) => onKeyDown && onKeyDown(event)}
                ref={inpRef}
                onBlur={onBlurHandler}
            />

            <bd.Button
                type="button"
                className="btn1 size-md icon-btn"
                onClick={btnSelectDateOnClick}
                disabled={disabled || readOnly}
                disableRipple
            >
                <SvgEvent />
            </bd.Button>

            {showErrorLabel && error && <div className="bd-error small">{error}</div>}

            <CalendarModal
                show={showCalendar}
                setShow={setShowCalendar}
                value={valueState}
                //onSelect={(value) => inpRef.current.onChange({ target: { value, id, name } })}
                onSelect={onSelect}
                selectable={!!selectable}
            />
        </div>
    );
};

type CalendarModalProps = {
    value: string | undefined;
    selectable: boolean;
    show: boolean;
    setShow: (show: boolean) => void;
    onSelect: (value: string) => void;
};

const CalendarModal = ({ value, selectable, show, setShow, onSelect }: CalendarModalProps) => {
    if (!value || !calendar.isValid(value)) value = undefined;
    const [model, setModel] = useState<{ view: string; y: number; m: number; value: string | undefined }>({
        view: "days",
        y: 0,
        m: 0,
        value: undefined,
    });
    const [days, setDays] = useState<any>([]);
    const isHoliday = (d: string, dow: number) => dow == 6;

    useEffect(() => {
        if (!show) return;
        const ymd = value ? value.split("/") : calendar.now().split("/");
        setModel({ view: "days", y: ymd[0], m: ymd[1], value: value ?? calendar.now() });
    }, [show]);

    useEffect(() => {
        setDays(calcDaysMatrix());
    }, [model]);

    const onSelectHandler = (value: string | undefined) => {
        if (!value) return;
        onSelect && onSelect(value);
        setShow(false);
    };

    const selectDate = (value: string) => {
        const ymd = value.split("/");
        setModel({ ...model, value, y: parseInt(ymd[0]), m: parseInt(ymd[1]) });
    };

    const toggleView = () =>
        setModel({
            ...model,
            view: model.view === "days" ? "months" : model.view === "months" ? "years" : "days",
        });

    const onKeyDownHandler = (ev: KeyboardEvent) => {
        let d = 0;
        let m = 0;
        let y = 0;
        const rtlSign = bd.helper.isRTL() ? -1 : 1;

        switch (ev.keyCode) {
            case 38: //up
                if (model.view == "days") d = -7;
                else if (model.view == "months") m = -3;
                else y -= 5;
                break;

            case 39: //right
                if (model.view == "days") d = rtlSign;
                else if (model.view == "months") m = rtlSign;
                else y = rtlSign;
                break;

            case 40: //down
                if (model.view == "days") d = +7;
                else if (model.view == "months") m = 3;
                else y = 5;
                break;

            case 37: //left
                if (model.view == "days") d = -rtlSign;
                else if (model.view == "months") m = -rtlSign;
                else y = -rtlSign;
                break;

            case 33: //page up
                if (model.view == "days") m = -1;
                else if (model.view == "months") y = -1;
                else y = -20;
                break;

            case 34: //page down
                if (model.view == "days") m = 1;
                else if (model.view == "months") y = 1;
                else y = 20;
                break;

            case 32:
                toggleView();
                return;
        }
        if (!d && !m && !y) return;
        const value = d
            ? calendar.addDays(model.value, d)
            : m
            ? calendar.addMonths(model.value, m)
            : calendar.addMonths(model.value, y * 12);
        selectDate(value);
    };

    const movePage = (sign: number) => {
        if (model.view === "years") setModel({ ...model, y: +model.y + sign * 20 });
        else if (model.view === "months") {
            setModel({ ...model, y: +model.y + sign });
        } else {
            let y = +model.y;
            let m = +model.m + sign;
            if (m <= 0) {
                m = 12;
                y -= 1;
            } else if (m > 12) {
                m = 1;
                y += 1;
            }
            setModel({ ...model, y, m });
        }
    };

    function calcDaysMatrix(): string[] {
        const days: any[] = [];
        const dow = calendar.DOW(model.y, model.m, 1);
        let d = calendar.addDays([model.y, model.m, 1], dow === 0 ? -7 : -dow);
        const last_date = calendar.addMonths([model.y, model.m, 1], 1);
        let done = false;
        for (let r = 0; !done && days.length < 8; r++) {
            days.push([0, 0, 0, 0, 0, 0, 0]);
            for (let c = 0; c < 7; c++) {
                const ymd = d.split("/");
                days[r][c] = { value: d, y: ymd[0], m: ymd[1], d: ymd[2] };
                if (d >= last_date) done = true;
                d = calendar.addDays(d, 1);
            }
        }
        return days;
    }

    const renderYears = () => {
        const y0 = yearRangeStart(model.y);

        return (
            <bd.Flex wrap>
                {[0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19].map((x) => (
                    <bd.Button
                        key={x}
                        className="calendar-year"
                        variant={y0 + x == model.y ? "outline" : undefined}
                        active={y0 + x == model.y}
                        onClick={() => setModel({ ...model, y: y0 + x, view: "months" })}
                        onKeyDown={onKeyDownHandler}
                        disableRipple
                        autoFocus
                        size="lg"
                    >
                        <div className="text-primary-text">{y0 + x}</div>
                    </bd.Button>
                ))}
            </bd.Flex>
        );
    };

    const renderMonths = () => (
        <bd.Flex wrap>
            {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12].map((m) => (
                <bd.Button
                    key={m}
                    className="calendar-month"
                    variant={m == model.m ? "outline" : undefined}
                    active={m == model.m}
                    onClick={() => setModel({ ...model, m, view: "days" })}
                    onKeyDown={onKeyDownHandler}
                    disableRipple
                    //autoFocus={m == 1}
                    autoFocus
                    size="lg"
                >
                    <div className="text-primary-text">{calendar.getMonthName(m)}</div>
                </bd.Button>
            ))}
        </bd.Flex>
    );

    const renderDays = () => (
        <>
            <div className="bg-gray-70 text-bg calendar-week-names">
                {calendar.getShortDowNames().map((x: any) => (
                    <div key={x}>{x}</div>
                ))}
            </div>

            {days.map((w: any, wIndex: number) => (
                <div key={wIndex}>
                    {w.map((cell: any, cellIndex: number) => (
                        <bd.Button
                            key={cell.d}
                            className="calendar-day my-1"
                            color={isHoliday(cell.d, cellIndex) ? "secondary" : "primary"}
                            variant={cell.value === model.value ? "outline" : undefined}
                            active={cell.value === model.value}
                            onClick={() => {
                                if (cell.m === model.m && !selectable) onSelectHandler(cell.value);
                                else setModel({ ...model, ...cell });
                            }}
                            onKeyDown={onKeyDownHandler}
                            disableRipple
                            autoFocus
                            size="lg"
                        >
                            <div
                                className={classNames({
                                    "calendar-day-out": cell.m != model.m,
                                    "text-secondary": isHoliday(cell.d, cellIndex),
                                    "text-primary-text": !isHoliday(cell.d, cellIndex),
                                })}
                            >
                                {code.localNumbers(+cell.d)}
                            </div>
                        </bd.Button>
                    ))}
                </div>
            ))}

            <bd.Flex className="mt-3" content="between">
                <bd.Button onClick={() => selectDate(calendar.now())} onKeyDown={onKeyDownHandler} disableRipple>
                    <T>today</T>
                </bd.Button>

                {selectable && (
                    <bd.Button variant="contained" onClick={() => onSelectHandler(model.value)}>
                        {model.value}
                    </bd.Button>
                )}
            </bd.Flex>
        </>
    );

    const yearRangeStart = (y: number) => Math.floor(y / 20) * 20;

    return (
        <Modal show={show} onHide={() => setShow(false)} animation={false} backdropClassName="modal-n" className="modal-n">
            <Modal.Body>
                <div className="calendar">
                    <bd.Flex className="py-2" content="between" align="center">
                        <bd.Button variant="icon" onClick={() => movePage(-1)}>
                            <SvgChevronLeft className="rtl-rotate-180" />
                        </bd.Button>

                        <bd.Button disableRipple onClick={toggleView}>
                            {model.view == "days"
                                ? `${calendar.getMonthName(model.m)} ${model.y}`
                                : model.view == "months"
                                ? model.y
                                : `${yearRangeStart(model.y)} - ${yearRangeStart(model.y) + 20}`}
                        </bd.Button>

                        <bd.Button variant="icon" onClick={() => movePage(1)}>
                            <SvgChevronRight className="rtl-rotate-180" />
                        </bd.Button>
                    </bd.Flex>

                    {model.view === "days" && renderDays()}
                    {model.view === "months" && renderMonths()}
                    {model.view === "years" && renderYears()}
                </div>
            </Modal.Body>
        </Modal>
    );
};
