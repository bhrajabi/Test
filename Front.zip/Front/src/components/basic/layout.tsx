import React, { CSSProperties } from "react";

type LayoutProps = {
    className?: string;
    vertical?: boolean;
    style?: CSSProperties | undefined;
    disableH100?: boolean;
    children: React.ReactNode;
};

type LayoutMainProps = {
    id?: string;
    className?: string;
    overflowVisible?: boolean;
    autoScroll?: boolean;
    style?: CSSProperties | undefined;
    grow?: boolean;
    fixed?: boolean;
    fixWidth?: number;
    children?: React.ReactNode;
};
type LayoutSectionProps = {
    className?: string;
    style?: CSSProperties | undefined;
    fixed?: boolean | undefined;
    children?: React.ReactNode;
    [x: string]: any;
};

export const Layout = ({ vertical, style, disableH100, children, ...rem }: LayoutProps) => {
    style = {
        ...style,
        display: "flex",
        flexDirection: vertical ? "column" : "row",
    };
    if (!disableH100) style = { ...style, height: "100%" };
    return (
        <div {...rem} style={style}>
            {children}
        </div>
    );
};

export const LayoutMain = ({ id, overflowVisible, autoScroll = true, style, children, ...rem }: LayoutMainProps) => {
    style = {
        ...style,
        flex: "1 1 auto",
        overflow: overflowVisible ? "visible" : autoScroll ? "auto" : "hidden",
        minHeight: 0,
    };

    return (
        <div id={id} {...rem} style={style}>
            {children}
        </div>
    );
};

export const LayoutSection = ({ fixed, style, children, ...rem }: LayoutSectionProps) => {
    if (fixed) style = { ...style, overflow: "hidden", flex: "0 0 auto" };
    return (
        <div {...rem} style={style}>
            {children}
        </div>
    );
};

export const LayoutItem = ({ className, autoScroll, style, grow, fixed, fixWidth, children, ...rem }: LayoutMainProps) => {
    if (grow) {
        style = { ...style, flex: "1 1 auto", minHeight: 0 };
    } else {
        if (fixed) style = { ...style, overflow: autoScroll ? "auto" : autoScroll == false ? "hidden" : autoScroll };
    }

    if (autoScroll) style = { ...style, overflow: "auto" };

    if (fixWidth) style = { ...style, minWidth: fixWidth, maxWidth: fixWidth };

    return (
        <div className={className} {...rem} style={style}>
            {children}
        </div>
    );
};
