import * as bd from "react-basic-design";
import classNames from "classnames";
import { T } from "./text";

export const StatusChip = ({ value = "", title = "", className = "", tooltip = "" }) => {
    if (!value) return <></>;
    value = value?.toUpperCase();
    let cn = "";
    switch (value) {
        case "UPDATED":
        case "NEW":
            cn = "bg-default border";
            break;

        case "DRFT":
        case "SLCT":
        case "DRAFT":
            cn = "alert-secondary border-1";
            break;

        case "SUBMIT":
        case "SUB":
        case "PEND":
        case "PUB":
        case "CLOSE":
        case "GRADE":
        case "AWARD":
        case "REVIEW":
            cn = "alert-warning border-1";
            break;

        case "PENDING":
            cn = "alert-dark border-1";
            break;

        case "RJCT":
        case "REJECT":
        case "CANCEL":
        case "FATAL":
            cn = "alert-danger border-1";
            break;

        case "SRC":
        case "REL":
        case "CALLBACK":
            cn = "alert-warning border-1";
            break;

        case "APRV":
        case "APPROVE":
        case "ACTIVE":
        case "ACPT":
        case "CMPL":
        case "VERIFY":
            cn = "alert-success border-1";
            break;
    }

    return <bd.Chip label={title || value} className={classNames(cn, className)} size="sm" title={tooltip} />;
};

export const NotifStatusChip = ({ value, title, className }) => {
    if (!value) return <></>;
    value = value?.toUpperCase();
    let cn = "";
    switch (value) {
        case "READY":
        case "NEW":
        case "VISITED":
        case "VISIT":
        case "NOTIFY":
            cn = "box-default";
            break;

        case "CLOSED":
            cn = "alert alert-info";
            break;

        case "REFERBACK":
            cn = "alert alert-warning";
            break;

        case "APRV":
        case "CMPL":
            cn = "alert alert-success";
            break;
    }

    return (
        value && <bd.Chip label={<T>{title?.toLowerCase() ?? value?.toLowerCase()}</T>} className={classNames(cn, className)} size="sm" />
    );
};
