import { Modal } from "react-bootstrap";
import { T } from "./text";
import classNames from "classnames";

export const Loading = ({ label = null, fullHeight = false, modal = false, show = false, onHide = () => {} }) => {
    const style = !fullHeight ? {} : { maxHeight: 600, minHeight: modal ? "" : "320px" };
    const result = (
        <div className={classNames("text-center text-secondary-text middle p-3", { "h-50": fullHeight })} style={style}>
            <div className="m-e-2 spinner-border spinner-border-sm"></div>
            <T>{label ?? "loading"}</T>
        </div>
    );
    return !modal ? (
        result
    ) : (
        <Modal show={show} size="sm" onHide={onHide} backdropClassName="modal-n" className="modal-n">
            <Modal.Body className="py-3">{result}</Modal.Body>
        </Modal>
    );
};

export const Spinner = ({ size }) => {
    return <div className="spinner-border spinner-border-sm" style={{ width: size, height: size }}></div>;
};
