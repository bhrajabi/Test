import * as bd from "react-basic-design";
import classNames from "classnames";
import { T } from "./text";

export const UserAuctionStatusChip = ({ value, className }) => {
    if (!value) return <></>;
    let title = "";
    value = value?.toUpperCase();
    let cn = "";
    switch (value) {
        case "BID":
            title = <T>bid</T>;
            cn = "alert alert-default";
            break;
        case "REGISTER":
            title = <T>registed</T>;
            cn = "alert alert-default";
            break;
        case "LOOSER":
            title = <T>looser</T>;
            cn = "alert alert-danger";
            break;

        case "WINNER":
            cn = "alert alert-success";
            title = <T>winner</T>;
            break;

        case "RESERVE":
            cn = "alert alert-warning";
            title = <T>reserve</T>;
            break;

        case "FINE":
            cn = "alert alert-danger";
            title = <T>fine</T>;
            break;

        case "DOCPAY":
            cn = "alert alert-default";
            title = <T>documnet-payment</T>;
            break;
        default:
            cn = "alert alert-default";
            title = <T>{value}</T>;
            break;
    }

    return (
        // value && <bd.Chip label={<T>{title?.toLowerCase() ?? value?.toLowerCase()}</T>} className={classNames(cn, className)} size="sm" />
        value && <bd.Chip label={title ?? value} className={classNames(cn, className)} size="sm" />
    );
};
