export const IF = ({ value, in: list, children }: { value: any; in?: any[]; children: any }) => {
    if (!list) return value == true ? children : <></>;
    if (!list.includes(value)) return <></>;
    return children;
};
