import classNames from "classnames";
import { ReactNode } from "react";
import * as bd from "react-basic-design";
import { useT } from "../../i18n";
import SvgLoading from "../../assets/loading";

type LoadingButtonProps = {
    variant?: "" | "inherit" | "contained" | "flat" | "icon" | "text" | "outline" | "fab";
    className?: string;
    color?: "" | "inherit" | "default" | "primary" | "secondary";
    size?: "" | "sm" | "md" | "lg";

    label: ReactNode;
    icon?: ReactNode;
    disableRipple?: boolean;
    disabled?: boolean;
    loading?: boolean;
    isValid?: boolean;
    [x: string]: any;
};

export const LoadingButton = ({
    variant = "contained",
    label,
    icon,
    disabled,
    loading,
    isValid = true,
    className = "",
    size = "md",
    disableRipple = false,
    ...props
}: LoadingButtonProps) => {
    if (typeof label === "string") {
        const { t } = useT();
        label = t(label);
    }

    return (
        <bd.Button
            variant={variant}
            className={classNames(className, { "min-w-80": !!label })}
            size={size}
            disableRipple={disableRipple}
            {...props}
            disabled={disabled || !isValid || loading}
        >
            {loading && <SvgLoading className={!label ? "" : "m-e-2"} />}
            {!loading && icon}
            {label}
        </bd.Button>
    );
};
