import { ReactNode, useState } from "react";
import * as bd from "react-basic-design";
import { BasicModal } from "./basic-modal";

type BasicModalWithButtonProps = {
    buttonIcon?: ReactNode;
    buttonText?: ReactNode;
    buttonVariant?: "" | "inherit" | "contained" | "flat" | "icon" | "text" | "outline" | "fab";
    buttonClassName?: string;
    color?: "" | "inherit" | "default" | "primary" | "secondary";
    buttonSize?: "" | "sm" | "md" | "lg";
    buttonDisabled: boolean;

    size?: "sm" | "md" | "lg" | "xl";
    depth?: "1" | "2" | "3" | "n";
    title: ReactNode;
    titleClassName?: string;
    children: ReactNode;
    closeButton?: boolean;
    loading?: boolean;
    className?: string;
    fullScreen?: boolean;
};

export const BasicModalWithButton = ({
    buttonIcon,
    buttonText,
    buttonVariant,
    buttonSize,
    buttonClassName,
    buttonDisabled,

    size,
    depth,
    title,
    titleClassName,
    children,
    closeButton,
    loading,
    className,
    fullScreen,
}: BasicModalWithButtonProps) => {
    const [showModal, setShowModal] = useState(false);
    return (
        <>
            <BasicModal
                size={size}
                depth={depth}
                show={showModal}
                onHide={() => setShowModal(false)}
                title={title}
                titleClassName={titleClassName}
                closeButton={closeButton}
                loading={loading}
                bodyClassName={className}
                fullScreen={fullScreen}
            >
                {children}
            </BasicModal>
        </>
    );
};
