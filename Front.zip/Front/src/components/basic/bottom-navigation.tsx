import classNames from "classnames";
import { ReactNode } from "react";
import * as bd from "react-basic-design";
import { useLocation, useNavigate } from "react-router-dom";
import { T } from "./text";

export const BottomNavigation = ({ className, children }: { className?: string; children: ReactNode }) => {
    return (
        <>
            <div
                className={classNames("border-top bg-default w-100", className)}
                style={{ position: "fixed", bottom: 0, left: 0, right: 0, zIndex: 1000 }}
            >
                <bd.Flex className="" align="center" content="around">
                    {children}
                </bd.Flex>
            </div>
        </>
    );
};

export const NavItem = ({
    className,
    variant,
    color,
    title,
    icon,
    href,
    disabled,
    onClick,
}: {
    className?: string;
    variant?: "" | "inherit" | "contained" | "flat" | "icon" | "text" | "outline" | "fab";
    color?: "" | "inherit" | "default" | "primary" | "secondary";
    title: ReactNode;
    icon?: ReactNode;
    href?: string;
    disabled?: boolean;
    onClick?: VoidFunction;
}) => {
    const navigate = useNavigate();
    const loc = useLocation();
    const isActive = loc.pathname == href;
    const isButton = onClick || href;

    return (
        <>
            {!isButton && <span className={className}>{title}</span>}

            {isButton && (
                <bd.Button
                    className={classNames(className, "w-100 px-1", {
                        "h-auto py-0 bg-default": !color,
                        "fw-bold": !color && isActive,
                        "text-muted": !color && !isActive,
                    })}
                    variant={variant}
                    color={!color ? "default" : color}
                    disableRipple
                    disabled={disabled}
                    onClick={() => {
                        if (onClick) onClick();
                        else if (href) navigate(href);
                    }}
                    style={{ fontSize: "1.1rem", borderRadius: 0 }}
                >
                    <bd.Flex vertical align="center" gap={1} className="py-1">
                        {icon && (
                            <>
                                {icon} <T style={{ fontSize: "0.6rem" }}>{title}</T>
                            </>
                        )}

                        {!icon && (
                            <>
                                <T style={{ fontSize: "1.0rem" }}>{title}</T>
                            </>
                        )}
                    </bd.Flex>
                </bd.Button>
            )}
        </>
    );
};
