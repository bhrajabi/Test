import { useState } from "react";
import * as bd from "react-basic-design";
import SvgCheck from "../../assets/icons/Check";
import SvgClose from "../../assets/icons/Close";
import classNames from "classnames";
import SvgDelete from "../../assets/icons/Delete";

export const DeleteButtonConfirm = ({ className, onConfirm }: { className?: string; onConfirm: VoidFunction }) => {
    const [beforeRemove, setBeforeRemove] = useState(false);

    if (beforeRemove)
        return (
            <bd.Flex align="center" content="between" gap={1}>
                <bd.Button
                    size="sm"
                    variant="icon"
                    className="p-0"
                    onClick={(ev: any) => {
                        ev.preventDefault();
                        ev.stopPropagation();
                        onConfirm();
                    }}>
                    <SvgCheck className="text-success" />
                </bd.Button>
                <bd.Button size="sm" variant="icon" className="p-0" onClick={() => setBeforeRemove(false)}>
                    <SvgClose className="text-danger" />
                </bd.Button>
            </bd.Flex>
        );

    return (
        <bd.Button
            size="sm"
            variant="icon"
            className={classNames("p-0", className)}
            onClick={(ev: any) => {
                ev.preventDefault();
                ev.stopPropagation();
                setBeforeRemove(true);
                setTimeout(() => setBeforeRemove(false), 3000);
            }}>
            <SvgDelete className="text-danger" />
        </bd.Button>
    );
};
