import { ReactNode } from "react";
import SvgCheckCircle from "../../assets/icons/CheckCircle";
import SvgClose from "../../assets/icons/Close";
import SvgInfo from "../../assets/icons/Info";
import SvgWarning from "../../assets/warning";
import { T } from "./text";

type ResultProps = {
    title: string;
    subTitle?: string;
    status?: "success" | "error" | "info" | "warning" | "404" | "403" | "500";
    extra?: ReactNode;
};

export const Result = ({ title, subTitle, status, extra }: ResultProps) => {
    return (
        <>
            <div className={"text-center p-3"}>
                {!!status && (
                    <div className="mb-4">
                        {status == "404" && (
                            <div className="mb-n4 text-danger" style={{ position: "relative" }}>
                                <span className="ltr" style={{ position: "absolute", top: 0, left: "44%" }}>
                                    Error:
                                </span>
                                <b style={{ fontSize: 90 }}>
                                    <span className="text-danger">4</span>
                                    <span className="text-warning">0</span>
                                    <span className="text-primary">4</span>
                                </b>
                            </div>
                        )}
                        {status == "403" && (
                            <div className="mb-n4 text-danger" style={{ position: "relative" }}>
                                <span className="ltr" style={{ position: "absolute", top: 0, left: "44%" }}>
                                    Error:
                                </span>
                                <b style={{ fontSize: 90 }}>403</b>
                            </div>
                        )}
                        {status == "500" && (
                            <div className="mb-n4 text-danger" style={{ position: "relative" }}>
                                <span className="ltr" style={{ position: "absolute", top: 0, left: "44%" }}>
                                    Error:
                                </span>
                                <b style={{ fontSize: 90 }}>500</b>
                            </div>
                        )}
                        {status == "info" && <SvgInfo className="text-info" style={{ fontSize: 64 }} />}
                        {status == "error" && (
                            <div
                                className="p-1 d-inline-block rounded rounded-circle text-danger"
                                style={{ backgroundColor: "currentColor" }}
                            >
                                <SvgClose className="text-white" style={{ fontSize: 56 }} />
                            </div>
                        )}
                        {status == "success" && <SvgCheckCircle className="text-success" style={{ fontSize: 64 }} />}
                        {status == "warning" && <SvgWarning className="text-warning" style={{ fontSize: 64 }} />}
                    </div>
                )}

                <T as="h4" className="my-3">
                    {title}
                </T>

                {subTitle && <div className="text-muted mb-4">{subTitle}</div>}

                {extra}
            </div>
        </>
    );
};
