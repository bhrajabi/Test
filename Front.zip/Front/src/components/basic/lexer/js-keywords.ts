export const JsTokenTypes = {
    SYMBOL: "SYMBOL",
    STRING: "STRING",
    NUMBER: "NUMBER",
    INT: "INT",
    ID: "ID",
    KEYWORD: "KEYWORD",
};

export const jsKeywords = [
    "type",
    "break",
    "case",
    "catch",
    "class",
    "const",
    "continue",
    "debugger",
    "default",
    "delete",
    "do",
    "else",
    "export",
    "extends",
    "false",
    "finally",
    "for",
    "function",
    "if",
    "import",
    "in",
    "instanceof",
    "new",
    "null",
    "return",
    "super",
    "switch",
    "this",
    "throw",
    "true",
    "try",
    "typeof",
    "var",
    "void",
    "while",
    "with",
];

export interface TextRange {
    fromPosition: number;
    fromLineNumber: number;
    fromColumn: number;

    toPosition: number;
    toLineNumber: number;
    toColumn: number;
}
