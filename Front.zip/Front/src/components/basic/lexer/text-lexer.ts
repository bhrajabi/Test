import { TextRange, jsKeywords } from "./js-keywords";

export type Token = {
    text: string;
    type: "EOT" | "SYMBOL" | "NUMBER" | "STRING" | "TEMPLATE-STRING" | "ID" | "KEYWORD" | "COMMENT" | "SPACE";
    position: number;
};

export const TokenTypes = {
    EOT: "EOT",
    SYMBOL: "SYMBOL",
    NUMBER: "NUMBER",
    STRING: "STRING",
    TEMPLATE_STRING: "TEMPLATE-STRING",
    ID: "ID",
    KEYWORD: "KEYWORD",
    COMMENT: "COMMENT",
    SPACE: "SPACE",

    isTemplateString: (t: { type: string }) => t.type == TokenTypes.TEMPLATE_STRING,
    isString: (t: { type: string }) => t.type == TokenTypes.STRING,
    isSpace: (t: { type: string }) => t.type == TokenTypes.SPACE,
};

const _spaces = [" ", "\r", "\n", "\t"];
const empty_chars = null;
////
////
export class TextLexer {
    public autoSkipWhiteSpaces = true;
    public caseSensitive = false;
    public position = 0;
    protected len = 0;
    protected chars: string[] | null = [];

    public constructor(x: string) {
        this.len = x.length;
        this.chars = [...x];
    }

    public dispose() {
        //this.chars = empty_chars;
    }
    public eot(skip_ws: boolean = false) {
        if (skip_ws) this.skipWhiteSpaces();
        return this.position >= this.len;
    }

    public isWhiteSpace(x: string) {
        return _spaces.includes(x);
    }

    private skipWhiteSpacesAt(i: number) {
        if (!this.chars) return -1;
        while (i < this.len && this.isWhiteSpace(this.chars[i])) i++;
        return i;
    }

    public skipWhiteSpaces() {
        const pos1 = this.position;
        this.position = this.skipWhiteSpacesAt(this.position);
        return pos1 == this.position ? null : this.substring(pos1, this.position);
    }

    public skipLine() {
        const sb: string[] = [];
        while (this.readNextChar() != "\n" && !this.eot()) sb.push();
        return sb.join("");
    }

    public substring(pos1: number, pos2: number | undefined = undefined) {
        if (!this.chars) return "";
        if (pos2 == undefined) pos2 = this.position;
        const sb = [];
        if (pos1 < 0) pos1 = 0;
        if (pos2 > this.len) pos2 = this.len;
        for (let i = pos1; i < pos2; i++) {
            sb.push(this.chars[i]);
        }
        return sb.join("");
    }

    private canReadCharAt(c: string, i: number) {
        if (!this.chars) return false;
        if (i >= this.len) return false;
        if (this.chars[i] == c) return true;
        if (!this.caseSensitive) return this.chars[i].toLowerCase() == c.toLowerCase();
        return false;
    }

    public canReadChar(c: string) {
        return this.canReadCharAt(c, this.position);
    }

    private canReadTextAt(inputText: string, i: number) {
        const text = [...inputText];
        if (this.autoSkipWhiteSpaces) i = this.skipWhiteSpacesAt(i);
        if (i + text.length > this.len) return -1;

        for (let k = 0; k < text.length; k++) {
            if (!this.canReadCharAt(text[k], i)) return -1;
            i += 1;
        }
        return i;
    }

    public canReadText(text: string) {
        return this.canReadTextAt(text, this.position) != -1;
    }

    public readText(text: string) {
        let i = this.canReadTextAt(text, this.position);
        if (i == -1) return false;
        this.position = i == -1 ? this.len : i;
        return true;
    }

    public readNextChar() {
        if (!this.chars) return "";
        if (this.eot()) return null;
        return this.chars[this.position++];
    }

    public readUntilWhiteSpace() {
        if (!this.chars) return "";
        if (this.autoSkipWhiteSpaces) this.skipWhiteSpaces();
        var sb = [];
        while (this.position < this.len && !this.isWhiteSpace(this.chars[this.position])) {
            sb.push(this.chars[this.position]);
            this.position++;
        }
        return sb.join("");
    }

    public readUntil(inputText: string) {
        if (!this.chars) return null;
        if (!inputText) return null;
        const sb: string[] = [];
        const text = [...inputText];

        while (!this.eot()) {
            if (
                this.position + text.length <= this.len &&
                text.every((x, xIndex) => this.chars && x == this.chars[this.position + xIndex])
            ) {
                return sb.join("");
            }
            sb.push(this.chars[this.position]);
            this.position += 1;
        }
        return sb.join("");
    }

    public readUntilAny(stops: string[]) {
        if (!this.chars) return null;
        if (stops.length < 1) return null;
        const sb: string[] = [];
        const texts = stops.map((x) => [...x]);

        while (!this.eot()) {
            for (let i = 0; i < texts.length; i++) {
                const text = texts[i];
                if (
                    this.position + text.length <= this.len &&
                    text.every((x, xIndex) => this.chars && x == this.chars[this.position + xIndex])
                ) {
                    return sb.join("");
                }
            }

            sb.push(this.chars[this.position]);
            this.position += 1;
        }
        return sb.join("");
    }

    public readAfter(inputText: string) {
        if (!inputText) return null;
        const t = this.readUntil(inputText);
        if (this.eot()) return t;
        this.position += inputText.length;
        return t + inputText;
    }

    public readUntilEndOfLine() {
        const sb = [];
        let c: string | null = "";
        while (!this.eot()) {
            c = this.readNextChar();
            if (c == "\n") break;
            sb.push(c);
        }
        return sb.join("");
    }

    public canReadRegex(regex: string) {
        if (!this.chars) return null;
        if (!regex) return null;
        const sb: string[] = [];
        let i = this.position;
        while (i < this.len && this.chars[i].match(regex)) {
            sb.push(this.chars[this.position]);
            this.position += 1;
        }
        return sb.join("");
    }

    public readRegex(regex: string | null) {
        if (!this.chars) return null;
        if (!regex) return null;
        const sb: string[] = [];
        while (!this.eot() && this.chars[this.position].match(regex)) {
            sb.push(this.chars[this.position]);
            this.position += 1;
        }
        return sb.join("");
    }

    public charAt(p: number) {
        if (!this.chars) return null;
        return p < this.len ? this.chars[p] : null;
    }

    public currentChar() {
        return this.charAt(this.position - 1);
    }

    public nextChar() {
        if (!this.chars) return null;
        if (this.eot()) return null;
        return this.chars[this.position];
    }

    public tryRead(text: string, skip_whitespaces: boolean = false) {
        if (!this.chars) return false;
        if (skip_whitespaces) this.skipWhiteSpaces();
        if (this.position + text.length > this.len) return false;
        for (let i = 0; i < text.length; i++) {
            if (text[i] != this.chars[this.position + i]) return false;
        }
        this.position += text.length;
        return true;
    }

    public tryReadDigit() {
        if (this.position + 1 > this.len) return null;
        const c = this.nextChar();
        if (!this.isDigit(c)) return null;
        this.position += 1;
        return c;
    }

    private isLetterOrUndeline(c: string) {
        return !!c && (c == "$" || c == "_" || c.match(/[a-zA-Z]/));
    }

    private isAlphaNumUnderline(c: string) {
        return c.match(/[0-9a-zA-Z_$]/);
    }

    public readId() {
        if (this.autoSkipWhiteSpaces) this.skipWhiteSpaces();
        let c = this.nextChar();
        if (!c || !this.isLetterOrUndeline(c)) return null;
        const sb: string[] = [];
        sb.push(c);
        this.position += 1;
        c = this.nextChar();
        while (c != null && this.isAlphaNumUnderline(c)) {
            sb.push(c);
            this.position += 1;
            c = this.nextChar();
        }
        return sb.join("");
    }

    private isDigit(c: string | null) {
        return !!c && c.length == 1 && c >= "0" && c <= "9";
    }

    public readNumber(skip_whitespaces: boolean, float: boolean, negative: boolean) {
        if (skip_whitespaces) this.skipWhiteSpaces();
        if (this.eot()) return null;
        const pos1 = this.position;
        const sb = [];
        let dot_visited = false;
        if (this.tryRead("+")) sb.push("+");
        else if (negative && this.tryRead("-")) sb.push("-");

        let c = this.tryReadDigit();
        if (c == null) {
            this.position = pos1;
            return null;
        }

        while (c != null) {
            sb.push(c);
            c = this.tryReadDigit();
        }
        if (float && this.tryRead(".")) {
            sb.push(".");
            c = this.tryReadDigit();
            while (c != null) {
                sb.push(c);
                c = this.tryReadDigit();
            }
        }
        return sb.join("");
    }

    private readStringToken(skip_whitespaces: boolean = false) {
        if (!this.chars) return null;
        if (skip_whitespaces) this.skipWhiteSpaces();

        const c1 = this.position < this.len && this.chars[this.position];
        const c2 = this.position + 1 < this.len && this.chars[this.position + 1];
        const q = c1 == "$" ? c2 : c1;
        if (q != '"' && q != "'") return null;
        const sb: string[] = [];
        this.position += c1 == "$" ? 2 : 1;
        while (true) {
            let c = this.readNextChar();
            if (c == q) break;
            if (c == null) throw new Error("Syntax Error: Invalid or unexpected token");
            if (c == "\\") {
                c = this.readNextChar();
                if (c == null) throw new Error("Syntax Error: Invalid or unexpected token");
                if (c == "f") sb.push("\f");
                else if (c == "n") sb.push("\n");
                else if (c == "r") sb.push("\r");
                else if (c == "t") sb.push("\t");
                else if (c == "v") sb.push("\v");
                else sb.push(c);
            } else {
                sb.push(c);
            }
        }
        return sb.join("");
    }

    private readTemplateString(skip_whitespaces: boolean = false) {
        if (skip_whitespaces) this.skipWhiteSpaces();

        const q = this.nextChar();
        if (q != "`") return null;
        const sb: string[] = [q];
        this.position += 1;
        while (true) {
            let c = this.readNextChar();
            if (c == q) {
                sb.push(q);
                break;
            }
            if (c == null) throw new Error("Syntax Error: Invalid or unexpected token");
            /*
            if (c == "\\") {
                c = this.readNextChar();
                if (c == null) throw new Error("Syntax Error: Invalid or unexpected token");
                if (c == "f") sb.push("\f");
                else if (c == "n") sb.push("\n");
                else if (c == "r") sb.push("\r");
                else if (c == "t") sb.push("\t");
                else if (c == "v") sb.push("\v");
                else sb.push(c);
            } else {
                sb.push(c);
            }
            */
            sb.push(c);
        }
        return sb.join("");
    }

    public readComment() {
        if (this.tryRead("//")) {
            return "//" + this.readUntil("\n");
        }
        if (this.tryRead("/*")) {
            const s = "/*" + this.readUntil("*/");
            return this.tryRead("*/") ? s + "*/" : s;
        }
        return null;
    }

    public skipUntilUnbalanceChar() {
        let t = this.readJsToken(false);
        while (t.text != null) {
            if ([")", "]", "}"].includes(t.text)) {
                this.unReadToken(t);
                return true;
            }
            if (t.text == "(") {
                if (!this.skipUntilUnbalanceChar()) return false;
                if (!this.tryRead(")")) return false;
            } else if (t.text == "[") {
                if (!this.skipUntilUnbalanceChar()) return false;
                if (!this.tryRead("]")) return false;
            } else if (t.text == "{") {
                if (!this.skipUntilUnbalanceChar()) return false;
                if (!this.tryRead("}")) return false;
            }
            t = this.readJsToken(false);
        }
        return false;
    }

    public readBalanced(stopChar: string, includeStopChar: boolean = true) {
        const pos1 = this.position;
        if (!this.skipBalanced(stopChar)) return this.substring(pos1);
        return includeStopChar ? this.substring(pos1) : this.substring(pos1, this.position - stopChar.length);
    }

    public skipBalanced(stopChar: string) {
        let t = this.readJsToken(false);
        while (t.text != null) {
            switch (t.text) {
                case stopChar:
                    return true;

                case "(":
                    if (!this.skipBalanced(")")) return false;
                    break;

                case "[":
                    if (!this.skipBalanced("]")) return false;
                    break;

                case "{":
                    if (!this.skipBalanced("}")) return false;
                    break;
            }

            t = this.readJsToken(false);
        }
        return false;
    }

    public skipBalancedUntil(stopChars: string[]) {
        let t = this.readJsToken(false);
        while (t.text != null) {
            if (stopChars.indexOf(t.text) >= 0) {
                return true;
            }
            switch (t.text) {
                case "(":
                    if (!this.skipBalancedUntil([")"])) return false;
                    break;

                case "[":
                    if (!this.skipBalancedUntil(["]"])) return false;
                    break;

                case "{":
                    if (!this.skipBalancedUntil(["}"])) return false;
                    break;
            }

            t = this.readJsToken(false);
        }
        return false;
    }

    public readIdSequence() {
        let t = this.readJsToken(true);
        const sb = [];
        while (t.type == "ID" || t.type == "KEYWORD") {
            sb.push(t.text);
            t = this.readJsToken(true);
        }
        if (!(t.type == "ID" || t.type == "KEYWORD")) {
            this.unReadToken(t);
        }
        return sb.join(" ");
    }

    public readJsToken(skipComments: boolean) {
        const pos = this.position;
        let text: string | null;
        if (skipComments) {
            while (this.skipWhiteSpaces() || this.readComment()) {}
        } else {
            text = this.skipWhiteSpaces();
            if (!!text) return { text, position: pos, type: TokenTypes.SPACE };
            //
            text = this.readComment();
            if (!!text) return { text, position: pos, type: TokenTypes.COMMENT };
        }
        //
        text = this.readStringToken();
        if (text != null) return { text, position: pos, type: TokenTypes.STRING };
        //
        text = this.readTemplateString();
        if (text != null) return { text, position: pos, type: TokenTypes.TEMPLATE_STRING };
        //
        text = this.readId();
        if (!!text) return { text, position: pos, type: jsKeywords.includes(text) ? TokenTypes.KEYWORD : TokenTypes.ID };
        //
        text = this.readNumber(true, true, true);
        if (!!text) return { text, position: pos, type: TokenTypes.NUMBER };
        //
        const special_symbols = ["===", "==", "!==", "!=", "+=", "++", "-=", "--", "*=", "/=", ">=", "<=", ">>", "<<", "||", "&&"];
        for (let i = 0; i < special_symbols.length; i++) {
            text = special_symbols[i];
            if (this.tryRead(text)) return { text, position: pos, type: TokenTypes.SYMBOL };
        }

        //
        text = this.readNextChar();
        if (!text) return { text, position: pos, type: TokenTypes.EOT };
        return { text, position: pos, type: TokenTypes.SYMBOL };
    }

    public unReadToken(token: { position: number }) {
        this.position = token.position;
    }

    public getTextPosition(position: number) {
        let lineNumber = 1;
        let column = 1;
        if (!!this.chars) {
            for (let i = 0; i < position && i < this.chars.length; ++i) {
                if (this.chars[i] !== "\n") column += 1;
                else {
                    lineNumber += 1;
                    column = 1;
                }
            }
        }
        return { lineNumber, column };
    }

    public getRange(fromPosition: number, toPosition?: number) {
        if (!toPosition) toPosition = this.position - 0;
        const p1 = this.getTextPosition(fromPosition);
        const p2 = this.getTextPosition(toPosition);
        return { fromLineNumber: p1.lineNumber, fromColumn: p1.column, toLineNumber: p2.lineNumber, toColumn: p2.column } as TextRange;
    }
}
