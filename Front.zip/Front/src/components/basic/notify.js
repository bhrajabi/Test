import { toast } from "react-toastify";

export const notify = {
    error: (title, message, props) => {
        if (title instanceof Error) {
            const ex = title;
            title = ex.message;
        } else if (title === "object" && title.response) {
            const ex = title;
            title = ex.response.data;
            message = ex.toString();
        }

        if (message instanceof Error) {
            const ex = message;
            message = ex.message;
        }

        if (!message) toast.error(<div>{title}</div>);
        else
            toast.error(
                () => (
                    <>
                        <h5>{title}</h5>
                        <small>{message}</small>
                    </>
                ),
                props
            );
    },

    success: (title, message, props) => {
        if (!message) toast.success(<div>{title}</div>);
        else
            toast.success(
                () => (
                    <>
                        <h5>{title}</h5>
                        <small>{message}</small>
                    </>
                ),
                props
            );
    },

    info: (title, message, props) => {
        if (!message) toast.info(<div>{title}</div>, { position: "bottom-center", ...props });
        else
            toast.info(
                () => (
                    <>
                        <h5>{title}</h5>
                        <small>{message}</small>
                    </>
                ),
                { position: "bottom-center", ...props }
            );
    },

    warning: (title, message, props) => {
        if (!message) toast.warning(<div>{title}</div>);
        else
            toast.warning(
                () => (
                    <>
                        <h5>{title}</h5>
                        <small>{message}</small>
                    </>
                ),
                props
            );
    },

    dark: (title, message, props) => {
        if (!message) toast.dark(<div>{title}</div>, { position: "bottom-center", ...props });
        else
            toast.dark(
                () => (
                    <>
                        <h5>{title}</h5>
                        <small>{message}</small>
                    </>
                ),
                { position: "bottom-center", ...props }
            );
    },

    close: (id) => toast.dismiss(id),
};
