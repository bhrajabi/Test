import { useState } from "react";
import * as bd from "react-basic-design";
import { code } from "./code";

type NumberInputProps = {
    value?: number | string | null;
    canTogglePercentage?: boolean;
    type?: "textarea" | "select" | "text" | "number" | "email" | "password" | "search" | "time" | "url" | "tel";
    inputStyle?: React.CSSProperties;
    buttonIcon?: React.ReactNode;
    maxLength?: number | string;
    buttonOnClick?: () => void;
    onChange: (ev: any) => void;

    [x: string]: any;
};

export const NumberInput = ({
    value = "",
    canTogglePercentage,
    inputStyle,
    buttonIcon,
    buttonOnClick,
    maxLength,
    type,
    onChange,
    ...props
}: NumberInputProps) => {
    const [hasPercent, setHasPercent] = useState(typeof value === "string" && value.endsWith("%"));

    const extractNumber = (text: string) => {
        if (typeof text !== "string") return text;
        if (!text) return null;
        const is_neg = text[0] == "-";
        if (is_neg) text = text.substring(1);
        const _val = text.match(/\d/g)?.join("");
        if (!_val) return null;
        return is_neg ? "-" + _val : _val;
    };

    const callOnChange = (_val: any, has_percent: boolean) => {
        if (_val === undefined) _val = null;
        else if (has_percent && _val) _val += "%";
        else if (_val) _val = type !== "tel" ? Number(_val) : _val;
        if (onChange) onChange({ target: { value: _val } });
    };

    const onChangeHandler = (ev: any) => {
        let _val = ev.target.value;
        _val = extractNumber(_val);
        // if (!supportNegative && !isNaN(_val) && Number(_val) < 0) {
        //     _val = "0";
        // }
        callOnChange(_val, hasPercent);
    };

    if (typeof value === "string") value = extractNumber(value);

    if (type === "tel") value = code.numbers(value) ?? "";
    if (type !== "tel") value = code.numberWithCommas(value) ?? "";

    return (
        <bd.TextField
            value={value}
            onChange={onChangeHandler}
            {...props}
            maxLength={maxLength ? maxLength : 21}
            type={"tel" as any}
            inputStyle={inputStyle}
            buttonIcon={canTogglePercentage || buttonIcon ? (hasPercent ? "%" : buttonIcon ?? "#") : null}
            buttonOnClick={() => {
                if (buttonOnClick) return buttonOnClick();
                if (!canTogglePercentage) return;
                const has_percent = !hasPercent;
                setHasPercent(has_percent);
                callOnChange(value, has_percent);
            }}
        />
    );
};
