import * as bd from "react-basic-design";
import { Modal } from "react-bootstrap";
import { useNavigate } from "react-router-dom";
import SvgArrowBack from "../../assets/icons/ArrowBack";
import SvgSync from "../../assets/icons/Sync";
import { T } from "./text";

type InitFailedProps = {
    ex: any;
    onRetry?: () => void;
    modal?: boolean;
    show?: boolean;
    onHide?: () => void;
    hideGoBack?: boolean;
};

export const InitFailed = ({ ex, onRetry, modal, show, onHide, hideGoBack }: InitFailedProps) => {
    const history = useNavigate();
    if (ex instanceof Error) ex = ex.message;
    else if (typeof ex === "object" && ex.response) ex = ex.response.data;

    const retry = () => {
        if (onRetry) onRetry();
        else {
            window.location.reload();
        }
    };

    const result = (
        <div className="text-center text-secondary-text middle h-100 p-3" style={{ maxHeight: 300, minHeight: 200 }}>
            <div>
                <T as="p" maxWidth={600} style={{ maxWidth: 600 }}>
                    {ex ?? "error-in-loading"}
                </T>
                <div>
                    <bd.Flex vertical>
                        <bd.Button onClick={retry} className="justify-content-start">
                            <SvgSync />
                            <T className="p-s-2">{onRetry ? "retry" : "refresh"}</T>
                        </bd.Button>
                        {!hideGoBack && (
                            <bd.Button variant="text" onClick={() => history(-1)} className="justify-content-start p-s-4">
                                <SvgArrowBack />
                                <T>go-back</T>
                            </bd.Button>
                        )}
                    </bd.Flex>
                </div>
            </div>
        </div>
    );

    return !modal ? (
        result
    ) : (
        <Modal show={show} onHide={onHide} size="lg">
            <Modal.Body>{result}</Modal.Body>
        </Modal>
    );
};
