import { CSSProperties, MouseEventHandler, ReactElement, ReactNode, useState } from "react";
import * as bd from "react-basic-design";
import { code } from "./code";
import { notify } from "./notify";
import { T } from "./text";

type PromiseButtonProps = {
    type?: string;
    outline?: boolean;
    color?: "" | "inherit" | "default" | "primary" | "secondary";
    className?: string;
    style?: CSSProperties;
    size?: "" | "sm" | "md" | "lg";
    disableRipple?: boolean;
    pill?: boolean;
    disabled?: boolean;
    icon?: ReactElement;
    children: ReactNode;

    confirmMessage?: string;

    onHide?: VoidFunction;
    onValidate?: () => boolean;
    onDone?: (result: any) => void;
    onClick: () => void | null | undefined | Promise<any>;
};

export const PromiseButton = ({
    type,
    outline,
    color,
    className,
    style,
    size,
    disableRipple,
    pill,
    disabled,
    icon,
    children,
    confirmMessage,

    onHide,
    onDone,
    onClick,
    onValidate,
}: PromiseButtonProps) => {
    const [isBusy, setIsBusy] = useState(false);

    if (!className || !className.includes("min-w-80")) className = ((className ?? "") + " min-w-80").trim();

    const onClickHandler = (ev: MouseEventHandler) => {
        code.stopPropagationFunc(ev);
        if (onValidate && !onValidate()) return;
        if (!confirmMessage) execute();
        else
            bd.msgbox(null, <T>{confirmMessage}</T>, [{ title: <T>continue</T>, action: execute }, { title: <T>close</T> }], {
                backdropClassName: "modal-n1",
                className: "modal-n1",
            });
    };

    const execute = () => {
        const prom = onClick();
        if (prom instanceof Promise) {
            setIsBusy(true);
            prom.then((result) => {
                onDone && onDone(result);
                onHide && onHide();
            })
                .catch((ex) => ex && notify.error(ex))
                .finally(() => {
                    setIsBusy(false);
                });
        }
    };

    return (
        <>
            <bd.Button
                variant={outline ? "outline" : "contained"}
                color={color}
                className={className}
                style={style}
                type={type ?? "button"}
                size={size}
                disableRipple={disableRipple}
                pill={pill}
                disabled={disabled || isBusy}
                onClick={onClickHandler}
            >
                {isBusy && <div className="m-e-2 spinner-border spinner-border-sm"></div>}
                {!isBusy && icon}
                {children}
            </bd.Button>
        </>
    );
};
