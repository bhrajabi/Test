import { Link } from "react-router-dom";
import classNames from "classnames";
import { CSSProperties } from "react";

type LinkButtonProps = {
    variant?: "" | "inherit" | "contained" | "flat" | "icon" | "text" | "outline" | "fab";
    size?: "" | "sm" | "md" | "lg";
    disabled?: boolean;
    href?: string;
    className?: string;
    title?: string;
    color?: "" | "inherit" | "default" | "primary" | "secondary";
    edge?: "start" | "end";
    active?: boolean;
    style?: CSSProperties;
    children?: any;
    onClick?: (e: any) => void;
};

export const LinkButton = ({
    variant = "text",
    size,
    disabled = false,
    href,
    className,
    title,
    color = "primary",
    edge,
    active = false,
    style,
    children,
    onClick,
    ...props
}: LinkButtonProps) => {
    var cn = "btn ";
    //------
    if (color === "inherit") color = "";
    else if (!color) color = "primary";

    if (!variant) variant = "text";
    //------
    if (variant === "icon") {
        cn += " btn-icon";
        if (color) cn += ` btn-text-${color}`;
    } else if (variant === "text") {
        cn += " btn-text";
        if (color) cn += ` btn-text-${color}`;
    } else if (variant === "outline") {
        cn += " btn-outline";
        if (color) cn += ` btn-outline-${color}`;
    } else if (variant === "fab") {
        cn += " btn-fab";
        if (color) cn += ` btn-${color}`;
    } else if (variant === "contained" || variant === "flat") {
        if (!!color) {
            cn += ` btn-contained btn-${color}`;
        }
    }
    cn = classNames(className, cn, {
        "btn-active": active,
        "btn-flat": variant === "flat",
        "btn-sm": size === "sm",
        "btn-md": size === "md",
        "btn-lg": size === "lg",
        "btn-disabled": !!disabled,
        "pe-none": !!disabled && !!href,
        "btn-edge-start": edge === "start",
        "btn-edge-end": edge === "end",
    });

    let newProps: any = { onClick };
    if (disabled) newProps = { ...newProps, disabled };
    return (
        <Link className={cn} to={href} style={style} title={title} {...newProps} {...props}>
            {children}
        </Link>
    );
};
