import { useEffect, useRef } from "react";

export const useWaiting = () => {
    const isBusy = useRef(false);
    const get = () => document.getElementById("_Progress_Tracker_");
    const onFocus = () => isBusy.current && document.activeElement.blur();
    let startTime = useRef();

    const start = () => {
        if (isBusy.current) return;
        get().style.display = "block";
        document.activeElement.blur();
        isBusy.current = true;
        startTime.current = new Date();
    };

    const stop = () => {
        var action = () => {
            get().style.display = "none";
            isBusy.current = false;
        };
        var now = new Date();
        if (startTime.current && now - startTime.current > 5) action();
        else setTimeout(action, 5);
    };

    useEffect(() => {
        if (!window.addEventListener) return;
        window.addEventListener("focus", onFocus, true);
        return () => window.removeEventListener("focus", onFocus, true);
    });

    return { start, stop, isBusy };
};
