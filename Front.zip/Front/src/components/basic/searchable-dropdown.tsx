import { CSSProperties } from "react";
import * as bd from "react-basic-design";
import { translate } from "./text";
import classNames from "classnames";

export type SearchableItem = { id: number | string; title: string };
export type OnChangeSearchableDropdown = (ev: { target: { name?: string; value?: string } }) => void;

type SearchableDropdownProps = {
    id?: string;
    name?: string;
    value?: string;
    items: (SearchableItem | string)[];
    searchPlaceholder?: string;
    autoFocus?: boolean;
    readOnly?: boolean;

    className?: string;
    maxLength?: number | string;
    width?: number | string;
    minWidth?: number | string;
    maxWidth?: number | string;
    dropdownHeight?: number | string;
    style?: CSSProperties;
    title?: string;

    onChange?: OnChangeSearchableDropdown;
};

export const SearchableDropdown = ({
    id,
    name,
    value,
    items,
    searchPlaceholder,
    autoFocus,
    readOnly,

    className,
    width,
    minWidth,
    maxWidth,
    dropdownHeight,
    style,
    title,

    onChange,
}: SearchableDropdownProps) => {
    if (!minWidth && !width) width = "10rem";
    if (maxWidth) style = { ...style, maxWidth };
    if (minWidth) style = { ...style, minWidth };
    if (width) style = { ...style, width };

    const list: SearchableItem[] = items.map((x) => (typeof x === "string" ? { id: x, title: x } : x));

    const onSelectItem = (item: SearchableItem) => {
        onChange && onChange({ target: { name, value: item.id?.toString() ?? null } });
    };

    const ddStyle = { maxHeight: dropdownHeight ?? 200 };

    return (
        <>
            <bd.Button
                variant="outline"
                color="default"
                type="button"
                id={id}
                name={name}
                autoFocus={autoFocus}
                disabled={readOnly}
                disableRipple
                className={classNames(className, "text-start dropdown-no-caret form-select border-primary-on-focus overflow-hidden", {
                    "bg-gray-5": readOnly,
                    "bg-default": !readOnly,
                })}
                style={style}
                title={title}
                menu={
                    <bd.Menu
                        className="pt-0 shadow-lg overflow-auto"
                        filterable
                        searchMessage={translate(searchPlaceholder ?? "search")}
                        style={ddStyle}>
                        {list.map((x, xIndex) => (
                            <bd.MenuItem key={xIndex} onClick={() => onSelectItem(x)}>
                                {x.title ?? "empty"}
                            </bd.MenuItem>
                        ))}
                    </bd.Menu>
                }>
                <span className="w-100">{list.find((x) => x.id == value)?.title ?? value}</span>
            </bd.Button>
        </>
    );
};
