import { Link } from "react-router-dom";

export const LinkMenuItem = ({ href, ...props }) => {
    return (
        <Link className="dropdown-item" role="button" to={href}>
            {props.children}
        </Link>
    );
    // <Dropdown.Item {...props}>{props.children}</Dropdown.Item>;
};
