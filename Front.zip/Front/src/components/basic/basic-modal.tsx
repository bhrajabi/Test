import classNames from "classnames";
import { ReactNode } from "react";
import * as bd from "react-basic-design";
import { Modal } from "react-bootstrap";
import SvgClose from "../../assets/icons/Close";
import { Loading } from "./loading";

type BasicModalProps = {
    size?: "sm" | "md" | "lg" | "xl";
    depth?: "1" | "2" | "3" | "4" | "5" | "6" | "7" | "8" | "9" | "10" | "n";
    show: boolean;
    title: ReactNode;
    titleClassName?: string;
    headerButtons?: ReactNode;
    children: ReactNode;
    closeButton?: boolean;
    loading?: boolean;
    error?: ReactNode;
    className?: string;
    bodyClassName?: string;
    fullScreen?: boolean;
    backdrop?: true | false | "static";
    hideHeader?: boolean;
    onHide?: VoidFunction;
};

export const BasicModal = ({
    size,
    depth,
    show,
    onHide,
    title,
    titleClassName,
    headerButtons,
    children,
    closeButton,
    loading,
    error,
    className,
    bodyClassName,
    fullScreen,
    backdrop,
    hideHeader,
}: BasicModalProps) => {
    if (error instanceof Error) error = error.message;

    return (
        <>
            <Modal
                show={show}
                onHide={onHide}
                size={size == "md" ? undefined : size}
                fullscreen={!size ? (fullScreen ? true : undefined) : `${size}-down`}
                contentClassName="shadow-5 overflow-hidden"
                className={classNames(className, !depth ? undefined : `modal-${depth}`)}
                backdropClassName={!depth ? undefined : `modal-${depth}`}
                backdrop={backdrop}
            >
                {!(hideHeader || (!title && !headerButtons && !closeButton)) && (
                    <Modal.Header className={titleClassName} style={{ zIndex: 10 }}>
                        <bd.Flex align="center" className="flex-grow-1" gap={2}>
                            <div className="m-0 h5 flex-grow-1">{title}</div>
                            {!loading && !error && headerButtons}
                            {closeButton && (
                                <bd.Button color="default" className="bg-transparent p-1 btn-close" variant="icon" onClick={onHide}>
                                    <SvgClose />
                                </bd.Button>
                            )}
                        </bd.Flex>
                    </Modal.Header>
                )}

                <Modal.Body className={bodyClassName}>
                    {loading && !error && <Loading />}
                    {!loading && !!error && <div className={classNames("rounded alert-danger p-3", { "mt-3": !title })}>{error}</div>}
                    {!loading && !error && children}
                </Modal.Body>
            </Modal>
        </>
    );
};
