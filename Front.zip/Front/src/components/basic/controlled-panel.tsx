import classNames from "classnames";
import { ReactNode, useState } from "react";
import { Collapse } from "react-bootstrap";
import * as bd from "react-basic-design";
import SvgChevronRight from "../../assets/icons/ChevronRight";

interface ControlledPanelProps {
    variant?: "text" | "button" | "menu";
    className?: string;
    title?: ReactNode;
    headerClassName?: string;
    titleClassName?: string;
    caretPosition?: "" | "start" | "middle" | "end";
    size?: "" | "sm" | "md" | "lg";
    fixed?: boolean;
    expanded?: boolean;
    disabled?: boolean;
    controls?: any;
    lazyload?: boolean;
    children?: any;
    setExpanded: (expanded: boolean) => void;
}

export const ControlledPanel = ({
    variant,
    className,
    title,
    headerClassName,
    titleClassName,
    caretPosition,
    size,
    fixed,
    expanded,
    disabled,
    controls,
    lazyload,
    children,
    setExpanded,
    ...props
}: ControlledPanelProps) => {
    const [render, setRender] = useState(expanded || !lazyload);

    const cn = classNames("bd-panel", className, { "bd-panel-menu": variant === "menu" });

    const toggle = (caret: any) => {
        var just_caret = variant !== "button" && variant !== "menu";
        if ((caret && !just_caret) || (!caret && just_caret)) return null;
        if (disabled || fixed) return;
        const isExpanded = !expanded;
        setExpanded(isExpanded);
        if (!render) setRender(true);
    };

    function renderHandler(position: "start" | "end" | "middle") {
        var show = (!caretPosition && position === "start") || caretPosition === position;
        if (fixed || !children || !show) return null;
        return (
            <span
                className={classNames("px-2 py-1", {
                    "cur-pointer": !disabled,
                    "edge-start": position === "start",
                    "edge-end": position === "end",
                })}
                onClick={() => toggle(true)}
            >
                <SvgChevronRight
                    className={classNames("transition-transform", {
                        "rotate-90": expanded,
                        "rtl-rotate-180": !expanded,
                    })}
                />
            </span>
        );
    }

    return (
        <div className={cn} {...props}>
            <bd.Toolbar
                size={size}
                onClick={() => toggle(false)}
                className={classNames(headerClassName, {
                    "cur-pointer": variant === "button" || variant === "menu",
                    disabled: disabled,
                })}
            >
                {renderHandler("start")}
                <h5 className={classNames("d-flex", titleClassName, { "flex-grow-1": caretPosition !== "middle" })}>{title}</h5>

                {renderHandler("middle")}

                {controls != null && <div className="m-s-auto"></div>}
                {controls}
                {renderHandler("end")}
            </bd.Toolbar>

            {children && (
                <Collapse in={expanded}>
                    <div>{(render || expanded) && children}</div>
                </Collapse>
            )}
        </div>
    );
};
