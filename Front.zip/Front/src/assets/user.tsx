import * as React from "react";

function SvgUser(props: React.SVGProps<SVGSVGElement>) {
    return (
        <svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 20 20" {...props}>
            <circle cx="10" cy="8" r="4" />
            <circle cx="10" cy="20" r="8" />
        </svg>
    );
}

export default SvgUser;
