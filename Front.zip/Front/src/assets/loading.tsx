import classNames from "classnames";
import * as React from "react";

function SvgLoading({ className }: { className?: string }) {
    return <div className={classNames(className, "spinner-border spinner-border-sm")}></div>;
}

export default SvgLoading;
