const SvgSandGlass = (props: any) => (
    <svg overflow="visible" viewBox="0 0 30.253 50.243" xmlns="http://www.w3.org/2000/svg" {...props}>
        <path
            d="M.697 4.347c0 15.548 13.34 13.222 13.34 20.812C14.037 32.138.842 29.2.842 45.972h28.856c0-16.712-13.775-13.736-13.775-20.813 0-7.534 13.605-7.534 13.701-20.812H.697z"
            fill="#ddd"
            stroke="#000"
            strokeWidth={1.038}
        />
        <path
            d="M1.956 44.819c2.164.067 24.894.067 26.585.067.067-.54-.135-3.99-1.557-7.373-1.556 0-23.405-.067-23.405-.067-1.759 3.653-1.69 7.509-1.623 7.373zM4.797 13.973c5.412.339 13.868.541 19.212.067-.136 1.895-8.998 5.345-9.065 9.605-.068-4.26-9.606-7.17-10.147-9.672z"
            fill="#B5AB93"
        />
        <linearGradient
            id="a"
            x1={-317.26}
            x2={-316.71}
            y1={542.41}
            y2={542.41}
            gradientTransform="matrix(29.494 0 0 -4.0625 9368.1 2206)"
            gradientUnits="userSpaceOnUse"
        >
            <stop stopColor="#A7873D" offset={0} />
            <stop stopColor="#663624" offset={1} />
        </linearGradient>
        <path fill="url(#a)" stroke="#000" strokeWidth={0.759} d="M.38.38h29.493v4.062H.38z" />
        <linearGradient
            id="b"
            x1={-317.26}
            x2={-316.72}
            y1={542.41}
            y2={542.41}
            gradientTransform="matrix(29.494 0 0 -4.0625 9368.1 2251.4)"
            gradientUnits="userSpaceOnUse"
        >
            <stop stopColor="#A7873D" offset={0} />
            <stop stopColor="#663624" offset={1} />
        </linearGradient>
        <path fill="url(#b)" stroke="#000" strokeWidth={0.759} d="M.38 45.801h29.493v4.062H.38z" />
        <path
            d="M4.003 6.02h6.088c0 10.932 4.687 11.253 5.173 17.354C13.178 16.083 4.689 16.01 4.003 6.02zM3.722 45.108H9.81c-1.663-11.188 4.687-10.673 5.172-18.202-2.086 7.291-12.119 5.14-11.26 18.202z"
            fill="#fff"
            opacity={0.6}
        />
    </svg>
);

export default SvgSandGlass;
