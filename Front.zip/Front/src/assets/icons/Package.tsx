import * as React from "react";

function SvgPackage(props: React.SVGProps<SVGSVGElement>) {
    return (
        <svg xmlns="http://www.w3.org/2000/svg" height="48" viewBox="0 96 960 960" width="48">
            <path d="m380 508 100-50 100 50V276H380v232ZM280 776v-80h200v80H280ZM180 936q-24 0-42-18t-18-42V276q0-24 18-42t42-18h600q24 0 42 18t18 42v600q0 24-18 42t-42 18H180Zm0-660v600-600Zm0 600h600V276H640v329l-160-80-160 80V276H180v600Z" />
        </svg>
    );
}

export default SvgPackage;
