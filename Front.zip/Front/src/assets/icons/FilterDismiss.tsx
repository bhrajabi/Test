import * as React from "react";

function SvgFilterDismiss(props: React.SVGProps<SVGSVGElement>) {
    return (
        <svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24" {...props}>
            <path
                fill="#828282"
                d="M23 7.5a5.5 5.5 0 1 1-11 0a5.5 5.5 0 0 1 11 0m-7.146-2.354a.5.5 0 0 0-.708.708L16.793 7.5l-1.647 1.646a.5.5 0 0 0 .708.708L17.5 8.207l1.646 1.647a.5.5 0 0 0 .708-.708L18.207 7.5l1.647-1.646a.5.5 0 0 0-.708-.708L17.5 6.793zM13.346 12.5a6.5 6.5 0 0 1-1.324-1.5H7.5a.75.75 0 0 0 0 1.5zM11 7.5q.002-.776.174-1.5H4.5a.75.75 0 0 0 0 1.5zm2.5 8.5a.75.75 0 0 1 0 1.5h-3a.75.75 0 0 1 0-1.5z"
            />
        </svg>
    );
}

export default SvgFilterDismiss;
