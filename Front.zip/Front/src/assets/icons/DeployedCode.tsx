import * as React from "react";

function SvgDeployedCode(props: React.SVGProps<SVGSVGElement>) {
    return (
        <svg xmlns="http://www.w3.org/2000/svg" height="48" viewBox="0 96 960 960" width="48">
            <path d="m180 746 270 156V593L180 437v309Zm330 156 270-156V436L510 593v309ZM213 387l267 155 266-155-266-154-267 154Zm-93 394V406q0-16 8-30t22-22l300-173q14-8 30-8t30 8l300 173q14 8 22 22t8 30v340q0 16-8 30t-22 22L510 971q-14 8-30 8t-30-8L120 781Zm360-205Z" />
        </svg>
    );
}

export default SvgDeployedCode;
