import * as React from "react";

function SvgArrowLeft(props: React.SVGProps<SVGSVGElement>) {
    return (
        <svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 48 48" {...props}>
            <path d="M28 34 18 24l10-10Z" />
        </svg>
    );
}

export default SvgArrowLeft;
