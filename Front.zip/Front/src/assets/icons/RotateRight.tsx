import * as React from "react";

function SvgRotateRight(props: React.SVGProps<SVGSVGElement>) {
    return (
        <svg viewBox="0 0 50 50" {...props}>
            <circle
                cx="25"
                cy="25"
                r="20"
                fill="none"
                stroke="currentColor"
                stroke-width="4"
                stroke-linecap="round"
                stroke-dasharray="125, 50"
            />
        </svg>
    );
}

export default SvgRotateRight;
