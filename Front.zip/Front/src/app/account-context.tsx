import React, { ReactNode, useContext, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { accountApi } from "../api/account-api";
import { api } from "../api/api";
import { setAppInfo } from "./constatnts";
import settings from "./settings";
import { RootState } from "./stores/store";
import { CompanyInfo, ConnectionStatuses, userInfoActions } from "./stores/user-info-slice";

export type AccountType = {
    connected?: boolean;
    setAsLoggedIn: VoidFunction;
    setAsConnected: VoidFunction;
    setAsConnecting: VoidFunction;
    setAsConnectionFailed: VoidFunction;
    setAsLoggedOut: () => void;
    setAsForbidden: () => void;

    getStatus: () => string | undefined;

    token?: string;
    status?: ConnectionStatuses;
    userName?: string;
    uniqueId?: string;
    displayName?: string;
    companyName?: string;
    companyId?: number;
    chartUserRoleSerial?: number | null;
    companyUniqueId?: string;
    enablePublicProfile?: boolean;
    isSeller?: boolean;
    isBuyer?: boolean;
    companies?: CompanyInfo[];
    isCarrier?: boolean;
    isNetwork?: boolean;

    isConnecting: () => boolean;
    isConnectionFailed: () => boolean;
    isConnected: () => boolean;
    isLoggedIn: () => boolean;
    isLoggedOut: () => boolean;
    isForbidden: () => boolean;

    init: () => Promise<any>;
    login: (key: string, userName: string, companyId: number, chartUserRoleSerial: number, current2FA?: string) => Promise<any>;
    resetLoginData: (
        status: ConnectionStatuses,
        token: string,
        userName: string,
        uniqueId: string,
        displayName: string,
        companyId: number,
        companyUniqueId: string,
        companyName: string,
        taskCount: number,
        show2FAAlarm: boolean,
        enablePublicProfile: boolean,
        isSeller: boolean,
        isBuyer: boolean,
        isCarrier: boolean,
        companies: any[],
        chartUserRoleSerial: number
    ) => void;

    logout: () => Promise<any>;
};

export const AccountContext = React.createContext<AccountType>({} as any);

export const useAccount = () => useContext<AccountType>(AccountContext);

export const AccountProvider = ({ children }: { children: ReactNode }) => {
    const dispatch = useDispatch();
    const userInfo = useSelector((state: RootState) => state.userInfo);

    useEffect(() => {
        const onLogoutEvent = (event: any) => {
            if (event.key === "sync-logout") logout(false);
        };
        window.addEventListener("storage", onLogoutEvent);
        return () => window.removeEventListener("storage", onLogoutEvent);
    }, []);

    function logout(sync: boolean) {
        let result = Promise.resolve();
        if (!api.getToken()) return result;
        account.setAsLoggedOut();
        if (sync) {
            result = accountApi.logout();
            api.setData({});
            localStorage.setItem("sync-logout", Date.now().toString());
        }
        api.setData({});
        return result;
    }

    const account: AccountType = {
        connected: userInfo.status === "connected" || userInfo.status === "logged-in",

        token: userInfo.token,
        status: userInfo.status,
        getStatus: () => userInfo.status,

        setAsLoggedIn: () => dispatch(userInfoActions.setStatus("logged-in")),
        setAsConnected: () => dispatch(userInfoActions.setStatus("connected")),
        setAsConnecting: () => dispatch(userInfoActions.setStatus("connecting")),
        setAsConnectionFailed: () => dispatch(userInfoActions.setStatus("connection-failed")),
        setAsLoggedOut: () => dispatch(userInfoActions.setStatus("logged-out")),
        setAsForbidden: () => dispatch(userInfoActions.setStatus("forbidden")),

        userName: userInfo.userName,
        uniqueId: userInfo.uniqueId,
        displayName: userInfo.displayName,
        companyName: userInfo.companyName,
        companyId: userInfo.companyId,
        chartUserRoleSerial: userInfo.chartUserRoleSerial,
        companyUniqueId: userInfo.companyUniqueId,
        enablePublicProfile: userInfo.enablePublicProfile,
        isSeller: userInfo.isSeller,
        isBuyer: userInfo.isBuyer,
        companies: userInfo.companies,
        isCarrier: userInfo.isCarrier,
        isNetwork: userInfo.companyName == "(NETWORK)",

        isConnecting: () => userInfo.status === "connecting",
        isConnectionFailed: () => userInfo.status === "connection-failed",
        isConnected: () => userInfo.status === "connected" || userInfo.status === "logged-in",
        isLoggedIn: () => userInfo.status === "logged-in",
        isLoggedOut: () => userInfo.status === "logged-out",
        isForbidden: () => userInfo.status === "forbidden",

        init: () => {
            account.setAsConnecting();
            return accountApi
                .userInfo()
                .then((result) => {
                    account.resetLoginData(
                        "connected",
                        result.token,
                        result.userName,
                        result.uniqueId,
                        result.displayName,
                        result.companyId,
                        result.companyUniqueId,
                        result.companyName,
                        result.taskCount,
                        result.show2FAAlarm,
                        result.enablePublicProfile,
                        result.isSeller,
                        result.isBuyer,
                        result.isCarrier,
                        result.companies,
                        result.chartUserRoleSerial
                    );
                    setAppInfo(result.appInfo);
                    return result;
                })
                .catch((ex) => {
                    if (ex.name === "401") account.setAsLoggedOut();
                    else account.setAsConnectionFailed();
                    throw ex;
                });
        },

        login: (key: string, userName: string, companyId: number, chartUserRoleSerial: number, current2FA?: string) =>
            accountApi
                .login({ key, userName, companyId, chartUserRoleSerial, appVersion: settings.getAppVersion(), current2FA })
                .then((result) => {
                    account.resetLoginData(
                        "logged-in",
                        result.token,
                        result.userName,
                        result.uniqueId,
                        result.displayName,
                        result.companyId,
                        result.companyUniqueId,
                        result.companyName,
                        result.taskCount,
                        result.show2FAAlarm,
                        result.enablePublicProfile,
                        result.isSeller,
                        result.isBuyer,
                        result.isCarrier,
                        result.companies,
                        chartUserRoleSerial
                    );
                    setAppInfo(result.appInfo);
                    return result;
                }),

        resetLoginData: (
            status: ConnectionStatuses,
            token: string,
            userName: string,
            uniqueId: string,
            displayName: string,
            companyId: number,
            companyUniqueId: string,
            companyName: string,
            taskCount: number,
            show2FAAlarm: boolean,
            enablePublicProfile: boolean,
            isSeller: boolean,
            isBuyer: boolean,
            isCarrier: boolean,
            companies: CompanyInfo[],
            chartUserRoleSerial: number
        ) => {
            dispatch(
                userInfoActions.init({
                    status: status,
                    token,
                    userName,
                    uniqueId,
                    displayName,
                    companyId,
                    companyUniqueId,
                    companyName,
                    taskCount,
                    show2FAAlarm,
                    enablePublicProfile,
                    isSeller,
                    isBuyer,
                    isCarrier,
                    chartUserRoleSerial,
                    companies,
                })
            );
            api.setData({ token, expiry: -1, userName, companyId, chartUserRoleSerial });
        },

        logout: () => logout(true),
    };

    useEffect(() => {
        if (userInfo.status === null) return;
        api.onUnauthorized(() => account.setAsLoggedOut());
        //api.onForbidden(() => account.isConnected() && account.setAsForbidden());
    }, [api, account]);

    return <AccountContext.Provider value={account}>{children}</AccountContext.Provider>;
};
