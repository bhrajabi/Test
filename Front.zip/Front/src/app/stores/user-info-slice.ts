import { createSlice } from "@reduxjs/toolkit";
import type { PayloadAction } from "@reduxjs/toolkit";

export interface CompanyInfo {
    chartTitle?: string;
    chartUserRoleSerial?: number;
    companyId: number;
    companyName: string;
    isConnected: boolean;
    roleTitle?: string;
    userName: string;
}

export type ConnectionStatuses = "" | "connecting" | "connection-failed" | "connected" | "logged-in" | "logged-out" | "forbidden";

export interface UserInfoState {
    token: string;
    status: ConnectionStatuses;
    userName: string;
    uniqueId: string;
    displayName: string;
    companyId: number;
    companyName: string;
    companyUniqueId: string;
    show2FAAlarm: boolean;
    taskCount: number;
    enablePublicProfile: boolean;
    isSeller: boolean;
    isBuyer: boolean;
    isCarrier: boolean;
    chartUserRoleSerial: number | null;
    companies: CompanyInfo[];
}

const initialState: UserInfoState = {
    token: "",
    status: "",
    userName: "",
    uniqueId: "",
    displayName: "",
    companyId: 0,
    companyUniqueId: "",
    companyName: "",
    taskCount: 0,
    show2FAAlarm: false,
    enablePublicProfile: false,
    isSeller: false,
    isBuyer: false,
    isCarrier: false,
    chartUserRoleSerial: null,
    companies: [],
};

const userInfoSlice = createSlice({
    name: "userInfo",
    initialState,
    reducers: {
        init: (state, action: PayloadAction<UserInfoState>) => {
            state.token = action.payload.token;
            state.status = action.payload.status;
            state.userName = action.payload.userName;
            state.uniqueId = action.payload.uniqueId;
            state.displayName = action.payload.displayName;
            state.companyId = action.payload.companyId;
            state.companyUniqueId = action.payload.companyUniqueId;
            state.companyName = action.payload.companyName;
            state.show2FAAlarm = action.payload.show2FAAlarm;
            state.taskCount = action.payload.taskCount;
            state.enablePublicProfile = action.payload.enablePublicProfile;
            state.isSeller = action.payload.isSeller;
            state.isBuyer = action.payload.isBuyer;
            state.isCarrier = action.payload.isCarrier;
            state.chartUserRoleSerial = action.payload.chartUserRoleSerial;
            state.companies = action.payload.companies;
        },

        setStatus: (state, action: PayloadAction<ConnectionStatuses>) => {
            state.status = action.payload;
        },

        updateTaskCount: (state, action) => {
            state.taskCount = action.payload.taskCount;
        },

        disableShow2FAAlarm: (state) => {
            state.show2FAAlarm = false;
        },
    },
});

const actions = userInfoSlice.actions;
export const userInfoActions = {
    init: actions.init,
    setStatus: actions.setStatus,
    updateTaskCount: actions.updateTaskCount,
    disableShow2FAAlarm: actions.disableShow2FAAlarm,
};
export const userInfoReducer = userInfoSlice.reducer;
