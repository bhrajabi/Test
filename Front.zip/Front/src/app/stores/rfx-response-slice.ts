import type { PayloadAction } from "@reduxjs/toolkit";
import { createSlice } from "@reduxjs/toolkit";
import { ResponseAlternativeForRFXDTO, ResponseSelectionDTO } from "../../api/rfx-api";
import { enums } from "../constatnts";

export interface RfxResponseState {
    selections: ResponseSelectionDTO[];
    alternatives: ResponseAlternativeForRFXDTO[];
    currAltId?: number;
    readOnly: boolean;
    alreadySubmited: boolean;
    responseCurrencyId: string;
}

const initialState: RfxResponseState = {
    selections: [],
    alternatives: [],
    currAltId: 0,
    readOnly: true,
    alreadySubmited: true,
    responseCurrencyId: "",
};

const createNewAlternative = (state: any, round: number) => {
    const a: ResponseAlternativeForRFXDTO = {
        id: -1,
        title: "",
        isMain: false,
        responses: [],
        terms: [],
        responseComments: [],
        rowId: state.alternatives.filter((x: any) => x.round == round).length + 1,
        round: round,
        statusId: enums.alternativeStatuses.SUB,
    };
    return a;
};

const ensureAlternative = (state: any) => {
    if (!state.alternatives.length) state.alternatives = [createNewAlternative(state, 1)];
    if (!state.alternatives.find((x: any) => x.id == state.currAltId)) {
        state.currAltId = state.alternatives[0]?.id;
    }
};

const rfxResponseSlice = createSlice({
    name: "rfxResponse",
    initialState,
    reducers: {
        init: (
            state,
            action: PayloadAction<{
                selections: ResponseSelectionDTO[];
                alternatives: ResponseAlternativeForRFXDTO[];
                allowSubmit: boolean;
                alreadySubmited: boolean;
                responseCurrencyId: string;
            }>
        ) => {
            const result = action.payload;
            state.selections = result.selections ?? [];
            state.readOnly = !result.allowSubmit || result.alreadySubmited;
            state.alreadySubmited = result.alreadySubmited;
            state.alternatives = result.alternatives;
            state.currAltId = result.alternatives[0]?.id;
        },

        addAlternative: (state, action: PayloadAction<{ round: number }>) => {
            const rules = action.payload;
            var a = createNewAlternative(state, rules.round);
            state.readOnly = false;
            state.alternatives = [...state.alternatives, a];
            state.currAltId = a.id;
        },

        setSelections: (state, action: PayloadAction<ResponseSelectionDTO[]>) => {
            state.selections = action.payload;
        },

        resetAlternatives: (state, action: PayloadAction<ResponseAlternativeForRFXDTO[]>) => {
            state.alternatives = action.payload;
            state.currAltId = action.payload[0]?.id;
            state.readOnly = true;
            ensureAlternative(state);
        },

        onSubmitResponse: (state, action: PayloadAction<ResponseAlternativeForRFXDTO[]>) => {
            state.alternatives = action.payload;
            state.alreadySubmited = true;
            state.readOnly = true;
            ensureAlternative(state);
        },

        modifyCurrentAlt: (state, action: PayloadAction<ResponseAlternativeForRFXDTO>) => {
            const changes = action.payload;
            state.alternatives = state.alternatives.map((x) => (x.id == state.currAltId ? { ...x, ...changes } : x));
            ensureAlternative(state);
        },

        selectAlternativeId: (state, action: PayloadAction<number>) => {
            state.currAltId = action.payload;
            ensureAlternative(state);
        },

        onEditAlt: (state, action: PayloadAction<number>) => {
            const a = state.alternatives.find((x) => x.id == action.payload);
            if (!a) return;
            state.currAltId = a.id;
            state.readOnly = false;
        },

        setReadOnly: (state, action: PayloadAction<boolean>) => {
            state.readOnly = action.payload;
        },

        cancelEditResponse: (state) => {
            if (state.currAltId == -1) {
                const list = state.alternatives.filter((x) => x.id != state.currAltId);
                if (list.length > 0) {
                    state.alternatives = list;
                    state.currAltId = list[0].id;
                }
            }
            state.readOnly = true;
        },
    },
});

const actions = rfxResponseSlice.actions;
export const rfxResponseActions = {
    init: actions.init,
    setReadOnly: actions.setReadOnly,
    addAlternative: actions.addAlternative,
    setSelections: actions.setSelections,
    resetAlternatives: actions.resetAlternatives,
    onSubmitResponse: actions.onSubmitResponse,
    modifyCurrentAlt: actions.modifyCurrentAlt,
    selectAlternativeId: actions.selectAlternativeId,
    onEditAlt: actions.onEditAlt,
    cancelEditResponse: actions.cancelEditResponse,
};
export const rfxResponseReducer = rfxResponseSlice.reducer;
