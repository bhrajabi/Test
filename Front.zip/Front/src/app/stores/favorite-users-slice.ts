import { createSlice } from "@reduxjs/toolkit";
import type { PayloadAction } from "@reduxjs/toolkit";

export interface FavoriteUsersState {
    initialized: boolean;
    users: any[];
    companyId: number;
}

const initialState: FavoriteUsersState = {
    initialized: false,
    users: [],
    companyId: 0,
};

const favoriteUsersSlice = createSlice({
    name: "favoriteUsers",
    initialState,
    reducers: {
        init: (state, action: PayloadAction<any>) => {
            const result = action.payload;

            state.initialized = true;
            state.users = [...result.users];
            state.companyId = result.companyId;
        },

        toggleIsFavorite: (state, action) => {
            var user = { ...action.payload };
            const u = state.users.find((x) => x.userName == user.userName);
            if (u) u.isFavorite = !u.isFavorite;
            else state.users.push(user);
        },
    },
});

const actions = favoriteUsersSlice.actions;
export const favoriteUserActions = { init: actions.init, toggleIsFavorite: actions.toggleIsFavorite };
export const favoriteUserReducer = favoriteUsersSlice.reducer;
