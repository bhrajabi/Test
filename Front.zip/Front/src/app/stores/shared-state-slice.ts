import type { PayloadAction } from "@reduxjs/toolkit";
import { createSlice } from "@reduxjs/toolkit";

type SharedStates = {
    value: { [x: string]: any };
};

const initialState: SharedStates = {
    value: {},
};

const sharedStatesSlice = createSlice({
    name: "sharedStates",
    initialState,

    reducers: {
        set: (state: SharedStates, action: PayloadAction<{ id: string; value: any }>) => {
            const value = { ...state.value, [action.payload.id]: action.payload.value };
            state.value = value;
        },
    },
});

const actions = sharedStatesSlice.actions;

export const sharedStatesActions = {
    set: actions.set,
};

export const sharedStatesReducer = sharedStatesSlice.reducer;
