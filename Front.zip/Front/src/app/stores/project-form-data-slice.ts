import type { PayloadAction } from "@reduxjs/toolkit";
import { createSlice } from "@reduxjs/toolkit";

export interface ProjectFormDataState {
    projectInitialized: boolean;
    plants: any[];
    purGroups: any[];
    purOrgs: any[];
    docTypes: any[];
    departments: any[];
    regions: any[];
    project: any;
}

const initialState: ProjectFormDataState = {
    projectInitialized: false,
    plants: [],
    purGroups: [],
    purOrgs: [],
    docTypes: [],
    departments: [],
    regions: [],
    project: {},
};

const projectFormDataSlice = createSlice({
    name: "projectFormData",
    initialState,
    reducers: {
        initProject: (state, action: PayloadAction<any>) => {
            state.projectInitialized = true;
            state.plants = action.payload.plants;
            state.purGroups = action.payload.purGroups;
            state.purOrgs = action.payload.purOrgs;
            state.docTypes = action.payload.docTypes;
            state.departments = action.payload.departments;
            state.regions = action.payload.regions;
            state.project = action.payload.project;
        },
    },
});

const actions = projectFormDataSlice.actions;
export const projectFormDataActions = { initProject: actions.initProject };
export const projectFormDataReducer = projectFormDataSlice.reducer;
