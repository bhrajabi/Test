import type { PayloadAction } from "@reduxjs/toolkit";
import { createSlice } from "@reduxjs/toolkit";
import { enums } from "../constatnts";
import { BsPrefixComponent } from "react-bootstrap/esm/helpers";

export interface EventDataState {
    initialized: boolean;
    now: any;
    isTemplate: boolean;
    templateTitle?: string;
    templateSerial?: number | null;

    parentProjectTitle: string;
    parentProjectType: string;
    parentProjectSerial?: number | null;
    parentProjectNumber: string;

    document: any;
    commodities: any[];
    addresses: any[];
    eventRules: any;

    projectUsers: any;
    allowEdit: boolean;
    canMaintaineSMList: boolean;
    isSupervisor: boolean;
    allowGrading: boolean;
    allowDelete: boolean;

    isFullProject: boolean;
    templateVersion: number;
    startDate: null | string;
    endDate: null | string;
    dueDate: null | string;
    defaultCurrency: null | string;
    showSellersName: boolean;
    meetings: any[];
    envelopes: any[];
    currencies: any[];
    invitations: any[];
    smsHistories: any[];

    purGroups: any[];
    purOrgs: any[];
    docTypes: any[];
    orderDocTypes: any[];
    conditions: any[];
    eventCategories: any[];
    existActiveAwardWorkfolw: boolean;
    activeAwardWorkflow: any;
    awardWorkflow: any;
    workingGroup: any;
    round: number;

    activePublishEventInstance?: any;
    publishEventWFInstance?: any;
    existActivePublishEventInstance?: boolean;
    existPublishEventWorkflow?: boolean;

    activeCloseEventInstance?: any;
    closeEventWFInstance?: any;
    existActiveCloseEventInstance?: boolean;
    existCloseEventWorkflow?: boolean;

    activeGradeEventInstance?: any;
    gradeEventWFInstance?: any;
    existActiveGradeEventInstance?: boolean;
    existGradeEventWorkflow?: boolean;

    eventRounds?: any[];
}

const initialState: EventDataState = {
    initialized: false,
    now: Date.now(),
    isTemplate: false,
    templateTitle: "",
    templateSerial: null,

    parentProjectTitle: "",
    parentProjectType: "",
    parentProjectSerial: null,
    parentProjectNumber: "",
    document: {},
    commodities: [],
    addresses: [],
    eventRules: null,

    projectUsers: [],
    allowEdit: false,
    canMaintaineSMList: false,
    isSupervisor: false,
    allowGrading: false,
    allowDelete: false,

    isFullProject: true,
    templateVersion: 0,
    startDate: null,
    endDate: null,
    dueDate: null,
    defaultCurrency: "",
    showSellersName: false,
    meetings: [],
    envelopes: [],
    currencies: [],
    invitations: [],
    smsHistories: [],

    purGroups: [],
    purOrgs: [],
    docTypes: [],
    orderDocTypes: [],
    conditions: [],
    eventCategories: [],
    existActiveAwardWorkfolw: false,
    activeAwardWorkflow: null,
    awardWorkflow: null,
    workingGroup: null,
    round: 1,

    activePublishEventInstance: null,
    publishEventWFInstance: null,
    existActivePublishEventInstance: false,
    existPublishEventWorkflow: false,

    activeCloseEventInstance: null,
    closeEventWFInstance: null,
    existActiveCloseEventInstance: false,
    existCloseEventWorkflow: false,

    activeGradeEventInstance: null,
    gradeEventWFInstance: null,
    existActiveGradeEventInstance: false,
    existGradeEventWorkflow: false,
    eventRounds: [],
};

const eventDataSlice = createSlice({
    name: "eventData",
    initialState,
    reducers: {
        init: (state: EventDataState, action: PayloadAction<any>) => {
            const p = action.payload;
            state.initialized = true;
            state.now = p.now;
            state.isTemplate = p.isTemplate;
            state.templateTitle = p.templateTitle;
            state.templateSerial = p.templateSerial;

            state.parentProjectTitle = p.parentProjectTitle;
            state.parentProjectType = p.parentProjectType;
            state.parentProjectSerial = p.parentProjectSerial;
            state.parentProjectNumber = p.parentProjectNumber;

            state.document = p.document;
            state.commodities = p.commodities;
            state.addresses = p.addresses;
            state.eventRules = p.eventRules;

            state.allowEdit = p.allowEdit;
            state.canMaintaineSMList = p.canMaintaineSMList;
            state.isSupervisor = p.isSupervisor;
            state.allowGrading = p.allowGrading;

            state.allowDelete = p.allowDelete;
            state.projectUsers = p.projectUsers;

            state.isFullProject = p.isFullProject;
            state.templateVersion = p.templateVersion;
            state.startDate = p.startDate;
            state.endDate = p.endDate;
            state.dueDate = p.dueDate;

            state.defaultCurrency = p.defaultCurrency;
            state.showSellersName = p.showSellersName;

            state.meetings = p.meetings;
            state.envelopes = p.envelopes;
            state.currencies = p.currencies;
            state.invitations = p.invitations;
            state.smsHistories = p.smsHistories;

            state.purGroups = p.purGroups;
            state.purOrgs = p.purOrgs;
            state.docTypes = p.docTypes;
            state.eventCategories = p.eventCategories;
            state.orderDocTypes = p.orderDocTypes;
            state.conditions = p.conditions;
            state.existActiveAwardWorkfolw = p.existActiveAwardWorkfolw;
            state.activeAwardWorkflow = p.activeAwardWorkflow;
            state.awardWorkflow = p.awardWorkflow;
            state.workingGroup = p.workingGroup;
            state.round = p.eventRules.round;

            state.activePublishEventInstance = p.activePublishEventInstance;
            state.publishEventWFInstance = p.publishEventWFInstance;
            state.existActivePublishEventInstance = p.existActivePublishEventInstance;
            state.existPublishEventWorkflow = p.existPublishEventWorkflow;

            state.activeCloseEventInstance = p.activeCloseEventInstance;
            state.closeEventWFInstance = p.closeEventWFInstance;
            state.existActiveCloseEventInstance = p.existActiveCloseEventInstance;
            state.existCloseEventWorkflow = p.existCloseEventWorkflow;

            state.activeGradeEventInstance = p.activeGradeEventInstance;
            state.gradeEventWFInstance = p.gradeEventWFInstance;
            state.existActiveGradeEventInstance = p.existActiveGradeEventInstance;
            state.existGradeEventWorkflow = p.existGradeEventWorkflow;

            state.eventRounds = p.eventRounds;
        },

        dispose: (state: EventDataState, action: PayloadAction<any>) => {
            state.initialized = false;
        },

        setRules: (state: EventDataState, action: PayloadAction<any>) => {
            state.eventRules = action.payload;
        },

        setMeetings: (state: EventDataState, action: PayloadAction<any>) => {
            state.meetings = action.payload;
        },

        setEventInfo: (
            state: EventDataState,
            action: PayloadAction<{
                title: string;
                description: string;
                commodities: any[];
                startDate: string;
                dueDate: string;
            }>
        ) => {
            state.document.title = action.payload.title;
            state.document.description = action.payload.description;
            state.commodities = action.payload.commodities;
            if (!state.isFullProject) {
                state.startDate = action.payload.startDate;
                state.dueDate = action.payload.dueDate;
            }
        },

        reloadEventData: (
            state: EventDataState,
            action: PayloadAction<{
                now: any;

                eventRules: any;
                currentAProcSerial: null | number;
                statusId: string;
                existActiveAwardWorkfolw: boolean;
                activeAwardWorkflow: null | any;
            }>
        ) => {
            const p = action.payload;
            state.now = p.now;
            state.eventRules = p.eventRules;
            state.document.currentAProcSerial = p.currentAProcSerial;
            state.existActiveAwardWorkfolw = p.existActiveAwardWorkfolw;
            state.activeAwardWorkflow = p.activeAwardWorkflow;
            state.document.statusId = p.statusId;
        },

        publishTemplate: (state: EventDataState) => {
            state.document.statusId = enums.documentStatuses.PUB;
        },

        setEnvelopes: (state: EventDataState, action: PayloadAction<any[]>) => {
            state.envelopes = [...action.payload];
        },

        setStatus: (state: EventDataState, action: PayloadAction<string>) => {
            state.document.statusId = action.payload;
        },

        setRound: (state: EventDataState, action: PayloadAction<number>) => {
            state.round = action.payload;
        },
    },
});

const actions = eventDataSlice.actions;
export const eventDataActions = {
    init: actions.init,
    dispose: actions.dispose,
    setRules: actions.setRules,
    setMeetings: actions.setMeetings,
    setEventInfo: actions.setEventInfo,
    reloadEventData: actions.reloadEventData,
    publishTemplate: actions.publishTemplate,
    setEnvelopes: actions.setEnvelopes,
    setStatus: actions.setStatus,
    setRound: actions.setRound,
};
export const eventDataReducer = eventDataSlice.reducer;
