import { configureStore } from "@reduxjs/toolkit";
import { apiCallsReducer } from "./apicalls-slice";
import { auctionDataReducer } from "./auction-data-slice";
import { chatReducer } from "./chat-slice";
import { commoditiesReducer } from "./commodities-slice";
import { eventDataReducer } from "./event-data-slice";
import { favoriteUserReducer } from "./favorite-users-slice";
import { formBuilderDataReducer } from "./form-builder-data-slice";
import { projectFormDataReducer } from "./project-form-data-slice";
import { responseMatrixReducer } from "./response-matrix-slice";
import { rfxResponseReducer } from "./rfx-response-slice";
import { sharedStatesReducer } from "./shared-state-slice";
import { testInfoReducer } from "./test-info-slice";
import { ticketReducer } from "./tickets-data-slice";
import { userInfoReducer } from "./user-info-slice";
import { userLookupReducer } from "./user-lookup-slice";
import { formInstancesReducer } from "./form-instances-slice";
import { formsReducer } from "./forms-slice";

export const store = configureStore({
    middleware: (getDefaultMiddleware) =>
        getDefaultMiddleware({
            serializableCheck: false,
        }),
    reducer: {
        userInfo: userInfoReducer,
        favoriteUsers: favoriteUserReducer,
        commodities: commoditiesReducer,
        userLookup: userLookupReducer,
        eventData: eventDataReducer,
        chat: chatReducer,
        auctionData: auctionDataReducer,
        responseMatrix: responseMatrixReducer,
        testInfo: testInfoReducer,
        tickets: ticketReducer,
        apiCalls: apiCallsReducer,
        sharedStates: sharedStatesReducer,
        rfxResponse: rfxResponseReducer,
        projectFormData: projectFormDataReducer,

        forms: formsReducer,
        formInstances: formInstancesReducer,
        formBuilderData: formBuilderDataReducer,
    },
});

export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;
