import type { PayloadAction } from "@reduxjs/toolkit";
import { createSlice } from "@reduxjs/toolkit";

export interface Tickets {
    initialized: boolean;
    tickets: any[];
    statuses: any[];
    auction: any;
    allowResponse: boolean;
}

const initialState: Tickets = {
    initialized: false,
    allowResponse: false,
    tickets: [],
    statuses: [],
    auction: {},
};

const initTicketSlice = createSlice({
    name: "initTickets",
    initialState,
    reducers: {
        init: (state, action) => {
            const result = action.payload;
            state.initialized = true;
            state.statuses = result.statuses;
            state.auction = result.auction;
            state.tickets = [...result.tickets];
            state.allowResponse = result.allowResponse;
        },
        clear: (state) => {
            state.initialized = false;
            state.allowResponse = false;
            state.tickets = [];
            state.statuses = [];
            state.auction = {};
        },
    },
});

const actions = initTicketSlice.actions;
export const initTicketActions = { init: actions.init, clear: actions.clear };
export const ticketReducer = initTicketSlice.reducer;
