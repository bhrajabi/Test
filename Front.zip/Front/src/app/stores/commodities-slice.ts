import type { PayloadAction } from "@reduxjs/toolkit";
import { createSlice } from "@reduxjs/toolkit";
import { ICommodityType, INodeCommodity, SearchCommodity } from "../../components/commodities/types";

export interface CommodityState {
    isInitialized: boolean;
    isInitializing: boolean;
    isBusy: boolean;
    commodities: INodeCommodity[];
    favorites: string[];
    recent: string[];
    result: SearchCommodity[];
    materialBaseResult: SearchCommodity[];
    materialsResult: SearchCommodity[];
    error: string | null;
}

const initialState: CommodityState = {
    isInitialized: false,
    isInitializing: false,
    isBusy: false,
    commodities: [],
    favorites: [],
    recent: [],
    result: [],
    materialBaseResult: [],
    materialsResult: [],
    error: null,
};

const fnSort = (a: INodeCommodity, b: INodeCommodity) => (a.code == b.code ? 0 : a.code > b.code ? 1 : -1);

const commoditiesSlice = createSlice({
    name: "commodities",
    initialState,
    reducers: {
        init: (
            state,
            action: PayloadAction<{
                commodities: INodeCommodity[];
                favorites: string[];
                recent: string[];
            }>
        ) => {
            const p = action.payload;
            state.isInitialized = true;
            state.isBusy = false;
            state.commodities = p.commodities.sort(fnSort);
            state.favorites = p.favorites;
            state.recent = p.recent;
            state.result = [];
        },

        setResult: (
            state,
            action: PayloadAction<{
                result: INodeCommodity[];
                materialBase: INodeCommodity[];
                materials: INodeCommodity[];
            }>
        ) => {
            state.isBusy = false;
            state.result = action.payload.result;
            state.materialBaseResult = action.payload.materialBase;
            state.materialsResult = action.payload.materials;
        },

        setIsBusy: (state, action: PayloadAction<boolean>) => {
            state.isBusy = action.payload;
        },

        setIsInitializing: (state, action: PayloadAction<boolean>) => {
            state.isInitializing = action.payload;
        },

        setIsInitialized: (state, action: PayloadAction<boolean>) => {
            state.isInitialized = action.payload;
        },

        updateFavorites: (state, action: PayloadAction<string[]>) => {
            state.favorites = action.payload;
        },

        updateRecent: (state, action: PayloadAction<string[]>) => {
            state.recent = action.payload;
        },

        updateNode: (state, action: PayloadAction<INodeCommodity>) => {
            state.commodities = state.commodities.map((x) => (x.code != action.payload.code ? x : action.payload)).sort(fnSort);
        },

        addNodes: (state, action: PayloadAction<INodeCommodity[]>) => {
            const new_nodes = action.payload;
            const filtered_nodes = state.commodities.filter((x) => !new_nodes.some((z) => z.code == x.code));
            state.commodities = [...filtered_nodes, ...new_nodes].sort(fnSort);
        },

        setError: (state, action: PayloadAction<string | null>) => {
            state.error = action.payload;
            state.isBusy = false;
        },

        collapseAll: (state) => {
            state.commodities = state.commodities.map((x) => ({ ...x, isExpanded: false }));
        },

        expandAll: (state) => {
            state.commodities = state.commodities.map((x) => ({ ...x, isExpanded: true }));
        },
    },
});

const actions = commoditiesSlice.actions;
export const commoditiesActions = {
    init: actions.init,
    setResult: actions.setResult,
    setIsBusy: actions.setIsBusy,
    setIsInitializing: actions.setIsInitializing,
    setIsInitialized: actions.setIsInitialized,
    updateFavorites: actions.updateFavorites,
    updateRecent: actions.updateRecent,
    updateNode: actions.updateNode,
    addNodes: actions.addNodes,
    setError: actions.setError,
    collapseAll: actions.collapseAll,
    expandAll: actions.expandAll,
};
export const commoditiesReducer = commoditiesSlice.reducer;
