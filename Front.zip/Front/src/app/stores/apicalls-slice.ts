import type { PayloadAction } from "@reduxjs/toolkit";
import { createSlice } from "@reduxjs/toolkit";

export type ApiCallInfoState = {
    id: string;
    initialized: boolean;
    initializing: boolean;
    success: boolean;
    busy: boolean;

    error?: any;
    result?: any;
};

export type ApiCallsState = {
    calls: ApiCallInfoState[];
};

const initialState: ApiCallsState = {
    calls: [],
};

const apiCallsSlice = createSlice({
    name: "apicalls",
    initialState,

    reducers: {
        add: (state: ApiCallsState, action: PayloadAction<string>) => {
            const c = state.calls.find((x) => x.id == action.payload);
            if (!!c) return;
            state.calls.push({ id: action.payload, initialized: false, initializing: false, success: false, busy: false });
        },

        remove: (state: ApiCallsState, action: PayloadAction<string>) => {
            state.calls = state.calls.filter((x) => x.id != action.payload);
        },

        setBusy: (state: ApiCallsState, action: PayloadAction<string>) => {
            const c = state.calls.find((x) => x.id == action.payload);
            if (!c) return;
            if (!c.initialized) c.initializing = true;
            c.busy = true;
            c.success = false;
            c.error = null;
        },

        updateResult: (state: ApiCallsState, action: PayloadAction<{ id: string; result: any }>) => {
            const c = state.calls.find((x) => x.id == action.payload.id);
            if (!c) return;

            c.initialized = true;
            c.initializing = false;
            c.busy = false;
            c.success = true;
            c.error = null;
            c.result = action.payload.result;
        },

        reset: (state: ApiCallsState, action: PayloadAction<string>) => {
            const c = state.calls.find((x) => x.id == action.payload);
            if (!c) return;

            c.initialized = false;
            c.initializing = false;
            c.busy = false;
            c.success = false;
            c.error = null;
            c.result = null;
        },

        setSuccess: (state: ApiCallsState, action: PayloadAction<{ id: string; result: any }>) => {
            const c = state.calls.find((x) => x.id == action.payload.id);
            if (!c) return;
            if (!c.initialized) c.initialized = true;
            c.initializing = false;
            c.busy = false;
            c.success = true;
            c.error = null;
            c.result = action.payload.result;
        },

        setError: (state: ApiCallsState, action: PayloadAction<{ id: string; error: any }>) => {
            const c = state.calls.find((x) => x.id == action.payload.id);
            if (!c) return;
            c.initializing = false;
            c.busy = false;
            c.success = false;
            c.error = action.payload.error;
        },
    },
});

const actions = apiCallsSlice.actions;

export const apiCallsActions = {
    add: actions.add,
    remove: actions.remove,
    setBusy: actions.setBusy,
    setSuccess: actions.setSuccess,
    setError: actions.setError,
    updateResult: actions.updateResult,
    reset: actions.reset,
};

export const apiCallsReducer = apiCallsSlice.reducer;
