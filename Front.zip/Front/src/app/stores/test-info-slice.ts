import type { PayloadAction } from "@reduxjs/toolkit";
import { createSlice } from "@reduxjs/toolkit";
import { number } from "yup";

export interface MessageState {
    type: string;
    message: string;
    date: number;
}

export interface TestCaseState {
    id: string;
    title: string;
    data: {};
    expectedComplete: boolean;
    serial?: number;
    status?: null | "running" | "completed" | "failed";
    passed?: boolean;
    failed?: boolean;
    messages?: MessageState[];
}

export interface TestPlanState {
    code: string;
    title: string;
    cases: TestCaseState[];
}

export interface TestGroupState {
    title: string;
    testPlans: TestPlanState[];
}

export interface TestInfoState {
    lastSerial: number;
    isRunning: boolean;
    groups: TestGroupState[];
    queue: TestCaseState[];
}

const login_test_cases: TestCaseState[] = [
    {
        id: "login-01",
        title: "Valid User - Fisrt Company",
        data: { userName: "2210129745", companyIndex: 0 },
        expectedComplete: true,
    },

    {
        id: "login-02",
        title: "Valid User - Second Company",
        data: { userName: "80206979", companyIndex: 1 },
        expectedComplete: true,
    },

    {
        id: "login-03",
        title: "Valid User - Invalid Company",
        data: { userName: "81203770", companyIndex: 100 },
        expectedComplete: false,
    },

    {
        id: "login-04",
        title: "Invalid User",
        data: { userName: "t2210129745" },
        expectedComplete: false,
    },

    {
        id: "login-05",
        title: "Empty User",
        data: { userName: "" },
        expectedComplete: false,
    },
];

const register_test_cases: TestCaseState[] = [
    {
        id: "register-01",
        title: "Valid User - User Exist",
        data: { userName: "2210129745", firstName: "sajad", lastName: "reyhani", phoneNumber: "09354661426", companyIndex: 0 },
        expectedComplete: false,
    },
    {
        id: "register-02",
        title: "Valid User - New User",
        data: { userName: "0458004758", firstName: "new", lastName: "user", phoneNumber: "09354661426", companyIndex: 1 },
        expectedComplete: true,
    },
    {
        id: "register-03",
        title: "Valid User - Invalid Phone Number",
        data: { userName: "0745645666", firstName: "new", lastName: "invalid phone", phoneNumber: "0935466142", companyIndex: -1 },
        expectedComplete: false,
    },
    {
        id: "register-04",
        title: "Invalid User",
        data: { userName: "0756912340", firstName: "sajad", lastName: "reyhani", phoneNumber: "09354661428" },
        expectedComplete: false,
    },
    {
        id: "register-05",
        title: "Empty User",
        data: { userName: "", firstName: "", lastName: "", phoneNumber: "" },
        expectedComplete: false,
    },
];

const company_profile_test_case: TestCaseState[] = [
    {
        id: "companyProfile-01",
        title: "Valid Company - Valid User",
        data: { userName: "80206979", companyIndex: 1 },
        expectedComplete: true,
    },
    {
        id: "companyProfile-02",
        title: "Valid User - invalid Company",
        data: { userName: "2210129745", companyIndex: 0 },
        expectedComplete: false,
    },
    {
        id: "companyProfile-03",
        title: "Valid User - None Company",
        data: { userName: "3992485390", companyIndex: 0 },
        expectedComplete: false,
    },

    {
        id: "companyProfile-05",
        title: "Invalid User - Invalid Company",
        data: { userName: "3146209870", companyIndex: 0 },
        expectedComplete: true,
    },
];
const monitor_event_test_case: TestCaseState[] = [
    {
        id: "companyMonitorEvent-01",
        title: "All Events  ",
        data: { userName: "80206979", companyIndex: 1, serial: 0 },
        expectedComplete: true,
    },
    {
        id: "companyMonitorEvent-02",
        title: "All Events, Invalid Supplier",
        data: { userName: "2210129745", companyIndex: 1, serial: 0 },
        expectedComplete: false,
    },
    {
        id: "companyMonitorEvent-03",
        title: "Single Event, Valid SellerId",
        data: { userName: "80206979", companyIndex: 1, serial: 22148, sellerId: 0 },
        expectedComplete: true,
    },
    {
        id: "companyMonitorEvent-04",
        title: "Single Event, Invalid Supplier, Valid SellerId",
        data: { userName: "2210129745", companyIndex: 1, serial: 22148, sellerId: 0 },
        expectedComplete: false,
    },
    {
        id: "companyMonitorEvent-05",
        title: "Single Invalid Event, Valid Supplier, Invalid SellerId",
        data: { userName: "80206979", companyIndex: 1, serial: 20148, sellerId: 2 },
        expectedComplete: false,
    },
    {
        id: "companyMonitorEvent-06",
        title: "Single Invalid Event, Invalid Supplier, Invalid SellerId",
        data: { userName: "2210129745", companyIndex: 1, serial: 20148, sellerId: 5 },
        expectedComplete: false,
    },
    {
        id: "companyMonitorEvent-07",
        title: "Single Valid Discovery, Valid User",
        data: { userName: "80206979", companyIndex: 1, discoveryId: 22051 },
        expectedComplete: true,
    },
    {
        id: "companyMonitorEvent-08",
        title: "Single Invalid Discovery, Valid User",
        data: { userName: "80206979", companyIndex: 1, discoveryId: 2 },
        expectedComplete: false,
    },
    {
        id: "companyMonitorEvent-09",
        title: "Single Valid Discovery, Invalid User",
        data: { userName: "2210129745", companyIndex: 1, discoveryId: 22051 },
        expectedComplete: false,
    },
    {
        id: "companyMonitorEvent-10",
        title: "Single Invalid Discovery, InValid User",
        data: { userName: "2210129745", companyIndex: 1, discoveryId: 12 },
        expectedComplete: false,
    },
];

const initialState: TestInfoState = {
    lastSerial: 0,
    isRunning: false,
    queue: [],
    groups: [
        {
            title: "Account",
            testPlans: [
                { code: "login", title: "Login tests", cases: login_test_cases },
                { code: "register", title: "Register tests", cases: register_test_cases },
            ],
        },
        {
            title: "Seller-Event",
            testPlans: [
                { code: "company-profile", title: "Company profile", cases: company_profile_test_case },
                // { code: "user-profile", title: "User profile", cases: [] },
                { code: "monitor-event", title: "Monitor event", cases: monitor_event_test_case },
                // { code: "accept-event", title: "Accept event", cases: [] },
            ],
        },
        {
            title: "Buyer-Event",
            testPlans: [
                { code: "create-event", title: "Create event", cases: [] },
                { code: "monitor-event", title: "Monitor event", cases: [] },
            ],
        },
    ],
};

function findTestCaseById(testInfo: TestInfoState, id: string) {
    for (let i = 0; i < testInfo.groups.length; i++) {
        for (let k = 0; k < testInfo.groups[i].testPlans.length; k++) {
            const tp = testInfo.groups[i].testPlans[k];
            const tc = tp.cases.find((x) => x.id == id);
            if (tc) return tc;
        }
    }
    return null;
}

const testInfoSlice = createSlice({
    name: "testInfo",
    initialState,

    reducers: {
        start: (state) => {
            state.isRunning = true;
        },

        stop: (state) => {
            state.isRunning = false;
        },

        log: (state, action: PayloadAction<{ serial: number; message: string }>) => {
            const tc = state.queue.find((x) => x.serial == action.payload.serial);
            if (tc == null) return;
            tc.messages?.push({ type: "info", message: action.payload.message, date: Number(Date.now()) });
        },

        addToQueue: (state, action: PayloadAction<string>) => {
            const tc = findTestCaseById(state, action.payload);
            if (tc == null) return;
            state.queue.push({
                ...tc,
                serial: ++state.lastSerial,
                status: null,
                passed: false,
                failed: false,
                messages: [],
            });
        },
        duplicate: (state, action: PayloadAction<number>) => {},

        resetStatus: (state) => {
            state.queue = state.queue.map((tc) => ({
                ...tc,
                status: null,
                passed: false,
                failed: false,
                messages: [],
            }));
        },

        clearAll: (state, action: PayloadAction<number>) => {
            state.queue = [];
        },

        clearPassQueue: (state) => {
            state.queue = state.queue.filter((x) => !x.passed);
        },

        clearFailedQueue: (state, action: PayloadAction<number>) => {
            const tc = state.queue.find((x) => x.serial == action.payload && x.status == "completed");
            if (tc == null) return;
            state.queue.push({
                ...tc,
                serial: ++state.lastSerial,
                status: null,
                passed: false,
                failed: false,
                messages: [],
            });
        },

        markAsRunning: (state, action: PayloadAction<number>) => {
            const tc = state.queue.find((x) => x.serial == action.payload && !x.status);
            if (tc == null) return;
            tc.status = "running";
            tc.messages?.push({ type: "info", message: "start test", date: Number(Date.now()) });
        },

        markAsCompleted: (state, action: PayloadAction<number>) => {
            const tc = state.queue.find((x) => x.serial == action.payload && x.status == "running");
            if (tc == null) return;
            tc.status = "completed";
            tc.passed = tc.expectedComplete;
            tc.failed = !tc.expectedComplete;
        },

        markAsFailed: (state, action: PayloadAction<{ serial: number; message: string }>) => {
            const tc = state.queue.find((x) => x.serial == action.payload.serial && x.status == "running");
            if (tc == null) return;
            tc.status = "failed";
            tc.passed = !tc.expectedComplete;
            tc.failed = tc.expectedComplete;
            tc.messages?.push({ type: "error", message: action.payload.message, date: Number(Date.now()) });
        },

        markAsNotPassed: (state, action: PayloadAction<{ serial: number; message: string }>) => {
            const tc = state.queue.find((x) => x.serial == action.payload.serial && x.status == "running");
            if (tc == null) return;
            tc.status = "failed";
            tc.passed = false;
            tc.failed = true;
            tc.messages?.push({ type: "error", message: action.payload.message, date: Number(Date.now()) });
        },
    },
});

const actions = testInfoSlice.actions;
export const testInfoActions = {
    log: actions.log,
    addToQueue: actions.addToQueue,
    clearAll: actions.clearAll,
    duplicate: actions.duplicate,
    resetStatus: actions.resetStatus,
    clearPassQueue: actions.clearPassQueue,
    clearFailedQueue: actions.clearFailedQueue,
    markAsRunning: actions.markAsRunning,
    markAsCompleted: actions.markAsCompleted,
    markAsFailed: actions.markAsFailed,
    markAsNotPassed: actions.markAsNotPassed,
    start: actions.start,
    stop: actions.stop,
};
export const testInfoReducer = testInfoSlice.reducer;
