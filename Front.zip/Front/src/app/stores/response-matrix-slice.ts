import type { PayloadAction } from "@reduxjs/toolkit";
import { createSlice } from "@reduxjs/toolkit";
import { enums } from "../constatnts";
import { bool, number } from "yup";
import { FormRefDTO } from "../../api/form-api";

export interface ResponseMatrixState {
    initialized: boolean;
    participants: any[];

    contents: any[];
    contentTerms: any[];

    alternatives: any[];
    responses: any[];
    termResponses: any[];

    comments: any[];
    scenarios: any[];
    scenarioItems: any[];
    orders: any[];
    round: number;
    allowEdit: boolean;
    forms: FormRefDTO[];
    selections: any[];
}

const initialState: ResponseMatrixState = {
    initialized: false,
    allowEdit: false,
    participants: [],
    contents: [],
    contentTerms: [],
    alternatives: [],
    responses: [],
    termResponses: [],
    comments: [],
    scenarios: [],
    scenarioItems: [],
    orders: [],
    round: 1,
    forms: [],
    selections: [],
};

const responseMatrixSlice = createSlice({
    name: "responseMatrix",
    initialState,
    reducers: {
        init: (state: ResponseMatrixState, action: PayloadAction<any>) => {
            state.initialized = true;
            state.participants = action.payload.participants;
            state.contents = action.payload.contents;
            state.contentTerms = action.payload.contentTerms;
            state.alternatives = action.payload.alternatives;
            state.responses = action.payload.responses;
            state.termResponses = action.payload.termResponses;
            state.comments = action.payload.comments;
            state.scenarios = action.payload.scenarios;
            state.scenarioItems = action.payload.scenarioItems;
            state.orders = action.payload.orders;
            state.round = action.payload.round;
            state.allowEdit = action.payload.allowEdit;
            state.forms = action.payload.forms;
            state.selections = action.payload.selections;
        },

        dispose: (state: ResponseMatrixState) => {
            state.initialized = false;
        },

        applyAlternativeVerification: (state: ResponseMatrixState, action: PayloadAction<{ alternative: any; grades: any[] }>) => {
            const p = action.payload;
            var a = state.alternatives.find((x) => x.id == p.alternative.id);
            a.comments = p.alternative.comments;
            a.statusId = p.alternative.statusId;
            state.responses
                .filter((x) => x.id == p.alternative.id)
                .forEach((x) => {
                    const g = p.grades.find((g) => g.contentSerial == x.contentSerial);
                    if (g) x.grade = g.grade;
                });
        },

        updateResponseScore: (
            state: ResponseMatrixState,
            action: PayloadAction<{ alternativeId: any; contentSerial: any; score: any }>
        ) => {
            const p = action.payload;
            var a = state.responses.find((x) => x.alternativeId == p.alternativeId && x.contentSerial == p.contentSerial);
            if (a) a.grade = p.score;
        },

        updateScenario: (state: ResponseMatrixState, action: PayloadAction<{ scenario: any; items: any[]; scenarioSerial: number }>) => {
            const p = action.payload;
            var scenarios = [...state.scenarios.filter((x) => x.serial != p.scenarioSerial)];
            var scenarioItems = [...state.scenarioItems.filter((x) => x.scenarioSerial != p.scenarioSerial)];
            if (p.scenario) {
                scenarios.push(p.scenario);
                scenarioItems = [...scenarioItems, ...p.items];
                scenarios = scenarios.sort((a, b) => a.serial - b.serial);
                if (enums.scenarioStatuses.isAWARD(p.scenario)) {
                    scenarios.forEach((x) => {
                        if (x.serial != p.scenario.serial) x.statusId = enums.scenarioStatuses.DRFT;
                    });
                }
            }
            state.scenarios = [...scenarios];
            state.scenarioItems = [...scenarioItems];
        },

        updateScenarioCNF: (state: ResponseMatrixState, action: PayloadAction<{ scenario: any; scenarioSerial: number }>) => {
            const p = action.payload;
            var scn = state.scenarios.find((x) => x.serial === p.scenarioSerial);
            scn.commissionNo = p.scenario.commissionNo;
            scn.commissionDate = p.scenario.commissionDate;
            scn.commissionComment = p.scenario.commissionComment;
            scn.isApproved = p.scenario.isApproved;
        },

        updateSuppliersOverhead: (
            state: ResponseMatrixState,
            action: PayloadAction<{
                sellerId: number;
                overheadCostCurrencyId: any;
                overheadCostValue: number;
                overheadExchangeRate: number;
                overheadCostPercent: number;
            }>
        ) => {
            const p = action.payload;
            var participant = state.participants.find((x) => x.sellerId == p.sellerId);
            if (participant) {
                participant.overheadCostCurrencyId = p.overheadCostCurrencyId;
                participant.overheadCostPercent = p.overheadCostPercent;
                participant.overheadCostValue = p.overheadCostValue;
                participant.overheadExchangeRate = p.overheadExchangeRate;
            }
        },
    },
});

const actions = responseMatrixSlice.actions;
export const responseMatrixActions = {
    init: actions.init,
    applyAlternativeVerification: actions.applyAlternativeVerification,
    updateResponseScore: actions.updateResponseScore,
    updateScenario: actions.updateScenario,
    updateSuppliersOverhead: actions.updateSuppliersOverhead,
    updateScenarioCNF: actions.updateScenarioCNF,
    dispose: actions.dispose,
};
export const responseMatrixReducer = responseMatrixSlice.reducer;
