import type { PayloadAction } from "@reduxjs/toolkit";
import { createSlice } from "@reduxjs/toolkit";
import { FieldProps } from "../../api/form-api";

export interface FormBuilderData {
    serial: number;
    initialValues: any;
    formFields: FieldProps[];
    curr?: FieldProps | null;
    insertMode: boolean;
    editMode: boolean;
}

export interface FormBuilderDataState {
    forms: {
        [index: number]: FormBuilderData;
    };
}

const initialState: FormBuilderDataState = {
    forms: {},
};

const formBuilderDataSlice = createSlice({
    name: "formBuilderData",
    initialState,
    reducers: {
        init: (state: FormBuilderDataState, action: PayloadAction<FormBuilderData>) => {
            const form = action.payload;
            form.formFields?.forEach((x) => {
                if (x.visible == undefined) x.visible = true;
            });
            state.forms[form.serial] = form;
        },

        dispose: (state: FormBuilderDataState, action: PayloadAction<FormBuilderData>) => {
            const form = action.payload;
            delete state.forms[form.serial];
        },
    },
});

const actions = formBuilderDataSlice.actions;
export const formBuilderDataActions = {
    init: actions.init,
    dispose: actions.dispose,
};
export const formBuilderDataReducer = formBuilderDataSlice.reducer;
