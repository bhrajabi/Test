import type { PayloadAction } from "@reduxjs/toolkit";
import { createSlice } from "@reduxjs/toolkit";
import { FormInstanceDTO } from "../../api/form-api";
import { WFInstance } from "../../components/wf/workflow-types";

export type FormInstanceInfo = {
    allowEdit: boolean;
    instance: FormInstanceDTO;
    values: any; //FormInstanceValueDTO[];
    arguments: any;
    existActiveInstance?: boolean;
    existFormWorkflow?: boolean;
    formWFInstance?: WFInstance;
    hasReport?: boolean;
};

export interface FormInstancesState {
    all: {
        [index: number]: FormInstanceInfo;
    };
}

const initialState: FormInstancesState = {
    all: {},
};

const formInstancesSlice = createSlice({
    name: "formInstances",
    initialState,
    reducers: {
        init: (state: FormInstancesState, action: PayloadAction<FormInstanceInfo>) => {
            const d = action.payload;
            if (!d.instance.serial) return;
            state.all[d.instance.serial] = d;
        },

        dispose: (state: FormInstancesState, action: PayloadAction<FormInstanceInfo>) => {
            const d = action.payload;
            if (!!d.instance.serial) delete state.all[d.instance.serial];
        },
    },
});

const actions = formInstancesSlice.actions;
export const formInstancesActions = {
    init: actions.init,
    dispose: actions.dispose,
};
export const formInstancesReducer = formInstancesSlice.reducer;
