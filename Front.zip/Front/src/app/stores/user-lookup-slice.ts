import { createSlice } from "@reduxjs/toolkit";
import type { PayloadAction } from "@reduxjs/toolkit";

export interface UserLookupState {
    initialized: boolean;
    companyId: number;
    filter: { userName: any; firstName: any; lastName: any };
    users: any[];
}

const initialState: UserLookupState = {
    initialized: false,
    filter: { userName: null, firstName: null, lastName: null },
    users: [],
    companyId: 0,
};

const userLookupSlice = createSlice({
    name: "userLookup",
    initialState,
    reducers: {
        init: (state, action: PayloadAction<any>) => {
            const result = action.payload;
            state.initialized = true;
            state.companyId = result.companyId;
            state.filter = result.filter;
            state.users = [...result.users];
        },

        clear: (state) => {
            state.initialized = false;
            state.filter = { userName: "", firstName: "", lastName: "" };
            state.users = [];
            state.companyId = 0;
        },
    },
});

const actions = userLookupSlice.actions;
export const userLookupActions = { init: actions.init, clear: actions.clear };
export const userLookupReducer = userLookupSlice.reducer;
