import type { PayloadAction } from "@reduxjs/toolkit";
import { createSlice } from "@reduxjs/toolkit";
import { apiConfig } from "../../api/config";
import { ChatNS } from "../../components/chat/types";

export interface ChatState {
    initialized: boolean;
    isChatFormVisible: boolean;
    unreadCount: number;
    justForAdmin: boolean;
    selectedChatSerial?: number;
    chats: ChatNS.ChatInfo[];
    isBusy: boolean;
    error?: Error;
}

const initialState: ChatState = {
    initialized: false,
    justForAdmin: false,
    isChatFormVisible: false,
    unreadCount: 0,
    chats: [],
    isBusy: false,
    error: undefined,
};

const chatSlice = createSlice({
    name: "chat",
    initialState,
    reducers: {
        setChatFormVisible: (state: ChatState, action: PayloadAction<boolean>) => {
            state.isChatFormVisible = action.payload;
        },

        init: (state: ChatState, action: PayloadAction<ChatNS.ChatInfo[]>) => {
            state.initialized = true;
            state.error = undefined;

            state.chats = action.payload.map((chat) => ({
                ...chat,
                messages: state.chats.filter((x) => x.serial == chat.serial)[0]?.messages ?? [],
            }));

            if (!!state.selectedChatSerial && !state.chats.some((x) => x.serial == state.selectedChatSerial))
                state.selectedChatSerial = undefined;
        },

        setSelectedChatSerial: (state: ChatState, actions: PayloadAction<number | undefined>) => {
            state.selectedChatSerial = actions.payload;
        },

        initChatMessages: (
            state: ChatState,
            actions: PayloadAction<{ chatSerial: number; messages: ChatNS.ChatMessageInfo[]; justForAdmin: boolean }>
        ) => {
            let chat = state.chats.find((x) => x.serial == actions.payload.chatSerial);
            if (!chat) return;

            chat.newMessageCount = 0;
            chat.messages = actions.payload.messages;
            state.justForAdmin = actions.payload.justForAdmin;
            var unreadCount = 0;
            state.chats.forEach((chat) => (unreadCount += chat.newMessageCount));
            state.unreadCount = unreadCount;
            state.selectedChatSerial = actions.payload.chatSerial;
        },

        addNewMessage: (state: ChatState, action: PayloadAction<{ chatSerial: number; message: ChatNS.ChatMessageInfo }>) => {
            state.chats = state.chats.map((chat) =>
                chat.serial == action.payload.chatSerial
                    ? { ...chat, lastMessage: action.payload.message, messages: [...(chat.messages || []), action.payload.message] }
                    : chat
            );
        },

        removeChatMessage: (state: ChatState, actions: PayloadAction<{ chatSerial: number; messageSerial: number }>) => {
            state.chats = state.chats.map((chat) =>
                chat.serial == actions.payload.chatSerial
                    ? { ...chat, messages: chat.messages?.filter((x) => x.serial != actions.payload.messageSerial) }
                    : chat
            );
        },

        removeChat: (state: ChatState, action: PayloadAction<{ chatSerial: number }>) => {
            state.chats = state.chats.filter((chat) => chat.serial != action.payload.chatSerial);
            state.selectedChatSerial = undefined;
        },

        downloadFile: (state: ChatState, action: PayloadAction<{ chatSerial: number; messageSerial: number }>) => {
            var chat = state.chats.find((x) => x.serial == action.payload.chatSerial);
            if (!chat) return;

            if (!chat.messages || !chat.messages.some((x) => x.serial == action.payload.messageSerial)) return;

            state.chats = state.chats.map((chat) =>
                chat.serial == action.payload.chatSerial
                    ? {
                          ...chat,
                          messages: chat.messages?.map((message) =>
                              message.serial == action.payload.messageSerial
                                  ? {
                                        ...message,
                                        thumbnail: undefined,
                                        attachmentUrl: `${apiConfig.ChatImageDownloadUrl}?messageSerial=${message.serial}`,
                                    }
                                  : message
                          ),
                      }
                    : chat
            );
        },

        setIsBusy: (state: ChatState, action: PayloadAction<boolean>) => {
            if (!state.isBusy) state.initialized = true;

            state.isBusy = action.payload;
        },

        setUnreadCount: (state: ChatState, action: PayloadAction<number>) => {
            state.unreadCount = action.payload;
        },

        setIsLoadingMessages: (state: ChatState, actions: PayloadAction<{ chatSerial: number; isLoadingMessages: boolean }>) => {
            state.chats = state.chats.map((chat) =>
                chat.serial == actions.payload.chatSerial ? { ...chat, isLoadingMessages: actions.payload.isLoadingMessages } : chat
            );
        },

        setError: (state: ChatState, action: PayloadAction<Error>) => {
            state.error = action.payload;
        },
        onDispose: (state: ChatState) => {
            state.initialized = false;
            state.justForAdmin = false;
            state.isChatFormVisible = false;
            state.unreadCount = 0;
            state.chats = [];
            state.isBusy = false;
            state.error = undefined;
        },
    },
});

const actions = chatSlice.actions;
export const chatActions = {
    setChatFormVisible: actions.setChatFormVisible,
    init: actions.init,
    setSelectedChatSerial: actions.setSelectedChatSerial,
    initChatMessages: actions.initChatMessages,
    setIsBusy: actions.setIsBusy,
    setIsLoadingMessages: actions.setIsLoadingMessages,
    setUnreadCount: actions.setUnreadCount,
    addNewMessage: actions.addNewMessage,
    removeChat: actions.removeChat,
    downloadFile: actions.downloadFile,
    removeChatMessage: actions.removeChatMessage,
    setError: actions.setError,
    onDispose: actions.onDispose,
};
export const chatReducer = chatSlice.reducer;
