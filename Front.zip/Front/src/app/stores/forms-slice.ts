import type { PayloadAction } from "@reduxjs/toolkit";
import { createSlice } from "@reduxjs/toolkit";
import { FormDTO } from "../../api/form-api";

export interface FormState {
    forms: {
        [index: number]: FormDTO;
    };
    args: {
        [index: number]: any;
    };
}

const initialState: FormState = {
    forms: {},
    args: {},
};

const formsSlice = createSlice({
    name: "forms",
    initialState,
    reducers: {
        init: (state: FormState, action: PayloadAction<{ form: FormDTO; args: any }>) => {
            const p = action.payload;
            if (!p.form?.serial) return;
            state.forms[p.form.serial] = p.form;
            state.args[p.form.serial] = p.args;
        },

        dispose: (state: FormState, action: PayloadAction<FormDTO>) => {
            const form = action.payload;
            if (!!form?.serial) {
                delete state.forms[form.serial];
                delete state.args[form.serial];
            }
        },
    },
});

const actions = formsSlice.actions;
export const formsActions = {
    init: actions.init,
    dispose: actions.dispose,
};
export const formsReducer = formsSlice.reducer;
