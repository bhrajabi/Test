import type { PayloadAction } from "@reduxjs/toolkit";
import { createSlice } from "@reduxjs/toolkit";
import { enums } from "../constatnts";

export interface AuctionDataState {
    initialized: boolean;
    now: any;
    auctionId: number;
    auctionNo: string;
    projectSerial: number;
    addressSerial: number;
    title: string;

    visitingHours: string | null;
    visitStartDate: any | null;
    visitStartTime: any | null;
    visitEndDate: any | null;
    visitEndTime: any | null;
    awardDate: any | null;
    startPaymentDate: any | null;
    lastPaymentDate: any | null;
    startRefundDate: any | null;
    endRefundDate: any | null;

    auctionRowVersion: number | null;

    publishAProcSerial: number | null;
    closeAProcSerial: number | null;
    gradeAProcSerial: number | null;
    awardAProcSerial: number | null;
    currentAProcSerial: number | null;

    statusId: string;
    costOfHolding: number | null;
    guaranteeAmountPercent: number | null;
    maxSelectableItems: number | null;
    enableEnvelope: boolean;
    publicKey: string | null;
    displayAnnouncement: boolean;
    createdBy: string;
    createdAt: any;
    quantityIsRequired: boolean;

    publishDate: any;

    parentProjectTitle: string;
    parentProjectType: string;
    parentProjectSerial?: number | null;

    currentNotificationData?: any;
    projectUsers: any;
    allowEdit: boolean;
    allowDelete: boolean;

    companyAddresses: [];
    attachments: [];

    auctionRules: any;
    meetingAddresses: any;
    auctionAddresses: any;

    officeAddress: any;
    visitAddress: any;
}

const initialState: AuctionDataState = {
    initialized: false,
    now: Date.now(),
    auctionId: 0,
    auctionNo: "",
    projectSerial: 0,
    addressSerial: 0,
    title: "",

    visitingHours: null,
    visitStartDate: null,
    visitStartTime: null,
    visitEndDate: null,
    visitEndTime: null,
    awardDate: null,
    startPaymentDate: null,
    lastPaymentDate: null,
    startRefundDate: null,
    endRefundDate: null,

    auctionRowVersion: null,

    publishAProcSerial: null,
    closeAProcSerial: null,
    gradeAProcSerial: null,
    awardAProcSerial: null,
    currentAProcSerial: null,

    statusId: "",
    costOfHolding: null,
    maxSelectableItems: null,
    enableEnvelope: false,
    publicKey: null,
    guaranteeAmountPercent: null,
    displayAnnouncement: false,
    createdBy: "",
    createdAt: "",
    publishDate: "",
    quantityIsRequired: false,

    parentProjectTitle: "",
    parentProjectType: "",
    parentProjectSerial: null,

    currentNotificationData: null,
    projectUsers: [],
    allowEdit: false,
    allowDelete: false,

    companyAddresses: [],
    auctionAddresses: [],
    meetingAddresses: [],
    attachments: [],
    auctionRules: null,

    officeAddress: null,
    visitAddress: null,
};

const auctionDataSlice = createSlice({
    name: "auctionData",
    initialState,
    reducers: {
        init: (state: AuctionDataState, action: PayloadAction<any>) => {
            const p = action.payload;
            state.initialized = true;
            state.now = p.now;
            state.addressSerial = p.auction.addressSerial;
            state.auctionId = p.auction.auctionId;
            state.auctionNo = p.auction.auctionNo;
            state.projectSerial = p.auction.projectSerial;
            state.title = p.auction.title;

            state.visitingHours = p.auction.visitingHours;
            state.visitStartDate = p.auction.visitStartDate;
            state.visitStartTime = p.auction.visitStartTime;
            state.visitEndDate = p.auction.visitEndDate;
            state.visitEndTime = p.auction.visitEndTime;
            state.awardDate = p.auction.awardDate;
            state.startPaymentDate = p.auction.startPaymentDate;
            state.lastPaymentDate = p.auction.lastPaymentDate;
            state.startRefundDate = p.auction.startRefundDate;
            state.endRefundDate = p.auction.endRefundDate;

            state.auctionRowVersion = p.auctionRowVersion;

            state.publishAProcSerial = p.auction.publishAProcSerial;
            state.closeAProcSerial = p.auction.closeAProcSerial;
            state.gradeAProcSerial = p.auction.gradeAProcSerial;
            state.awardAProcSerial = p.auction.awardAProcSerial;
            state.currentAProcSerial = p.auction.currentAProcSerial;

            state.statusId = p.auction.statusId;
            state.costOfHolding = p.auction.costOfHolding;
            state.maxSelectableItems = p.auction.maxSelectableItems;
            state.enableEnvelope = p.auction.enableEnvelope;
            state.publicKey = p.auction.publicKey;
            state.guaranteeAmountPercent = p.auction.guaranteeAmountPercent;
            state.displayAnnouncement = p.auction.displayAnnouncement;
            state.createdBy = p.auction.createdBy;
            state.createdAt = p.auction.createdAt;
            state.publishDate = p.auction.publishDate;
            state.quantityIsRequired = p.auction.quantityIsRequired;

            state.allowEdit = p.allowEdit;
            state.currentNotificationData = p.currentNotificationData;
            state.allowDelete = p.allowDelete;
            state.projectUsers = p.projectUsers;
            state.companyAddresses = p.companyAddresses ?? [];
            state.attachments = p.attachments ?? [];
            state.meetingAddresses = p.meetingAddresses ?? [];
            state.auctionAddresses = p.auctionAddresses ?? [];
            state.auctionRules = p.auctionRules ?? null;

            state.visitAddress = p.visitAddress ?? null;
            state.officeAddress = p.officeAddress ?? null;
        },

        setRules: (
            state: AuctionDataState,
            action: PayloadAction<{
                publicKey: string;
                displayAnnouncement: boolean;
                auctionRules: any | null;
            }>
        ) => {
            state.publicKey = action.payload.publicKey;
            state.displayAnnouncement = action.payload.displayAnnouncement;
            state.auctionRules = action.payload.auctionRules;
        },

        setAuctionInfo: (state: AuctionDataState, action: PayloadAction<{ title: string; auctionNo: string; addressSerial: number }>) => {
            state.title = action.payload.title;
            state.auctionNo = action.payload.auctionNo;
            state.addressSerial = action.payload.addressSerial;
        },

        setAuctionAddress: (state: AuctionDataState, action: PayloadAction<{ officeAddress: any; visitAddress: any }>) => {
            state.officeAddress = action.payload.officeAddress;
            state.visitAddress = action.payload.visitAddress;
        },

        setAuctionAnnouncement: (state: AuctionDataState, action: PayloadAction<{ attachments: any | null }>) => {
            state.attachments = action.payload.attachments;
        },

        setAuctionDates: (
            state: AuctionDataState,
            action: PayloadAction<{
                visitingHours: string | null;
                visitStartDate: any | null;
                visitStartTime: any | null;
                visitEndDate: any | null;
                visitEndTime: any | null;
                awardDate: any | null;
                startPaymentDate: any | null;
                lastPaymentDate: any | null;
                startRefundDate: any | null;
                endRefundDate: any | null;
            }>
        ) => {
            state.visitingHours = action.payload.visitingHours;
            state.visitStartDate = action.payload.visitStartDate;
            state.visitStartTime = action.payload.visitStartTime;
            state.visitEndDate = action.payload.visitEndDate;
            state.visitEndTime = action.payload.visitEndTime;
            state.awardDate = action.payload.awardDate;
            state.startPaymentDate = action.payload.startPaymentDate;
            state.lastPaymentDate = action.payload.lastPaymentDate;
            state.startRefundDate = action.payload.startRefundDate;
            state.endRefundDate = action.payload.endRefundDate;
        },

        reloadAuctionData: (
            state: AuctionDataState,
            action: PayloadAction<{
                now: any;
                currentNotificationData: any;
                currentAProcSerial: null | number;
                statusId: string;
                rowVersion: number;
            }>
        ) => {
            const p = action.payload;
            state.now = p.now;
            state.currentNotificationData = p.currentNotificationData;
            state.currentAProcSerial = p.currentAProcSerial;
            state.statusId = p.statusId;
            state.auctionRowVersion = p.rowVersion;
        },

        setAProce: (state: AuctionDataState, action: PayloadAction<{ action: string; aprocSerial: number }>) => {
            switch (action.payload.action) {
                case enums.actions.PUB:
                    state.publishAProcSerial = action.payload.aprocSerial;
                    break;

                case enums.actions.CLOSE:
                    state.closeAProcSerial = action.payload.aprocSerial;
                    break;

                case enums.actions.GRADE:
                    state.gradeAProcSerial = action.payload.aprocSerial;
                    break;

                case enums.actions.AWARD:
                    state.awardAProcSerial = action.payload.aprocSerial;
                    break;
            }
        },
    },
});

const actions = auctionDataSlice.actions;
export const auctionDataActions = {
    init: actions.init,
    setRules: actions.setRules,
    setAProc: actions.setAProce,
    setAuctionInfo: actions.setAuctionInfo,
    reloadAuctionData: actions.reloadAuctionData,
    setAuctionDates: actions.setAuctionDates,
    setAuctionAnnouncement: actions.setAuctionAnnouncement,
    setAuctionAddress: actions.setAuctionAddress,
};
export const auctionDataReducer = auctionDataSlice.reducer;
