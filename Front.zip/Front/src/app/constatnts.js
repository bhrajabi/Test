/*
   SELECT '{id:"'+Id+'", title:"'+Id+'" },'
   FROM [Logistics].[PUR].[DocumentStatuses]
   ORDER BY SortOrder Descanding
*/

import { title } from "process";

const getStatusId = (x) => (typeof x == "string" ? x : x ? x.statusId : null)?.toUpperCase();
const getEventTypeId = (x) => (typeof x == "string" ? x : x ? x.eventTypeId : null)?.toUpperCase();
const getProjectType = (x) => (typeof x == "string" ? x : x ? x.projectType : null)?.toUpperCase();
const getProjectNumber = (x) => (typeof x == "string" ? x : x ? x.number : null)?.toUpperCase();
const getDocumentType = (x) => (typeof x == "string" ? x : x ? x.documentType : null)?.toUpperCase();
const getContentTypeId = (x) => (typeof x == "string" ? x : x ? x.contentTypeId : null)?.toUpperCase();
const getAnswerTypeId = (x) => (typeof x == "string" ? x : x ? x.answerTypeId : null)?.toUpperCase();

export const readAppInfo = (key) => {
    var result = localStorage.getItem("appinfo");
    result = JSON.parse(result);
    if (result == null) result = { data: "{}", version: 0 };

    var data = JSON.parse(result.data);

    var value = data[key] || [];

    return value;
};

export const setAppInfo = (data) => {
    if (!data) return;
    if (data) localStorage.setItem("appinfo", JSON.stringify(data));
    enums.Currencies = readAppInfo("currencies");
    enums.Countries = readAppInfo("countries");
    enums.CompanyTypes = readAppInfo("companyTypes");
    enums.AttachmentTypes = readAppInfo("attachmentTypes");
    enums.eventContentResponseReasons = readAppInfo("eventContentResponseReasons");
};

export const enums = {
    formScopes: {
        COMPANY: "COMPANY",
        REQUEST: "REQUEST",
        ORDER: "ORDER",
        PUWS: "PUWS",
        EVENT: "EVENT",
        SCENARIO: "SCENARIO",
        SUPWS: "SUPWS",

        isCOMPANY: (x) => (x?.scope ?? x) == enums.formScopes.COMPANY,
        isREQUEST: (x) => (x?.scope ?? x) == enums.formScopes.request,
        isORDER: (x) => (x?.scope ?? x) == enums.formScopes.ORDER,
        isPUWS: (x) => (x?.scope ?? x) == enums.formScopes.PUWS,
        isEVENT: (x) => (x?.scope ?? x) == enums.formScopes.EVENT,
        isSCENARIO: (x) => (x?.scope ?? x) == enums.formScopes.SCENARIO,
        isSUPWS: (x) => (x?.scope ?? x) == enums.formScopes.SUPWS,
    },

    formDisplays: {
        INLINE: "INLINE",
        MENU: "MENU",
        TOOLBAR: "TOOLBAR",

        isINLINE: (x) => (x.displayIn ?? x) == enums.formDisplays.INLINE,
        isTOOLBAR: (x) => (x.displayIn ?? x) == enums.formDisplays.TOOLBAR,
    },

    poHistoryTypes: [
        { id: "GR", title: "goods-receipt" },
        { id: "GI", title: "goods-issue" },
        { id: "IP", title: "invoice-parking" },
        { id: "IR", title: "invoice-receipt" },
        { id: "DC", title: "debit-credit" },
    ],

    /*
      SELECT ''+ REPLACE(Id,'-','_') +':"'+Id+'",'
      FROM [Logistics].[PUR].[AddressUsage]
     */

    orderConfirmationStatuses: {
        APRV: "APRV",
        PARTIAL: "PARTIAL",
        RJCT: "RJCT",
        isAPRV: (x) => getStatusId(x) == "APRV",
        isPARTIAL: (x) => getStatusId(x) == "PARTIAL",
        isRJCT: (x) => getStatusId(x) == "RJCT",
    },

    workingGroupMembersRoles: [
        { id: "IsResponsible", title: "is-responsible" },
        { id: "IsAccountable", title: "is-accountable" },
        { id: "IsInformed", title: "is-informed" },
    ],

    eventContentResponseReasons: [
        { id: "DISC", title: "توقف توليد" },
        { id: "FULL", title: "تكميل ظرفيت" },
        { id: "OTHR", title: "عدم انتخاب" },
    ],

    Currencies: [
        { id: "CNY", title: "يوان" },
        { id: "EUR", title: "يورو" },
        { id: "IRR", title: "ريال" },
        { id: "USD", title: "دلار" },
    ],

    getCurrencyTitle: (id) => {
        return enums.Currencies.find((x) => x.id == id)?.title ?? id;
    },

    Countries: [
        // { id: "AF", title: "Afghanistan" },
        // { id: "AL", title: "Albania" },
        //{ id: "DZ", title: "Algeria" },
        // { id: "AS", title: "American Samoa" },
        // { id: "AD", title: "Andorra" },
        // { id: "AO", title: "Angola" },
        // { id: "AI", title: "Anguilla" },
        // { id: "AQ", title: "Antarctica" },
        // { id: "AG", title: "Antigua and Barbuda" },
        //{ id: "AR", title: "Argentina" },
        //{ id: "AM", title: "Armenia" },
        // { id: "AW", title: "Aruba" },
        //{ id: "AU", title: "Australia" },
        //{ id: "AT", title: "Austria" },
        //{ id: "AZ", title: "Azerbaijan" },
        // { id: "BS", title: "Bahamas (the)" },
        // { id: "BH", title: "Bahrain" },
        // { id: "BD", title: "Bangladesh" },
        // { id: "BB", title: "Barbados" },
        // { id: "BY", title: "Belarus" },
        //{ id: "BE", title: "Belgium" },
        // { id: "BZ", title: "Belize" },
        // { id: "BJ", title: "Benin" },
        // { id: "BM", title: "Bermuda" },
        // { id: "BT", title: "Bhutan" },
        // { id: "BO", title: "Bolivia (Plurinational State of)" },
        // { id: "BQ", title: "Bonaire}, Sint Eustatius and Saba" },
        // { id: "BA", title: "Bosnia and Herzegovina" },
        // { id: "BW", title: "Botswana" },
        // { id: "BV", title: "Bouvet Island" },
        //{ id: "BR", title: "Brazil" },
        // { id: "IO", title: "British Indian Ocean Territory (the)" },
        // { id: "BN", title: "Brunei Darussalam" },
        //{ id: "BG", title: "Bulgaria" },
        // { id: "BF", title: "Burkina Faso" },
        // { id: "BI", title: "Burundi" },
        // { id: "CV", title: "Cabo Verde" },
        // { id: "KH", title: "Cambodia" },
        // { id: "CM", title: "Cameroon" },
        //{ id: "CA", title: "Canada" },
        // { id: "KY", title: "Cayman Islands (the)" },
        // { id: "CF", title: "Central African Republic (the)" },
        // { id: "TD", title: "Chad" },
        // { id: "CL", title: "Chile" },
        { id: "CN", title: "چين", titleEN: "China", countryCode: "+86" },
        // { id: "CX", title: "Christmas Island" },
        // { id: "CC", title: "Cocos (Keeling) Islands (the)" },
        // { id: "CO", title: "Colombia" },
        // { id: "KM", title: "Comoros (the)" },
        // { id: "CD", title: "Congo (the Democratic Republic of the)" },
        // { id: "CG", title: "Congo (the)" },
        // { id: "CK", title: "Cook Islands (the)" },
        // { id: "CR", title: "Costa Rica" },
        // { id: "HR", title: "Croatia" },
        // { id: "CU", title: "Cuba" },
        // { id: "CW", title: "Curaçao" },
        // { id: "CY", title: "Cyprus" },
        //{ id: "CZ", title: "Czechia" },
        // { id: "CI", title: "Côte d'Ivoire" },
        //{ id: "DK", title: "Denmark" },
        // { id: "DJ", title: "Djibouti" },
        // { id: "DM", title: "Dominica" },
        // { id: "DO", title: "Dominican Republic (the)" },
        // { id: "EC", title: "Ecuador" },
        //{ id: "EG", title: "Egypt" },
        // { id: "SV", title: "El Salvador" },
        // { id: "GQ", title: "Equatorial Guinea" },
        // { id: "ER", title: "Eritrea" },
        // { id: "EE", title: "Estonia" },
        // { id: "SZ", title: "Eswatini" },
        // { id: "ET", title: "Ethiopia" },
        // { id: "FK", title: "Falkland Islands (the) [Malvinas]" },
        // { id: "FO", title: "Faroe Islands (the)" },
        // { id: "FJ", title: "Fiji" },
        //{ id: "FI", title: "Finland" },
        //{ id: "FR", title: "France" },
        //{ id: "GF", title: "French Guiana" },
        // { id: "PF", title: "French Polynesia" },
        // { id: "TF", title: "French Southern Territories (the)" },
        // { id: "GA", title: "Gabon" },
        // { id: "GM", title: "Gambia (the)" },
        // { id: "GE", title: "Georgia" },
        //{ id: "DE", title: "Germany" },
        // { id: "GH", title: "Ghana" },
        // { id: "GI", title: "Gibraltar" },
        // { id: "GR", title: "Greece" },
        // { id: "GL", title: "Greenland" },
        // { id: "GD", title: "Grenada" },
        // { id: "GP", title: "Guadeloupe" },
        // { id: "GU", title: "Guam" },
        // { id: "GT", title: "Guatemala" },
        // { id: "GG", title: "Guernsey" },
        // { id: "GN", title: "Guinea" },
        // { id: "GW", title: "Guinea-Bissau" },
        // { id: "GY", title: "Guyana" },
        // { id: "HT", title: "Haiti" },
        // { id: "HM", title: "Heard Island and McDonald Islands" },
        // { id: "VA", title: "Holy See (the)" },
        // { id: "HN", title: "Honduras" },
        //{ id: "HK", title: "Hong Kong" },
        //{ id: "HU", title: "Hungary" },
        // { id: "IS", title: "Iceland" },
        //{ id: "IN", title: "India" },
        // { id: "ID", title: "Indonesia" },
        {
            id: "IR",
            title: "ايران",
            titleEN: "Iran",
            countryCode: "+98",
        },
        { id: "IQ", title: "عراق", titleEN: "Iraq" },
        //{ id: "IE", title: "Ireland" },
        // { id: "IM", title: "Isle of Man" },
        // { id: "IL", title: "Israel" },
        //{ id: "IT", title: "Italy" },
        // { id: "JM", title: "Jamaica" },
        //{ id: "JP", title: "Japan" },
        // { id: "JE", title: "Jersey" },
        // { id: "JO", title: "Jordan" },
        // { id: "KZ", title: "Kazakhstan" },
        // { id: "KE", title: "Kenya" },
        // { id: "KI", title: "Kiribati" },
        // { id: "KP", title: "Korea (the Democratic People's Republic of)" },
        { id: "KR", title: "كره جنوبي", titleEN: "South Korea" },
        // { id: "KW", title: "Kuwait" },
        // { id: "KG", title: "Kyrgyzstan" },
        // { id: "LA", title: "Lao People's Democratic Republic (the)" },
        // { id: "LV", title: "Latvia" },
        //{ id: "LB", title: "Lebanon" },
        // { id: "LS", title: "Lesotho" },
        // { id: "LR", title: "Liberia" },
        // { id: "LY", title: "Libya" },
        //{ id: "LI", title: "Liechtenstein" },
        // { id: "LT", title: "Lithuania" },
        // { id: "LU", title: "Luxembourg" },
        // { id: "MO", title: "Macao" },
        // { id: "MG", title: "Madagascar" },
        // { id: "MW", title: "Malawi" },
        //{ id: "MY", title: "Malaysia" },
        // { id: "MV", title: "Maldives" },
        // { id: "ML", title: "Mali" },
        // { id: "MT", title: "Malta" },
        // { id: "MH", title: "Marshall Islands (the)" },
        // { id: "MQ", title: "Martinique" },
        // { id: "MR", title: "Mauritania" },
        // { id: "MU", title: "Mauritius" },
        // { id: "YT", title: "Mayotte" },
        // { id: "MX", title: "Mexico" },
        // { id: "FM", title: "Micronesia (Federated States of)" },
        // { id: "MD", title: "Moldova (the Republic of)" },
        // { id: "MC", title: "Monaco" },
        // { id: "MN", title: "Mongolia" },
        // { id: "ME", title: "Montenegro" },
        // { id: "MS", title: "Montserrat" },
        //{ id: "MA", title: "Morocco" },
        // { id: "MZ", title: "Mozambique" },
        // { id: "MM", title: "Myanmar" },
        // { id: "NA", title: "Namibia" },
        // { id: "NR", title: "Nauru" },
        // { id: "NP", title: "Nepal" },
        //{ id: "NL", title: "Netherlands (the)" },
        // { id: "NC", title: "New Caledonia" },
        // { id: "NZ", title: "New Zealand" },
        // { id: "NI", title: "Nicaragua" },
        // { id: "NE", title: "Niger (the)" },
        // { id: "NG", title: "Nigeria" },
        // { id: "NU", title: "Niue" },
        // { id: "NF", title: "Norfolk Island" },
        // { id: "MP", title: "Northern Mariana Islands (the)" },
        // { id: "NO", title: "Norway" },
        //{ id: "OM", title: "Oman" },
        // { id: "PK", title: "Pakistan" },
        // { id: "PW", title: "Palau" },
        // { id: "PS", title: "Palestine}, State of" },
        // { id: "PA", title: "Panama" },
        // { id: "PG", title: "Papua New Guinea" },
        // { id: "PY", title: "Paraguay" },
        // { id: "PE", title: "Peru" },
        // { id: "PH", title: "Philippines (the)" },
        // { id: "PN", title: "Pitcairn" },
        //{ id: "PL", title: "Poland" },
        //{ id: "PT", title: "Portugal" },
        // { id: "PR", title: "Puerto Rico" },
        //{ id: "QA", title: "Qatar" },
        //{ id: "MK", title: "Republic of North Macedonia" },
        //{ id: "RO", title: "Romania" },
        //{ id: "RU", title: "Russian Federation (the)" },
        // { id: "RW", title: "Rwanda" },
        // { id: "RE", title: "Réunion" },
        // { id: "BL", title: "Saint Barthélemy" },
        // { id: "SH", title: "Saint Helena}, Ascension and Tristan da Cunha" },
        // { id: "KN", title: "Saint Kitts and Nevis" },
        // { id: "LC", title: "Saint Lucia" },
        // { id: "MF", title: "Saint Martin (French part)" },
        // { id: "PM", title: "Saint Pierre and Miquelon" },
        // { id: "VC", title: "Saint Vincent and the Grenadines" },
        // { id: "WS", title: "Samoa" },
        // { id: "SM", title: "San Marino" },
        // { id: "ST", title: "Sao Tome and Principe" },
        //{ id: "SA", title: "Saudi Arabia" },
        // { id: "SN", title: "Senegal" },
        // { id: "RS", title: "Serbia" },
        //{ id: "SC", title: "Seychelles" },
        // { id: "SL", title: "Sierra Leone" },
        //{ id: "SG", title: "Singapore" },
        // { id: "SX", title: "Sint Maarten (Dutch part)" },
        //{ id: "SK", title: "Slovakia" },
        //{ id: "SI", title: "Slovenia" },
        // { id: "SB", title: "Solomon Islands" },
        // { id: "SO", title: "Somalia" },
        //{ id: "ZA", title: "South Africa" },
        // { id: "GS", title: "South Georgia and the South Sandwich Islands" },
        // { id: "SS", title: "South Sudan" },
        //{ id: "ES", title: "Spain" },
        // { id: "LK", title: "Sri Lanka" },
        // { id: "SD", title: "Sudan (the)" },
        // { id: "SR", title: "Suriname" },
        // { id: "SJ", title: "Svalbard and Jan Mayen" },
        //{ id: "SE", title: "Sweden" },
        //{ id: "CH", title: "Switzerland" },
        // { id: "SY", title: "Syrian Arab Republic" },
        //{ id: "TW", title: "Taiwan" },
        //{ id: "TJ", title: "Tajikistan" },
        // { id: "TZ", title: "Tanzania}, United Republic of" },
        //{ id: "TH", title: "Thailand" },
        // { id: "TL", title: "Timor-Leste" },
        // { id: "TG", title: "Togo" },
        // { id: "TK", title: "Tokelau" },
        // { id: "TO", title: "Tonga" },
        // { id: "TT", title: "Trinidad and Tobago" },
        //{ id: "TN", title: "Tunisia" },
        //{ id: "TR", title: "Turkey" },
        //{ id: "TM", title: "Turkmenistan" },
        // { id: "TC", title: "Turks and Caicos Islands (the)" },
        // { id: "TV", title: "Tuvalu" },
        // { id: "UG", title: "Uganda" },
        // { id: "UA", title: "Ukraine" },
        //{ id: "AE", title: "United Arab Emirates (the)" },
        //{ id: "GB", title: "United Kingdom " },
        // { id: "UM", title: "United States Minor Outlying Islands (the)" },
        //{ id: "US", title: "United States of America (the)" },
        // { id: "UY", title: "Uruguay" },
        // { id: "UZ", title: "Uzbekistan" },
        // { id: "VU", title: "Vanuatu" },
        //{ id: "VE", title: "Venezuela (Bolivarian Republic of)" },
        // { id: "VN", title: "Viet Nam" },
        // { id: "VG", title: "Virgin Islands (British)" },
        // { id: "VI", title: "Virgin Islands (U.S.)" },
        // { id: "WF", title: "Wallis and Futuna" },
        // { id: "EH", title: "Western Sahara" },
        // { id: "YE", title: "Yemen" },
        // { id: "ZM", title: "Zambia" },
        // { id: "ZW", title: "Zimbabwe" },
        // { id: "AX", title: "Åland Islands" },
    ],

    CompanyTypes: [
        { id: "LEGAL-GOV", title: "دولتی" },
        { id: "LEGAL-LIMITED", title: "با مسئولیت محدود" },
        { id: "LEGAL-OTHER", title: "سایر" },
        { id: "LEGAL-PRIVATE", title: "سهامی خاص" },
        { id: "LEGAL-PUBLIC", title: "سهامی عام" },
        { id: "PRIVATE-OFFICE", title: "دفتر" },
        { id: "PRIVATE-OTHER", title: "ساير" },
        { id: "PRIVATE-PERSONAL", title: "شخصي" },
        { id: "PRIVATE-STORE", title: "فروشگاه" },
        { id: "PRIVATE-WORKSHOP", title: "کارگاه" },
    ],
    DS_RequestStatuses: {
        APRV: "APRV",
        NEW: "NEW",
        RJCT: "RJCT",
        isAPRV: (requestStatusId) => requestStatusId === "APRV",
        isNEW: (requestStatusId) => requestStatusId === "NEW",
        isRJCT: (requestStatusId) => requestStatusId === "RJCT",
    },
    AttachmentTypes: {
        ["address-image"]: {
            title: "تصوير آدرس",
            maxSize: 1024,
            validTypes: "jpg,jpeg,png",
            count: 0,
        },
        ["attachment"]: {
            title: "ضمیمه",
            maxSize: 1024,
            validTypes: "JPG , JPEG , PNG",
            count: 1,
        },
        ["auction-announcement"]: {
            title: "آگهي برگزاري مزايده",
            maxSize: 2048,
            validTypes: "pdf",
            count: 1,
        },
        ["auction-content-file"]: {
            title: "فايل پيوست محتواي مزايده",
            maxSize: 1024,
            validTypes: "pdf,jpg,jpeg,png,doc,docx,txt,xlsx,xls",
            count: 1,
        },
        ["auction-content"]: {
            title: "پيوست محتوا",
            maxSize: 4096,
            validTypes: "pdf,jpg,jpeg,png,docx,txt,pdf",
            count: 1,
        },
        ["auction-location"]: {
            title: "تصوير نقشه برگزاري مزايد",
            maxSize: 2048,
            validTypes: "jpg,png",
            count: 1,
        },
        ["auction-logo"]: {
            title: "لوگوي مزايده",
            maxSize: 2048,
            validTypes: "jpg,png",
            count: 1,
        },
        ["auction-pack"]: {
            title: "پك مزايده",
            maxSize: 2048,
            validTypes: "jpg,jpeg,png",
            count: 5,
        },
        ["auction-ticket"]: {
            title: "فايل پيوست تيكت مزايده",
            maxSize: 1024,
            validTypes: "",
            count: 1,
        },
        ["company-statute"]: {
            title: "تصویر اساسنامه",
            maxSize: 2048,
            validTypes: "jpg,png",
            count: 1,
        },
        ["company-banner"]: {
            title: "بنر شركت",
            maxSize: 2048,
            validTypes: "jpg,png",
            count: 0,
        },
        ["company-business-card"]: {
            title: "کارت ویزیت شرکت",
            maxSize: 1024,
            validTypes: "image",
            count: 2,
        },
        ["company-doc"]: {
            title: "اسناد مالكيت",
            maxSize: 3072,
            validTypes: "image",
            count: 1,
        },
        ["company-fin"]: {
            title: "صورتهاي مالي",
            maxSize: 3072,
            validTypes: "pdf",
            count: 1,
        },
        ["company-id-card"]: {
            title: "كارت ملي مديرعامل",
            maxSize: 2048,
            validTypes: "jpg,png",
            count: 1,
        },
        ["company-logo"]: {
            title: "لوگو شركت",
            maxSize: 1024,
            validTypes: "jpg,png",
            count: 0,
        },
        ["company-rasmi"]: {
            title: "روزنامه رسمي تاسيس",
            maxSize: 2048,
            validTypes: "jpg,png",
            count: 1,
        },
        ["company-stamp"]: {
            title: "مهر شركت",
            maxSize: 2048,
            validTypes: "jpg,png",
            count: 1,
        },
        ["content"]: { title: "محتوا", maxSize: 4096, validTypes: "", count: 0 },
        ["document-discovery"]: {
            title: "Document Discovery",
            maxSize: 5120,
            validTypes: "",
            count: 5,
        },
        ["face-picture"]: {
            title: "تصوير مدير",
            maxSize: 1024,
            validTypes: "jpg,png",
            count: 1,
        },
        ["file"]: { title: "فايل", maxSize: 1024, validTypes: "", count: 5 },
        ["id-cart-first"]: {
            title: "صفحه اول كارت ملي",
            maxSize: 1024,
            validTypes: "jpg,png",
            count: 1,
        },
        ["id-cart-second"]: {
            title: "صفحه دوم كارت ملي",
            maxSize: 1024,
            validTypes: "jpg,png",
            count: 1,
        },
        ["logo"]: { title: "لوگو", maxSize: 2048, validTypes: "jpg,png", count: 0 },
        ["meeting"]: {
            title: "صورتجلسه",
            maxSize: 10240,
            validTypes: "pdf,jpg,jpeg,png,doc,docx,txt,xlsx,xls",
            count: 3,
        },
        ["order-confirm"]: {
            title: "Order Confirm",
            maxSize: 2048,
            validTypes: "pdf,jpg,jpeg,png,doc,docx,txt,xlsx,xls",
            count: 5,
        },
        ["prj-doc"]: { title: "سند پروژه", maxSize: 10240, validTypes: "", count: 1 },
        ["profile-image"]: {
            title: "تصوير پروفايل كاربر",
            maxSize: 1024,
            validTypes: "jpg,png",
            count: 0,
        },
        ["project-logo"]: {
            title: "لوگو پروژه",
            maxSize: 2048,
            validTypes: "jpg,png",
            count: 1,
        },
        ["request"]: {
            title: "Sourcing Request",
            maxSize: 10240,
            validTypes: "",
            count: 5,
        },
        ["research-posting"]: {
            title: "Research Posting",
            maxSize: 4096,
            validTypes: "",
            count: 0,
        },
        ["response-attachment"]: {
            title: "Response Attachment",
            maxSize: 2048,
            validTypes: "",
            count: 0,
        },
        ["rfx-comment"]: {
            title: "RFX Comment",
            maxSize: 2048,
            validTypes: "pdf,jpg,jpeg,png,docx,txt,pdf",
            count: 0,
        },
        ["rfx-content-response"]: {
            title: "RFX Content Response",
            maxSize: 2048,
            validTypes: "",
            count: 0,
        },
        ["shipment"]: {
            title: "اعلامیه حمل",
            maxSize: 4096,
            validTypes: "pdf,jpg,jpeg,png,doc,docx,txt,xlsx,xls",
            count: 1,
        },
        ["signature-image"]: {
            title: "تصوير نمونه امضاء",
            maxSize: 1024,
            validTypes: "jpg,png",
            count: 1,
        },
        ["signed-order"]: {
            title: "قرارداد امضاء شده",
            maxSize: 4096,
            validTypes: "pdf",
            count: 0,
        },
    },

    participationRateTypes: [
        { id: "PARTICIPATED", title: "min-one-inquiry-participated" },
        { id: "RESPONSED", title: "min-one-inquiry-responsed" },
        { id: "ORDERED", title: "min-one-purchase-order" },
    ],
    Incoterms: [
        { id: "EXW", title: "EXW" },
        { id: "FCA", title: "FCA" },
        { id: "FAS", title: "FAS" },
        { id: "FOB", title: "FOB" },
        { id: "CFR", title: "CFR" },
        { id: "CIF", title: "CIF" },
        { id: "CPT", title: "CPT" },
        { id: "CIP", title: "CIP" },
        { id: "DAP", title: "DAP" },
        { id: "DPU", title: "DPU" },
        { id: "DDP", title: "DDP" },
    ],

    reportTypes: {
        DISC: "DISC",
        AWARD: "AWARD",
        QUESTION: "QUESTION",
        SUPPLIERS: "SUPPLIERS",
        CNT_RSP: "CNT-RSP",
        ORDER_CONF: "ORDER-CONF",
        CNF: "CNF",
        INQUIRY: "INQUIRY",
        INQ_RPT: "INQ-RPT",
        FORM: "FORM",
    },

    addressUsages: {
        AUC: "AUC",
        EVENT: "EVENT",
        AUCTION: "AUCTION",
        SHIP_TO: "SHIP-TO",
        SHIP_FROM: "SHIP-FROM",
        COMP_LOC: "COMP-LOC",
        TM_LOC: "TM-LOC",
    },

    authenticationStatus: {
        APPROVED: "APPROVED",
        IN_PROC: "IN-PROC",
        NEW: "NEW",
        REJECTED: "REJECTED",

        isNEW: (x) => getStatusId(x) == "NEW",
        isREJECTED: (x) => getStatusId(x) == "REJECTED",
    },

    logTypes: {
        Document: "DOCUMENT",
        Project: "PROJECT",
        Auction: "AUCTION",
    },
    freightUnitStatuses: {
        DRAFT: "DRAFT",
        PLAN: "PLAN",
        CMPL: "CMPL",
        DELIVERED: "DELIVERED",
        INTRANSIT: "IN-TRANSIT",
        ONHOLD: "ON-HOLD",
        CANCEL: "CANCEL",
    },
    meetingTypes: {
        CNF: "CNF",
        ENV: "ENV",
    },

    meetingStatuses: {
        ACTIVE: "ACTIVE",
        CLOSE: "CLOSE",
        isACTIVE: (x) => getStatusId(x) == "ACTIVE",
        isCLOSE: (x) => getStatusId(x) == "CLOSE",
    },

    messageTypes: {
        TEXT: "TEXT",
        IMG: "IMG",
        TXT: "TXT",
        JSON: "JSON",
        PDF: "PDF",
        ZIP: "ZIP",
        XLSX: "XLSX",
        DOCX: "DOCX",

        isTEXT: (x) => x == "TEXT",
        isIMG: (x) => x == "IMG",
        isTXT: (x) => x == "TXT",
        isJSON: (x) => x == "JSON",
        isXLSX: (x) => x == "XLSX",
        isWORD: (x) => x == "DOCX",
        isPDF: (x) => x == "PDF",
        isZIP: (x) => x == "ZIP",
    },

    documentCommentStatuses: {
        APRV: "APRV",
        NEW: "NEW",
        RJCT: "REJCT",
        isNEW: (x) => getStatusId(x) == "NEW",
        isAPRV: (x) => getStatusId(x) == "APRV",
        isRJCT: (x) => getStatusId(x) == "REJCT",
    },

    authenticationMethods: {
        Phone: "Phone",
        Password_Phone: "Password_Phone",
        Password_Email: "Password_Email",
        isPhone: (x) => x == "Phone",
        isPassword_Phone: (x) => x == "Password_Phone",
        isPassword_Email: (x) => x == "Password_Email",
    },
    ticketStatuses: {
        ANSWERED: "ANSWERED",
        CLOSED: "CLOSED",
        WAITING: "WAITING",
        isANSWERED: (x) => getStatusId(x) == "ANSWERED",
        isCLOSED: (x) => getStatusId(x) == "CLOSED",
        isWAITING: (x) => getStatusId(x) == "WAITING",
    },
    alternativeStatuses: {
        SUB: "SUB",
        RJCT: "RJCT",
        GRD: "GRD",
        NOT_APRV: "NOT-APRV",
        WINNER: "WINNER",
        LOOSER: "LOOSER",
        isSUB: (x) => getStatusId(x) == "SUB",
        isGRD: (x) => getStatusId(x) == "GRD",
        isRJCT: (x) => getStatusId(x) == "RJCT",
        isWINNER: (x) => getStatusId(x) == "WINNER",
        isLOOSER: (x) => getStatusId(x) == "LOOSER",
        isNOT_APRV: (x) => getStatusId(x) == "NOT-APRV",
        isApproved: (x) => {
            const st = getStatusId(x);
            return st == "GRD" || st == "LOOSER" || st == "WINNER";
        },
    },

    documentCommoditiesStatuses: {
        DRFT: "DRFT",
        PREFER: "PREFER",
        QUAL: "QUAL",
        RJCT: "RJCT",
        Titles: {
            DRFT: "Draft",
            PREFER: "Preferred",
            QUAL: "Qualified",
            RJCT: "Rejected",
        },
    },

    documentSuppliersStatuses: {
        ACPT: "ACPT",
        SLCT: "SLCT",
        VISIT: "VISIT",
        SUB: "SUB",
        RJCT: "RJCT",
        isSUB: (x) => getStatusId(x) == "SUB",
        isACPT: (x) => getStatusId(x) == "ACPT",
        isRJCT: (x) => getStatusId(x) == "RJCT",
        isSLCT: (x) => getStatusId(x) == "SLCT",
        isVISIT: (x) => getStatusId(x) == "VISIT",
        isAccepted: (x) => {
            const st = getStatusId(x);
            return st == "ACPT" || st == "SLCT" || st == "VISIT";
        },
    },

    WFObjects: {
        AwardEvent: "AWARD-EVENT",
        PublishEvent: "PUB-EVENT",
        CloseEvent: "CLOSE-EVENT",
        GradeEvent: "GRADE-EVENT",
        SumbitConf: "SUBMIT-CONF",
        RegReq: "REG-REQ",
        SrcReQ: "SRC-REQ",
        FormFaxMoj: "FORM-FAX-MOJ",
        Form: "FORM-",
    },

    objectClasses: {
        Users: "Users",
        Document: "Document",
        Request: "Request",
        Order: "Order",
        Project: "Project",
    },
    notificationTypes: {
        NOTIFY: "NOTIFY",
        SMS: "SMS",
        TASK: "TASK",
    },

    notificationStatuses: {
        APRV: "APRV",
        CLOSED: "CLOSED",
        REFERBACK: "REFERBACK",
        RJCT: "RJCT",
        VISITED: "VISITED",
        NEW: "NEW",
        isNEW: (t) => {
            if (t.status) t = t.status;
            else if (t.statusId) t = t.statusId;
            return t?.toUpperCase() == "NEW";
        },
        isVISITED: (t) => {
            if (t.status) t = t.status;
            else if (t.statusId) t = t.statusId;
            return t?.toUpperCase() == "VISITED";
        },
    },

    regReqStatuses: {
        NEW: "NEW",
        REVIEW: "REVIEW",
        PENDING: "PENDING",
        UPDATED: "UPDATED",
        APPROVE: "APPROVE",
        REJECT: "REJECT",
        EVAL: "EVAL",
        isNEW: (x) => getStatusId(x) == enums.regReqStatuses.NEW,
        isREVIEW: (x) => getStatusId(x) == enums.regReqStatuses.REVIEW,
        isPENDING: (x) => getStatusId(x) == enums.regReqStatuses.PENDING,
        isUPDATED: (x) => getStatusId(x) == enums.regReqStatuses.UPDATED,
        isAPPROVE: (x) => getStatusId(x) == enums.regReqStatuses.APPROVE,
        isREJECT: (x) => getStatusId(x) == enums.regReqStatuses.REJECT,
        isEVAL: (x) => getStatusId(x) == enums.regReqStatuses.EVAL,
    },

    roles: {
        PR_OWNER: "PR_OWNER",
        PRASSIGN: "PRASSIGN",
        REQ: "REQ",
        QUICK_RFP: "QUICK-RFP",
        QUICK_DISC: "QUICK-DISC",
        OWNER: "OWNER",
        PUWS: "PUWS",
        KN: "KN",
        DEL: "DEL",
        SURV: "SURV",
        SM: "SM",
        ORDER: "ORDER",
        CNF: "CNF",
        INQWS: "INQWS",
        IPG_ADMIN: "IPG-ADMIN",
        IPG_REPORT: "IPG-REPORT",
        APROC: "APROC",
        TMPL: "TMPL",
        MASTERDATA: "MASTERDATA",
        PROFILE: "PROFILE",
    },

    actions: {
        PUB: "PUB",
        CLOSE: "CLOSE",
        GRADE: "GRADE",
        AWARD: "AWARD",

        BDRFT: "BDRFT",
        BPUB: "BPUB",
        BCLOSE: "BCLOSE",
        BGRADE: "BGRADE",
        CNF: "CNF",
    },

    aprocActions: {
        PUB: "PUB",
        CLOSE: "CLOSE",
        GRADE: "GRADE",
        AWARD: "AWARD",
        CMPL: "CMPL",
        RELEASE: "RELEASE",
        SUBMIT: "SUBMIT",
        QUAL_RJCT: "QUAL_RJCT",
        QUAL: "QUAL",
        RJCT: "RJCT",
        CNF: "CNF",
    },

    wfActions: {
        WF_EVENT_AWARD: "WF-EVENT-AWARD",
    },

    smsRequest: {
        NEW: "NEW",
        isNEW: (t) => t?.toUpperCase() == "NEW",
    },

    requestStatuses: {
        NEW: "NEW",
        SRC: "SRC",

        isNEW: (t) => t?.toUpperCase() == "NEW",
        isSRC: (t) => t?.toUpperCase() == "SRC",
    },

    contentTypes: {
        isSEC: (x) => getContentTypeId(x) == "SEC",
        isQN: (x) => getContentTypeId(x) == "QN",
        isCOND: (x) => getContentTypeId(x) == "COND",
        isITEM: (x) => getContentTypeId(x) == "ITEM",
        isLine: (x) => getContentTypeId(x) == "LINE",
    },

    orderHistoryCategories: {
        isGR: (x) => x == "GR",
        isIR: (x) => x == "IR",
        isSRV: (x) => x == "SRV",
    },

    answerTypes: {
        isCMB: (x) => getAnswerTypeId(x) == "CMB",
        isDATE: (x) => getAnswerTypeId(x) == "DATE",
        isMEMO: (x) => getAnswerTypeId(x) == "MEMO",
        isNUM: (x) => getAnswerTypeId(x) == "NUM",
        isTXT: (x) => getAnswerTypeId(x) == "TXT",
        isUPL: (x) => getAnswerTypeId(x) == "UPL",
        isYESNO: (x) => getAnswerTypeId(x) == "YESNO",
    },

    smGrades: [
        { id: "A", title: "A" },
        { id: "B", title: "B" },
        { id: "C", title: "C" },
        { id: "D", title: "D" },
    ],

    shipmentStatuses: {
        DRFT: "DRFT",
        SUBMIT: "SUBMIT",

        isDRFT: (x) => getStatusId(x) == enums.shipmentStatuses.DRFT,
        isSUBMIT: (x) => getStatusId(x) == enums.shipmentStatuses.SUBMIT,
    },

    poStatuses: {
        DRFT: "DRFT",
        RELEASE: "RELEASE",
        CONF: "CONF",
        CMPL: "CMPL",
        RJCT: "RJCT",
        SUBMIT: "SUBMIT",

        isDRFT: (x) => getStatusId(x) == enums.poStatuses.DRFT,
        isRELEASE: (x) => getStatusId(x) == enums.poStatuses.RELEASE,
        isCONF: (x) => getStatusId(x) == enums.poStatuses.CONF,
        isCMPL: (x) => getStatusId(x) == enums.poStatuses.CMPL,
        isSUBMIT: (x) => getStatusId(x) == enums.poStatuses.SUBMIT,
    },

    documentStatuses: {
        DRFT: "DRFT",
        PUB: "PUB",
        CLOSE: "CLOSE",
        GRADE: "GRADE",
        AWARD: "AWARD",
        CMPL: "CMPL",
        SUB: "SUB",

        isDRFT: (x) => getStatusId(x) == enums.documentStatuses.DRFT,
        isPUB: (x) => getStatusId(x) == enums.documentStatuses.PUB,
        isCLOSE: (x) => getStatusId(x) == enums.documentStatuses.CLOSE,
        isOPEN: (x) => getStatusId(x) == enums.documentStatuses.ope,
        isGRADE: (x) => getStatusId(x) == enums.documentStatuses.GRADE,
        isAWARD: (x) => getStatusId(x) == enums.documentStatuses.AWARD,
        isCMPL: (x) => getStatusId(x) == enums.documentStatuses.CMPL,
    },

    confirmationStatuses: {
        DRFT: "DRFT",
        SUBMIT: "SUBMIT",
        REJECT: "REJECT",
        APPROVE: "APPROVE",
        CANCEL: "CANCEL",

        isDRFT: (x) => getStatusId(x) == enums.confirmationStatuses.DRFT,
        isSUBMIT: (x) => getStatusId(x) == enums.confirmationStatuses.SUBMIT,
        isREJECT: (x) => getStatusId(x) == enums.confirmationStatuses.REJECT,
        isAPPROVE: (x) => getStatusId(x) == enums.confirmationStatuses.APPROVE,
        isCANCEL: (x) => getStatusId(x) == enums.confirmationStatuses.CANCEL,
    },

    scenarioStatuses: {
        DRFT: "DRFT",
        AWARD: "AWARD",

        isDRFT: (x) => getStatusId(x) == "DRFT",
        isAWARD: (x) => getStatusId(x) == "AWARD",
    },

    eventTypes: {
        RFI: "RFI",
        RFP: "RFP",
        SURV: "SURV",
        BAUC: "BAUC",
        isRFI: (x) => getEventTypeId(x) == "RFI",
        isRFP: (x) => getEventTypeId(x) == "RFP",
        isBAUC: (x) => getEventTypeId(x) == "BAUC",
        isSURV: (x) => getEventTypeId(x) == "SURV",
    },

    projectTypes: {
        PUWS: "PUWS",
        INQWS: "INQWS",
        REQ: "REQ",
        KN: "KN",
        RFP: "RFP",

        isKN: (x) => getProjectType(x) == "KN",
        isPUWS: (x) => getProjectType(x) == "PUWS",
        isREQ: (x) => getProjectType(x) == "REQ",
        isINQWS: (x) => getProjectType(x) == "INQWS",
        isRFP: (x) => getProjectType(x) == "RFP",
    },

    projectStatuses: {
        DRAFT: "DRAFT",
        ACTIVE: "ACTIVE",
        CANCEL: "CANCEL",
        CLOSE: "CLOSE",
        CMPL: "CMPL",

        isDRAFT: (x) => getStatusId(x) == "DRAFT",
        isACTIVE: (x) => getStatusId(x) == "ACTIVE",
        isCLOSE: (x) => getStatusId(x) == "CLOSE",
    },

    projectNumbers: {
        SysTMPL: "SYS-TMPL",

        isSysTMPL: (x) => getProjectNumber(x) == "SYS-TMPL",
        isSysKN: (x) => getProjectNumber(x) == "SYS-KN",
        isSysSKNA: (x) => getProjectNumber(x) == "SYS-SKNA",
        isSysCNF: (x) => getProjectNumber(x) == "SYS-CNF",
        isSysSRLIB: (x) => getProjectNumber(x) == "SYS-SRLIB",
    },

    documentTypes: {
        PUWS: "PUWS",        
        INQWS: "INQWS",
        KN: "KN",
        EVENT: "EVENT",
        CONT: "CONT",
        SPQ: "SPQ",
        DISC: "DISC",
        CNF: "CNF",
        REG: "REG",
        RFP: "RFP",

        isPUWS: (x) => getDocumentType(x) == "PUWS",
        isINQWS: (x) => getDocumentType(x) == "INQWS",
        isKN: (x) => getDocumentType(x) == "KN",
        isEVENT: (x) => getDocumentType(x) == "EVENT",
        isCONT: (x) => getDocumentType(x) == "CONT",
        isSPQ: (x) => getDocumentType(x) == "SPQ",
        isDISC: (x) => getDocumentType(x) == "DISC",
        isCNF: (x) => getDocumentType(x) == "CNF",
        isREG: (x) => getDocumentType(x) == "REG",
        isRFP: (x) => getDocumentType(x) == "RFP",
    },

    itemCategories: {
        M: "M",
        P: "P",
        S: "S",
        isMaterial: (type) => type?.toUpperCase() == "M",
        isPalette: (type) => type?.toUpperCase() == "P",
        isService: (type) => type?.toUpperCase() == "S",
    },
    approvementStatuses: {
        APRV: "APRV",
        NEW: "NEW",
        RJCT: "RJCT",
        CANCEL: "CANCEL",

        isNEW: (x) => {
            if (x?.approvementStatus) x = x.approvementStatus;
            return x?.toUpperCase() == "NEW";
        },

        isRJCT: (x) => {
            if (x?.approvementStatus) x = x.approvementStatus;
            return x?.toUpperCase() == "RJCT";
        },

        isCANCEL: (x) => {
            if (x?.approvementStatus) x = x.approvementStatus;
            return x?.toUpperCase() == "CANCEL";
        },

        isAPRV: (x) => {
            if (x?.approvementStatus) x = x.approvementStatus;
            return x?.toUpperCase() == "APRV";
        },
    },

    calculationMethods: {
        DISC_: "DISC%",
        DISC: "DISC",
        COST: "COST",
        TAX: "TAX",
    },

    inboxActionStatuses: {
        APRV: "APRV",
        CLOSED: "CLOSED",
        NOTIFY: "NOTIFY",
        READY: "READY",
        RJCT: "RJCT",
        REFERBACK: "REFERBACK",
    },

    auctionStatuses: {
        DRFT: "DRFT",
        PUB: "PUB",
        CLOSE: "CLOSE",
        GRADE: "GRADE",
        AWARD: "AWARD",
        CMPL: "CMPL",
        SUB: "SUB",

        isDRFT: (x) => getStatusId(x) == enums.auctionStatuses.DRFT,
        isPUB: (x) => getStatusId(x) == enums.auctionStatuses.PUB,
        isCLOSE: (x) => getStatusId(x) == enums.auctionStatuses.CLOSE,
        isGRADE: (x) => getStatusId(x) == enums.auctionStatuses.GRADE,
        isAWARD: (x) => getStatusId(x) == enums.auctionStatuses.AWARD,
        isCMPL: (x) => getStatusId(x) == enums.auctionStatuses.CMPL,
    },

    auctionMethodTypes: {
        CASH: "CASH",
        CREDIT: "CREDIT",
        CHEQUE: "CHEQUE",
    },

    auctionContentTypes: {
        PREREQ: "PREREQ",
        QNCMB: "QN-CMB",
        CQNMEMO: "QN-MEMO",
        QNTEXT: "QN-TEXT",
        QNYN: "QN-YN",
        TEXT: "TEXT",
        UPLOAD: "UPLOAD",

        isDRFT: (x) => getStatusId(x) == enums.auctionStatuses.DRFT,
        isPUB: (x) => getStatusId(x) == enums.auctionStatuses.PUB,
        isCLOSE: (x) => getStatusId(x) == enums.auctionStatuses.CLOSE,
        isGRADE: (x) => getStatusId(x) == enums.auctionStatuses.GRADE,
        isAWARD: (x) => getStatusId(x) == enums.auctionStatuses.AWARD,
        isCMPL: (x) => getStatusId(x) == enums.auctionStatuses.CMPL,
    },

    termTypes: {
        TEXT: "TEXT",
        SUPPLIER: "SUPPLIER",

        isTEXT: (x) => x.termType == enums.termTypes.TEXT,
        isSUPPLIER: (x) => x.termType == enums.termTypes.SUPPLIER,
    },

    userAuctionStatuses: {
        ACPT: "ACPT",
        BID: "BID",
        DOCPAY: "DOCPAY",
        FINE: "FINE",
        LOOSER: "LOOSER",
        REGISTER: "REGISTER",
        RESERVE: "RESERVE",
        RSPN: "RSPN",
        WINNER: "WINNER",
    },
};

export const eventTypes = [
    { id: "RFI", title: "rfi" },
    { id: "RFP", title: "rfp" },
    { id: "SURV", title: "surv" },
    { id: "AUC", title: "auc" },
];

export const documentSuppliersStatuses = [
    { id: "ACPT", title: "accept" },
    { id: "SLCT", title: "select" },
    { id: "VISIT", title: "visit" },
    { id: "SUB", title: "submit" },
    { id: "RJCT", title: "reject" },
];

export const ticketStatuses = [
    { id: "ANSWERED", title: "پاسخ داده شده" },
    { id: "CLOSED", title: "تكمیل شده" },
    { id: "WAITING", title: "در انتظار پاسخ" },
];

export const RegReqStatuses = [
    { id: "NEW", title: "جدید", isArchived: false },
    { id: "REVIEW", title: "در حال پردازش", isArchived: false },
    { id: "PENDING", title: "در انتظار اصلاح فرم", isArchived: false },
    { id: "UPDATED", title: "اصلاح شده", isArchived: false },
    { id: "EVAL", title: "در حال ارزیابی", isArchived: false },
    { id: "APPROVE", title: "تایید شده", isArchived: true },
    { id: "REJECT", title: "رد شده", isArchived: true },
];

export const DOCUMENT_STATUSES = {
    DRFT: "DRFT",
    PUB: "PUB",
    CLOSE: "CLOSE",
    GRADE: "GRADE",
    AWARD: "AWARD",
    CMPL: "CMPL",
    RJCT: "RJCT",
};

export const wfSystemTriggers = {
    APPROVE: "APPROVE",
    REJECT: "REJECT",
    AWARD_EVENT: "AWARD-EVENT",
    CONFIRM_EVENT: "CONFIRM-EVENT",
    FINISH: "FINISH",
    NEW_ROUND: "NEW-ROUND",
    PENDING: "PENDING",
    REG_REQ: "REG-REQ",
    REJECT_EVENT: "REJECT-EVENT",
    SUBMIT_CONF: "SUBMIT-CONF",
};

export const ORDER_STATUSES = {
    DRFT: "DRFT",
    RELEASE: "RELEASE",
    ACK: "ACK",
    CMPL: "CMPL",
    RJCT: "RJCT",
    SUBMIT: "SUBMIT",
    CONF: "CONF",
};
export const ORDER_DOCTYPES = { ZFPN: "ZFPN", ZNPM: "ZNPM", ZPLN: "ZPLN" };
/*
  SELECT '{id:"'+Id+'", title:"'+Title+'" },'
    FROM [Logistics].[PUR].[TicketTypes]
 */

export const ticketTypes = [
    { id: "AWARD", title: "اعتراض به اعلام نتايج" },
    { id: "BID", title: "مشكل در پيشنهاد قيمت" },
    { id: "PAYMENT", title: "مشكل در پرداخت وجه" },
    { id: "REFUND", title: "عدم دريافت وجه تضمين" },
    { id: "SUGGESTION", title: "انتقادات و پيشنهادات" },
];

/*
SELECT '{id:"'+Id+'", title:"'+Id+'" },'
FROM [Logistics].[PUR].[TermTypes]
*/

export const termTypes = [
    { id: "-", title: "-" },
    { id: "-%", title: "-%" },
    { id: "+", title: "+" },
    { id: "+%", title: "+%" },
    { id: "SUPPLIER", title: "SUPPLIER" },
    { id: "TEXT", title: "TEXT" },
];

/*
 SELECT '{id:"'+Id+'", title:"'+Id+'" },'
    FROM [Logistics].[PUR].[AddressUsage]

*/

export const addressUsage = [
    { id: "AUCTION", title: "محل بازديد اقلام مزايده" },
    { id: "ORDER-ADR", title: "آدرس تحويل سفارش" },
    { id: "TM-LOC", title: "آدرس حمل و نقل" },
    { id: "AUC", title: "محل برگزاری جلسات مزایده" },
    { id: "EVENT", title: "محل برگزاری جلسات مناقصه" },
];

/*
    SELECT '{id:"'+Id+'", title:"'+Id+'" },'
    FROM [Logistics].[PUR].[EventTypes]
    ORDER BY SortOrder
 */
export const EVENT_TYPES = { RFI: "RFI", RFP: "RFP", AUC: "AUC", SURV: "SURV" };

export const ContentTypes = [
    { id: "PREREQ", title: "پيش نياز" },
    { id: "QN-CMB", title: "سوال-انتخابي" },
    { id: "QN-MEMO", title: "سوال-متن-طولاني" },
    { id: "QN-TEXT", title: "سوال-متن-كوتاه" },
    { id: "QN-YN", title: "سواال-بله يا خير" },
    { id: "TEXT", title: "متن نمايشي" },
    { id: "UPLOAD", title: "دريافت فايل از كاربر" },
];
export const freightUnitStatuses = ["DRAFT", "PLAN", "CMPL", "DELIVERED", "IN-TRANSIT", "ON-HOLD", "CANCEL"];

export const SectionTypes = [
    { id: "AUTH", title: "احراز هويت اشخاص حقوقي" },
    { id: "DOCS", title: "مستندات و سوالات مزايده" },
    { id: "TOC", title: "قوانين و مقررات" },
];

export const AuctionMethodTypes = [
    { id: "CASH", title: "نقدي" },
    { id: "CREDIT", title: "اسناد تضمين" },
    { id: "CHEQUE", title: "اعتباري" },
];

/*
    SELECT '{id:"'+Id+'", title:"'+Title+'" },'
    FROM [Logistics].[PUR].[BusinessTypes]
    ORDER BY SortOrder
 */
export const allBusinessTypes = [
    { id: "contractor-consultant", title: "پیمانکار / مشاور" },
    { id: "distributor-wholesaler", title: "توزیع کننده / عمده فروش" },
    { id: "government-public-agency", title: "دولت / سازمان دولتی" },
    { id: "manufacturer", title: "سازنده" },
    { id: "retailer", title: "خرده فروش" },
    { id: "sales-agent-manufacturers-representative", title: "نماینده فروش / نماینده سازنده" },
    { id: "service-provider", title: "ارائه دهنده خدمات" },
    { id: "transportation-logistics", title: "حمل و نقل0" },
    { id: "other", title: "سایر" },
];

export const conditionEditTypes = [
    { id: "AMUNT", title: "مبلغ" },
    { id: "CMB", title: "انتخاب از ليست" },
    { id: "MEMO", title: "متن چند خطي" },
    { id: "PRCNT", title: "درصد" },
    { id: "QUNT", title: "مقدار" },
    { id: "TXT", title: "متن تك خطي" },
];

/*
    SELECT '{id:"'+Id+'", title:"'+Title+'" },'
    FROM [Logistics].[PUR].[IndustrySectors]
    ORDER BY SortOrder
*/
export const industrySectors = [
    { id: "aerospace-defense", title: "هوافضا و دفاع" },
    { id: "agricultrue-mining", title: "کشاورزی و معدن" },
    { id: "automotive", title: "خودرو" },
    { id: "building-materials-clay-glass", title: "مصالح ساختمانی، شیشه سفالی" },
    { id: "chemical", title: "شیمیایی" },
    { id: "consumer-products", title: "محصولات مصرفی" },
    { id: "engineering-construction", title: "مهندسی و ساخت و ساز" },
    { id: "financial-services", title: "خدمات مالی" },
    { id: "forest-products-paper", title: "محصولات جنگلی و کاغذ" },
    { id: "furniture", title: "مبلمان" },
    { id: "healthcare", title: "مراقبت های بهداشتی" },
    { id: "high-tech-electronic", title: "فناوری پیشرفته و الکترونیک" },
    { id: "higher-education-research", title: "آموزش عالی و تحقیقات" },
    { id: "hospitality", title: "مهمان نوازي / هتلداري / پذيرايي" },
    { id: "industrial-machinery-components", title: "ماشین آلات و قطعات صنعتی" },
    { id: "insurance", title: "بیمه" },
    { id: "media", title: "رسانه ها" },
    { id: "metal-products", title: "محصولات فلزی" },
    { id: "oil-gas", title: "نفت و گاز" },
    { id: "pharmaceuticals", title: "داروسازی" },
    { id: "primary-metal-steel", title: "فلز و فولاد اولیه" },
    { id: "public-sector", title: "بخش دولتي" },
    { id: "retail", title: "خرده فروشی" },
    { id: "service-provider", title: "ارائه دهنده خدمات" },
    { id: "telecomunication", title: "مخابرات" },
    { id: "textiles-production", title: "تولید منسوجات" },
    { id: "transportation-storage", title: "حمل و نقل و انبار" },
    { id: "utilities", title: "خدمات رفاهی" },
    { id: "wholesale-distribution", title: "توزیع عمده فروشی" },
    { id: "other", title: "ساير" },
];

/*
    SELECT '{id:"'+Id+'", title:"'+Id+'" },'
    FROM [Logistics].[PUR].[DocumentCommodityStatuses]
 */

export const approvementStatuses = [
    { id: "NEW", title: "New" },
    { id: "APRV", title: "Approved" },
    { id: "RJCT", title: "Rejected" },
    { id: "CANCEL", title: "CANCEL" },
];

export const projectCommodityStatuses = [
    { id: "DRFT", title: "draft" },
    { id: "QUAL", title: "qualified" },
    // { id: "PREFER", title: "preferred" },
    { id: "RJCT", title: "rejected" },
];

export const documentCommodityStatuses = [
    { id: "DRFT", title: "DRFT" },
    { id: "PREFER", title: "PREFER" },
    { id: "QUAL", title: "QUAL" },
];

/*
SELECT '{id:"'+Id+'", title:"'+Title+'" },'
FROM [Logistics].[PUR].[EventContentResponseReasons]
*/

export const eventContentResponseReasons = [
    { id: "DISC", title: "Discontinue" },
    { id: "FULL", title: "Full Capacity" },
    { id: "OTHR", title: "Other" },
];

/*
    SELECT '{id:"'+Id+'", title:"'+Id+'" },'
    FROM [Logistics].[PUR].[PurReqStatuses]
 */
export const SR_STATUSES = {
    NEW: "NEW",
    SRC: "SRC",
    CANCEL: "CANCEL",
    CMPL: "CMPL",
    RJCT: "RJCT",
};

export const smsCodes = [
    {
        code: "RELATION-STATUS",
        title: "وضعیت ارتباط کاری",
    },
    {
        code: "ACCOUNT-REGISTER",
        title: "ایجاد حساب کاربری",
    },
    {
        code: "USER-INVITATION",
        title: "ارسال دعوتنامه کاربر جدید",
    },

    {
        code: "USER-REFERRAL",
        title: "دعوت به ثبت نام",
    },

    {
        code: "EXISTING_USER_INVITATION",
        title: "ارسال دعوتنامه کاربر موجود",
    },

    {
        code: "SELLER-ORDER-CONFIRM-NOTIF",
        title: "اطلاع رسانی ایجاد سفارش",
    },
    {
        code: "AUC-WINNER",
        title: "برنده مزایده",
    },

    {
        code: "REGREQ-ERP-NUMBER-ASSIGNED",
        title: "تخصیص کد فروشنده",
    },

    {
        code: "REGREQ-APPROVED",
        title: "تایید درخواست ثبت نام",
    },

    {
        code: "REGREQ-REJECTED",
        title: "رد درخواست ثبت نام",
    },

    {
        code: "REGREQ-PENDING",
        title: "عودت درخواست ثبت نام",
    },

    {
        code: "ERROR-REPORT",
        title: "گزارش خطا",
    },

    { code: "GRADE", title: "امتیاز به رویداد" },
    { code: "LOOSER", title: "بازنده در رویداد" },
    { code: "AWARD", title: "برنده در رویداد" },
];

/*
    SELECT '["'+Id+'"] : {title:"'+Title+'", maxSize: '+cast(MaxSize as varchar) + ', validTypes:"'+ ValidTypes+'", count:'+CAST(count as varchar)+' }, '
    FROM PUR.ZAttachmentTypes
*/
export const attachmenTypes = {
    ["address-image"]: { title: "تصوير آدرس", maxSize: 10240, validTypes: "jpg,jpeg,png", count: 0 },
    ["attachment"]: { title: "ضمیمه", maxSize: 10240, validTypes: "JPG , JPEG , PNG", count: 1 },
    ["auction-announcement"]: { title: "آگهي برگزاري مزايده", maxSize: 10240, validTypes: "pdf", count: 1 },
    ["auction-content-file"]: {
        title: "فايل پيوست محتواي مزايده",
        maxSize: 10240,
        validTypes: "pdf,jpg,jpeg,png,doc,docx,txt,xlsx,xls",
        count: 1,
    },
    ["auction-content"]: { title: "پيوست محتوا", maxSize: 10240, validTypes: "pdf,jpg,jpeg,png,docx,txt,pdf", count: 1 },
    ["auction-location"]: { title: "تصوير نقشه برگزاري مزايد", maxSize: 10240, validTypes: "jpg,png", count: 1 },
    ["auction-logo"]: { title: "لوگوي مزايده", maxSize: 10240, validTypes: "jpg,png", count: 1 },
    ["auction-pack"]: { title: "پك مزايده", maxSize: 10240, validTypes: "jpg,jpeg,png", count: 5 },
    ["auction-ticket"]: { title: "فايل پيوست تيكت مزايده", maxSize: 10240, validTypes: "", count: 0 },
    ["chat-message"]: { title: "ضميمه پيام", maxSize: 10240, validTypes: "pdf,jpg,jpeg,png,doc,docx,txt,xlsx,xls", count: 1 },
    ["company-banner"]: { title: "بنر شركت", maxSize: 10240, validTypes: "jpg,png", count: 0 },
    ["company-business-card"]: { title: "کارت ویزیت شرکت", maxSize: 10240, validTypes: "image", count: 2 },
    ["company-doc"]: { title: "اسناد مالكيت", maxSize: 10240, validTypes: "image", count: 1 },
    ["company-fin"]: { title: "صورتهاي مالي", maxSize: 10240, validTypes: "pdf", count: 1 },
    ["company-id-card"]: { title: "كارت ملي مديرعامل", maxSize: 10240, validTypes: "jpg,png", count: 1 },
    ["company-logo"]: { title: "لوگو شركت", maxSize: 10240, validTypes: "jpg,png", count: 0 },
    ["company-rasmi"]: { title: "روزنامه رسمي تاسيس", maxSize: 10240, validTypes: "jpg,png", count: 1 },
    ["company-stamp"]: { title: "مهر شركت", maxSize: 10240, validTypes: "jpg,png", count: 1 },
    ["company-tac-attachment"]: { title: "تعهدنامه", maxSize: 10240, validTypes: "pdf", count: 1 },
    ["content"]: { title: "محتوا", maxSize: 10240, validTypes: "", count: 0 },
    ["discovery-item"]: { title: "مشخصات فني", maxSize: 10240, validTypes: "pdf,jpg,jpeg,png,doc,docx,txt,xlsx,xls,zip,rar", count: 1 },
    ["document-discovery"]: { title: "Document Discovery", maxSize: 10240, validTypes: "", count: 5 },
    ["document-message"]: { title: "ضميمه پيام", maxSize: 10240, validTypes: "pdf,jpg,jpeg,png,doc,docx,txt,xlsx,xls", count: 1 },
    ["face-picture"]: { title: "تصوير مدير", maxSize: 10240, validTypes: "jpg,png", count: 1 },
    ["file"]: { title: "فايل", maxSize: 10240, validTypes: "", count: 5 },
    ["id-cart-first"]: { title: "صفحه اول كارت ملي", maxSize: 10240, validTypes: "jpg,png", count: 1 },
    ["id-cart-second"]: { title: "صفحه دوم كارت ملي", maxSize: 10240, validTypes: "jpg,png", count: 1 },
    ["logo"]: { title: "لوگو", maxSize: 10240, validTypes: "jpg,png", count: 1 },
    ["meeting"]: { title: "صورت جلسه", maxSize: 10240, validTypes: "pdf,jpg,jpeg,png,doc,docx,txt,xlsx,xls", count: 3 },
    ["order-confirm"]: { title: "Order Confirm", maxSize: 10240, validTypes: "pdf,jpg,jpeg,png,doc,docx,txt,xlsx,xls", count: 5 },
    ["prj-doc"]: { title: "سند پروژه", maxSize: 10240, validTypes: "", count: 1 },
    ["profile-image"]: { title: "تصوير پروفايل كاربر", maxSize: 10240, validTypes: "jpg,png", count: 0 },
    ["project-logo"]: { title: "لوگو پروژه", maxSize: 10240, validTypes: "jpg,png", count: 1 },
    ["reg-req-image"]: { title: "تصویر درخواست ثبت نام", maxSize: 10240, validTypes: "jpg,png", count: 0 },
    ["reg-spq"]: { title: "پرسشنامه ثبت نام", maxSize: 10240, validTypes: "pdf,jpg,jpeg,png,doc,docx,txt,xlsx,xls,zip,rar", count: 0 },
    ["request"]: { title: "Sourcing Request", maxSize: 10240, validTypes: "", count: 5 },
    ["research-posting"]: { title: "Research Posting", maxSize: 10240, validTypes: "", count: 0 },
    ["response-attachment"]: { title: "Response Attachment", maxSize: 10240, validTypes: "", count: 0 },
    ["rfx-comment"]: { title: "RFX Comment", maxSize: 10240, validTypes: "pdf,jpg,jpeg,png,docx,txt,pdf", count: 0 },
    ["rfx-content-response"]: {
        title: "RFX Content Response",
        maxSize: 10240,
        validTypes: "pdf,jpg,jpeg,png,doc,docx,txt,xlsx,xls,zip,rar",
        count: 0,
    },
    ["shipment"]: { title: "اعلامیه حمل", maxSize: 10240, validTypes: "pdf,jpg,jpeg,png,doc,docx,txt,xlsx,xls", count: 1 },
    ["signature-image"]: { title: "تصوير نمونه امضاء", maxSize: 10240, validTypes: "jpg,png", count: 1 },
    ["signed-order"]: { title: "قرارداد امضاء شده", maxSize: 10240, validTypes: "pdf", count: 0 },
    ["vendor-eval-info"]: {
        title: "اطلاعات فني فروشنده",
        maxSize: 10240,
        validTypes: "pdf,jpg,jpeg,png,doc,docx,txt,xlsx,xls,zip,rar",
        count: 1,
    },
};

export const authenticationStatuses = [
    { id: "NEW", title: "جديد" },
    { id: "IN-PROC", title: "در حال بررسي" },
    { id: "APPROVED", title: "تاييد شده" },
    { id: "REJECTED", title: "رد شده" },
];

export const DocumentTypes = {
    PUWS: "PUWS",
    KN: "KN",
    PR: "PR",
    EVENT: "EVENT",
    DISC: "DISC",
    SUPWS: "SUPWS",
    CNF: "CNF",
};

export const Decorations = {
    INFO: "INFO",
    SUCCESS: "SUCCESS",
    ERROR: "ERROR",
    WARNING: "WARNING",
};

export const MessageStatuses = {
    COMPL: "COMPL",
    NEW: "NEW",
    READ: "READ",
};

export const EventTypes = {
    RFI: "RFI",
    RFP: "RFP",
    SURV: "SURV",
    AUC: "AUC",
};

export const deliveryTerms = [
    { id: "EXW", title: "ex-works-or-ex-warehouse" },
    { id: "FCA", title: "free-carrier" },
    { id: "FAS", title: "free-alongside-ship" },
    { id: "FOB", title: "free-on-board" },
    { id: "CFR", title: "cost-and-freight" },
    { id: "CIF", title: "cost-insurance-and-freight" },
    { id: "CPT", title: "carriage-paid-to" },
    { id: "CIP", title: "carriage-and-insurance-paid-to" },
    { id: "DAP", title: "delivered-at-place" },
    { id: "DPU", title: "delivered-at-place-unloaded" },
    { id: "DDP", title: "delivered-duty-paid" },
];

export const itemCategories = [
    { id: "M", title: "Material" },
    { id: "P", title: "Palette" },
    { id: "S", title: "Service" },
];

export const orderCategories = [
    { id: "A", title: "Schedule Agreement" },
    { id: "C", title: "Contract" },
    { id: "O", title: "Order" },
];

/*
  SELECT '{id:"'+Id+'", title:"'+Title+'" },'
    FROM [Logistics].[PUR].[ShippingMethods]
 */
export const shipingMethods = [
    { id: "FLY", title: "fly" },
    { id: "RAIL", title: "rail" },
    { id: "ROAD", title: "road" },
    { id: "SEA", title: "sea" },
];

/*
  SELECT '{id:"'+Id+'", title:"'+Title+'" },'
    FROM [Logistics].[PUR].[TruckTypes]
 */
export const truckTypes = [
    { id: "CONT", title: "container" },
    { id: "PICK", title: "pickup" },
    { id: "TRAI", title: "trailer" },
    { id: "TRUCK", title: "truck" },
];

/*
  SELECT '{id:"'+Id+'", title:"'+Title+'" },'
    FROM [Logistics].[PUR].[ZAuthenticationMethods]
 */

export const authenticationMethods = [
    { id: "Password_Email", title: "password+email" },
    { id: "Password_Phone", title: "password+phone" },
];

/*
  SELECT '{id:"'+Id+'", title:"'+Title+'" },'
    FROM [Logistics].[PUR].[PaymentMethods]
 */

export const paymentMethods = [
    { id: "ACC", title: "the-shipping-charges-are-charged-to-an-account" },
    { id: "COLLECT", title: "the-consignee-pays-the-freight-charges" },
    {
        id: "MIXED",
        title: "the-shipment-is-partially-collected-and-partially-prepaid",
    },
    {
        id: "SELLER",
        title: "the-seller-pays-the-shipping-fee-to-the-shipping-company-before-shipping",
    },
    {
        id: "OTHER",
        title: "any-shipping-payment-method-or-third-party-shipping-fee-will-pay-the-shipping-fee.-when-you-select-this-option,-you-can-also-enter-a-description.",
    },
];

export const notificationStatus = [
    { id: "READY", title: "READY" },
    { id: "APRV", title: "APRV" },
    { id: "CLOSED", title: "CLOSED" },
    // { id: "NOTIFY", title: "NOTIFY" },
    { id: "NOTIFY", title: "NOTIFY" },
    { id: "REFERBACK", title: "REFERBACK" },
    { id: "RJCT", title: "RJCT" },
    { id: "NEW", title: "NEW" },
    { id: "VISITED", title: "VISITED" },
];

export const notificationTypes = [
    { id: "NOTIFY", title: "NOTIFY" },
    { id: "TASK", title: "TASK" },
    { id: "SMS", title: "sms" },
];

export const languages = [
    {
        id: "fa",
        title: "فارسی",
        country_code: "ir",
        dir: "rtl",
    },
    {
        id: "en",
        title: "English",
        country_code: "gb",
    },
];

export const twoFactorAutenticatorMethodes = [
    {
        id: "authenticator",
        title: "authenticator-app-(totp)",
        descrption:
            "in-this-method,-by-using-a-dynamic-password-generator-software-such-as-google-authenticator,-you-can-enter-the-system-by-entering-the-password-generated-in-the-software.",
    },
    {
        id: "sms",
        title: "sms",
        descrption: "in-this-method,-a-text-message-containing-a-validation-code-will-be-sent-to-your-mobile-number.",
        countryUsage: "ir",
    },
    // {
    //     id: "email",
    //     title: "email",
    //     descrption: "in-this-method,-a-text-message-containing-a-validation-code-will-be-sent-to-your-email.",
    // },
    // {
    //     id: "token",
    //     title: "token",
    //     descrption: "in-this-method,-a-hardware-token-containing-your-identity-information-is-used-to-log-into-the-system.",
    //     countryUsage: "ir",
    // },
];

/*
// SELECT '{ id: "'+Id+'", title:"'+Title+'", maxSize: '+cast(MaxSize as varchar) + ', validTypes:"'+ ValidTypes+'", count:'+CAST(count as varchar)+' },'
// FROM PUR.ZAttachmentTypes

export const attachmenTypes = [
    { id: "attachment", title: "ضمیمه", maxSize: 1024, validTypes: "JPG , JPEG , PNG", count: 1 },
    { id: "company-business-card", title: "کارت ویزیت شرکت", maxSize: 1024, validTypes: "image", count: 2 },
    { id: "company-doc", title: "اسناد مالكيت", maxSize: 3072, validTypes: "image", count: 1 },
    { id: "company-fin", title: "صورتهاي مالي", maxSize: 3072, validTypes: "pdf", count: 1 },
    { id: "company-id-card", title: "كارت ملي مديرعامل", maxSize: 2048, validTypes: "jpg,png", count: 1 },
    { id: "company-logo", title: "لوگو شركت", maxSize: 1024, validTypes: "jpg,png", count: 1 },
    { id: "company-rasmi", title: "روزنامه رسمي تاسيس", maxSize: 2048, validTypes: "jpg,png", count: 1 },
    { id: "company-stamp", title: "مهر شركت", maxSize: 2048, validTypes: "jpg,png", count: 1 },
    { id: "Content", title: "محتوا", maxSize: 4096, validTypes: "pdf,jpg,jpeg,png,docx,txt", count: 3 },
    { id: "face-picture", title: "تصوير مدير", maxSize: 1024, validTypes: "jpg,png", count: 1 },
    { id: "file", title: "فايل", maxSize: 1024, validTypes: "", count: 5 },
    { id: "id-cart-first", title: "صفحه اول كارت ملي", maxSize: 1024, validTypes: "jpg,png", count: 1 },
    { id: "id-cart-second", title: "صفحه دوم كارت ملي", maxSize: 1024, validTypes: "jpg,png", count: 1 },
    { id: "logo", title: "لوگو", maxSize: 2048, validTypes: "jpg,png", count: 1 },
    { id: "prj-doc", title: "سند پروژه", maxSize: 10240, validTypes: "", count: 1 },
    { id: "profile-image", title: "تصوير پروفايل كاربر", maxSize: 1024, validTypes: "image", count: 1 },
    { id: "response-attachment", title: "Response Attachment", maxSize: 2048, validTypes: "", count: 1 },
];
*/

// SELECT '{ id: "'+Id+'", title:"'+Title+'"},' FROM pur.ContentVisibilities
export const contentVisibilities = [
    { id: "ACPT", title: "after-terms-are-accpeted" },
    { id: "ALL", title: "all-times" },
    { id: "HIDDEN", title: "hidden" },
];

// SELECT '{ id: "'+Id+'", title:"'+Title+'"},' FROM pur.AnswerTypes
export const answerTypes = [
    { id: "CMB", title: "انتخاب از ليست" },
    { id: "DATE", title: "تاريخ شمسي" },
    { id: "MEMO", title: "متن چند خطي" },
    { id: "NUM", title: "عدد صحيح" },
    { id: "TXT", title: "متن تك خطي" },
    { id: "UPL", title: "آپلود" },
    { id: "YESNO", title: "Yes / No" },
    { id: "ADR", title: "آدرس" },
    { id: "EMAIL", title: "ایمیل" },
    { id: "SITE", title: "سایت" },
    { id: "PHONE", title: "Tel1,Tel2" },
    { id: "BANK", title: "اطلاعات بانک" },
];
