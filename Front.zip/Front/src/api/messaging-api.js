import { api } from "./api";
import { apiConfig } from "./config";

export const messagingApi = {
    initProfileChat: (dto) => api.call("post", `${apiConfig.messagingUrl}/init-profile-chat`, dto),
    initPeerToPeerChat: (dto) => api.call("post", `${apiConfig.messagingUrl}/init-peer-to-peer-chat`, dto),
    createSavedMessage: () => api.call("post", `${apiConfig.messagingUrl}/create-saved-message`),
    initAdminMessage: () => api.call("post", `${apiConfig.messagingUrl}/init-admin-message`),
    createEventChat: (documentSerial) =>
        api.call("post", `${apiConfig.eventMessagingUrl}/create-chat-by-seller?documentSerial=${documentSerial}`),
    getCurrentUserCompanyType: (documentSerial) =>
        api.call("post", `${apiConfig.eventMessagingUrl}/get-current-user-company-type?documentSerial=${documentSerial}`),
};
