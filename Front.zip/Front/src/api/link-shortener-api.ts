import { api } from "./api";
import { apiConfig } from "./config";

export const LinkShortenerApi = {
    initShortLink: (serial: string) => api.call("post", `${apiConfig.linkShortenerUrl}/init-short-link?serial=${serial}`),
};
