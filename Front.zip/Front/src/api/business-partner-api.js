import { api } from "./api";
import { apiConfig } from "./config";

export const businessPartnerApi = {
    getPartners: () => api.call("post", apiConfig.businessPartnerUrl + `/get-business-partners`),
};
