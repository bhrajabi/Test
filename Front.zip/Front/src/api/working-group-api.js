import { api } from "./api";
import { apiConfig } from "./config";

export const workingGroupApi = {
    initWorkingGroups: (companyId) => api.call("post", `${apiConfig.workingGroupUrl}/init-working-groups?companyId=${companyId}`),

    getWorkingGroups: (companyId) => api.call("post", `${apiConfig.workingGroupUrl}/get-working-groups?companyId=${companyId}`),

    getWorkingGroupsAndExpertsOfThem: (companyId) =>
        api.call("post", `${apiConfig.workingGroupUrl}/get-working-groups-and-members?companyId=${companyId}`),

    saveWorkingGroup: (companyId, data) => api.call("post", `${apiConfig.workingGroupUrl}/save-working-group?companyId=${companyId}`, data),

    deleteWorkingGroup: (companyId, serial) =>
        api.call("post", `${apiConfig.workingGroupUrl}/delete-working-group?companyId=${companyId}&serial=${serial}`),

    saveWorkingGroupMember: (companyId, serial, user) =>
        api.call("post", `${apiConfig.workingGroupUrl}/save-working-group-member?companyId=${companyId}&serial=${serial}`, user),

    deleteWorkingGroupMember: (companyId, serial, user) =>
        api.call("post", `${apiConfig.workingGroupUrl}/delete-working-group-member?companyId=${companyId}&serial=${serial}`, user),

    getProjectWorkingGroup: (projectSerial) =>
        api.call("post", `${apiConfig.workingGroupUrl}/get-project-working-group?projectSerial=${projectSerial}`),

    getMyWorkingGroups: () => api.call("post", `${apiConfig.workingGroupUrl}/get-my-working-groups`),
};
