import { api } from "./api";
import { apiConfig } from "./config";

export const aprocApi = {
    initAproc: () => api.call("post", `${apiConfig.aprocUrl}/init-aproc`),

    //aprocList: () => api.call("post", `${apiConfig.aprocUrl}/get-aproc-list`),

    addAProc: (data) => api.call("post", apiConfig.aprocUrl + "/add-aproc", data),

    editProcess: (data, cloneMode) => api.call("post", `${apiConfig.aprocUrl}/save-aproc?clone=${cloneMode ? "1" : "0"}`, data),

    //
    initAprocLevel: (serial) => api.call("post", `${apiConfig.aprocUrl}/init-aproc-level?serial=${serial}`),
    saveLevel: (procSerial, data) => api.call("post", apiConfig.aprocUrl + "/save-level?serial=" + procSerial, data),
    deleteLevel: (procSerial) => api.call("post", apiConfig.aprocUrl + "/delete-level?serial=" + procSerial),

    addUser: (levelSerial, userName) =>
        api.call("post", `${apiConfig.aprocUrl}/add-level-user?levelSerial=${levelSerial}&userName=${userName}`),

    deleteUser: (levelSerial, userName) =>
        api.call("post", `${apiConfig.aprocUrl}/delete-level-user?levelSerial=${levelSerial}&userName=${userName}`),

    //setUserActive: (levelSerial, userName, active) =>
    //    api.call("post", `${apiConfig.aprocUrl}/set-user-active?levelSerial=${levelSerial}&userName=${userName}&active=${active ? 1 : 0}`),

    deleteProcess: (serial) => api.call("post", `${apiConfig.aprocUrl}/delete-aproc?serial=${serial}`),

    //inbox
    inboxList: (newItems, topRows = 10, archived) =>
        api.call("post", `${apiConfig.aprocUrl}/inbox-list?newItems=${newItems}&topRows=${topRows}&archived=${archived}`),

    taskFlow: (taskSerial, levelSerial) =>
        api.call("post", `${apiConfig.aprocUrl}/task-flow?taskSerial=${taskSerial}&levelSerial=${levelSerial}`),

    actionOnInbox: (data) => api.call("post", `${apiConfig.aprocUrl}/action-on-inbox`, data),

    markInboxAsVisited: (notificationSerial) =>
        api.call("post", `${apiConfig.aprocUrl}/mark-inbox-as-visited?inboxSerial=${notificationSerial}`),

    nextLevelInfo: (taskSerial) => api.call("post", `${apiConfig.aprocUrl}/get-next-level-info?taskSerial=${taskSerial}`),

    archiveMessage: (notificationSerial) => api.call("post", `${apiConfig.aprocUrl}/archive-inbox?inboxSerial=${notificationSerial}`),

    // -- new apies
    intStartAproc: (aprocSerial, action, objectKey, customizedParameter = "") =>
        api.call(
            "post",
            `${apiConfig.aprocUrl}/init-start-aproc?aprocSerial=${aprocSerial}&action=${action}
        &objectKey=${objectKey}&customizedParameter=${customizedParameter}`
        ),

    //aprocFlow: (aprocSerial) => api.call("post", `${apiConfig.aprocUrl}/inbox-flow-by-aproc?aprocSerial=${aprocSerial}`),

    start: (data) => api.call("post", `${apiConfig.aprocUrl}/start`, data),

    action: (data) => api.call("post", `${apiConfig.notificationUrl}/action`, data),
};
