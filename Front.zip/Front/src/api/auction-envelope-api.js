import { api } from "./api";
import { apiConfig } from "./config";

export const auctionEnvelopeApi = {
    initOpenEnvelope: (auctionId) => api.call("post", `${apiConfig.auctionEnvelopeUrl}/init-auction-open-envelope?auctionId=${auctionId}`),
    getOpenEnvelopeUsers: (auctionId) => api.call("post", `${apiConfig.auctionEnvelopeUrl}/get-open-envelope-users?auctionId=${auctionId}`),
    openEnvelope: (auctionId, meetingSerial, data) =>
        api.call(
            "post",
            `${apiConfig.auctionEnvelopeUrl}/open-auction-envelope?auctionId=${auctionId}&meetingSerial=${meetingSerial}`,
            data
        ),
};
