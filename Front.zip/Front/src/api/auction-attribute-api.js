import { api } from "./api";
import { apiConfig } from "./config";

export const auctionAttributeApi = {
    initAuctionAttribute: (projectSerial) =>
        api.call("post", `${apiConfig.auctionAttributeUrl}/init-auction-attribute?projectSerial=${projectSerial}`),

    saveAuctionAttribute: (data) => api.call("post", `${apiConfig.auctionAttributeUrl}/save-auction-attribute`, data),

    deleteAuctionAttribute: (projectSerial, data) =>
        api.call("post", `${apiConfig.auctionAttributeUrl}/delete-auction-attribute?projectSerial=${projectSerial}`, data),
};
