import { notify } from "../components/basic/notify";
import { translate } from "../components/basic/text";
import { api } from "./api";
import { apiConfig } from "./config";

const MinFileSize = 0;
const MaxFileSize = 5 * 1024 * 1024;

export const auctionAttachmentApi = {
    // getImage: (url) => {
    //     const withCredentials = true;
    //     const headers = { authorization: "Bearer " + api.getToken() };
    //     return axios.get(url, { responseType: "arraybuffer", withCredentials, headers });
    // },

    download: (url) => {
        api.call("post", url, null)
            .then((reqId) => {
                window.location.href = apiConfig.auctionAttachmentUrl + "/download?id=" + reqId;
            })
            .catch(notify.error);
    },

    attach: (url, file, params) => {
        const f = file.files[0];
        if (f.size < MinFileSize) {
            setTimeout(() => (file.value = ""), 0);
            return Promise.reject(translate("file-is-empty"));
        }
        if (f.size > MaxFileSize) {
            setTimeout(() => (file.value = ""), 0);
            return Promise.reject(translate("file-is-too-big"));
        }
        const form_data = new FormData();
        form_data.append("file", f);

        if (params) {
            for (const p in params) form_data.append(p, params[p]);
        }

        setTimeout(() => (file.value = ""), 0);

        return api.call("post", url, form_data, { "Content-Type": "multipart/form-data" });
    },
};
