import { IkcoIpgRequestPaymentDTO } from "../pages/home/dashboard/ikco-ipg/ikco-ipg-test-payment/types/ipg-request-payment-dto";
import { IkcoIPGVerifyPaymentDTO } from "../pages/home/dashboard/ikco-ipg/ikco-ipg-test-payment/types/ipg-verify-payment-dto";
import { api } from "./api";
import { apiConfig } from "./config";

export const ikcoIpgTestPaymentApi = {
    initTestPayment: () => api.call("post", `${apiConfig.IKCOIpgTestPaymentUrl}/init-test-payment`),
    getToken: (model: IkcoIpgRequestPaymentDTO) => api.call("post", `${apiConfig.IKCOIpgTestPaymentUrl}/get-token`, model),
    verifyTransaction: (model: IkcoIPGVerifyPaymentDTO) => api.call("post", `${apiConfig.IKCOIpgTestPaymentUrl}/verify-transaction`, model),
    inquiryTransaction: (transactionSerial: number) =>
        api.call("post", `${apiConfig.IKCOIpgTestPaymentUrl}/inquiry-transaction?transactionSerial=${transactionSerial}`),
    GetTransactionByRequestId: (requestId: string, ipgId: number) =>
        api.call("post", `${apiConfig.IKCOIpgTestPaymentUrl}/get-transaction-by-requestId?requestId=${requestId}&ipgId=${ipgId}`),
    //verify: () => api.call("post", `${apiConfig.IKCOIpgTestPaymentUrl}/request-verify`),
};
