import { api } from "./api";
import { apiConfig } from "./config";

export const publicCompanyApi = {
    initPublicCompanyProfile: (companyId) => api.call("post", `${apiConfig.publicCompanyUrl}/init-company-profile?companyId=${companyId}`),
    initSearch: () => api.call("post", `${apiConfig.publicCompanyUrl}/init-search`),
    searchCompany: (data) => api.call("post", `${apiConfig.publicCompanyUrl}/search`, data),
};
