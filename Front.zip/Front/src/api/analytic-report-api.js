import { api } from "./api";
import { apiConfig } from "./config";

export const analyticReportApi = {
    initReport: () => api.call("post", apiConfig.reportUrl + "/init-report"),
    getCycleTimesByWorkingGroup: (serial) => api.call("post", apiConfig.reportUrl + `/get-cycle-times-by-working-group?serial=${serial}`),
    saveMyWidget: (reportWidgets) => api.call("post", apiConfig.reportUrl + "/update-my-widgets-order", reportWidgets),

    initSmReport: () => api.call("post", apiConfig.reportUrl + "/init-sm-report"),
    initSourcingReport: () => api.call("post", `${apiConfig.reportUrl}/init-sourcing-report`),
    initSourcingReportByWorkingGroup: (ws) => api.call("post", `${apiConfig.reportUrl}/init-sourcing-report-by-working-group?ws=${ws}`),
};
