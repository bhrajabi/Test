import { code } from "../components/basic/code";
import { api } from "./api";
import { apiConfig } from "./config";

export const logsApi = {
    logWafError: (blockedRequestInfo) =>
        api.callAxios("post", apiConfig.logsUrl + "/log-blocked-request", {
            data: code.jsonBeautifier(blockedRequestInfo),
        }),

    healthError: (data) => api.call("post", apiConfig.logsUrl + "/health-error", data),

    getSystemLogs: (logSource, values) => api.call("post", apiConfig.logsUrl + `/get-sys-logs?logSource=${logSource}`, values),
    getLogsGroupByMessage: (logSource, values) =>
        api.call("post", apiConfig.logsUrl + `/get-logs-group-by-message?logSource=${logSource}`, values),
    getLogsGroupByUrl: (logSource, values) => api.call("post", apiConfig.logsUrl + `/get-logs-group-by-url?logSource=${logSource}`, values),

    getSystemLog: (serial, logSource) => api.call("post", apiConfig.logsUrl + `/get-sys-log?serial=${serial}&logSource=${logSource}`),

    getIPGSystemLogs: (values) => api.call("post", apiConfig.logsUrl + "/get-ipg-sys-logs", values),
    getIpgSystemLog: (serial) => api.call("post", apiConfig.logsUrl + `/get-ipg-sys-log?serial=${serial}`),
    updateSysLogInfo: (logSource, data) => api.call("post", apiConfig.logsUrl + `/update-sys-log-info?logSource=${logSource}`, data),

    getMostErrorLog: () => api.call("post", apiConfig.logsUrl + `/get-most-sys-logs`),

    getUserLogs: (values) => api.call("post", apiConfig.logsUrl + `/get-user-logs`, values),

    initJobs: (values) => api.call("post", apiConfig.logsUrl + `/init-jobs`, values),

    getVisitLogs: (values) => api.call("post", apiConfig.logsUrl + `/get-visit-logs`, values),

    initSourcingReport: (data) => api.call("post", `${apiConfig.sourcingReports}/material-report`, data),
    getCompanies: (data) => api.call("post", `${apiConfig.sourcingReports}/material-report-company`, data),
};
