import { useApi } from "../pages/seller/home/api/use-api-call";

export const useInitRespondApi = () => useApi<InitRespondDTO>("/rfx/init-respond?documentSerial={documentSerial}&sellerId={sellerId}", {});

export const useCancelDeclinedEventApi = () =>
    useApi<{ responseStatusId: string; isResponseDeclined: boolean }>(
        "/rfx/cancel-declined-event?documentSerial={documentSerial}&sellerId={sellerId}",
        { persist: false }
    );

export const useDeclinedEventApi = () =>
    useApi<{ responseStatusId: string; isResponseDeclined: boolean }>(
        "/rfx/decline-event?documentSerial={documentSerial}&sellerId={sellerId}&declinReason={declinReason}",
        { persist: false }
    );

export const useAcceptEventApi = () =>
    useApi<{ responseStatusId: string; isResponseDeclined: boolean }>(
        "/rfx/accept-event?documentSerial={documentSerial}&sellerId={sellerId}&currencyId={currencyId}",
        { persist: false }
    );

export const useDeleteAlternativeApi = () =>
    useApi<ResponseAlternativeForRFXDTO[]>(
        "/rfx/delete-alternative?documentSerial={documentSerial}&sellerId={sellerId}&alternativeId={alternativeId}",
        { persist: false }
    );

export const useSubmitSelectionsApi = () =>
    useApi<{ selections: ResponseSelectionDTO[] }>("/rfx/submit-selections?documentSerial={documentSerial}&sellerId={sellerId}", {
        persist: false,
    });

export const useSubmitResponseApi = () =>
    useApi<SubmitResultDTO>("/rfx/submit-response?documentSerial={documentSerial}&sellerId={sellerId}", {
        persist: false,
    });

export type InitRespondDTO = {
    now: Date;
    rules: EventRuleDTO;
    contents: DocumentContentsDTO[];
    alternatives: ResponseAlternativeForRFXDTO[];
    scenarioItems: any[];
    participantCount: number;
    alreadySubmited: boolean;
    document: EventDocumentDTO;
    selections: ResponseSelectionDTO[];
    response: DocumentSupplierDTO;
    terms: ContentTermDTO[];
    conditions: ConditionDTO[];
    bidHistories: any[];
    allowSubmit: boolean;
    sellerName: string;
    expertName: string;
    expertPhoneNumber: string;
};

export type EventDocumentDTO = {
    serial: number;
    statusId: string;
    number: string;
    title: string;
    currencyId: string;
    eventTypeId: string;
};

export type ResponseSelectionDTO = {
    contentSerial: number;
    isSelected: boolean;
    rejectResonId: string | null | undefined;
};

export type DocumentSupplierDTO = {
    participantName: string;
    sellerId: number;
    isResponseDeclined: boolean;
    responseDeclinReason: string;
    responseStatusId: string;
    projectSerial: number;
    isInvitationApproved: boolean;
    isInvitationLocked: boolean;
    invitationComment: string;
    buyerCanSubmitResponse: boolean;
    sellerUnreadMessageCount: number;
    createdBy: string;
    createdAt: Date;
    lastEventDate: Date;
    participantFullName: string;
    companyName: string;
    responseCurrencyId: string;
    round: number;
    responseDate: Date;
};

export type ContentTermDTO = {
    id: number;
    contentSerial: number;
    refTermId: string;
    termType: string;
    title: string;
    answerRequired: boolean;
    sign: string;
    isPercentage: boolean;
    historicPrice: number;
    initialValue: string;
    valueIsEditable: boolean;
    fromValue: number;
    toValue: number;
    unit: string;
    sortOrder: number;
};

export type ConditionDTO = {
    code: string;
    title: string;
    validValues: string;
    editTypeId: string;
    value: number;
};

export type ResponseAlternativeForRFXDTO = {
    id?: number;
    title?: string;
    isMain?: boolean;

    statusId?: string;
    round?: number;
    rowId?: number;
    totalPrice?: number;

    responses?: RFXResponseDTO[];
    terms?: RFXTermResponseDTO[];
    responseComments?: RFXResponseCommentDTO[];

    cert?: string;
    signedResponses?: string;
    responsesData?: string;
    responseCurrencyId?: string;
    lastResponseDate?: Date;
};

export type RFXResponseDTO = {
    contentSerial: number;
    value: string;
    attachmentId?: number | null;
    quantity: number;
};

export type RFXTermResponseDTO = {
    contentSerial: number;
    termId: number;
    value: string;
};

export type RFXResponseCommentDTO = {
    serial: number;
    alternativeId: number;
    contentSerial: number;
    attachmentId?: number;
    comment: string;
    createdAt?: Date;
    createdBy?: string;
};

export type RFXAcceptedTOCDTO = {
    signedTC?: string | null;
    tc?: string | null;
    cert?: string | null;
};

export type SubmitResultDTO = {
    alreadySubmited: boolean;
    alternativeId: number;
    alternatives: ResponseAlternativeForRFXDTO[];
    bidHistories: any[];
};

export type DocumentContentsDTO = {
    serial: number;

    documentId: number;
    parentSerial: number;
    contentTypeId: string;
    title: string;
    partNumber: string;
    description: string;
    envelopNumber: number;
    sortOrder: number;
    visibility: string;
    answerTypeId: string;
    answerRequired: boolean;
    participantCanAttach: boolean;
    isQuntityModifiable: boolean;
    conditionCode: string;
    pRSerial: number;
    lineId: number;
    materialNo: string;
    itemNo: string;
    quantity: number;
    initialPrice: number;
    unit: string;
    scoreImportance: number;
    scoreOveral: number;
    attachmentId1: number;

    contentChoices: ContentChoiceDTO[];
    contentTerms: ContentTermDTO[];
    contentCommodities: ContentCommodityDTO[];
    attachments: ZAttachmentDTO[];
};

export type ContentChoiceDTO = {
    contentSerial: number;
    title: string;
    score: number;
    setDefault: boolean;
};

export type ContentCommodityDTO = {
    contentSerial: number;
    commodityCode: string;
};

export type ZAttachmentDTO = {
    id: number;
    objectKey: string;
    typeId: string;
    title: string;
    description: string;
    mimeType: string;
    fileName: string;
    size: number;
    dataSerial: number;
    status: string;
    draftId: number;
};

export type EventRuleDTO = {
    startDate?: Date;
    endDate?: Date;
    previewStartDate?: Date;
    previewEndDate?: Date;
    acceptTerms?: boolean;
    termsText?: string;
    multiCurrency?: boolean;
    currencyId?: string;
    allowMessaging?: boolean;
    askReasonForDeclining?: boolean;
    rejectReasonIsRequired?: boolean;
    alternativeResponseEnabled?: boolean;
    alternativeLimit: number;
    showRank?: boolean;
    showItemRank?: boolean;
    showLeadBid?: string;
    allowTieBids?: boolean;
    tieBidDistance?: number;
    improveBid?: boolean;
    bidGuardian?: number;
    bidHistory?: boolean;
    improveBidAmount?: number;
    allowResponseTeam?: boolean;
    allowOvertime?: boolean;
    hasPreview?: boolean;
    overtimeRank?: number;
    overtimePeriod?: number;
    enableEnvelop?: boolean;
    enableTrafficLight?: boolean;
    shipToAddressSerial?: number;
    trafficLightGreenBid?: string;
    trafficLightYellowBid?: string;
    showParticipantCount?: string;
    isExternal?: boolean;
    ownerSee?: boolean;
    ownerCanRespond?: boolean;
    orderCategoryId?: string;
    hideCompanyName?: boolean;
    updatePeriod?: number;
    assignedTo?: string;
    lastAssignmentDate?: Date;
    isDigitalSignatureRequired?: boolean;
    round: number;
    enableMultiRounding?: boolean;
};
