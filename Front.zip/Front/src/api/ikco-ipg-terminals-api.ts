import { IkcoIpgDTO } from "../pages/home/dashboard/ikco-ipg/types/ikco-ipg-dto";
import { IkcoIpgTerminalDTO } from "../pages/home/dashboard/ikco-ipg/types/ikco-ipg-terminal.dto";
import { api } from "./api";
import { apiConfig } from "./config";

export const ikcoIpgTerminalsApi = {
    initIKCOIpgTerminals: () => api.call("post", `${apiConfig.IKCOIpgTerminals}/init-terminals`),
    initIkcoTerminal: (terminalId: string) => api.call("post", `${apiConfig.IKCOIpgTerminals}/init-terminal?id=${terminalId}`),
    initIkcoTerminalIpgs: (terminalId: string) => api.call("post", `${apiConfig.IKCOIpgTerminals}/init-terminal-ipgs?id=${terminalId}`),
    initCreate: () => api.call("post", `${apiConfig.IKCOIpgTerminals}/init-create`),
    initEdit: (terminalId: string) => api.call("post", `${apiConfig.IKCOIpgTerminals}/init-edit?id=${terminalId}`),
    saveIkcoTerminal: (dto: IkcoIpgTerminalDTO) => api.call("post", `${apiConfig.IKCOIpgTerminals}/save-ikco-terminal`, dto),
    deleteIkcoterminal: (id: string) => api.call("post", `${apiConfig.IKCOIpgTerminals}/delete-ikco-terminal?id=${id}`),
    checkId: (id: string) => api.call("post", `${apiConfig.IKCOIpgTerminals}/check-id?id=${id}`),
    deleteIpg: (dto: IkcoIpgDTO) => api.call("post", `${apiConfig.IKCOIpgTerminals}/delete-terminal-ipgs`, dto),
};
