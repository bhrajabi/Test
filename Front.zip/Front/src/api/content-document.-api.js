import { api } from "./api";
import { apiConfig } from "./config";

export const contentDocumentApi = {
    initCreateContent: (projectSerial) =>
        api.call("post", `${apiConfig.documentContentUrl}/init-create-document-content?projectSerial=${projectSerial}`),
    initDocumentContent: (documentSerial) =>
        api.call("post", `${apiConfig.documentContentUrl}/init-document-content?documentSerial=${documentSerial}`),
    initUpdateContentDocument: (documentSerial) =>
        api.call("post", `${apiConfig.documentContentUrl}/init-update-document-content?documentSerial=${documentSerial}`),
    getContentDocument: (documentSerial) =>
        api.call("post", `${apiConfig.documentContentUrl}/get-document-content?documentSerial=${documentSerial}`),
    createContentDocument: (document) => api.call("post", `${apiConfig.documentContentUrl}/create-document-content`, document),
    updateContentDocument: (document) => api.call("post", `${apiConfig.documentContentUrl}/update-document-content`, document),
    deleteDocumentContent: (documentSerial) =>
        api.call("post", `${apiConfig.documentContentUrl}/delete-document-content?documentSerial=${documentSerial}`),
};
