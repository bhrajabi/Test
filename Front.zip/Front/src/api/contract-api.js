import { api } from "./api";
import { apiConfig } from "./config";

export const contractApi = {
    getContract: (documentSerial) => api.call("post", `${apiConfig.contractUrl}/init-contract?documentSerial=${documentSerial}`),

    // sendToERP: (documentSerial, contractSerial) =>
    //     api.call("post", `${apiConfig.contractUrl}/get-document?documentSerial=${documentSerial}&contractSerial=${contractSerial}`),
};
