import { api } from "./api";
import { apiConfig } from "./config";

export const cycleTimeApi = {
    initEventCycleTime: () => api.call("post", apiConfig.cycleTimeUrl + "/init-event-cycle-time"),
    getEventCycleTime: (data) => api.call("post", apiConfig.cycleTimeUrl + "/get-event-cycle-time", data),

    initRequestCycleTime: () => api.call("post", apiConfig.cycleTimeUrl + "/init-request-cycle-time"),
    getRequestCycleTime: (data) => api.call("post", apiConfig.cycleTimeUrl + "/get-request-cycle-time", data),
};
