import { api } from "./api";
import { attachmentApi } from "./attachment-api";
import { apiConfig } from "./config";

export const sellerOrderApi = {
    initReviewOrder: (serial) => api.call("post", `${apiConfig.sellerOrderUrl}/init-review-order?serial=${serial}`),

    initConfirmOrder: (serial, action) =>
        api.call("post", `${apiConfig.sellerOrderUrl}/init-confirm-order?serial=${serial}&action=${action}`),

    confirmOrder: (data) => api.call("post", `${apiConfig.sellerOrderUrl}/confirm-order`, data),

    getOrderConfirmation: (serial, documentSerial) =>
        api.call("post", `${apiConfig.sellerOrderUrl}/get-order-confirmation?serial=${serial}&documentSerial=${documentSerial}`),

    orderList: (statusId) => api.call("post", `${apiConfig.sellerOrderUrl}/order-list?statusId=${statusId}`),

    releasedOrderList: () => api.call("post", `${apiConfig.sellerOrderUrl}/released-order-list`),

    confirmedOrderList: () => api.call("post", `${apiConfig.sellerOrderUrl}/confirmed-order-list`),

    updateConfirmOrder: (data) => api.call("post", `${apiConfig.sellerOrderUrl}/update-confirm-order`, data),

    downloadAttachment: (orderSerial, id) =>
        attachmentApi.download(apiConfig.sellerOrderUrl + `/download-attachment?orderSerial=${orderSerial}&attachmentId=${id}`),
};
