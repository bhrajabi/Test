import { api } from "./api";
import { apiConfig } from "./config";

type SendMessageDTO = {
    chatSerial: number;
    message: string;
};

export const adminChatApi = {
    initAdminChats: () => api.call("post", apiConfig.adminMessagingUrl + `/init-chats`),
    initAdminMessages: () => api.call("post", apiConfig.adminMessagingUrl + `/init-message`),
    sendAdminMessage: (dto: SendMessageDTO) => api.call("post", apiConfig.adminMessagingUrl + `/send-message`, dto),
    initAdminChatMessages: (chatSerial: number) =>
        api.call("post", apiConfig.adminMessagingUrl + `/init-chat-messages?chatSerial=${chatSerial}`),

    leftFromChat: (chatSerial: number) => api.call("post", apiConfig.adminMessagingUrl + `/left-from-chat?chatSerial=${chatSerial}`),
    removeChatMessage: (chatSerial: number, messageSerial: number) =>
        api.call("post", apiConfig.adminMessagingUrl + `/remove-chat-message?messageSerial=${messageSerial}&chatSerial=${chatSerial}`),
};
