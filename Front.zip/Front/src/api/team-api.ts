import { api } from "./api";
import { apiConfig } from "./config";

export const teamApi = {
    initTeam: (companyId: number, projectSerial: number) =>
        api.call("post", `${apiConfig.teamUrl}/init-team?companyId=${companyId ?? 0}&projectSerial=${projectSerial ?? 0}`),

    insertTeamUser: (companyId: number, serial: number, userName: string) =>
        api.call(
            "post",
            `${apiConfig.teamUrl}/insert-team-user?companyId=${companyId ?? 0}&serial=${serial}&userName=${encodeURI(userName)}`
        ),

    deleteTeamUser: (companyId: number, serial: number, userName: string) =>
        api.call(
            "post",
            `${apiConfig.teamUrl}/delete-team-user?companyId=${companyId ?? 0}&serial=${serial}&userName=${encodeURI(userName)}`
        ),

    saveTeam: (companyId: number, projectSerial: number, data: any) =>
        api.call("post", `${apiConfig.teamUrl}/save-team?companyId=${companyId ?? 0}&projectSerial=${projectSerial}`, data),

    deleteTeam: (companyId: number, teamSerial: number) =>
        api.call("post", `${apiConfig.teamUrl}/delete-team?companyId=${companyId ?? 0}&teamSerial=${teamSerial}`),
};
