import { MaterialAttachmentDTO, SelectedMaterialAttachmentDTO } from "../pages/req/monitor/material-images-modal";
import { useApi } from "../pages/seller/home/api/use-api-call";
import { api } from "./api";
import { attachmentApi } from "./attachment-api";
import { apiConfig } from "./config";

export const materialApi = {
    addCommodityToMaterial: (data: any) => api.call("post", apiConfig.materialUrl + `/add-commodity-to-material`, data),

    initSearch: () => api.call("post", apiConfig.materialUrl + `/init-search-materials`),

    getMaterials: (data: any) => api.call("post", apiConfig.materialUrl + `/get-materials`, data),

    getMaterialsForPackaging: (data: any, isPackaging: boolean) =>
        api.call("post", apiConfig.materialUrl + `/get-materials-for-packaging?isPackaging=${isPackaging}`, data),

    getMaterialDetails: (materialNo: string) => api.call("post", apiConfig.materialUrl + `/get-material-details?materialNo=${materialNo}`),

    filterMaterials: (dto: any) => api.call("post", apiConfig.materialUrl + `/filter-material`, dto),

    updateMaterialCommodity: (materialNo: string, commodityCode: string) =>
        api.call("post", apiConfig.materialUrl + `/update-material-commodity?materialNo=${materialNo}&commodityCode=${commodityCode}`),

    initUploadMaterials: () => api.call("post", apiConfig.materialUrl + `/init-upload-materials`),

    uploadExcelTemp: (e: any) => attachmentApi.attach(apiConfig.materialUrl + `/upload-excel-temp`, e.target),

    submitMaterials: (materials: any) => api.call("post", apiConfig.materialUrl + `/submit-materials`, materials),
    // remove: (materialNumber, commodityCode) =>
    //     api.call(
    //         "post",
    //         apiConfig.materialUrl + `/remove-commodity-from-material?materialNumber=${materialNumber}&commodityCode=${commodityCode}`
    //     ),

    getMaterialAttachments: (requestItemSerial: number) =>
        api.call("post", apiConfig.materialUrl + `/get-material-attachments?requestItemSerial=${requestItemSerial}`),

    deleteMaterialAttachment: (requestItemSerial: number, id: number, objectKey?: string) =>
        api.call(
            "post",
            apiConfig.materialUrl +
                `/delete-material-attachment?requestItemSerial=${requestItemSerial}&attachmentId=${id}&objectKey=${objectKey}`
        ),

    saveMaterialAttachments: (requestItemSerial: number, ids: SelectedMaterialAttachmentDTO[]) =>
        api.call("post", apiConfig.materialUrl + `/save-material-attachments?requestItemSerial=${requestItemSerial}`, { ids }),

    saveMaterialAttachmentTitle: (requestItemSerial: number, data: MaterialAttachmentDTO) =>
        api.call("post", apiConfig.materialUrl + `/save-material-attachment-title?requestItemSerial=${requestItemSerial}`, data),
};

export const useSearchMaterials = () => useApi<{ materials: MaterialSearchResultDTO[] }>("/material/get-materials");
//
type MaterialSearchResultDTO = {
    materialNo: string;
    title: string;
    titleEN: string;
    partNumber: string;
    materialType: string;
    materialGroup: string;
    unit: string;
    commodityCode: string;
    commodityTitle: string;
    isBatchManaged: boolean;
    isSerialManaged: boolean;
    isPackagingMaterial: boolean;
    isContainer: boolean;
};
