import { api } from "./api";
import { apiConfig } from "./config";

export const orderInfoRecordApi = {
    getInfoRecord: (data) => api.call("post", `${apiConfig.orderInfoRecordUrl}/get-record`, data),
};
