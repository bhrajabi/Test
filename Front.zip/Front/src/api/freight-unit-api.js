import { api } from "./api";
import { apiConfig } from "./config";

export const freightUnitApi = {
    initCreate: () => api.call("post", apiConfig.freightUnit + `/init-create`),
    initEdit: (serial) => api.call("post", apiConfig.freightUnit + `/init-update?serial=${serial}`),
    save: (dto) => api.call("post", apiConfig.freightUnit + `/save`, dto),
    initTmAddressList: () => api.call("post", apiConfig.freightUnit + `/init-tm-address-list`),
    initTmAddress: (addressSerial) => api.call("post", apiConfig.freightUnit + `/init-tm-address?addressSerial=${addressSerial}`),
    initStages: (freightUnitSerial) => api.call("post", apiConfig.freightUnit + `/init-stages?freightUnitSerial=${freightUnitSerial}`),
    addStageStop: (freightUnitSerial, sequence, addressSerial) =>
        api.call(
            "post",
            apiConfig.freightUnit +
                `/add-stage-stop?freightUnitSerial=${freightUnitSerial}&sequence=${sequence}&addressSerial=${addressSerial}`
        ),
    mergeDownStage: (freightUnitSerial, sequence) =>
        api.call("post", apiConfig.freightUnit + `/merge-down-stage?freightUnitSerial=${freightUnitSerial}&sequence=${sequence}`),

    editStage: (dto) => api.call("post", apiConfig.freightUnit + `/edit-stage`, dto),
};
