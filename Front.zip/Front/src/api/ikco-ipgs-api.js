import { api } from "./api";
import { apiConfig } from "./config";

export const ikcoIpgsApi = {
    initIPGS: () => api.call("post", `${apiConfig.IpgsUrl}/init-ipgs`),
    initIPG: (ipgId) => api.call("post", `${apiConfig.IpgsUrl}/init-ipg?id=${ipgId}`),
    initCreate: () => api.call("post", `${apiConfig.IpgsUrl}/init-create`),
    initEdit: (ipgId) => api.call("post", `${apiConfig.IpgsUrl}/init-edit?id=${ipgId}`),
    saveIpg: (ikcoTerminalId, dto) => api.call("post", `${apiConfig.IpgsUrl}/save-ipg?ikcoTerminalId=${ikcoTerminalId}`, dto),
    deleteIPG: (id) => api.call("post", `${apiConfig.IpgsUrl}/delete-ipg?id=${id}`),
};
