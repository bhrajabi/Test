import { ConfirmationDTO } from "../pages/confirmations/use-confirmation";
import { api } from "./api";
import { apiConfig } from "./config";

export const confirmationApi = {
    initCreateConfirmation: (projectSerial: number) =>
        api.call("post", `${apiConfig.confirmationUrl}/init-create-confirmation?projectSerial=${projectSerial}`),

    initConfirmations: () => api.call("post", `${apiConfig.confirmationUrl}/init-confirmations`),

    getConfirmation: (confirmationSerial: number) =>
        api.call("post", `${apiConfig.confirmationUrl}/get-confirmation?confirmationSerial=${confirmationSerial}`),

    confirmationView: (documentSerial?: number, cnfSerial?: number) =>
        api.call("post", `${apiConfig.confirmationUrl}/confirmation-view?documentSerial=${documentSerial}&cnfSerial=${cnfSerial}`),

    saveConfirmation: (projectSerial: number, data: ConfirmationDTO) =>
        api.call("post", `${apiConfig.confirmationUrl}/save-confirmation?projectSerial=${projectSerial}`, data),

    getCnfDocument: (confirmationSerial?: number) =>
        api.call("post", `${apiConfig.confirmationUrl}/get-cnf-document?confirmationSerial=${confirmationSerial}`),

    getCnfDocuments: () => api.call("post", `${apiConfig.confirmationUrl}/get-cnf-documents`),

    cancelConfirmation: (confirmationSerial?: number) =>
        api.call("post", `${apiConfig.confirmationUrl}/cancel-confirmation?confirmationSerial=${confirmationSerial}`),

    submitConfirmation: (confirmationSerial?: number) =>
        api.call("post", `${apiConfig.confirmationUrl}/submit-confirmation?confirmationSerial=${confirmationSerial}`),

    submitCnf: (confirmationSerial?: number) =>
        api.call("post", `${apiConfig.confirmationUrl}/submit-cnf?serial=${confirmationSerial}`),

    approveConfirmation: (confirmationSerial?: number) =>
        api.call("post", `${apiConfig.confirmationUrl}/approve-confirmation?confirmationSerial=${confirmationSerial}`),

    changeToBackState: (confirmationSerial?: number) =>
        api.call("post", `${apiConfig.confirmationUrl}/change-to-back-state?confirmationSerial=${confirmationSerial}`),

    cnfPrintRequest: (confirmationSerial?: number) =>
        api.call("post", `${apiConfig.confirmationUrl}/cnf-print-request?confirmationSerial=${confirmationSerial}`),

    confirmationAProcList: (cnfSerial: number) =>
        api.call("post", apiConfig.confirmationUrl + `/get-confirmation-aproc-list?cnfSerial=${cnfSerial}`),

    //wf

    wfEditConfirmationSupplier: (wfInstanceSerial: number) =>
        api.call("post", `${apiConfig.confirmationUrl}/wf-edit-confirmation-supplier?wfInstanceSerial=${wfInstanceSerial}`),

    wfConfirmationView: (wfInstanceSerial?: number) =>
        api.call("post", `${apiConfig.confirmationUrl}/wf-confirmation-view?wfInstanceSerial=${wfInstanceSerial}`),

    initWFConfirmationCnf: (wfInstanceSerial: number) =>
        api.call("post", apiConfig.confirmationUrl + `/wf-init-confirmation-cnf?wfInstanceSerial=${wfInstanceSerial}`),

    updateConfirmationApprove: (wfInstanceSerial: number, data: any) =>
        api.call("post", `${apiConfig.confirmationUrl}/update-confirmation-approve?wfInstanceSerial=${wfInstanceSerial}`, data),

    saveWfSuppliers: (wfInstanceSerial: number, data: ConfirmationDTO) =>
        api.call("post", `${apiConfig.confirmationUrl}/save-wf-suppliers?wfInstanceSerial=${wfInstanceSerial}`, data),

    wfCnfPrintRequest: (wfInstanceSerial?: number) =>
        api.call("post", `${apiConfig.confirmationUrl}/wf-confirmation-print-request?wfInstanceSerial=${wfInstanceSerial}`),
};
