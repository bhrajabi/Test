import { api } from "./api";
import { apiConfig } from "./config";

export const publicEventApi = {
    init: (documentSerial: number) => api.call("post", apiConfig.publicEventUrl + `/get-public-event?documentSerial=${documentSerial}`),
    sendJoinToEventRequest: (documentSerial: number) =>
        api.call("post", apiConfig.publicEventUrl + `/send-join-to-event-request?documentSerial=${documentSerial}`),

    connectToBuyer: (documentSerial: number, data: any) =>
        api.call("post", apiConfig.publicEventUrl + `/connect-to-buyer?documentSerial=${documentSerial}`, data),
};
