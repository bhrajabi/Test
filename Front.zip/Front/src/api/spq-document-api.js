import { api } from "./api";
import { apiConfig } from "./config";

export const spqDocumentApi = {
    //--initialize
    initSpq: (documentSerial) => api.call("post", `${apiConfig.spqUrl}/init-spq?documentSerial=${documentSerial}`),
    initUpdateSpq: (documentSerial) => api.call("post", `${apiConfig.spqUrl}/init-update-spq?documentSerial=${documentSerial}`),
    initCreateSpq: (projectSerial) => api.call("post", `${apiConfig.spqUrl}/init-create-spq?projectSerial=${projectSerial}`),
    filterSpqParticipants: (documentSerial, dto) =>
        api.call("post", `${apiConfig.spqUrl}/filter-spq-participants?documentSerial=${documentSerial}`, dto),

    //--crud
    createSpqDocument: (document) => api.call("post", `${apiConfig.spqUrl}/create-spq-document`, document),
    updateSpqDocument: (document) => api.call("post", `${apiConfig.spqUrl}/update-spq-document`, document),
    deleteSpqDocument: (documentSerial) => api.call("post", `${apiConfig.spqUrl}/delete-spq-document?documentSerial=${documentSerial}`),
    assignSpqEvent: (values) => api.call("post", apiConfig.spqUrl + `/assign-spq-event`, values),

    //--events
    filterSpqEvents: (documentSerial, dto) =>
        api.call("post", `${apiConfig.spqUrl}/filter-spq-events?documentSerial=${documentSerial}`, dto),
    getSpqEvent: (documentSerial) => api.call("post", `${apiConfig.spqUrl}/get-spq-event?documentSerial=${documentSerial}`),
    rejectEventResponses: (eventSerial) => api.call("post", `${apiConfig.spqUrl}/reject-spq-event-responses?eventSerial=${eventSerial}`),

    //--status
    updateSpqStatus: (documentSerial, status) =>
        api.call("post", `${apiConfig.spqUrl}/update-spq-status?documentSerial=${documentSerial}&newStatus=${status}`),

    restoreToPreviousStatus: (documentSerial) =>
        api.call("post", apiConfig.spqUrl + `/restore-to-previous-status?documentSerial=${documentSerial}`),

    searchSpq: (data) => api.call("post", `${apiConfig.spqDocumentUrl}/search-spq-documents`, data),

    changeAlternativeResponsesStatus: (alternativeId, statusId) =>
        api.call("post", `${apiConfig.spqUrl}/change-alternative-responses-status?alternativeId=${alternativeId}&statusId=${statusId}`),

    updateLastSuppliersResponse: (eventSerial) =>
        api.call("post", `${apiConfig.spqUrl}/update-last-supplier-response?eventSerial=${eventSerial}`),

    updateEndDate: (model) => api.call("post", `${apiConfig.spqUrl}/update-spq-event-end-date`, model),
};
