export const db2CodeUrls = {
    init: "/db2code/init",
    get_table: "/db2code/get-table",
};

export type Db2Code_InitDTO = {
    tables: string[];
    views: string[];
    relations: any[];
};

export type Db2Code_GetTableDTO = {
    table: {
        columns: {
            name: string;
            maxLength: number;
            isNullable: boolean;
            precision: number;
            scale: number;
        }[];
        primaryKey: string[];
        uniqueConstraints: string[];
    };
};
