import { api } from "./api";
import { apiConfig } from "./config";

export const serviceWorkerApi = {
  getServiceWorker: () =>
    api.call("get", `${apiConfig.serviceWorkerUrl}/service-wroker`),
};
