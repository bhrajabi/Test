import { api } from "./api";
import { attachmentApi } from "./attachment-api";
import { apiConfig } from "./config";

export const discoveryApi = {
    initDiscoveryCreate: (projectSerial) =>
        api.call("post", `${apiConfig.discoveryUrl}/init-create-discovery?projectSerial=${projectSerial}`),

    initQucikDiscoveryCreate: (requestSerial) =>
        api.call("post", `${apiConfig.discoveryUrl}/init-create-quick-discovery?requestSerial=${requestSerial}`),

    initEditDiscovery: (serial) => api.call("post", `${apiConfig.discoveryUrl}/init-edit-discovery?serial=${serial}`),

    getEventTemplates: (serial) => api.call("post", `${apiConfig.discoveryUrl}/get-disc-templates?projectSerial=${serial}`),

    initDiscoveryMonitoring: (documentSerial) =>
        api.call("post", `${apiConfig.discoveryUrl}/init-discovery-monitoring?serial=${documentSerial}`),

    createDiscovery: (projectSerial, dto) =>
        api.call("post", `${apiConfig.discoveryUrl}/create-discovery?projectSerial=${projectSerial}`, dto),

    createQuickDiscovery: (dto) => api.call("post", `${apiConfig.discoveryUrl}/create-quick-discovery`, dto),

    updateDiscovery: (serial, dto) => {
        return api.call("post", `${apiConfig.discoveryUrl}/update-discovery?serial=${serial}`, { ...dto });
    },

    updateDiscoveryDates: (serial, dto) =>
        api.call("post", `${apiConfig.discoveryUrl}/update-discovery-dates?serial=${serial}`, { ...dto }),

    deleteDiscovery: (serial) => api.call("post", `${apiConfig.discoveryUrl}/delete-discovery?serial=${serial}`),

    publishTemplate: (serial) => api.call("post", apiConfig.discoveryUrl + "/publish-discovery-template?documentSerial=" + serial),
    //

    uploadAttachment: (e, draftId) => attachmentApi.attach(apiConfig.discoveryUrl + `/upload-attachment?draftId=${draftId}`, e.target),

    removeAttachment: (attachmentId) => api.call("post", apiConfig.discoveryUrl + "/remove-attachment?id=" + attachmentId),

    downloadAttachment: (attachmentId, documentSerial) => {
        attachmentApi.download(
            apiConfig.discoveryUrl + `/attachment-download-request?attachmentId=${attachmentId}&documentSerial=${documentSerial}`
        );
    },
    downloadPublicAttachment: (attachmentId, documentSerial) => {
        attachmentApi.download(
            apiConfig.discoveryUrl + `/attachment-download-seller-request?attachmentId=${attachmentId}&documentSerial=${documentSerial}`
        );
    },

    initAllDiscoveries: () => api.call("post", apiConfig.discoveryUrl + `/init-document-discoveries`),

    initDiscoveryItemDetail: (serial) => api.call("post", apiConfig.discoveryUrl + `/init-discovery-item-detail?serial=${serial}`),

    initByCompanyId: () => api.call("post", apiConfig.discoveryUrl + `/init-discovery-by-companyId`),

    participate: (serial, file, dto) => attachmentApi.attach(apiConfig.discoveryUrl + `/participate?serial=${serial}`, file, dto),

    updateRule: (documentSerial, dto) =>
        api.call("post", apiConfig.discoveryUrl + `/update-discovery-rule?documentSerial=${documentSerial}`, dto),

    toggleDiscoveryItemRequest: (selected, documentSerial, dto) =>
        api.call(
            "post",
            apiConfig.discoveryUrl + `/toggle-discovery-item-request?documentSerial=${documentSerial}&selected=${selected}`,
            dto
        ),
    restoreToPreviousStatus: (docSerial) =>
        api.call("post", apiConfig.discoveryUrl + `/restore-to-previous-status?documentSerial=${docSerial}`),
    
    publish: (docSerial) => api.call("post", apiConfig.discoveryUrl + `/publish-discovery?discoverySerial=${docSerial}`),

    completeDiscovery: (docSerial) => api.call("post", apiConfig.discoveryUrl + `/complete-discovery?documentSerial=${docSerial}`),

    searchDiscovery: (status) => api.call("post", apiConfig.discoveryUrl + `/search-seller-discovery?status=${status}`),

    searchBuyerDiscovery: (dto) => api.call("post", apiConfig.discoveryUrl + `/search-buyer-discovery`, dto),

    participatedInDiscovery: () => api.call("post", apiConfig.discoveryUrl + `/participate-in-discovery`),

    initMessaging: (documentSerial) => api.call("post", apiConfig.discoveryUrl + `/init-messaging?documentSerial=${documentSerial}`),

    sendMessage: (documentSerial, data) =>
        api.call("post", apiConfig.discoveryUrl + `/send-message?documentSerial=${documentSerial}`, data),

    cancelMessage: (documentSerial, requestSerial) =>
        api.call("post", apiConfig.discoveryUrl + `/cancel-message?documentSerial=${documentSerial}&requestSerial=${requestSerial}`),

    discoveryRuleAProcList: (discoverySerial) =>
        api.call("post", apiConfig.discoveryUrl + `/get-discovery-aproc-list?discoverySerial=${discoverySerial}`),

    changeDiscoveryRuleAproc: (discoverySerial, action, aprocSerial) =>
        api.call(
            "post",
            apiConfig.discoveryUrl +
            `/change-discovery-rule-aproc?discoverySerial=${discoverySerial}&aprocAction=${action}&aprocSerial=${aprocSerial}`
        ),

    discoveryEventReport: (documentSerial, reportSerial) =>
        api.call("post", apiConfig.discoveryUrl + `/discovery-event-report?documentSerial=${documentSerial}&reportSerial=${reportSerial}`),
};
