import { useApi } from "../pages/seller/home/api/use-api-call";
import { api } from "./api";
import { attachmentApi } from "./attachment-api";
import { apiConfig } from "./config";

export const eventApi = {
    initGuidedEvent: (serial: number) => api.call("post", apiConfig.eventUrl + "/init-guided-event?serial=" + serial),
    initEventMembers: (serial: number, chatSerial: number) =>
        api.call("post", apiConfig.eventUrl + `/init-event-chat-member?documentSerial=${serial}&chatSerial=${chatSerial}`),
    quickChangeStatus: (documentSerial: number, statusId: any) =>
        api.call("post", `${apiConfig.eventUrl}/quick-change-status?documentSerial=${documentSerial}&statusId=${statusId}`),

    reloadEventData: (serial: number) => api.post("/event/reload-event-data?serial=" + serial),

    saveEventInfo: (serial: number, data: any) => api.call("post", apiConfig.eventUrl + "/save-event-info?serial=" + serial, data),

    saveEventRules: (serial: number, data: any) => api.call("post", `${apiConfig.eventUrl}/save-event-rules?serial=${serial}`, data),

    initEventMonitoring: (serial: number) => api.call("post", apiConfig.eventUrl + "/init-event-monitoring?serial=" + serial),

    // invited events
    initSuppliersEvents: (dto: any) => api.call("post", apiConfig.eventUrl + "/init-suppliers-events", dto),
    filterSuppliersEvents: (dto: any) => api.call("post", apiConfig.eventUrl + "/filter-suppliers-events", dto),

    wfinitEventMonitoring: (serial: number, instanceSerial: number) =>
        api.call("post", apiConfig.eventUrl + `/wf-init-event-timing?serial=${serial}&wfInstanceSerial=${instanceSerial}`),

    wfinitEventTiming: (serial: number, instanceSerial: number) =>
        api.call("post", apiConfig.eventUrl + `/wf-init-event-monitoring?serial=${serial}&wfInstanceSerial=${instanceSerial}`),

    initGuidedEventMonitor: (serial: number) => api.call("post", apiConfig.eventUrl + "/init-guided-event-monitor?serial=" + serial),

    wfInitGuidedEventMonitor: (serial: number, instanceSerial: number) =>
        api.call("post", apiConfig.eventUrl + `/wf-init-guided-event-monitor?serial=${serial}&wfInstanceSerial=${instanceSerial}`),

    wfInitGradingEvent: (serial: number, instanceSerial: number) =>
        api.call("post", apiConfig.eventUrl + `/wf-init-guided-event-monitor?serial=${serial}&wfInstanceSerial=${instanceSerial}`),

    initEventPreview: (documentSerial: number) =>
        api.call("post", apiConfig.rfxUrl + "/init-event-preview?documentSerial=" + documentSerial),

    declineEvent: (documentSerial: number, sellerId: number, declinReason: string) =>
        api.call(
            "post",
            apiConfig.rfxUrl + `/decline-event?documentSerial=${documentSerial}&sellerId=${sellerId}&declinReason=${declinReason}`
        ),

    cancelDeclinedEvent: (documentSerial: number, sellerId: number) =>
        api.call("post", apiConfig.rfxUrl + `/cancel-declined-event?documentSerial=${documentSerial}&sellerId=${sellerId}`),

    acceptEvent: (documentSerial: number, sellerId: number, currencyId: string, acceptedTerms: any) =>
        api.call(
            "post",
            apiConfig.rfxUrl + `/accept-event?documentSerial=${documentSerial}&sellerId=${sellerId}&currencyId=${currencyId}`,
            acceptedTerms
        ),

    deleteAlternative: (documentSerial: number, sellerId: number, alternativeId: number) =>
        api.call(
            "post",
            apiConfig.rfxUrl + `/delete-alternative?documentSerial=${documentSerial}&sellerId=${sellerId}&alternativeId=${alternativeId}`
        ),

    submitSelections: (documentSerial: number, sellerId: number, selections: any) =>
        api.call("post", apiConfig.rfxUrl + `/submit-selections?documentSerial=${documentSerial}&sellerId=${sellerId}`, selections),

    submitResponse: (documentSerial: number, sellerId: number, data: any) =>
        api.call("post", apiConfig.rfxUrl + `/submit-response?documentSerial=${documentSerial}&sellerId=${sellerId}`, data),

    uploadContentResponseAttachment: (
        documentSerial: number,
        sellerId: number,
        alternativeId: number | undefined,
        contentSerial: number,
        e: any
    ) => {
        return attachmentApi.attach(
            apiConfig.rfxUrl +
                `/upload-content-response-attachment?documentSerial=${documentSerial}&sellerId=${sellerId}&alternativeId=${alternativeId}&contentSerial=${contentSerial}`,
            e.target
        );
    },

    uploadResponseCommentAttachment: (documentSerial: number, sellerId: number, alternativeId: number, e: any) => {
        return attachmentApi.attach(
            apiConfig.rfxUrl +
                `/upload-response-comment-attachment?documentSerial=${documentSerial}&sellerId=${sellerId}
               &alternativeId=${alternativeId}`,
            e.target
        );
    },

    downloadResponseAttachment: (documentSerial: number, sellerId: number, attachmentId: number) =>
        attachmentApi.download(
            apiConfig.rfxUrl +
                `/download-response-request?documentSerial=${documentSerial}&sellerId=${sellerId}&attachmentId=${attachmentId}`
        ),

    publishTemplate: (serial: number) => api.call("post", apiConfig.documentUrl + "/publish-event-template?documentSerial=" + serial),

    updateEndDate: (documentSerial: number, endDate: any, endTime: any) =>
        api.call(
            "post",
            `${apiConfig.documentUrl}/update-event-end-date?documentSerial=${documentSerial}&newEndDate=${endDate}&newEndTime=${endTime}`
        ),

    cancelEvent: (documentSerial: number) => api.call("post", apiConfig.documentUrl + `/cancel-event?documentSerial=${documentSerial}`),

    deleteEvent: (documentSerial: number) => api.call("post", apiConfig.documentUrl + `/delete-event?documentSerial=${documentSerial}`),

    addSellerToEvent: (documentSerial: number) =>
        api.call("post", apiConfig.eventUrl + `/add-seller-to-event?documentSerial=${documentSerial}`),

    printScenarioEvent: (documentSerial: number, reportSerial: number, round: any) =>
        api.call(
            "post",
            `${apiConfig.eventUrl}/print-scenario?documentSerial=${documentSerial}&reportSerial=${reportSerial}&round=${round}`
        ),

    printWfScenarioEvent: (wfInstanceSerial: number, documentSerial: number, reportSerial: number) =>
        api.call(
            "post",
            `${apiConfig.eventUrl}/print-wf-scenario?wfInstanceSerial=${wfInstanceSerial}&documentSerial=${documentSerial}&reportSerial=${reportSerial}`
        ),

    initSellerMessages: (documentSerial: number) =>
        api.call("post", `${apiConfig.eventUrl}/init-seller-messaging?documentSerial=${documentSerial}`),

    removeAwardCnfRequest: (documentSerial: number, assignedTo: any) =>
        api.call("post", `${apiConfig.eventUrl}/remove-award-cnf-request?documentSerial=${documentSerial}&assignedTo=${assignedTo}`),

    initDocumentMeetings: (documentSerial: number) =>
        api.call("post", apiConfig.eventUrl + `/init-document-meetings?documentSerial=${documentSerial}`),

    requestInquiryPrint: (documentSerial: number, sellerId: number) =>
        api.call("post", `${apiConfig.rfxUrl}/request-inquiry-print?documentSerial=${documentSerial}&sellerId=${sellerId}`),
};

//
//
//

export const useEventSummaryApi = () => useApi<EventSummary>("/event/summary?serial={serial}");

export type EventSummary = {
    document: DocumentSummary;
    project: ProjectSummary;
    eventRules: EventRuleSummary;
    contentItems: ContentItemSummary[];
    invitations: InvitationSummary[];
    envelopes: EnvelopeSummary[];
    rounds: RoundSummary[];
    alternatives: AlternativeSummary[];
    scenarios: ScenarioSummary[];
    orders: OrderSummary[];
    sms: SmsSummary[];
    defaultCurrency: string;
};

//------
export type DocumentSummary = {
    serial: number;
    number: string;
    title: string;
    documentType: string;
    eventTypeId: string;
    createdAt: Date;
    createdBy: string;
    createdByName: string;
    statusId: string;
    isCancelled: boolean;
};

export type ProjectSummary = {
    serial: number;
    number: string;
    title: string;
    isTemplate: boolean;
    projectType: string;
    isFullProject: boolean;
    startDate: Date;
    endDate: Date;
    dueDate: Date;
    createdAt: Date;
    owner: string;
    ownerName: string;
    workingGroup: string;
    exceededDueDate: number;
};

export type EventRuleSummary = {
    eventCategoryId: string;
    eventCategory: string;
    isExternal: boolean;
    publishDate: Date;
    startDate: Date;
    endDate: Date;
    closeDate: Date;
    gradeDate: Date;
    awardDate: Date;
    hasPreview: boolean;
    previewStartDate: Date;
    previewEndDate: Date;
};

export type ContentItemSummary = {
    serial: number;
    prNumber: string;
    partNumber: string;
    prItem: string;
    materialNo: string;
    title: string;
    description: string;
    prSerial: number;
    quantity: number;
    unit: string;
    initialPrice: number;
    deliveryDate: Date;
    prIsClosed: boolean;
    prIsDeleted: boolean;
    prProjectSerial?: number;
    prReleaseDate?: Date;
    prRequestDate?: Date;
    prCreatedAt: Date;
};

export type InvitationSummary = {
    sellerId: number;
    companyName: string;
    erpNumber: string;

    invitationComment: string;
    isInvitationApproved: boolean;
    isInvitationLocked: boolean;
    isResponseDeclined: boolean;
    requestStatusId: string;
    responseCurrencyId: string;
    responseDate: Date;
    responseDeclinReason: string;
    responseExchangeRate: Date;
    responseStatusId: string;
    responseUserName: string;
    round: number;
    submitCount: number;
    visitCount: number;

    gradeDate: Date;
    comment: string;
    participantFullName: string;
    responseUserFullName: string;
    createdByFullName: string;
    createdAt: Date;
};

export type EnvelopeSummary = {
    documentSerial: string;
    seq: string;
    title: string;
    encryptionMethod: string;
    encryptionKey: string;
    verifyResponseBeforeOpening: string;
    isOpened: string;
    openingDate: string;
    openedBy: string;
};

export type RoundSummary = {
    eventSerial: number;
    round: number;
    comments: string;
    createdBy: string;
    createdAt: Date;
    publishDate: Date;
    startDate: Date;
    endDate: Date;
    closeDate: Date;
    gradeDate: Date;
    awardDate: Date;
};

export type AlternativeSummary = {
    id: number;
    rowId: number;
    sellerId: number;
    participantName: string;
    round: number;
    isMain: boolean;
    totalScore: number;
    totalPrice: number;
    rejectReason: string;
    approveDate: Date;
    comments: string;
    statusId: string;
    createdAt: Date;
    lastResponseDate: Date;
};

export type ScenarioSummary = {
    title: string;
    isApproved: boolean;
    round: number;
    statusId: string;
    commissionNo: string;
    commissionDate: string;
    commissionComment: string;
    comment: string;
    createdBy: string;
};

export type OrderSummary = {
    serial: number;
    number: string;
    orderDate: Date;
    totalAmount: number;
    totalAmountInCurrency: number;
    currencyId: string;
    sellerId: number;
    isDeleted: boolean;
    statusId: string;
};

export type SmsSummary = {
    serial: number;
    code: string;
    userName: string;
    createdAt: Date;
};
