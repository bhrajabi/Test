import { api } from "./api";
import { apiConfig } from "./config";

export const chatApi = {
    initMyChats: () => api.call("post", apiConfig.chatUrl + `/init-my-chats`),
    sendMessage: (dto) => api.call("post", apiConfig.chatUrl + `/send-message`, dto),
    inviteNewChatMember: (dto) => api.call("post", apiConfig.chatUrl + `/invite-new-chat-member`, dto),
    initMyChatMessages: (chatSerial) => api.call("post", apiConfig.chatUrl + `/init-my-chat-messages?chatSerial=${chatSerial}`),
    initChatMessagesBySerial: (chatSerial) => api.call("post", apiConfig.chatUrl + `/init-chat-messages?chatSerial=${chatSerial}`),
    leftFromChat: (chatSerial) => api.call("post", apiConfig.chatUrl + `/left-from-chat?chatSerial=${chatSerial}`),
    removeChatMessage: (chatSerial, messageSerial) =>
        api.call("post", apiConfig.chatUrl + `/remove-chat-message?messageSerial=${messageSerial}&chatSerial=${chatSerial}`),
};
