import { api } from "./api";
import { attachmentApi } from "./attachment-api";
import { apiConfig } from "./config";

export const registrationRequestApi = {
    uploadAttachment: (e, data) => attachmentApi.attach(apiConfig.registrationRequestUrl + `/upload-reg-req-image`, e.target, data),

    downloadRegReqAttachedImage: (attachmentId, mobile) => {
        attachmentApi.downloadImage(
            apiConfig.registrationRequestUrl + `/download-reg-req-attachment?attachmentId=${attachmentId}&mobile=${mobile}`,
            mobile
        );
    },

    downloadRegReqAttachment: (attachmentId, mobile) => {
        attachmentApi.download(
            apiConfig.registrationRequestUrl + `/download-reg-req-attachment?attachmentId=${attachmentId}&mobile=${mobile}`,
            mobile
        );
    },

    loadRegReqMessage: (serial, data) =>
        api.call("post", apiConfig.registrationRequestUrl + `/load-reg-req-message?serial=${serial}`, data),

    sendRegReqMessage: (serial, data) =>
        api.call("post", apiConfig.registrationRequestUrl + `/send-reg-req-message?serial=${serial}`, data),

    getRegistrationRequest: (serial, data) =>
        api.call("post", apiConfig.registrationRequestUrl + `/get-registration-request?serial=${serial}`, data),

    saveRegisterRequest: (uid, data) =>
        api.directCall("post", apiConfig.registrationRequestUrl + `/save-register-request?uid=${uid}`, data),

    validateRegReq: (nid, nin, data) =>
        api.call("post", `${apiConfig.registrationRequestUrl}/validate-reg-req?nid=${nid ?? ""}&nin=${nin ?? ""}`, data),

    getBuyerSpq: (buyerId, data) => api.call("post", `${apiConfig.registrationRequestUrl}/get-buyer-spq?buyerId=${buyerId}`, data),

    uploadSpqContentResponseAttachment: (attachmentKey, contentSerial, e) => {
        return attachmentApi.attach(
            apiConfig.registrationRequestUrl +
                `/upload-spq-content-response-attachment?attachmentKey=${attachmentKey}&contentSerial=${contentSerial}`,
            e.target
        );
    },

    downloadSpqResponseAttachment: (attachmentKey, attachmentId, mobile) => {
        attachmentApi.download(
            apiConfig.registrationRequestUrl +
                `/download-spq-response-attachment?attachmentKey=${attachmentKey}&attachmentId=${attachmentId}&mobile=${mobile}`,
            mobile
        );
    },

    createCompanyTacDownloadRequest: (companyId, attachmentId, mobile) =>
        attachmentApi.download(
            apiConfig.registrationRequestUrl +
                `/download-company-tac-attachment?companyId=${companyId}&attachmentId=${attachmentId}&mobile=${mobile}`,
            mobile
        ),

    setMessagesAsVisited: (serial, data) =>
        api.call("post", apiConfig.registrationRequestUrl + `/set-messages-as-visited?serial=${serial}`, data),

    saveRegReqSpqResponses: (wfInstanceSerial, data) =>
        api.call("post", apiConfig.registrationRequestUrl + `/save-reg-req-spq-responses?wfInstanceSerial=${wfInstanceSerial}`, data),

    completeResponseToEvaluation: (wfInstanceSerial, wfMessageSerial) =>
        api.call(
            "post",
            apiConfig.registrationRequestUrl +
                `/complete-response-to-evaluation?wfInstanceSerial=${wfInstanceSerial}&wfMessageSerial=${wfMessageSerial}`
        ),

    setWfRegReqToPending: (serial, data) =>
        api.call("post", apiConfig.registrationRequestUrl + `/wf-pending-reg-req?serial=${serial}`, data),

    wfSetAsEVAL: (wfMessageSerial) =>
        api.call("post", apiConfig.registrationRequestUrl + `/wf-reg-req-set-as-eval?serial=${wfMessageSerial}`),

    setWfRegReqToReject: (wfMessageSerial, data) =>
        api.call("post", apiConfig.registrationRequestUrl + `/wf-reject-reg-req?serial=${wfMessageSerial}`, data),

    wfSetRegReqErpNumber: (wfMessageSerial, erpNumber) =>
        api.call("post", apiConfig.registrationRequestUrl + `/wf-set-reg-req-erp-number?serial=${wfMessageSerial}&erpNumber=${erpNumber}`),

    wfApproveRegReq: (messageSerial, data) =>
        api.call("post", apiConfig.registrationRequestUrl + `/wf-approve-reg-req?serial=${messageSerial}`, data),
};
