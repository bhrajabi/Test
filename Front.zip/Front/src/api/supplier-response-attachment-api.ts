import { useApi } from '../pages/seller/home/api/use-api-call';
import { api } from './api';
import { attachmentApi } from './attachment-api';
import { apiConfig } from './config';

export const supplierResponseAttachmentApi = {
    initSupplierResponseAttachments: (documentSerial: number) =>
        api.call('post', `${apiConfig.supplierResponseAttachment}/init-attachments?ds=${documentSerial}`),

    deleteAttachment: (id: number, ds: number) =>
        api.call('post', apiConfig.supplierResponseAttachment + `/delete-attachment?ds=${ds}&attachmentId=${id}`),

    getAttachment: (id: number, ds: number, objectKey: string) =>
        api.call('post', apiConfig.supplierResponseAttachment + `/get-attachment?ds=${ds}&attachmentId=${id}&objectKey=${objectKey}`),

    downloadFile: (id: number, ds: number) => {
        attachmentApi.download(`${apiConfig.supplierResponseAttachment}/download-attachment?documentSerial=${ds}&attachmentId=${id}`);
    },
};
