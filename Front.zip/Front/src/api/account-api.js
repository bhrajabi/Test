import settings from "../app/settings.ts";
import { api } from "./api";
import { apiConfig } from "./config";

export const accountApi = {
    userProfileImageUrl: apiConfig.attachmentUrl + "/user-profile-image",
    userInfo: () => api.directCall("post", `${apiConfig.accountUrl}/user-info?version=${settings.getAppVersion()}`),

    generateVerificationCodeForRegister: (data) =>
        api.directCall("post", apiConfig.accountUrl + "/generate-verification-code-for-register", data),

    generateVerificationCodeForUserProfile: (phoneNumber, captcha) =>
        api.directCall(
            "post",
            apiConfig.accountUrl + `/generate-verification-code-for-user-profile?phoneNumber=${phoneNumber}&captcha=${captcha}`
        ),

    generateVerificationCode: (data) => api.directCall("post", apiConfig.accountUrl + "/generate-verification-code", data),

    recoveryPassword: (data) => api.directCall("post", apiConfig.accountUrl + `/recovery-password`, data),
    resetPassword: (data) => api.directCall("post", apiConfig.accountUrl + `/reset-password`, data),

    verifyCode: (data) => api.directCall("post", apiConfig.accountUrl + "/verify-code", data),
    verifyPassword: (data) => api.directCall("post", apiConfig.accountUrl + "/verify-password", data),

    getMyCompanies: (key, userName, phoneNumber, current2FA) =>
        api.directCall("post", apiConfig.accountUrl + "/get-my-companies", { key, userName, phoneNumber, current2FA }),

    login: (data) => api.directCall("post", apiConfig.accountUrl + "/login", data),

    register: (data) => api.directCall("post", apiConfig.accountUrl + "/register", data),
    companyRegister: (data) => api.directCall("post", apiConfig.accountUrl + "/company-register", data),

    companyRecoveryAsReal: (data) => api.directCall("post", apiConfig.accountUrl + "/company-recovery-as-real", data),

    //authenticateRegister: (data) => api.directCall("post", apiConfig.accountUrl + "/authenticate-register", data),

    initUserProfile: () => api.call("post", apiConfig.accountUrl + "/init-user-profile"),

    updateUserProfile: (user) => api.call("post", apiConfig.accountUrl + "/update-user-profile", user),
    changeUserPassword: (data) => api.call("post", apiConfig.accountUrl + "/change-user-password", data),
    changeUserPhoneNumber: (data) => api.call("post", apiConfig.accountUrl + "/change-user-phone-number", data),

    // terminateOtherUserSession: (sessions) => api.call("delete", apiConfig.accountUrl + "/terminate-sessions", sessions),

    logout: () => api.directCall("post", apiConfig.accountUrl + "/logout"),
    refresh: () => api.refresh(),

    verifyCertificate: (data) => api.directCall("post", apiConfig.accountUrl + `/verify-certificate`, data),
    recoveryLegalCompanyByToken: (data) => api.directCall("post", apiConfig.accountUrl + `/recovery-legal-company-by-token`, data),
    verifyCertificateForCreateCompany: (data) =>
        api.directCall("post", apiConfig.accountUrl + `/verify-certificate-for-create-company`, data),

    verificationTwoFactorCode: (data) => api.directCall("post", apiConfig.accountUrl + `/verification-tow-factor-code`, data),

    generateVerificationCodeFor2FA: (type) => api.call("post", apiConfig.accountUrl + `/generate-verification-code-for-2fa?type=${type}`),
    generateVerificationCodeFor2FALogin: (data) =>
        api.call("post", apiConfig.accountUrl + "/generate-verification-code-for-2fa-login", data),

    initTwoFactor: () => api.call("post", apiConfig.accountUrl + `/init-two-factor`),
    enableAppTwoFactor: (data) => api.call("post", apiConfig.accountUrl + `/enable-app-two-factor`, data),
    disableTwoFactor: () => api.call("post", apiConfig.accountUrl + `/disable-two-factor`),
    changePreferred: () => api.call("post", apiConfig.accountUrl + `/change-preferred`),
    confirmUserPhoneNumber: (data) => api.call("post", apiConfig.accountUrl + `/confirm-user-phone-number`, data),
    confirmUserEmail: (data) => api.call("post", apiConfig.accountUrl + `/confirm-user-email-address`, data),
    disableShow2FAAlarm: () => api.call("post", apiConfig.accountUrl + `/disable-tow-factor-alarm`),
    get2FAStatus: () => api.call("post", apiConfig.accountUrl + `/get-2fa-status`),

    verifyUserForSetPassword: (userName) =>
        api.directCall("post", apiConfig.accountUrl + `/verify-user-for-set-password?userName=${userName}`),

    getVerificationCode: (data) => api.directCall("post", apiConfig.accountUrl + `/get-verification-code`, data),
    verificationCode: (data) => api.directCall("post", apiConfig.accountUrl + `/verification-code`, data),
    registerBussiness: (data) => api.directCall("post", apiConfig.accountUrl + `/register-bussiness`, data),

    requestOtpCode: (phoneNumber, captcha) =>
        api.directCall("post", apiConfig.accountUrl + `/request-otp-code?phoneNumber=${phoneNumber}&captcha=${captcha}`),

    verifyOtp: (data) => api.call("post", apiConfig.accountUrl + "/anonymous-verify-otp", data),

    getRegistrationRequests: (data) => api.call("post", apiConfig.accountUrl + `/get-registration-requests`, data),

    getUserDevices: () => api.call("post", apiConfig.accountUrl + `/get-user-devices`),

    updateUserDevices: (id) => api.call("post", apiConfig.accountUrl + `/update-user-device?id=${id}`),

    getUserCompanies: () => api.call("post", apiConfig.accountUrl + `/get-user-companies`),

    changeCompanies: (companyId, chartUserRoleSerial) =>
        api.call(
            "post",
            apiConfig.accountUrl + `/change-company?userCompanyId=${companyId}&chartUserRoleSerial=${chartUserRoleSerial ?? ""}`
        ),

    reportError: (data) => api.call("post", apiConfig.accountUrl + `/report-error`, data),
};
