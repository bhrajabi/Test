import { api } from "./api";
import { attachmentApi } from "./attachment-api";
import { apiConfig } from "./config";

export const projectDocumentsApi = {
    GetCommodities: (documentSerial) => api.call("post", apiConfig.prjDocsUrl + `/get-commodities?documentSerial=${documentSerial}`),
    RenameFileDocument: (documentSerial, title) =>
        api.call("post", apiConfig.prjDocsUrl + `/rename-file-document?documentSerial=${documentSerial}&documentTitle=${title}`),

    documentFile: (documentSerial) => {
        attachmentApi.download(apiConfig.prjDocsUrl + `/file-download-request?documentSerial=${documentSerial}`);
    },

    toggleQuickLink: (documentSerial) => api.call("post", apiConfig.prjDocsUrl + `/toggle-quick-link?documentSerial=${documentSerial}`),
    uploadDocument: (projectSerial, folderSerial, e) =>
        attachmentApi.attach(
            apiConfig.prjDocsUrl +
                `/upload-document-file?projectSerial=${projectSerial}&folderSerial=${folderSerial > 0 ? folderSerial : 0}`,
            e.target
        ),
    deleteDocument: (documentSerial) => api.call("post", apiConfig.prjDocsUrl + `/delete-document?documentSerial=${documentSerial}`),
    initProjectDocuments: (projectSerial, selectedFolderId) =>
        api.call("post", apiConfig.prjDocsUrl + `/init-project-documents?projectSerial=${projectSerial}&folderId=${selectedFolderId}`),
    saveDocumentFolder: (projectSerial, data) =>
        api.call("post", apiConfig.prjDocsUrl + `/save-document-folder?projectSerial=${projectSerial}`, data),
    deleteDocumentFolder: (projectSerial, documentFolderSerial) =>
        api.call(
            "post",
            apiConfig.prjDocsUrl + `/delete-document-folder?projectSerial=${projectSerial}&documentFolderSerial=${documentFolderSerial}`
        ),
    moveToFolder: (documentSerial, folderId) =>
        api.call("post", apiConfig.prjDocsUrl + `/move-to-folder?documentSerial=${documentSerial}&folderId=${folderId}`),
};
