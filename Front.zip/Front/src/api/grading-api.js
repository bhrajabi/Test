import { api } from "./api";
import { apiConfig } from "./config";

export const gradingApi = {
    initGrading: (documentSerial, readOnly) =>
        api.call("post", `${apiConfig.GradingUrl}/init-grading?documentSerial=${documentSerial}&hideGrades=${readOnly}`),

    wfInitGrading: (documentSerial, readOnly, wfInstanceSerial) =>
        api.call("post", `${apiConfig.GradingUrl}/wf-init-grading?documentSerial=${documentSerial}&hideGrades=${readOnly}&wfInstanceSerial=${wfInstanceSerial}`),

    applyAlternativeVerification: (alternativeId, data, wfInstanceSerial = null) =>
        api.post(`/grading/apply-alternative-verification?alternativeId=${alternativeId}&wfInstanceSerial=${wfInstanceSerial}`, data),

    updateResponseScore: (alternativeId, contentSerial, score) =>
        api.post(`/grading/update-response-score?alternativeId=${alternativeId}&contentSerial=${contentSerial}&score=${score}`),
};
