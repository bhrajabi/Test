import axios from "axios";
import { notify } from "../components/basic/notify";
import { translate } from "../components/basic/text";
import { api } from "./api";
import { apiConfig } from "./config";

const MinFileSize = 0;
const MaxFileSize = 10 * 1024 * 1024 - 10;

export const attachmentApi = {
    getImage: (url) => {
        const withCredentials = true;
        const headers = { authorization: "Bearer " + api.getToken() };
        return axios.get(url, { responseType: "arraybuffer", withCredentials, headers });
    },

    download: (url, mobile = "") => {
        api.call("post", url, null)
            .then((reqId) => {
                //window.location.href = `${apiConfig.attachmentUrl}/download?id=${reqId}&mobile=${mobile}`;
                const url = `${apiConfig.attachmentUrl}/download?id=${reqId}&mobile=${mobile}`;
                window.open(url, "_blank");
            })
            .catch(notify.error);
    },

    downloadImage: (url, mobile = "") => {
        api.call("post", url, null)
            .then((reqId) => {
                const url = `${apiConfig.attachmentUrl}/download-image?id=${reqId}&mobile=${mobile}`;
                window.open(url);
            })
            .catch(notify.error);
    },

    attach: (url, target, params, file, onProgressChanged) => {
        const f = file ?? target.files[0];
        if (f.size < MinFileSize) {
            setTimeout(() => {
                if (target) target.value = "";
            }, 0);

            return Promise.reject(translate("file-is-empty"));
        }
        if (f.size > MaxFileSize) {
            setTimeout(() => {
                if (target) target.value = "";
            }, 0);

            return Promise.reject(translate("file-is-too-big"));
        }
        const form_data = new FormData();
        form_data.append("file", f);

        if (params) {
            for (const p in params) form_data.append(p, params[p]);
        }

        setTimeout(() => {
            if (target) target.value = "";
        }, 0);

        return api.call("post", url, form_data, { "Content-Type": "multipart/form-data" }, null, onProgressChanged);
    },
};
