import { WFInstance } from "../components/wf/workflow-types";
import { useApi } from "../pages/seller/home/api/use-api-call";

type GetFormInstanceDTO = {
    allowEdit: boolean;
    form: FormDTO;
    instance: FormInstanceDTO;
    values?: any; //FormInstanceValueDTO[];
    arguments: any;
    existActiveInstance?: boolean;
    existFormWorkflow?: boolean;
    formWFInstance?: WFInstance;
    hasReport: boolean;
};

export const useGetFormInstanceApi = (serial: number, formSerial: number) =>
    useApi<GetFormInstanceDTO>(
        `/form/get-form-instance?serial=${serial ?? ""}&formSerial=${formSerial}&r={r}&o={o}&scn={scn}&d={d}&p={p}`,
        { skipResult: true }
    );

export const useGetFormInstanceByWfInstanceApi = () =>
    useApi<GetFormInstanceDTO>("/form/wf-get-form-instance?wfInstanceSerial={wfInstanceSerial}");

export const useGetFormInstancesApi = (formSerial: number) =>
    useApi<{
        allowEdit: boolean;
        form: FormDTO;
        list: FormInstanceDTO[];
        arguments: any;
        existActiveInstance?: boolean;
        existFormWorkflow?: boolean;
        formWFInstance?: WFInstance;
    }>(`/form/get-form-instances?f=${formSerial ?? ""}&r={r}&o={o}&scn={scn}&d={d}&p={p}`);

export const useInitFormListApi = (formSerial: number) => useApi<{ form: FormDTO }>(`/form/init-form-list?serial=${formSerial}`);

export const useSaveFormInstanceApi = () =>
    useApi<{ instance: FormInstanceDTO; arguments: any }>("/form/save-form-instance?serial={serial}", { skipResult: true });

export const useApproveFormInstanceApi = () =>
    useApi<GetFormInstanceDTO>("/form/approve-form-instance?serial={serial}", { skipResult: true });

export const useDeleteFormInstanceApi = () => useApi("/form/delete-form-instance?serial={serial}", { skipResult: true });

export const usePrintFormInstanceApi = () => useApi("/form/print-form-request?serial={serial}", { skipResult: true });

export const useGetFromApi = (serial: number) => useApi<{ form: FormDTO }>(`/form/get-form?serial=${serial}`, { persist: false });
export const useSearchDesignFormApi = () => useApi<{ allowEdit: boolean; list: FormDTO[] }>("/form/search-forms");
export const useFormSaveDesignFormApi = (serial: number) =>
    useApi<{ form: FormDTO }>(`/form/save-form?serial=${serial}`, { skipResult: true });
export const useFormDeleteDesignFormApi = (serial: number) => useApi(`/form/delete-form?serial=${serial}`, { persist: false });

export type FormEditState = "VIEW" | "EDIT" | "INSERT";

//--------
export type FormRefDTO = {
    serial?: number;
    code?: string;
    title?: string;
    displayIn?: string;
    displayGroup?: string;
    instanceCount?: number;
};

export type FormDTO = {
    serial?: number;
    code?: string;
    title?: string;
    instanceTitleTemplate?: string;
    scope?: string;
    displayIn?: string;
    displayGroup?: string;
    sortOrder?: number;
    target?: string;
    instanceCount?: number;
    wfType?: string;
    jsonData?: string; // {fields:[{type:"TEXT"}, {...}]}
    filters?: string;
    isActive?: boolean;
    createdBy?: string;
    createdAt?: Date;
};

export type FormInstanceDTO = {
    serial?: number;
    title?: string;
    formSerial?: number;
    projectSerial?: number;
    documentSerial?: number;
    orderSerial?: number;
    requestSerial?: number;
    scenarioSerial?: number;
    sellerId?: number;
    statusId?: string;
    createdBy?: string;
    createdAt?: Date;
};

// export type FormInstanceValueDTO = {
//     name?: string;
//     value?: string;
// };

export type GridColumnTypes = "LABEL" | "TEXT" | "DATE" | "TOGGLE" | "";

export type GridColumnProps = {
    id: string;
    type: GridColumnTypes;

    name: string;
    title: string;
    width?: number;
    minWidth?: number;
    className?: string;
    readOnly?: boolean;
    validValues?: string; //"1=IR\r\nUSA"
};

export type FieldProps = {
    id: string;
    parenId?: string;
    type: "UPLOAD" | "VENDOR" | "LABEL" | "TEXT" | "DATE" | "TOGGLE" | "GRID" | "FLEX";
    name?: string;
    label?: string;
    title?: string;
    placeholder?: string;
    labelWidth?: number;
    className?: string;
    vertical?: boolean;
    content?: "center" | "start" | "end" | "between" | "around" | undefined;
    align?: "center" | "start" | "end" | "baseline" | "stretch" | undefined;
    gap?: number;
    maxWidth?: any;
    width?: any;
    height?: any;
    validTypes?: string;
    imageOnly?: boolean;
    readOnly?: boolean;
    visible?: boolean;
    multiLine?: boolean;
    rows?: number;
    validValues?: string; //"1=IR\r\nUSA"
    columns?: GridColumnProps[];
};
