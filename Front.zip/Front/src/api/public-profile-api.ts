import { ICommodity } from "../components/commodities/types";
import { useApi } from "../pages/seller/home/api/use-api-call";
import { ICompanyDTO } from "../types/company-dto";

export const usePublicProfileInitApi = () => useApi<PublicProfileDTO>(`/company/init-public-profile`);
export const useUpdateServiceDescription = () => useApi(`/company/update-company-service-description`);
export const useUpdateCompanyInfo = () => useApi<{ company: ICompanyDTO }>(`/company/update-company-info`);
export const useUpdateCompanyDescription = () => useApi(`/company/update-company-description`);
export const useUpdateCompanyContactInfo = () => useApi(`/company/update-contact-info?companyId={companyId}`);
export const useUpdateCompanyCommodities = () => useApi(`/company/update-company-commodities`);
export const useDeleteCompanyLoaction = () => useApi(`/company/delete-company-location?companyId={companyId}&serial={serial}`);
export const useSaveCompanyLoactions = () => useApi(`/company/save-company-locations?companyId={companyId}`);

export const useTogglePublicUser = () => useApi(`/company/toggle-public-person?userUniqueId={userUniqueId}&companyId={companyId}`);
export const useToggleEnablePublicProfile = () =>
    useApi<{ enablePublicProfile: boolean }>(`/company/toggle-enable-public-profile?uniqueId={uniqueId}`);

export type CompanyCurrency = {
    code: string;
    companyOwnerCanChange: boolean;
    editControl: string;
    title: string;
    value: string;
};

export type PublicProfileDTO = {
    company: ICompanyDTO;
    relation: RelationDTO;
    relationMessages: RelationMessagesDTO[];
    address: AddressDTO;
    addresses: AddressDTO[];
    defaultCurrency: CompanyCurrency;
    contactInfo: CompanyContactDTO;
    myContacts: ContactsDTO[];
    commodities: ICommodity[];
    companyProducts: CompanyProductDTO[];
    contacts: PublicContactDTO[];
    allowEdit: boolean;
    isNetworkAdmin: boolean;
    showAllUser?: boolean;
};

export type UpdateCompanyInfoDTO = {
    name2: string;
    shortName: string;

    countryId: string;
    stateId: string;
    city: string;
    postalCode: string;
};

export type PublicContactDTO = {
    uniqueId: string;

    userName: string;
    firstName: string;
    lastName: string;
    title: string;
    email: string;
    website: string;
    phoneNumber: string;
    workPhoneNumber: string;

    isPublicPerson: boolean;
    isConnected: boolean;
    isBlocked: boolean;
    isDisabled: boolean;

    displayOrder: number;
};

export type CompanyContactDTO = {
    tel1: string;
    tel2: string;
    fax: string;
    email: string;
    website: string;
};

export type CompanyProductDTO = {
    title: string;
    descriptions: string;
    price: number;
};

export interface CompanyProductPreviewDTO extends CompanyProductDTO {
    errorMessages: string[];
}

export type AddressDTO = {
    serial: number;
    countryId: string;
    stateId?: string;
    city?: string;
    address?: string;
    postalCode?: string;
    title?: string;
    addressLine1?: string;
    mobile?: string;
    phone?: string;
    fax?: string;
    email?: string;
    isMain?: boolean;
    isActive: boolean;
};

type RelationDTO = {
    buyerId: number;
    buyerUniqueId: string;
    projectSerial: number;
    avgScore?: number;
    grade: string;
    approvementStatus: string;
    description: string;
    isValid: boolean;
    createdAt: Date;
    createdByFullName: string;
    mainContactFullName: string;
};

type RelationMessagesDTO = {
    comment: string;
    isUnreadMessageNotified: boolean;
    sent: boolean;
    received: boolean;
    createdBy: string;
    createdAt: Date;
    fromUser: string;
    toUser: string;
    fromUserName: string;
    toUserName: string;
};

type ContactsDTO = {
    userName: string;
    firstName: string;
    lastName: string;
    displayName: string;
    nationalCode: string;
    email: string;
    phoneNumber: string;
    isDeleted: boolean;
    isDisabled: boolean;
    title: string;
    address: string;
    isConnected: boolean;
    isBlocked: boolean;
    uniqueId: string;
    lastUpdate: Date;
    createdAt: Date;
};
