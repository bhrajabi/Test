import { api } from "./api";
import { attachmentApi } from "./attachment-api";
import { apiConfig } from "./config";

export const ticketApi = {
    initAllTicketsByAuctionId: (auctionId) =>
        api.call("post", `${apiConfig.ticketUrl}/init-all-ticket-by-auction-id?auctionSerial=${auctionId}`),
    initAllTickets: () => api.call("post", `${apiConfig.ticketUrl}/init-all-ticket`),
    initTicket: (ticketSerial) => api.call("post", `${apiConfig.ticketUrl}/init-ticket?ticketSerial=${ticketSerial}`),
    downloadTicketAttachment: (serial, id) =>
        attachmentApi.download(apiConfig.ticketUrl + `/download-ticket-attachment?serial=${serial}&id=${id}`),
    addTicketMessage: (ticketSerial, message) =>
        api.call("post", `${apiConfig.ticketUrl}/add-ticket-message?ticketSerial=${ticketSerial}&message=${message}`),
};
