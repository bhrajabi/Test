import { IkcoIpgFilterTransactionDTO } from "../pages/home/dashboard/ikco-ipg/types/ikco-ipg-filter-transaction-dto";
import { api } from "./api";
import { apiConfig } from "./config";

export const ikcoIpgTransactionApi = {
    filtertransactions: (fromIndex: number, model: IkcoIpgFilterTransactionDTO) =>
        api.call("post", `${apiConfig.IKCOIpgUrl}/filter-transactions?fromIndex=${fromIndex}`, model),
    initPaymentGateways: (terminalId: string) => api.call("post", `${apiConfig.IKCOIpgUrl}/init-payment-gateways?terminalId=${terminalId}`),
    initTransactions: () => api.call("post", `${apiConfig.IKCOIpgUrl}/init-transactions`),
    initTransactionLogs: (serial: number) => api.call("post", `${apiConfig.IKCOIpgUrl}/init-transaction-logs?transactionSerial=${serial}`),
    inquiryTransaction: (serial: number) => api.call("post", `${apiConfig.IKCOIpgInquiry}/inquiry-transaction?transactionSerial=${serial}`),

    uninquiredTransactions: () => api.call("post", `${apiConfig.IKCOIpgInquiry}/uninquired-transactions`),

    getTransactionLogs: (fromIndex: number, data: any) =>
        api.call("post", `${apiConfig.IKCOIpgUrl}/get-transaction-logs?fromIndex=${fromIndex}`, data),

    updateTransactionLogs: (data: any) => api.call("post", `${apiConfig.IKCOIpgUrl}/update-transaction-logs`, data),
};
