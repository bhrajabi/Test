import { api } from "./api";
import { attachmentApi } from "./attachment-api";
import { apiConfig } from "./config";

export const shipmentApi = {
    initShipment: (serial, shipmentSerial, items) =>
        api.call("post", `${apiConfig.shipmentUrl}/init-shipment?orderSerial=${serial}&shipmentSerial=${shipmentSerial}&items=${items}`),

    saveShipment: (serial, data) => api.call("post", `${apiConfig.shipmentUrl}/save-shipment?orderSerial=${serial}`, data),

    initEditShipment: (serial, shipmentSerial) =>
        api.call("post", `${apiConfig.shipmentUrl}/init-edit-shipment?orderSerial=${serial}&shipmentSerial=${shipmentSerial}`),

    editShipment: (serial, shipmentSerial, data) =>
        api.call("post", `${apiConfig.shipmentUrl}/edit-shipment?orderSerial=${serial}&shipmentSerial=${shipmentSerial}`, data),

    getSellerOpenOrders: () => api.call("post", `${apiConfig.shipmentUrl}/get-seller-open-orders`),

    getMaterialPackaging: () => api.call("post", `${apiConfig.shipmentUrl}/get-material-packaging`),

    getHuPackaging: (orderSerial, data) => api.call("post", `${apiConfig.shipmentUrl}/get-hu-packaging?orderSerial=${orderSerial}`, data),

    shipmentList: (statusId) => api.call("post", `${apiConfig.shipmentUrl}/shipment-list?statusId=${statusId}`),

    //
    uploadAttachment: (e) => attachmentApi.attach(apiConfig.shipmentUrl + "/upload-attachment", e.target),
    downloadAttachment: (attachmentId) =>
        attachmentApi.download(apiConfig.shipmentUrl + "/download-attachment?attachmentId=" + attachmentId),
    removeAttachment: (attachmentId) => api.call("post", apiConfig.shipmentUrl + "/remove-attachment?attachmentId=" + attachmentId),
    //

    getShipmentItems: (data, fromIndex) => api.call("post", `${apiConfig.shipmentUrl}/get-shipment-report?fromIndex=${fromIndex}`, data),
};
