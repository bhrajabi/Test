import { api } from "./api";
import { attachmentApi } from "./attachment-api";
import { apiConfig } from "./config";

export const auctionMeetingApi = {
    initEdit: (meetingSerial) => api.call("post", apiConfig.auctionMeetingsUrl + `/init-edit?meetingSerial=${meetingSerial}`),

    initMonitoringMeeting: (meetingSerial) =>
        api.call("post", apiConfig.auctionMeetingsUrl + `/init-meeting-monitoring?meetingSerial=${meetingSerial}`),

    initCreateMeeting: () => api.call("post", apiConfig.auctionMeetingsUrl + `/init-create-cnf`),

    initMeeting: (auctionId, meetingType) =>
        api.call("post", apiConfig.auctionMeetingsUrl + `/init-meeting?auctionId=${auctionId}&meetingType=${meetingType}`),

    initAllMeeting: (meetingType) => api.call("post", apiConfig.auctionMeetingsUrl + `/init-all-meeting?meetingType=${meetingType}`),

    getDraft: (auctionId) => api.call("post", apiConfig.auctionMeetingsUrl + `/get-draft?auctionId=${auctionId}`),

    addMeeting: (auctionId, draftId, values) =>
        api.call("post", apiConfig.auctionMeetingsUrl + `/add-meeting?auctionId=${auctionId}&draftId=${draftId}`, values),

    updateMeeting: (auctionId, draftId, values) =>
        api.call("post", apiConfig.auctionMeetingsUrl + `/update-meeting?auctionId=${auctionId}&draftId=${draftId}`, values),

    saveMeeting: (values, draftId) => api.call("post", apiConfig.auctionMeetingsUrl + `/save-meeting?draftId=${draftId}`, values),

    deleteMeeting: (auctionId, meetingSerial) =>
        api.call("post", apiConfig.auctionMeetingsUrl + `/delete-meeting?auctionId=${auctionId}&meetingSerial=${meetingSerial}`),
    deleteCnf: (meetingSerial) => api.call("post", apiConfig.auctionMeetingsUrl + `/delete-cnf?meetingSerial=${meetingSerial}`),

    closeMeeting: (auctionId, meetingSerial) =>
        api.call("post", apiConfig.auctionMeetingsUrl + `/close-meeting?auctionId=${auctionId}&meetingSerial=${meetingSerial}`),

    duplicateMeeting: (auctionId, meetingSerial) =>
        api.call("post", apiConfig.auctionMeetingsUrl + `/duplicate-meeting?auctionId=${auctionId}&meetingSerial=${meetingSerial}`),

    uploadAttachment: (e, meetingType, auctionId, draftId) =>
        attachmentApi.attach(
            apiConfig.auctionMeetingsUrl +
                `/upload-meeting-attachment?auctionId=${auctionId}&meetingType=${meetingType}&draftId=${draftId}`,
            e.target
        ),

    downloadAttachment: (id, auctionId, meetingSerial) =>
        attachmentApi.download(
            apiConfig.auctionMeetingsUrl + `/download-request?id=${id}&auctionId=${auctionId}&meetingSerial=${meetingSerial}`
        ),

    removeAttachment: (attachmentId, meetingSerial, auctionId) =>
        api.call(
            "post",
            apiConfig.auctionMeetingsUrl + `/remove-attachment?id=${attachmentId}&auctionId=${auctionId}&meetingSerial=${meetingSerial}`
        ),

    uploadCNFAttachment: (e, meetingType, serial, draftId) =>
        attachmentApi.attach(
            apiConfig.auctionMeetingsUrl + `/upload-cnf-attachment?serial=${serial}&meetingType=${meetingType}&draftId=${draftId}`,
            e.target
        ),

    downloadCNFAttachment: (id, meetingSerial) =>
        attachmentApi.download(
            apiConfig.auctionMeetingsUrl + `/download-cnf-attachment?attachmentId=${id}&&meetingSerial=${meetingSerial}`
        ),

    removeCNFAttachment: (attachmentId, meetingSerial) =>
        api.call("post", apiConfig.auctionMeetingsUrl + `/remove-cnf-attachment?id=${attachmentId}&meetingSerial=${meetingSerial}`),

    searchItems: (meetingSerial, data) =>
        api.call("post", apiConfig.cnfAuctionMeetingsUrl + `/search-items?meetingSerial=${meetingSerial}`, data),

    deleteCnfItem: (meetingSerial, referenceKey) =>
        api.call("post", apiConfig.cnfAuctionMeetingsUrl + `/delete-cnf-item?meetingSerial=${meetingSerial}&referenceKey=${referenceKey}`),
    initConfirmationDocuments: (auctionId) =>
        api.call("post", apiConfig.cnfAuctionMeetingsUrl + `/init-cnf-meetings?auctionId=${auctionId}`),
    changeStatus: (auctionId, status) =>
        api.call("Post", apiConfig.cnfAuctionMeetingsUrl + `/change-document-status?auctionId=${auctionId}&status=${status}`),
};
