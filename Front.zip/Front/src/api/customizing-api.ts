import { ChartUserRoles } from "../pages/company/organization-charts/chart-types";
import { api } from "./api";
import { attachmentApi } from "./attachment-api";
import { apiConfig } from "./config";

export const customizingApi = {
    initCustomizing: () => api.call("post", apiConfig.customizingUrl + `/init-customizing`),
    getDataTable: (tableName: string) => api.call("post", apiConfig.customizingUrl + `/get-data-table?tableName=${tableName}`),
    saveRow: (tableName: string, insertMode: boolean, data: any) =>
        api.call("post", apiConfig.customizingUrl + `/save-row?tableName=${tableName}&insertMode=${insertMode}`, data),
    deleteRow: (tableName: string, data: any) => api.call("post", apiConfig.customizingUrl + `/delete-row?tableName=${tableName}`, data),

    initCompanySettings: () => api.call("post", apiConfig.customizingUrl + `/init-settings`),
    saveCompanySettings: (data: any) => api.call("post", apiConfig.customizingUrl + `/save-setting`, data),

    initAddressList: (usage: string) => api.call("post", `${apiConfig.customizingUrl}/init-address-list?usage=${usage}`),
    saveAddress: (data: any) => api.call("post", `${apiConfig.customizingUrl}/save-address`, data),
    saveAddressAttachment: (addressSerial: number, e: any) =>
        attachmentApi.attach(`${apiConfig.customizingUrl}/save-address-attachment?addressSerial=${addressSerial}`, e.target),
    deleteAddress: (serial: number) => api.call("post", `${apiConfig.customizingUrl}/delete-address?serial=${serial}`),

    initWFRoles: () => api.call("post", `${apiConfig.customizingUrl}/init-work-flow-roles`),
    saveWFRoles: (data: any) => api.call("post", `${apiConfig.customizingUrl}/save-work-flow-roles`, data),
    deleteWFRoles: (id: string) => api.call("post", `${apiConfig.customizingUrl}/delete-work-flow-roles?id=${id}`),

    initEventCategory: () => api.call("post", `${apiConfig.customizingUrl}/init-event-category`),
    saveEventCategory: (data: any) => api.call("post", `${apiConfig.customizingUrl}/save-event-category`, data),
    deleteEventCategory: (id: string) => api.call("post", `${apiConfig.customizingUrl}/delete-event-category?id=${id}`),

    initConfirmationCategories: () => api.call("post", `${apiConfig.customizingUrl}/init-confirmation-categories`),
    saveConfirmationCategories: (data: any) => api.call("post", `${apiConfig.customizingUrl}/save-confirmation-categories`, data),
    deleteConfirmationCategories: (id: string) => api.call("post", `${apiConfig.customizingUrl}/delete-confirmation-categories?id=${id}`),

    initWorkFlowActions: () => api.call("post", `${apiConfig.customizingUrl}/init-work-flow-actions`),
    saveWorkFlowActions: (data: any) => api.call("post", `${apiConfig.customizingUrl}/save-work-flow-actions`, data),
    deleteWorkFlowActions: (id: string) => api.call("post", `${apiConfig.customizingUrl}/delete-work-flow-actions?id=${id}`),

    initWFGroups: () => api.call("post", `${apiConfig.customizingUrl}/init-work-flow-groups`),
    saveWFGroups: (data: any) => api.call("post", `${apiConfig.customizingUrl}/save-work-flow-groups`, data),
    deleteWFGroups: (data: any) => api.call("post", `${apiConfig.customizingUrl}/delete-work-flow-groups`, data),

    /***********/
    initOrgChart: () => api.call("post", `${apiConfig.baseUrl}/orgchart/init-org-chart`),

    deleteOrgChart: (serial: number, comment: string) =>
        api.call("post", `${apiConfig.baseUrl}/orgchart/delete-org-chart?serial=${serial}&comment=${comment}`),

    saveOrgChart: (data: any) => api.call("post", `${apiConfig.baseUrl}/orgchart/save-org-chart`, data),

    restoreOrgChart: (serial: number) => api.call("post", `${apiConfig.baseUrl}/orgchart/restore-org-chart?serial=${serial}`),

    /////
    getOrgChartUserRoles: (chartSerial: number) =>
        api.call("post", `${apiConfig.baseUrl}/orgchart/get-org-chart-user-roles?chartSerial=${chartSerial}`),

    insertOrgChartUserRole: (ChartSerial: number, roleId: string, userName: string) =>
        api.call("post", `${apiConfig.baseUrl}/orgchart/insert-org-chart-user-role`, { ChartSerial, userName, roleId }),

    deleteOrgChartUserRoles: (serial: number, comment: string) =>
        api.call("post", `${apiConfig.baseUrl}/orgchart/delete-org-chart-user-roles?serial=${serial}&comment=${comment}`),

    restoreOrgChartUserRoles: (serial: number) =>
        api.call("post", `${apiConfig.baseUrl}/orgchart/restore-org-chart-user-roles?serial=${serial}`),

    initExternalApi: () => api.call("post", `${apiConfig.customizingUrl}/init-external-api`),
    saveExternalApi: (data: any) => api.call("post", `${apiConfig.customizingUrl}/save-external-api`, data),
    deleteExternalApi: (serial: number) => api.call("post", `${apiConfig.customizingUrl}/delete-external-api?serial=${serial}`),

    initExchangeRate: () => api.call("post", `${apiConfig.customizingUrl}/init-exchange-rate`),
    saveExchangeRate: (data: any) => api.call("post", `${apiConfig.customizingUrl}/save-exchange-rate`, data),
    deleteExchangeRate: (currencyId: string) =>
        api.call("post", `${apiConfig.customizingUrl}/delete-exchange-rate?currencyId=${currencyId}`),

    initSmsTemplates: () => api.call("post", `${apiConfig.customizingUrl}/init-sms-template`),
    saveSmsTemplates: (data: any) => api.call("post", `${apiConfig.customizingUrl}/save-sms-template`, data),
    deleteSmsTemplates: (code: string) => api.call("post", `${apiConfig.customizingUrl}/delete-sms-template?code=${code}`),

    downloadFile: (attachmentId: string) => {
        attachmentApi.download(`${apiConfig.customizingUrl}/download-attachment?attachmentId=${attachmentId}`);
    },

    removeAttachment: (code: string) => {
        api.call("post", `${apiConfig.customizingUrl}/remove-attachment?code=${code}`);
    },

    initConditions: () => api.call("post", `${apiConfig.customizingUrl}/init-conditions`),
    saveConditions: (data: any) => api.call("post", `${apiConfig.customizingUrl}/save-conditions`, data),
    deleteConditions: (code: string) => api.call("post", `${apiConfig.customizingUrl}/delete-conditions?code=${code}`),
};
