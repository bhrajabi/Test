import { api } from "./api";
import { apiConfig } from "./config";

export const projectMemberApi = {
    initprojectMembers: (projectSerial) =>
        api.call("post", `${apiConfig.projectMemberUrl}/init-project-members?projectSerial=${projectSerial}`),

    saveProjectMember: (data) => api.call("post", `${apiConfig.projectMemberUrl}/save-project-member`, data),

    deleteProjectMember: (data) => api.call("post", `${apiConfig.projectMemberUrl}/delete-project-member`, data),
};
