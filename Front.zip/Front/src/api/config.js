import { code } from "../components/basic/code";

//const port = "5001";
const port = "44346"; //proxy port

//B2C Port
const auctionPort = "3003";

const host = code.isDevelopmentEnv()
    ? // ipn back url
    "https://localhost:" + port
    : code.isIPNTestEnv()
        ? "https://wsIPNTest.ikco.ir"
        : code.isIPNStgEnv()
            ? "https://wsIPNStg.ikco.ir"
            : code.isIPNSecEnv()
                ? "http://wsIPNTest.ikco.sec"
                : code.isIPNProductionEnv()
                    ? "https://wsIPN.ikco.ir"
                    : "";

//B2C Host
const auctionHost = code.isDevelopmentEnv()
    ? "https://localhost:" + auctionPort
    : code.isTestEnv()
        ? "https://inquirytest.ikco.ir"
        : code.isStgEnv()
            ? "https://inquirystg.ikco.ir"
            : code.isSecEnv()
                ? "https://inquirySEC.ikco.ir"
                : code.isProductionEnv()
                    ? "https://inquiry.ikco.ir"
                    : "";

export const apiConfig = {
    host: host,
    localeUrl: host,
    inquiryUrl: auctionHost,
    //localeUrl: "",
    baseUrl: host,
    linkShortenerUrl: host + "/link-shortener",
    accountUrl: host + "/authentication",
    smsUrl: host + "/sms",
    companyComposersUrl: host + "/companyComposers",
    gridsUrl: host + "/grids",
    GradingUrl: host + "/grading",
    ScenariogUrl: host + "/scenario",
    AwardUrl: host + "/award",
    AddressUrl: host + "/address",
    networkUrl: host + "/network",
    aprocUrl: host + "/aproc",
    wfUrl: host + "/wf",
    notificationUrl: host + "/notificaton",
    dashboardUrl: host + "/dashboard",
    suppliersUrl: host + "/suppliermanagement",
    suppliersExportToExcelDownloadUrl: host + "/suppliermanagement/export-to-excel",

    erpSrviceUrl: host + "/erp-service",
    documentSupplierUrl: host + "/documentsupplier",
    documentSupplierDiscoveryReportUrl: host + "/documentsupplier/supplier-discovery-report",
    documentSuppliersReportUrl: host + "/documentsupplier/supplier-report",
    attachmentUrl: host + "/attachment",
    auctionAttachmentUrl: host + "/auction-attachment",
    companyLogoUrl: host + "/company/logo",
    companyBannerUrl: host + "/company/banner",
    zuserImageUrl: host + "/company/zuser-image",
    companyUrl: host + "/company",
    companyProductsUrl: host + "/company-products",
    publicCompanyUrl: host + "/public-company",
    findSupplierUrl: host + "/findSupplier",
    projectUrl: host + "/project",
    auctionRuleUrl: host + "/auction-rule",
    teamUrl: host + "/team",
    workingGroupUrl: host + "/working-group",
    projectMemberUrl: host + "/project-member",
    commodityUrl: host + "/commodity",
    relationUrl: host + "/relation",
    supplierRelationUrl: host + "/supplier-relation",
    eventUrl: host + "/event",
    eventReportUrl: host + "/event/download-print-scenario",
    rfxUrl: host + "/rfx",
    plantsUrl: host + "/plants",
    locationUrl: host + "/location",
    documentUrl: host + "/documents",
    orderConfirmationReportUrl: host + "/order/download-print-order-confirmation",
    prjDocsUrl: host + "/prjdocs",
    projectTaskUrl: host + "/projecttask",
    userlogsUrl: host + "/userlogs",
    sourcingReports: host + "/report",
    evaluationRequestsUrl: host + "/evaluation-requests",
    reportErrorUrl: host + "/report-error",
    evaluationRequestsDownloadExcelUrl: host + "/evaluation-requests/download-vendors-excel",
    eventRuleUrl: host + "/event-rule",
    logsUrl: host + "/log",
    contractUrl: host + "/contract",
    documentContentUrl: host + "/document-content",
    contentUrl: host + "/content",
    contentReportUrl: host + "/content/download-report",
    downloadReportAndAttachmentsUrl: host + "/content/download-report-and-attachments",
    contentResponseReportUrl: host + "/content/download-content-response-report",
    spqUrl: host + "/spq",
    registrationRequestUrl: host + "/reg-req",
    spqDocumentUrl: host + "/spq-documents",
    discoveryUrl: host + "/discovery",
    discoveryEventReportUrl: host + "/discovery/event-discovery-report",
    masterDataUrl: host + "/masterdata",
    customizingUrl: host + "/customizing",
    smsRequestUrl: host + "/sms-request",
    auctionSmsRequestUrl: host + "/auction-message",
    envelopeUrl: host + "/envelope",
    auctionEnvelopeUrl: host + "/auction-envelope",
    materialUrl: host + "/material",
    businessPartnerUrl: host + "/business-partner",
    orderUrl: host + "/order",
    supplierResponseAttachment: host + "/supplier-response-attachment",
    orderInfoRecordUrl: host + "/order-info-record",
    sellerOrderUrl: host + "/seller-order",
    shipmentUrl: host + "/shipment",
    startUpUrl: host + "/startup",
    cnfUrl: host + "/cnf",
    recentsUrl: host + "/recents",
    userRecentsUrl: host + "/userRecents",
    reqUrl: host + "/req",
    reqCommodityUrl: host + "/req-commodity",
    cycleTimeUrl: host + "/cycle-time",
    reportUrl: host + "/report",
    categoriesUrl: host + "/categories",
    meetingsUrl: host + "/meeting",
    auctionMeetingsUrl: host + "/auction-meeting",
    cnfMeetingsUrl: host + "/cnf-meeting",
    chatUrl: host + "/chat",
    ChatImageDownloadUrl: host + "/chat/download-attachment",
    messagingUrl: host + "/messaging",
    adminMessagingUrl: host + "/admin-messaging",
    eventMessagingUrl: host + "/event-messaging",
    cnfAuctionMeetingsUrl: host + "/auction-cnf-meeting",

    auctionAttributeUrl: host + "/auction-attribute",
    projectContactUrl: host + "/project-contact",
    auctionContactUrl: host + "/auction-contact",
    auctionContentUrl: host + "/auction-content",
    auctionUrl: host + "/auction",
    IpgsUrl: host + "/ipgs",
    IKCOIpgUrl: host + "/ikco-ipg",
    IKCOIpgTestPaymentUrl: host + "/ipg-test-payment",
    IKCOIpgTerminals: host + "/ikco-ipg-terminals",
    IKCOIpgInquiry: host + "/ikco-ipg-inquiry",
    ticketUrl: host + "/tickets",
    freightUnit: host + "/freightunit",
    sourcingUrl: host + "/sourcing",

    companyReportsUrl: host + "/companyreports",
    downloadDocumentMessageAttachmentUrl: host + "/download-msg-attachment",

    serviceWorkerUrl: host + "/sw",
    workFlowUrl: host + "/workFlow",
    discoveryItemUrl: host + "/discovery-item",
    confirmationUrl: host + "/confirmation",
    materialPackagingUrl: host + "/material-packaging",
    publicEventUrl: host + "/public-event",
    formUrl: host + "/form",
};
