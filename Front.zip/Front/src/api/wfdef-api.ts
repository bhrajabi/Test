import { WFLink, WFNode, Workflow } from "../components/wf/workflow-types";
import { api } from "./api";
import { apiConfig } from "./config";

export const wfDefApi = {
    initWorkflowList: () => api.call("post", `${apiConfig.baseUrl}/wfdef/init-wf-list`),

    getWorkflowData: (wfSerial: number) => api.call("post", `${apiConfig.baseUrl}/wfdef/get-wf-data?wfSerial=${wfSerial}`),

    deleteWorkflow: (wfSerial: number) => api.call("post", `${apiConfig.baseUrl}/wfdef/delete-wf?wfSerial=${wfSerial}`),

    saveWorkflow: (workflow: Workflow, clone: boolean) => api.call("post", `${apiConfig.baseUrl}/wfdef/save-wf`, { workflow, clone }),

    saveWorkflowData: (wfSerial: number, nodes: WFNode[], links: WFLink[]) =>
        api.call("post", `${apiConfig.baseUrl}/wfdef/save-wf-data?wfSerial=${wfSerial}`, { nodes, links }),
};
