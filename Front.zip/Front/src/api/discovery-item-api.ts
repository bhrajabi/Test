import { DiscoveryItemDTO } from "../types/discovery-item-dto";
import { DiscoveryItemFilterView } from "../types/discovery-item-filter-view-dto";
import { DiscoveryItemMemberDTO } from "../types/discovery-item-member-dto";
import { api } from "./api";
import { attachmentApi } from "./attachment-api";
import { apiConfig } from "./config";

export const discoveryItemApi = {
    initDiscoveryItem: (discoverySerial: number) =>
        api.call("post", apiConfig.discoveryItemUrl + `/init?discoverySerial=${discoverySerial}`),

    initDiscovery: (serial: number) => api.call("post", apiConfig.discoveryItemUrl + `/init-discovery-item?serial=${serial}`),

    filterDiscoveryItem: (discoverySerial: number, dto: DiscoveryItemFilterView) =>
        api.call("post", apiConfig.discoveryItemUrl + `/filter?discoverySerial=${discoverySerial}`, dto),
    saveChanges: (dto: DiscoveryItemDTO, draftId: number) =>
        api.call("post", apiConfig.discoveryItemUrl + `/save-changes?draftId=${draftId ?? 0}`, dto),
    delete: (serial: number) => api.call("post", apiConfig.discoveryItemUrl + `/delete?serial=${serial}`),

    removeAttachment: (attachmentId: number) => api.call("post", apiConfig.discoveryItemUrl + `/remove-attachment?id=${attachmentId}`),

    downloadAttachment: (attachmentId: number) => {
        attachmentApi.download(apiConfig.discoveryItemUrl + `/download-discovery-item-attachment?attachmentId=${attachmentId}`);
    },

    addDiscoveryItemMember: (dto: DiscoveryItemMemberDTO) =>
        api.call("post", apiConfig.discoveryItemUrl + `/add-discovery-item-member`, dto),
    initDiscoveryItemMembers: (discoveryItemSerial: number) =>
        api.call("post", apiConfig.discoveryItemUrl + `/init-discovery-item-members?discoveryItemSerial=${discoveryItemSerial}`),
    deleteDiscoveryItemMember: (dto: DiscoveryItemMemberDTO) =>
        api.call("post", apiConfig.discoveryItemUrl + `/delete-discovery-item-member`, dto),
    toggleRequest: (serial: number) => api.call("post", apiConfig.discoveryItemUrl + `/toggle-request?serial=${serial}`),
};
