import { api } from "./api";
import { attachmentApi } from "./attachment-api";
import { apiConfig } from "./config";

export const projectApi = {
    initExpiringProjects: (days) => api.post(`/project/init-expiring-projects?days=${days}`),

    initCreate: (projectTypeId, eventTypeId, parent, sr) =>
        api.post(`/project/init-create?eventTypeId=${eventTypeId}&projectTypeId=${projectTypeId}&parentSerial=${parent}&sr=${sr}`),

    initEditProject: (projectSerial) => api.post(`/project/init-edit-project?projectSerial=${projectSerial}`),

    getProjectFormData: (serial) => api.post(`/project/get-project-form-data?serial=${serial}`),

    createProject: (data, sr) => api.post(`/project/create-project?sr=${sr}`, data),

    saveProject: (data) => api.post("/project/save-project", data),

    saveProjectInfo: (serial, data) => api.post(`/project/save-project-info?serial=${serial}`, data),

    updateProject: (data) => api.post("/project/save-project-info", data),

    updateProjectOwner: (serial, userName, workingGroupSerial) =>
        api.post(`/project/update-project-owner?projectSerial=${serial}&owner=${userName}&workingGroupSerial=${workingGroupSerial}`),

    deleteProject: (serial) => api.post("/project/delete-project?serial=" + serial),

    deleteAuctionProject: (serial) => api.post("/project/delete-auction-project?projectSerial=" + serial),

    //publishTemplate: (projectSerial, status) => api.post(`/project/change-project-status?serial=${projectSerial}&status=${status}`),

    markProjectAs: (serial, status) => api.post(`/project/change-project-status?serial=${serial}&status=${status}`),

    getTasks: (projectSerial, actionId, documentSerial) =>
        api.post(`/project/get-tasks?projectSerial=${projectSerial}&actionId=${actionId}&documentSerial=${documentSerial}`),

    initProjectFlow: (projectSerial) => api.post("/project/init-project-flow?projectSerial=" + projectSerial),

    initProjectTeam: (serial) => api.post(`/project/init-project-team?serial=${serial}`),

    initProject: (serial) => api.post(`/project/init-project-data?serial=${serial}`),

    getProjectLogo: (projectSerial) => api.call("post", `${apiConfig.projectUrl}/get-project-logo?projectSerial=${projectSerial}`),

    uploadProjectLogo: (e, projectSerial, typeId) =>
        attachmentApi.attach(apiConfig.projectUrl + `/upload-project-logo?projectSerial=${projectSerial}&typeId=${typeId}`, e.target),

    removeProjectLogo: (projectSerial, attachmentId) =>
        api.call("post", apiConfig.projectUrl + `/remove-project-logo?projectSerial=${projectSerial}&id=${attachmentId}`),

    projectAProcList: (projectSerial) => api.call("post", apiConfig.projectUrl + `/get-project-aproc-list?projectSerial=${projectSerial}`),

    changeProjectAproc: (projectSerial, action, aprocSerial) =>
        api.call(
            "post",
            apiConfig.projectUrl + `/change-project-aproc?projectSerial=${projectSerial}&aprocAction=${action}&aprocSerial=${aprocSerial}`
        ),
};
