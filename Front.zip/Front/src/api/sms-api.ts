import { api } from "./api";
import { apiConfig } from "./config";

export const smsApi = {
    initUserReferral: () => api.call("post", `${apiConfig.smsUrl}/init-user-referral`),

    sendReferralMessage: (userPhoneNumber: string) =>
        api.call("post", `${apiConfig.smsUrl}/send-referral-message?phone=${userPhoneNumber}`),

    initMessages: () => api.call("post", `${apiConfig.smsUrl}/init-send-sms`),

    getMessagesByMobile: (mobileNumber: string) =>
        api.call("post", `${apiConfig.smsUrl}/get-messages-by-mobile?mobileNumber=${mobileNumber}`),

    sendSmsToUser: (mobileNumber: string, data: any) =>
        api.call("post", `${apiConfig.smsUrl}/send-sms-to-user?mobileNumber=${mobileNumber}`, data),

    getMessagesByUser: (fromIndex: number) => api.call("post", `${apiConfig.smsUrl}/get-user-sms?fromIndex=${fromIndex}`),
};
