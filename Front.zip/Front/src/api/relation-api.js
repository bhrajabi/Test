import { api } from "./api";
import { apiConfig } from "./config";

export const relationsApi = {
    initRelation: (sellerId) => api.call("Post", apiConfig.supplierRelationUrl + `/init-relation?sellerId=${sellerId}`),
    addRelation: (dto) => api.call("Post", apiConfig.supplierRelationUrl + `/add-supplier-relation`, dto),
    updateRelation: (dto) => api.call("Post", apiConfig.supplierRelationUrl + `/update-supplier-relation`, dto),
    autoUpdateCompanyInfo: (companyId) => api.call("Post", apiConfig.supplierRelationUrl + `/auto-update-company-info?id=${companyId}`),
    cancelRelation: (dto) => api.call("Post", apiConfig.supplierRelationUrl + `/cancel-relation`, dto),
    sendMessage: (dto) => api.call("Post", apiConfig.relationUrl + `/send-message`, dto),
    markAsRead: (dto) => api.call("Post", apiConfig.relationUrl + `/mark-as-read`, dto),
    initMessages: (relationProjectSerial) =>
        api.call("Post", apiConfig.relationUrl + `/init-messages?relationProjectSerial=${relationProjectSerial}`),

    udpateRelations: (dto) => api.call("Post", apiConfig.relationUrl + `/udpate-relations`, dto),

};
