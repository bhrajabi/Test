import { ICommodity } from '../components/commodities/types';
import { api } from './api';
import { attachmentApi } from './attachment-api';
import { apiConfig } from './config';
import { FormRefDTO } from './form-api';

export const requestApi = {
    initRequestMonitor: (projectSerial: number) => api.call('post', `${apiConfig.reqUrl}/init-request-monitor?p=${projectSerial}`),

    reloadRequestData: (projectSerial: number) => api.call('post', `${apiConfig.reqUrl}/reload-request-data?p=${projectSerial}`),

    saveRequestCommodities: (documentSerial: number, commodities: string[]) =>
        api.call('post', `${apiConfig.reqUrl}/save-request-commodities?d=${documentSerial}`, { commodities }),

    createRfpDocument: (projectSerial: number) => api.call('post', `${apiConfig.reqUrl}/create-rfp-doc?p=${projectSerial}`),

    deleteRfpDoc: (documentSerial: number) => api.call('post', `${apiConfig.reqUrl}/delete-rfp-doc?d=${documentSerial}`),

    updateRfpTitle: (projectSerial: number, data: any) => api.call('post', `${apiConfig.reqUrl}/update-rfp-title?s=${projectSerial}`, data),

    //--
    initRequest: (projectSerial: number) => api.call('post', `${apiConfig.reqUrl}/init-request?serial=${projectSerial}`),

    searchRequestByNumber: (number: string) => api.call('post', `${apiConfig.reqUrl}/get-request-by-number?number=${number}`),

    importPr: (number: string) => api.call('post', `${apiConfig.reqUrl}/import-pr?number=${number}`),

    recentPR: () => api.call('post', `${apiConfig.reqUrl}/init-recent-reqeust`),

    initCreate: () => api.call('post', `${apiConfig.reqUrl}/init-create-request`),

    createRequest: (data: any) => api.call('post', apiConfig.reqUrl + `/create-request`, data),

    initEdit: (projectSerial: number) => api.call('post', `${apiConfig.reqUrl}/init-edit-request?serial=${projectSerial}`),

    editRequest: (data: any, projectSerial: number) =>
        api.call('post', apiConfig.reqUrl + `/edit-request?projectSerial=${projectSerial}`, data),

    updateRequest: (data: any) => api.call('post', apiConfig.reqUrl + `/update-request`, data),

    initSearchRequestItems: () => api.call('post', apiConfig.reqUrl + `/init-search-request-items`),

    initSearchRequests: () => api.call('post', apiConfig.reqUrl + `/init-search-request`),

    getMyItems: (data: any) => api.call('post', apiConfig.reqUrl + `/get-my-items`, data),

    getMyRequests: (data: any) => api.call('post', apiConfig.reqUrl + `/get-my-requests`, data),

    getAssignedItems: (serial: number) => api.call('post', apiConfig.reqUrl + `/get-assigned-items?projectSerial=${serial}`),

    assignItems: (data: any) => api.call('post', apiConfig.reqUrl + `/save-assigned-items`, data),

    removeAssignedItems: (data: any) => api.call('post', apiConfig.reqUrl + `/remove-assigned-items`, data),

    getReuestItemsByDocSerial: (docSerial: number) =>
        api.call('post', apiConfig.reqUrl + `/get-request-items-by-document-serial?documentSerial=${docSerial}`),

    rejectitems: (data: any) => api.call('post', apiConfig.reqUrl + `/reject-items`, data),

    getProjectsAndDocs: (reqItemsSerial: number) =>
        api.call('post', apiConfig.reqUrl + `/get-docs-and-projects?requestItemSerial=` + reqItemsSerial),

    requestRelations: (docSerial: number) =>
        api.call('post', apiConfig.reqUrl + `/request-relatrions-by-document-serial?documentSerial=` + docSerial),

    closeRequest: (requestSerial: number) => api.call('post', apiConfig.reqUrl + `/close-request?requestSerial=` + requestSerial),

    unCloseRequest: (requestSerial: number) => api.call('post', apiConfig.reqUrl + `/un-close-request?requestSerial=` + requestSerial),

    // changeSourcingType: (requestSerial, sourcingType) =>
    //     api.call("post", apiConfig.reqUrl + `/change-request-sourcing-type?requestSerial=${requestSerial}&sourcingType=${sourcingType}`),

    initSourcingDocuments: (requestSerial: number) =>
        api.call('post', apiConfig.reqUrl + `/init-sourcing-documents?requestSerial=${requestSerial}`),

    downloadAttachment: (serial: number, id: number) =>
        attachmentApi.download(apiConfig.reqUrl + `/download-request-attachment?serial=${serial}&id=${id}`),

    uploadAttachment: (e: any, serial: number, typeId: string) =>
        attachmentApi.attach(apiConfig.reqUrl + `/upload-request-attachment?serial=${serial}&typeId=${typeId}`, e.target),

    removeAttachment: (serial: number, attachmentId: number) =>
        api.call('post', apiConfig.reqUrl + `/remove-request-attachment?serial=${serial}&id=${attachmentId}`),

    updateProjectOwner: (projectSerial: number, owner: string, workingGroupSerial: number) =>
        api.call(
            'post',
            apiConfig.reqUrl +
                `/update-project-owner?projectSerial=${projectSerial}&owner=${owner}&workingGroupSerial=${workingGroupSerial}`
        ),

    rejectReqItem: (itemSerial: number) => api.call('post', apiConfig.reqUrl + `/reject-request-item?requestItemSerial=${itemSerial}`),

    unrejectReqItem: (itemSerial: number) => api.call('post', apiConfig.reqUrl + `/un-reject-request-item?requestItemSerial=${itemSerial}`),

    closeReqItem: (itemSerial: number) => api.call('post', apiConfig.reqUrl + `/close-request-item?requestItemSerial=${itemSerial}`),

    unCloseReqItem: (itemSerial: number) => api.call('post', apiConfig.reqUrl + `/un-close-request-item?requestItemSerial=${itemSerial}`),

    requestAProcList: (projectSerial: number) => api.call('post', apiConfig.reqUrl + `/get-req-aproc-list?projectSerial=${projectSerial}`),

    requestItemCommodityView: (reqItemSerial: number) =>
        api.call('post', apiConfig.reqCommodityUrl + `/init-req-item-commodity?reqItemSerial=${reqItemSerial}`),

    updateRequestItemCommodity: (data: any) => api.call('post', apiConfig.reqCommodityUrl + `/update-req-item-commodity`, data),

    // changeAproc: (projectSerial:number, action, aprocSerial) =>
    //     api.call(
    //         "post",
    //         apiConfig.reqUrl + `/change-req-aproc?projectSerial=${projectSerial}&aprocAction=${action}&aprocSerial=${aprocSerial}`
    //     ),

    restoreToPreviousStatus: (prjSerial: number) =>
        api.call('post', apiConfig.reqUrl + `/restore-to-previous-status?projectSerial=${prjSerial}`),

    unReleaseReq: (prjSerial: number) => api.call('post', apiConfig.reqUrl + `/un-release-request?projectSerial=${prjSerial}`),

    deleteRequest: (prjSerial: number) => api.call('post', apiConfig.reqUrl + `/delete-request?projectSerial=${prjSerial}`),

    releaseRequest: (prjSerial: number) => api.call('post', apiConfig.reqUrl + `/release-request?projectSerial=${prjSerial}`),

    udpateRequestByExternalService: (prjSerial: number) => api.call('post', apiConfig.reqUrl + `/udpate-request-by-ex?serial=${prjSerial}`),

    wfInitMonitoring: (serial: number, wfInstanceSerial: number) =>
        api.call('post', apiConfig.reqUrl + `/wf-init-request-monitor?r=${serial}&instanceSerial=${wfInstanceSerial}`),

    wfTriggerByLevel: (msgSerial: number, action: string) =>
        api.call('post', apiConfig.reqUrl + `/wf-trigger-request-by-level?msgSerial=${msgSerial}&action=${action}`),
};

export type RequestDTO = {
    serial: number;
    projectSerial: number;
    number: string;
    title: string;
    description: string;
    currencyId: string;
    plantId: string;
    planningGroup: string;
    docType: string;
    orderDocType: string;
    purOrg: string;
    baselineSpend: number;
    requestDate?: Date;
    releaseDate?: Date;
    isCompleted: boolean;
    isReleased: boolean;
    isClosed: boolean;
    isSynchronized: boolean;
    isDeleted: boolean;
    modifiedBy: string;
    modifiedAt: Date;
    createdBy: string;
    createdAt: Date;
};

export type RequestItemDTO = {
    serial: number;
    number: string;
    itemNo: string;
    itemCategory: string;
    materialNo: string;
    materialText: string;
    qty: number;
    unit: string;
    unitPrice: number;
    orderQty: number;
    plantId: string;
    storageLocation: string;
    deliveryDate: Date;
    statusId: string;
    isClosed: boolean;
    isDeleted: boolean;
    modifiedBy: string;
    modifiedAt: Date;
    createdBy: string;
    createdAt: Date;

    itemLines: {
        requestItemSerial: number;
        lineId: number;
        code: string;
        title: string;
        qty: number;
        unit: string;
    }[];
};

export type RFPDocument = {
    serial: number;
    title: string;
    version: number;
    createdAt: Date;
    createdBy: string;
};

export type ReqMonitorModel = {
    project: {
        serial: number;
        number: any;
        owner: string;
        title: string;
        ownerName: string;
        templateVersion: string;
        isTemplate: boolean;
    };
    rfpDocument: RFPDocument;
    commodities: ICommodity[];
    request: RequestDTO;
    items: RequestItemDTO[];
    canView: boolean;
    allowEdit: boolean;
    allowCreateProject: boolean;
    allowAssign: boolean;
    allowDelete: boolean;
    allowEditMembers: boolean;
    allowLogs: boolean;
    attachments: any[];
    workingGroup: any;
    requestWFInstance: any;
    existActiveRequestInstance: boolean;
    existRequestWorkflow: boolean;
    forms: FormRefDTO[];
};
