import { api } from "./api";
import { apiConfig } from "./config";

export const aucitonContactApi = {
    initAuctionContacts: (projectSerial, auctionId) =>
        api.call("post", `${apiConfig.auctionContactUrl}/init-auction-contacts?projectSerial=${projectSerial}&auctionId=${auctionId}`),
    saveContact: (data, auctionId) => api.call("post", `${apiConfig.auctionContactUrl}/save-contact?auctionId=${auctionId}`, data),
    addContacts: (data) => api.call("post", `${apiConfig.auctionContactUrl}/add-contacts`, data),
    deleteContacts: (data) => api.call("post", `${apiConfig.auctionContactUrl}/delete-contacts`, data),
};
