import { ErrorReportFilter } from "../types/error-report-dto";
import { api } from "./api";
import { apiConfig } from "./config";

export const reportErrorApi = {
    filterErrors: (filter: ErrorReportFilter) => api.call("post", apiConfig.reportErrorUrl + `/filter-report`, filter),
    archiveError: (serial: number) => api.call("post", apiConfig.reportErrorUrl + `/archive?serial=${serial}`),
    archiveErrors: (model: { errors: ErrorReportFilter[] }) => api.call("post", apiConfig.reportErrorUrl + `/bulk-archive`, model),

    getErrorReportSmsList: (serial: number) => api.call("post", apiConfig.reportErrorUrl + `/get-error-report-sms-list?serial=${serial}`),
    sendErrorReportSms: (serial: number, message: string) =>
        api.call("post", apiConfig.reportErrorUrl + `/send-error-report-sms?serial=${serial}`, { message }),
};
