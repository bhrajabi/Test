import { api } from "./api";

export const projectDashboardApi = {
    initProject: (serial, number) => api.post(`/project/init-project?serial=${serial}&number=${number}`),
    initTemplates: () => api.post(`/project/init-templates`),
};
