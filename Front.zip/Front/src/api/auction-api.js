import { api } from "./api";
import { auctionAttachmentApi } from "./auction-attachment-api";
import { apiConfig } from "./config";

export const auctionApi = {
    initCreateAuction: (projectSerial) => api.call("post", `${apiConfig.auctionUrl}/init-create-auction?projectSerial=${projectSerial}`),

    initAuctionMonitoring: (auctionId) => api.call("post", `${apiConfig.auctionUrl}/init-auction-monitoring?auctionId=${auctionId}`),

    getProjectAuctions: (projectSerial) => api.call("post", `${apiConfig.auctionUrl}/get-project-auctions?projectSerial=${projectSerial}`),

    getOpenAuctions: (projectSerial) => api.call("post", `${apiConfig.auctionUrl}/get-open-auctions?projectSerial=${projectSerial}`),

    createAuction: (data) => api.call("post", `${apiConfig.auctionUrl}/create-auction`, data),

    aprocList: (id) => api.call("post", `${apiConfig.auctionUrl}/aproc-list?auctionId=${id}`),

    reloadAuctionData: (id) => api.call("post", `${apiConfig.auctionUrl}/reload-auction-data?auctionId=${id}`),

    updateAuctionTimes: (data) => api.call("post", `${apiConfig.auctionUrl}/update-auction-times`, data),

    updateAuctionInfo: (data) => api.call("post", `${apiConfig.auctionUrl}/update-auction-info`, data),

    updateAuctionRules: (data) => api.call("post", `${apiConfig.auctionUrl}/update-auction-rules`, data),

    createAuctionPack: (data) => api.call("post", `${apiConfig.auctionUrl}/create-auction-pack`, data),

    deleteAuction: (id) => api.call("post", `${apiConfig.auctionUrl}/delete-auction?auctionId=${id}`),

    changeStatus: (id, status) => api.call("post", `${apiConfig.auctionUrl}/update-auction-status?auctionId=${id}&status=${status}`),

    updateAuctionPack: (data) => api.call("post", `${apiConfig.auctionUrl}/update-auction-pack`, data),

    getAuctionPacks: (auctionId) => api.call("post", `${apiConfig.auctionUrl}/get-auction-packs?auctionId=${auctionId}`),

    removeAuctionPacks: (auctionId, rowId) =>
        api.call("post", `${apiConfig.auctionUrl}/remove-auction-pack?auctionId=${auctionId}&rowId=${rowId}`),

    toggleCancelAuctionPack: (auctionId, rowId, data) =>
        api.call("post", `${apiConfig.auctionUrl}/toggle-cancel-auction-pack?auctionId=${auctionId}&rowId=${rowId}`, data),

    changeAuctionAproc: (auctionId, action, aprocSerial) =>
        api.call(
            "post",
            apiConfig.auctionUrl + `/change-auction-aproc?auctionId=${auctionId}&aprocAction=${action}&aprocSerial=${aprocSerial}`
        ),

    uploadAttachment: (e, auctionId, typeId) =>
        auctionAttachmentApi.attach(apiConfig.auctionUrl + `/upload-auction-attachment?auctionId=${auctionId}&typeId=${typeId}`, e.target),

    downloadAttachment: (auctionId, id) =>
        auctionAttachmentApi.download(apiConfig.auctionUrl + `/download-auction-attachment?auctionId=${auctionId}&id=${id}`),

    downloadCompanyAttachment: (auctionId, companyId, id) =>
        auctionAttachmentApi.download(
            apiConfig.auctionUrl + `/download-auction-company-attachment?auctionId=${auctionId}&companyId=${companyId}&id=${id}`
        ),

    downloadGuranteeAttachment: (auctionId, id) =>
        auctionAttachmentApi.download(apiConfig.auctionUrl + `/download-gurantee-attachment?auctionId=${auctionId}&id=${id}`),

    removeAttachment: (auctionId, attachmentId) =>
        api.call("post", apiConfig.auctionUrl + `/remove-auction-attachment?auctionId=${auctionId}&id=${attachmentId}`),

    uploadAuctionPackImg: (e, auctionId, rowId, typeId) =>
        auctionAttachmentApi.attach(
            apiConfig.auctionUrl + `/upload-auction-pack-image?auctionId=${auctionId}&rowId=${rowId}&typeId=${typeId}`,
            e.target
        ),

    downloadAuctionPackImg: (auctionId, rowId, id) =>
        auctionAttachmentApi.download(apiConfig.auctionUrl + `/download-auction-pack-image?auctionId=${auctionId}&rowId=${rowId}&id=${id}`),

    removeAuctionPackImg: (auctionId, rowId, attachmentId) =>
        api.call("post", apiConfig.auctionUrl + `/remove-auction-pack-image?auctionId=${auctionId}&rowId=${rowId}&id=${attachmentId}`),

    getImage: (id) => api.call("post", `${apiConfig.auctionUrl}/auction-pack-image?id=${id}`),

    getAuctionPackImage: (auctionId, rowId) =>
        api.call("post", `${apiConfig.auctionUrl}/get-auction-pack-images?auctionId=${auctionId}&rowId=${rowId}`),

    getAuctionAttachments: (auctionId) => api.call("post", `${apiConfig.auctionUrl}/auction-attachments?auctionId=${auctionId}`),

    getPackItemMaterialsAndAttributes: (auctionId, rowId) =>
        api.call("post", `${apiConfig.auctionUrl}/get-pack-items-and-attributes?auctionId=${auctionId}&rowId=${rowId}`),

    updatePackItemsAndAttributes: (data) => api.call("post", `${apiConfig.auctionUrl}/update-pack-items-and-attributes`, data),

    initGuidedAuctionMonitor: (auctionId) => api.call("post", apiConfig.auctionUrl + "/init-guided-auction-monitor?auctionId=" + auctionId),

    restoreToPreviousStatus: (auctionId) => api.call("post", apiConfig.auctionUrl + `/restore-to-previous-status?auctionId=${auctionId}`),

    initReviewResponses: (auctionId) => api.call("post", `${apiConfig.auctionUrl}/init-review-responses?auctionId=${auctionId}`),

    initReviewResponsesReport: (auctionId) =>
        api.call("post", `${apiConfig.auctionUrl}/init-review-responses-report?auctionId=${auctionId}`),

    autoSelectWinner: (auctionId) => api.call("post", `${apiConfig.auctionUrl}/auto-select-winners?auctionId=${auctionId}`),

    auctionItemResponses: (auctionId, rowId) =>
        api.call("post", `${apiConfig.auctionUrl}/get-auction-item-responses?auctionId=${auctionId}&rowId=${rowId}`),

    rejectUserAuctionWinner: (data) => api.call("post", `${apiConfig.auctionUrl}/reject-winner`, data),

    changeUserAuctionStatus: (data) => api.call("post", `${apiConfig.auctionUrl}/change-user-auction-status`, data),

    fineUserAuction: (data) => api.call("post", `${apiConfig.auctionUrl}/fine-user-auction`, data),

    changeUserAuctionToWinner: (data) => api.call("post", `${apiConfig.auctionUrl}/change-user-auction-to-winner`, data),

    saveAddress: (data, auctionId) => api.call("post", `${apiConfig.auctionUrl}/save-address?auctionId=${auctionId}`, data),

    saveAddressAttachment: (addressSerial, auctionId, e) =>
        auctionAttachmentApi.attach(
            `${apiConfig.auctionUrl}/save-address-attachment?auctionId=${auctionId}&addressSerial=${addressSerial}`,
            e.target
        ),

    changeAucitonPackDefaultImage: (data) => api.call("post", `${apiConfig.auctionUrl}/change-default-pack-image`, data),

    initAuctionUsers: (auctionId) => api.call("post", `${apiConfig.auctionUrl}/init-auction-users?auctionId=${auctionId}`),

    approveAuctionUser: (auctionId, userName, model) =>
        api.call("post", `${apiConfig.auctionUrl}/approve-auction-user?auctionId=${auctionId}&userName=${userName}`, model),

    approveAuctionCompany: (auctionId, userName, companyId, model) =>
        api.call(
            "post",
            `${apiConfig.auctionUrl}/approve-auction-company?auctionId=${auctionId}&userName=${userName}&companyId=${companyId}`,
            model
        ),

    approveAuctionPayment: (auctionId, userName, rowId, model) =>
        api.call(
            "post",
            `${apiConfig.auctionUrl}/approve-auction-payment?auctionId=${auctionId}&userName=${userName}&rowId=${rowId}`,
            model
        ),

    getUserToAprv: (auctionId, userName) =>
        api.call("post", `${apiConfig.auctionUrl}/get-user-to-aprv?auctionId=${auctionId}&userName=${userName}`),

    getCompanyToAprv: (auctionId, companyId) =>
        api.call("post", `${apiConfig.auctionUrl}/get-company-to-aprv?auctionId=${auctionId}&companyId=${companyId}`),
};
