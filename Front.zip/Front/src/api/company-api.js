import { api } from "./api";
import { attachmentApi } from "./attachment-api";
import { apiConfig } from "./config";

export const companyApi = {
    initCompanyProfile: () => api.call("post", apiConfig.companyUrl + "/init-company-profile"),

    initConnections: () => api.call("post", apiConfig.relationUrl + "/init-connections"),
    saveCompanyPublicProfile: (company) => api.call("post", `${apiConfig.companyUrl}/save-company-public-profile`, company),
    initProfileContacts: (uniqueId) => api.call("post", `${apiConfig.companyUrl}/init-profile-contacts?uniqueId=${uniqueId}`),

    sendRelationReq: (buyerId, mainContactUser) =>
        api.call("post", apiConfig.relationUrl + `/send-relation-request?buyerId=${buyerId}&mainContactUser=${mainContactUser}`),

    cancelRelationReq: (buyerId) => api.call("post", apiConfig.relationUrl + "/cancel-relation-request?buyerId=" + buyerId),

    //getSmCompany: (serial) => api.call("post", apiConfig.suppliersUrl + `/get-company?serial=${serial}`),

    getCompanyMembers: (id) => api.call("post", apiConfig.companyUrl + "/get-company-members?id=" + id),

    requestForEditCompany: () => api.call("post", apiConfig.companyUrl + "/request-for-edit-company"),

    uploadLogoAttachment: (file, companyId) =>
        attachmentApi.attach(apiConfig.companyUrl + `/upload-logo-attachment?companyId=${companyId}`, undefined, undefined, file),

    uploadBannerAttachment: (file, companyId) =>
        attachmentApi.attach(apiConfig.companyUrl + `/upload-banner-attachment?companyId=${companyId}`, undefined, undefined, file),

    //
    downloadAttachment: (id) => attachmentApi.download(apiConfig.companyUrl + "/download-request?id=" + id),

    uploadAttachment: (e, typeId) => attachmentApi.attach(apiConfig.companyUrl + "/upload-attachment?typeId=" + typeId, e.target),

    uploadDraft: (e, draftId, typeId) =>
        attachmentApi.attach(apiConfig.companyUrl + `/upload-draft?draftId=${draftId}&typeId=${typeId}`, e.target),

    removeAttachment: (attachmentId) => api.call("post", apiConfig.companyUrl + "/remove-attachment?id=" + attachmentId),

    initCompanyContacts: () => api.call("post", apiConfig.relationUrl + `/init-company-contacts`),

    initCompany: (companyId) => api.call("post", apiConfig.companyUrl + `/init-company?companyId=${companyId}`),

    confirmCompany: (data) => api.call("post", apiConfig.companyUrl + "/confirm-company", data),

    /**********/
    toggleFavoriteCompany: (sellerId) => api.call("post", apiConfig.companyUrl + "/toggle-favorite-company?sellerId=" + sellerId),
    saveMyRecentCompanies: (sellers) => api.call("post", apiConfig.companyUrl + "/save-my-recent-companies", sellers),
};
