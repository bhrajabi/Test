import { api } from "./api";
import { apiConfig } from "./config";

export const erpServiceApi = {
    inquirySupplierByErpService: (dto: any) => api.call("post", apiConfig.erpSrviceUrl + `/inquiry-supplier-by-erp-service`, dto),
    findIPNCompany: (dto: any) => api.call("post", apiConfig.erpSrviceUrl + `/find-ipn-company`, dto),
    importVendor: (dto: any) => api.call("post", apiConfig.erpSrviceUrl + `/import-vendor`, dto),
};
