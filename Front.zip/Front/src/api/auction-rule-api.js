import { api } from "./api";
import { attachmentApi } from "./attachment-api";
import { apiConfig } from "./config";

export const auctionRuleApi = {
    uploadAuctionProjectLogo: (e, projectSerial, auctionId, typeId) =>
        attachmentApi.attach(
            apiConfig.auctionRuleUrl +
                `/upload-auciton-project-logo?projectSerial=${projectSerial}&aucitonId=${auctionId}&typeId=${typeId}`,
            e.target
        ),

    removeAucitonProjectLogo: (projectSerial, attachmentId, auctionId) =>
        api.call(
            "post",
            apiConfig.auctionRuleUrl +
                `/remove-auction-project-logo?projectSerial=${projectSerial}&id=${attachmentId}&aucitonId=${auctionId}`
        ),

    getAuctionProjectLogo: (projectSerial, auctionId) =>
        api.call("post", `${apiConfig.auctionRuleUrl}/get-auction-logo?projectSerial=${projectSerial}&aucitonId=${auctionId}`),

    update: (data) => api.call("post", `${apiConfig.auctionRuleUrl}/update`, data),

    init: (serial) => api.call("post", `${apiConfig.auctionRuleUrl}/init-auction-rules?serial=${serial}`),

    uploadAuctionProjectAddress: (e, projectSerial, auctionId, typeId) =>
        attachmentApi.attach(
            apiConfig.auctionRuleUrl +
                `/upload-auciton-project-address?projectSerial=${projectSerial}&aucitonId=${auctionId}&typeId=${typeId}`,
            e.target
        ),

    getAuctionProjectAddress: (projectSerial, auctionId) =>
        api.call("post", `${apiConfig.auctionRuleUrl}/get-auction-address?projectSerial=${projectSerial}&aucitonId=${auctionId}`),
};
