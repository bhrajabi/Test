import { api } from "./api";
import { apiConfig } from "./config";

export const CategoriesApi = {
    initCategory: (parentCode) => api.call("post", `${apiConfig.categoriesUrl}/init-category?parentCode=${parentCode}`),
};
