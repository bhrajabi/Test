import { api } from "./api";
import { apiConfig } from "./config";

export const findSupplierApi = {
    initFindByMaterial: (documentSerial) =>
        api.call("post", apiConfig.findSupplierUrl + `/init-search-by-material?documentSerial=${documentSerial}`),

    getMyCompanyContacts: () => api.call("post", apiConfig.findSupplierUrl + `/get-my-company-contacts`),

    getCompanyContacts: (companyId) => api.call("post", apiConfig.findSupplierUrl + `/get-company-contacts?companyId=${companyId}`),
};
