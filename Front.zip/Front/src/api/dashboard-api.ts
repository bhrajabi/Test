import { useApi } from "../pages/seller/home/api/use-api-call";
import { SellerDashboardDTO } from "../pages/seller/home/types";

export const useDashboardInitApi = (muted: boolean) => useApi<SellerDashboardDTO>("/dashboard/init-dashboard", { muted });
export const useDashboardIndicatorsApi = () => useApi("/dashboard/init-menu-indicatores");
export const useGlobalSearchApi = () => useApi<DashboardQuickSearchResultDTO>("/dashboard/global-search");

export type DashboardQuickSearchResultDTO = {
    requests: SearchRequestResultView[];
    orders: SearchOrderResultView[];
    events: SearchEventResultView[];
};

export type SearchRequestResultView = {
    serial: bigint;
    projectSerial: bigint;
    number: string;

    createdBy: string;
    createdAt: Date;
};

export type SearchOrderResultView = {
    serial: bigint;
    number: string;
    eventSerial?: bigint;
    statusId: string;
    releaseDate?: Date;
    createdBy: string;
    createdAt: Date;
};

export type SearchEventResultView = {
    serial: bigint;
    prSerial?: bigint;
    number: string;
    documentType?: string;
    eventTypeId?: string;
    eventCategoryId?: string;
    isExternal?: boolean;
    statusId?: string;
    createdBy: string;
    createdAt: Date;
};
