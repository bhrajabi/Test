import { useApi } from "../pages/seller/home/api/use-api-call";

export const useSellerSearchEventsApi = () => useApi("/seller/search-events?status={status}&number={number}&title={title}");
export const useSellerSearchPublicEventsApi = () => useApi("/seller/search-public-events?status={status}");
export const useSellerInitSellerTeam = () => useApi<SellerTeamDTO>("/seller/init-seller-team");
export const useSellerDeleteSellerUser = () => useApi("/seller/delete-seller-user?userName={userName}", { skipResult: true });
export const useSellerSaveSellerUser = () => useApi("/seller/save-seller-user", { skipResult: true });
export const useSellerGetRecentPublicEvents = () => useApi("/seller/get-recent-public-events");

export type CompanyUserDTO = {
    userName?: string;
    isConnected?: boolean;
    isBlocked?: boolean;
    fullName?: string;
    firstName?: string;
    lastName?: string;
    phoneNumber?: string;
    createdBy?: string;
    createdAt?: Date;
};

export type ProjectTeamDTO = {
    serial: number;
    title: string;
    isEditable: boolean;
    sysCode: string;
};

export type ProjectRoleDTO = {
    id: string;
    title: string;
    accessRights: string;
    includeAuthGroup: boolean;
};

export type ProjectTeamUserDTO = {
    projectTeamSerial: number;
    userName: string;
    fullName: string;
};

export type ProjectTeamRoleDTO = {
    projectTeamSerial: number;
    roleId: string;
    accessRight: string;
};

export type InitTeamDTO = {
    isTemplate: boolean;
    teams: ProjectTeamDTO[];
    teamUsers: ProjectTeamUserDTO[];
    teamRoles: ProjectTeamRoleDTO[];
    roles: ProjectRoleDTO[];
    allowEdit: boolean;
};

export type SellerTeamDTO = {
    users: CompanyUserDTO[];
    teamUsers: ProjectTeamUserDTO[];
    teams: ProjectTeamDTO[];
    allowEdit: boolean;
};
