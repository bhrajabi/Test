import { api } from "./api";
import { apiConfig } from "./config";

export const materialPackagingApi = {
    initPackaging: (materialNo, packageNo) =>
        api.call("post", apiConfig.materialPackagingUrl + `/init-packaging?materialNo=${materialNo}&packageNo=${packageNo}`),

    addMaterialPackaging: (data) => api.call("post", apiConfig.materialPackagingUrl + `/add-packaging`, data),
    updateMaterialPackaging: (data) => api.call("post", apiConfig.materialPackagingUrl + `/update-packaging`, data),

    deleteMaterialPackaging: (materialNo, packageNo) =>
        api.call("post", `${apiConfig.materialPackagingUrl}/delete-packaging?materialNo=${materialNo}&packageNo=${packageNo}`),
};
