import { api } from "./api";
import { apiConfig } from "./config";

export const companyUsersApi = {
    initCompanyUsers: (companyId, filter) =>
        api.call("post", `${apiConfig.companyUrl}/init-company-users?companyId=${companyId ?? 0}`, filter),

    initCompanyUser: (companyId, userName) =>
        api.call("post", `${apiConfig.companyUrl}/init-company-user?companyId=${companyId ?? 0}&userName=${userName}`),

    getUserProjectsByAzg: (companyId, userName) =>
        api.call("post", `${apiConfig.companyUrl}/get-user-projects?companyId=${companyId ?? 0}&userName=${userName}`),

    createUser: (companyId, user) => api.call("post", `${apiConfig.companyUrl}/create-user?companyId=${companyId ?? 0}`, user),

    addUser: (companyId, user) => api.call("post", `${apiConfig.companyUrl}/add-user?companyId=${companyId ?? 0}`, user),

    updateUser: (companyId, user) => api.call("post", `${apiConfig.companyUrl}/update-user?companyId=${companyId ?? 0}`, user),

    resetUserPassword: (companyId, data) =>
        api.call("post", `${apiConfig.companyUrl}/reset-user-password?companyId=${companyId ?? 0}`, data),

    changeCompanyUserPhoneNumber: (companyId, data) =>
        api.call("post", `${apiConfig.companyUrl}/change-company-user-phone-number?companyId=${companyId ?? 0}`, data),

    sendActivationMessage: (companyId, userName) =>
        api.call("post", `${apiConfig.companyUrl}/send-activation-message?companyId=${companyId ?? 0}&userName=${userName}`),
};
