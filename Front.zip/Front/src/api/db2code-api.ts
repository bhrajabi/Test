import { useApi } from "../pages/seller/home/api/use-api-call";

export const useDb2CodeInitApi = () => useApi<Db2Code_InitDTO>("/db2code/init");
export const useDb2CodeGetTableApi = (tbName: string) => useApi<{ table: D2C_Table_DTO }>(`/db2code/get-table?tb=${tbName}`);

export const useDb2CodeExecSqlApi = (tbName: string) => useApi<D2C_ExecSQL_DTO>(`/db2code/exec-sql?${tbName}`);

export type Db2Code_InitDTO = {
    tables: string[];
    views: string[];
    relations: ForeignKeyRelationshipDTO[];
};

type ForeignKeyRelationshipDTO = {
    fkName: string;
    parentTable: string;
    referencedTable: string;
    parentColumn: string;
    referencedColumn: string;
};

export type D2C_Table_DTO = {
    columns: D2C_Column_DTO[];
    primaryKey: string[];
    uniqueConstraints: string[];
};

export type D2C_Column_DTO = {
    name: string;
    dataType: string;
    maxLength: number;
    isNullable: boolean;
    precision: number;
    scale: number;
    isIdentity: boolean;
};

export type D2C_ExecSQL_DTO = {
    header: {
        name: string;
        dataType: string;
        unique: boolean;
        maxLength: number;
        allowDBNull: boolean;
        autoIncrement: boolean;
        defaultValue: string;
        readOnly: boolean;
        expression: string;
        namespace: string;
    }[];
    body: any[][];
};
