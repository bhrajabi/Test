import { api } from "./api";
import { apiConfig } from "./config";

export const networkApi = {
    initBuyer: (buyerId: number) => api.call("post", `${apiConfig.networkUrl}/init-buyer?buyerId=${buyerId}`),

    initNetwork: () => api.call("post", apiConfig.networkUrl + `/init-network`),
    refreshSysMenus: () => api.call("get", apiConfig.networkUrl + `/refresh-sysmenu`),
    getDataTable: (tableName: string) => api.call("post", apiConfig.networkUrl + `/get-data-table?tableName=${tableName}`),
    saveRow: (tableName: string, insertMode: boolean, data: any) =>
        api.call("post", apiConfig.networkUrl + `/save-row?tableName=${tableName}&insertMode=${insertMode}`, data),
    deleteRow: (tableName: string, data: any) => api.call("post", apiConfig.networkUrl + `/delete-row?tableName=${tableName}`, data),

    createMegaCompany: (data: any) => api.call("post", apiConfig.networkUrl + `/create-mega-company`, data),
    initSearchCompany: (data: any) => api.call("post", apiConfig.networkUrl + `/init-search-companies`, data),
    getCompaniesByFilter: (fromIndex: number, data: any) =>
        api.call("post", apiConfig.networkUrl + `/get-search-companies-by-filter?fromIndex=${fromIndex}`, data),

    saveCompanyAccess: (companyId: number, data: any) =>
        api.call("post", `${apiConfig.networkUrl}/save-company-access?companyId=${companyId}`, data),
    saveCompanyAAuthenticationStatus: (companyId: number, data: any) =>
        api.call("post", `${apiConfig.networkUrl}/save-company-authentication-status?companyId=${companyId}`, data),

    searchUser: (data: any) => api.call("post", `${apiConfig.networkUrl}/search-user`, data),
    searchCompanyUser: (userName: string) => api.call("post", `${apiConfig.networkUrl}/search-company-users?userName=${userName}`),
};
