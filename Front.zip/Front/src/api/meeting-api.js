import { api } from "./api";
import { attachmentApi } from "./attachment-api";
import { apiConfig } from "./config";

export const meetingApi = {
    initCnfEdit: (meetingSerial) => api.call("post", apiConfig.cnfMeetingsUrl + `/init-edit?meetingSerial=${meetingSerial}`),

    initMonitoringMeeting: (meetingSerial) =>
        api.call("post", apiConfig.cnfMeetingsUrl + `/init-meeting-monitoring?meetingSerial=${meetingSerial}`),

    initCreateMeeting: () => api.call("post", apiConfig.cnfMeetingsUrl + `/init-create-cnf`),

    initMeeting: (documentSerial, meetingType) =>
        api.call("post", apiConfig.meetingsUrl + `/init-meeting?documentSerial=${documentSerial}&meetingType=${meetingType}`),

    initCnfMeeting: (documentSerial) => api.call("post", apiConfig.cnfMeetingsUrl + `/init-meeting?documentSerial=${documentSerial}`),

    initAllCnfMeeting: () => api.call("post", apiConfig.cnfMeetingsUrl + `/init-all-cnf-meeting`),

    getDraft: (documentSerial) => api.call("post", apiConfig.meetingsUrl + `/get-draft?documentSerial=${documentSerial}`),

    getDraftCnf: (documentSerial) => api.call("post", apiConfig.cnfMeetingsUrl + `/get-draft-cnf?documentSerial=${documentSerial}`),

    addMeeting: (documentSerial, draftId, values) =>
        api.call("post", apiConfig.meetingsUrl + `/add-meeting?documentSerial=${documentSerial}&draftId=${draftId}`, values),

    addCnfMeeting: (documentSerial, draftId, values) =>
        api.call("post", apiConfig.cnfMeetingsUrl + `/add-cnf-meeting?documentSerial=${documentSerial}&draftId=${draftId}`, values),

    updateMeeting: (documentSerial, draftId, values) =>
        api.call("post", apiConfig.meetingsUrl + `/update-meeting?documentSerial=${documentSerial}&draftId=${draftId}`, values),

    updateCnfMeeting: (documentSerial, draftId, values) =>
        api.call("post", apiConfig.cnfMeetingsUrl + `/update-cnf-meeting?documentSerial=${documentSerial}&draftId=${draftId}`, values),

    saveCnfMeeting: (values, draftId) => api.call("post", apiConfig.cnfMeetingsUrl + `/save-meeting?draftId=${draftId}`, values),

    deleteMeeting: (documentSerial, meetingSerial) =>
        api.call("post", apiConfig.meetingsUrl + `/delete-meeting?documentSerial=${documentSerial}&meetingSerial=${meetingSerial}`),

    deleteCnf: (meetingSerial) => api.call("post", apiConfig.cnfMeetingsUrl + `/delete-cnf?meetingSerial=${meetingSerial}`),

    closeMeeting: (documentSerial, meetingSerial) =>
        api.call("post", apiConfig.meetingsUrl + `/close-meeting?documentSerial=${documentSerial}&meetingSerial=${meetingSerial}`),

    closeAwardMeeting: (documentSerial, meetingSerial) =>
        api.call("post", apiConfig.meetingsUrl + `/close-award-meeting?documentSerial=${documentSerial}&meetingSerial=${meetingSerial}`),

    duplicateMeeting: (documentSerial, meetingSerial) =>
        api.call("post", apiConfig.meetingsUrl + `/duplicate-meeting?documentSerial=${documentSerial}&meetingSerial=${meetingSerial}`),

    uploadAttachment: (e, meetingType, documentSerial, draftId) =>
        attachmentApi.attach(
            apiConfig.meetingsUrl +
                `/upload-meeting-attachment?documentSerial=${documentSerial}&meetingType=${meetingType}&draftId=${draftId}`,
            e.target
        ),

    downloadAttachment: (id, documentSerial, meetingSerial) =>
        attachmentApi.download(
            apiConfig.meetingsUrl + `/download-request?id=${id}&documentSerial=${documentSerial}&meetingSerial=${meetingSerial}`
        ),

    removeAttachment: (attachmentId, meetingSerial, documentSerial) =>
        api.call(
            "post",
            apiConfig.meetingsUrl + `/remove-attachment?id=${attachmentId}&documentSerial=${documentSerial}&meetingSerial=${meetingSerial}`
        ),

    uploadCNFAttachment: (e, meetingType, serial, draftId) =>
        attachmentApi.attach(
            apiConfig.meetingsUrl + `/upload-cnf-attachment?serial=${serial}&meetingType=${meetingType}&draftId=${draftId}`,
            e.target
        ),

    downloadCNFAttachment: (id, meetingSerial) =>
        attachmentApi.download(apiConfig.meetingsUrl + `/download-cnf-attachment?attachmentId=${id}&&meetingSerial=${meetingSerial}`),

    removeCNFAttachment: (attachmentId, meetingSerial) =>
        api.call("post", apiConfig.meetingsUrl + `/remove-cnf-attachment?id=${attachmentId}&meetingSerial=${meetingSerial}`),

    searchAwardItems: (meetingSerial, data) =>
        api.call("post", apiConfig.cnfMeetingsUrl + `/search-award-items?meetingSerial=${meetingSerial}`, data),

    searchSourcingItems: () => api.call("post", apiConfig.cnfMeetingsUrl + `/search-sourcing-items`),

    deleteCnfItem: (meetingSerial, referenceKey) =>
        api.call("post", apiConfig.cnfMeetingsUrl + `/delete-cnf-item?meetingSerial=${meetingSerial}&referenceKey=${referenceKey}`),

    initConfirmationDocuments: (documentSerial) =>
        api.call("post", apiConfig.cnfMeetingsUrl + `/init-cnf-meetings?documentSerial=${documentSerial}`),

    changeStatus: (documentSerial, status) =>
        api.call("Post", apiConfig.cnfMeetingsUrl + `/change-document-status?documentSerial=${documentSerial}&status=${status}`),

    requestPrintMeeting: (documentSerial, meetingSerial) =>
        api.call("Post", apiConfig.meetingsUrl + `/request-print-meeting?documentSerial=${documentSerial}&meetingSerial=${meetingSerial}`),

    //wf
    initWFMeetings: (wfInstanceSerial, documentType) =>
        api.call("post", apiConfig.meetingsUrl + `/wf-init-meetings?wfInstanceSerial=${wfInstanceSerial}&documentType=${documentType}`),

    getWfMeetingDraft: (wfInstanceSerial, documentType) =>
        api.call("post", apiConfig.meetingsUrl + `/wf-get-meeting-draft?wfInstanceSerial=${wfInstanceSerial}&documentType=${documentType}`),

    addWfMeeting: (wfInstanceSerial, documentType, values, draftId) =>
        api.call(
            "post",
            apiConfig.meetingsUrl + `/wf-add-meeting?wfInstanceSerial=${wfInstanceSerial}&draftId=${draftId}&documentType=${documentType}`,
            values
        ),

    updateWfMeeting: (wfInstanceSerial, documentType, draftId, values) =>
        api.call(
            "post",
            apiConfig.meetingsUrl +
                `/wf-update-meeting?wfInstanceSerial=${wfInstanceSerial}&draftId=${draftId}&documentType=${documentType}`,
            values
        ),

    deleteWfMeeting: (wfInstanceSerial, documentType, meetingSerial) =>
        api.call(
            "post",
            apiConfig.meetingsUrl +
                `/wf-delete-meeting?wfInstanceSerial=${wfInstanceSerial}&meetingSerial=${meetingSerial}&documentType=${documentType}`
        ),

    downloadWfAttachment: (wfInstanceSerial, documentType, id) =>
        attachmentApi.download(
            apiConfig.meetingsUrl +
                `/wf-download-attachment?wfInstanceSerial=${wfInstanceSerial}&attachmentId=${id}&documentType=${documentType}`
        ),

    removeWfAttachment: (wfInstanceSerial, documentType, attachmentId) =>
        api.call(
            "post",
            apiConfig.meetingsUrl +
                `/wf-remove-attachment?&wfInstanceSerial=${wfInstanceSerial}&attachmentId=${attachmentId}&documentType=${documentType}`
        ),

    uploadWfAttachment: (wfInstanceSerial, draftId, e) =>
        attachmentApi.attach(
            apiConfig.meetingsUrl + `/wf-upload-attachment?wfInstanceSerial=${wfInstanceSerial}&draftId=${draftId}`,
            e.target
        ),

    closeWfMeeting: (wfInstanceSerial, meetingSerial, documentType) =>
        api.call(
            "post",
            apiConfig.meetingsUrl +
                `/wf-close-meeting?wfInstanceSerial=${wfInstanceSerial}&meetingSerial=${meetingSerial}&documentType=${documentType}`
        ),
};
