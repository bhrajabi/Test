import { useApi } from '../pages/seller/home/api/use-api-call';
import { api } from './api';
import { apiConfig } from './config';

export const orderApi = {
    initCreateOrder: (eventSerial: number, docSerial: number, sellerId: number) =>
        api.call(
            'post',
            `${apiConfig.orderUrl}/init-create-order?eventSerial=${eventSerial}&requestProjectSerial=${docSerial}&sellerId=${sellerId}`
        ),
    initOrderHistory: (orderSerial: number) => api.call('post', `${apiConfig.orderUrl}/init-order-history?orderSerial=${orderSerial}`),

    initSellerOrderHistory: (orderSerial: number) =>
        api.call('post', `${apiConfig.orderUrl}/init-seller-order-history?orderSerial=${orderSerial}`),

    getRecentOrders: () => api.call('post', `${apiConfig.orderUrl}/get-recent-orders`),

    createOrder: (data: any) => api.call('post', `${apiConfig.orderUrl}/create-order`, data),

    onChhangeCurrency: (currency: any) => api.call('post', `${apiConfig.orderUrl}/on-change-currency?newCurrency=${currency}`),

    submitOrder: (orderSerial: number) => api.call('post', `${apiConfig.orderUrl}/submit-order?orderSerial=${orderSerial}`),

    updateOrderByExternalService: (number: string) =>
        api.call('post', `${apiConfig.orderUrl}/update-order-by-external-service?number=${number}`),

    deleteOrder: (orderSerial: number) => api.call('post', `${apiConfig.orderUrl}/delete-order?orderSerial=${orderSerial}`),

    initEditOrder: (serial: number) => api.call('post', `${apiConfig.orderUrl}/init-edit-order?serial=${serial}`),

    initViewOrder: (serial: number | null, number?: string) =>
        api.call('post', `${apiConfig.orderUrl}/init-view-order?serial=${!serial ? 0 : serial}&number=${number ?? ''}`),

    editOrder: (data: any, submitOrder: any) => api.call('post', `${apiConfig.orderUrl}/edit-order?changeToSubmit=${submitOrder}`, data),

    initSearchOrder: () => api.call('post', `${apiConfig.orderUrl}/init-search-order`),

    searchOrders: (data: any) => api.call('post', `${apiConfig.orderUrl}/search-orders`, data),

    saveOrderSL: (data: any) => api.call('post', `${apiConfig.orderUrl}/save-order-sl`, data),

    getOrdersWithoutSl: () => api.call('post', `${apiConfig.orderUrl}/orders-without-sl`),

    searchOrderItemsSchedules: (data: any) => api.call('post', `${apiConfig.orderUrl}/search-sls`, data),

    searchOrder: (dto: any) => api.call('post', `${apiConfig.orderUrl}/search-order`, dto),

    printOrderConfirmation: (orderSerial: number, reportSerial: number) =>
        api.call('post', `${apiConfig.orderUrl}/print-order-confirmation?orderSerial=${orderSerial}&reportSerial=${reportSerial}`),

    getOrderHistory: (orderSerial: number) => api.call('post', `${apiConfig.orderUrl}/get-order-history?orderSerial=${orderSerial}`),

    importPO: (number: string) => api.call('post', `${apiConfig.orderUrl}/import-po?number=${number}`),

    getOrderItem: (data: any, fromIndex: number) => api.call('post', `${apiConfig.orderUrl}/get-order-items?fromIndex=${fromIndex}`, data),

    getOrderScheduleLinesItem: (data: any, fromIndex: number) =>
        api.call('post', `${apiConfig.orderUrl}/get-order-schedule-lines-item?fromIndex=${fromIndex}`, data),
};

//
//
export const useSearchOrderApi = () => useApi<{ orders: OrdererSearchResultDTO[] }>('/order/search-order');

export type OrdererSearchResultDTO = {
    number: string;
    subTotal: number;
};
