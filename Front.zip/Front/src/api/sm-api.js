import { api } from "./api";
import { attachmentApi } from "./attachment-api";
import { apiConfig } from "./config";

export const smApi = {
    //initSM: () => api.call("post", apiConfig.suppliersUrl + `/init-sm`),
    updateSupplierContactInfo: (data) => api.call("post", apiConfig.suppliersUrl + `/update-supplier-contact-info`, data),
    initNewSM: () => api.call("post", apiConfig.suppliersUrl + `/init-new-sm`),

    initExpiredQuestionaries: () => api.call("post", apiConfig.suppliersUrl + `/init-expired-questionaries`),

    initSmCompany: (sellerId) => api.call("post", apiConfig.suppliersUrl + `/init-supws?sellerId=${sellerId}`),

    //getCompanyProject: (projectSerial) => api.call("post", apiConfig.suppliersUrl + `/init-company-project?projectSerial=${projectSerial}`),

    initSmOverview: (projectSerial) => api.call("post", apiConfig.suppliersUrl + `/init-overview?projectSerial=${projectSerial}`),

    deleteCommodity: (projectSerial, code) =>
        api.call("post", apiConfig.suppliersUrl + `/delete-document-commodity?projectSerial=${projectSerial}&code=${code}`),

    getDocumentCommodityStatuses: (projectSerial) =>
        api.call("post", apiConfig.suppliersUrl + `/init-document-commodity-statuses?projectSerial=${projectSerial}`),

    changeDocumentCommodityStatus: (projectSerial, commodityCode, newStatus) => {
        return api.call(
            "post",
            apiConfig.suppliersUrl +
                `/change-document-commodity-status?projectSerial=${projectSerial}&commodityCode=${commodityCode}&newStatus=${newStatus}`
        );
    },

    syncDocumentCommodities: (projectSerial, list) =>
        api.call("post", apiConfig.suppliersUrl + `/sync-document-commodities?projectSerial=${projectSerial}`, list),

    getCompanyInfo: (nid) => api.call("post", apiConfig.suppliersUrl + "/get-company-info?nationalId=" + nid),
    register: (data) => api.call("post", apiConfig.suppliersUrl + "/create-vendor", data),

    searchByCompanyInfo: (data) => api.call("post", apiConfig.suppliersUrl + "/search-by-company-info", data),

    searchByCategory: (data) => api.call("post", apiConfig.suppliersUrl + `/search-by-category`, data),

    updateSpqResponseGrade: (projectSerial, dto) =>
        api.call("post", apiConfig.suppliersUrl + `/update-spq-response-grade?projectSerial=${projectSerial}`, dto),
    syncCommodityProfileDocument: (sellerId) =>
        api.call("post", apiConfig.suppliersUrl + `/sync-commodity-profile-document?sellerId=${sellerId}`),
    initSupplierContacts: (sellerId) => api.call("post", apiConfig.suppliersUrl + `/init-supplier-contacts?sellerId=${sellerId}`),

    getProfileSpq: (sellerId) => api.call("post", apiConfig.suppliersUrl + `/get-profile-spq?sellerId=${sellerId}`),

    getRelatedSurveyEvents: (spqSerial, sellerId) =>
        api.call("post", apiConfig.suppliersUrl + `/get-related-spq-survey-events?spqSerial=${spqSerial}&sellerId=${sellerId}`),

    updateSupplierGrade: (projectSerial, grade) =>
        api.call("post", apiConfig.suppliersUrl + `/update-supplier-grade?projectSerial=${projectSerial}&grade=${grade}`),

    initSupplierSellerId: (sellerId) => api.call("post", apiConfig.suppliersUrl + `/init-supplier-sellerId?sellerId=${sellerId}`),

    initSpqBySerial: (spqSerial) => api.call("post", apiConfig.suppliersUrl + `/init-spq-serial?spqSerial=${spqSerial}`),

    initSearch: (dto) => api.call("post", apiConfig.suppliersUrl + "/init-search-suppliers", dto),

    searchSuppliers: (fromIndex, data) => api.call("post", apiConfig.suppliersUrl + `/search-suppliers?fromIndex=${fromIndex}`, data),

    toggleFavoriteSupplier: (sellerId) => api.call("post", apiConfig.suppliersUrl + `/toggle-favorite-supplier?sellerId=${sellerId}`),

    initUploadSuppliers: () => api.call("post", apiConfig.suppliersUrl + `/init-upload-suppliers`),

    uploadExcelTemp: (e) => attachmentApi.attach(apiConfig.suppliersUrl + `/upload-suppliers`, e.target),

    submitSuppliers: (suppliers) => api.call("post", apiConfig.suppliersUrl + `/submit-suppliers`, suppliers),

    duplicateErpNumber: () => api.call("post", apiConfig.suppliersUrl + `/duplicate-erp-number`),

    deleteDuplicateErpNumber: (sellerId) => api.call("post", apiConfig.suppliersUrl + `/delete-duplicate-erp-number?sellerId=${sellerId}`),

    initRegReq: (isArchived, filter) => api.call("post", apiConfig.suppliersUrl + `/init-reg-req?isArchived=${isArchived}`, filter),

    approveRegReq: (serial, businessName) =>
        api.call("post", apiConfig.suppliersUrl + `/approve-reg-req?serial=${serial}&name=${businessName}`),

    rejectRegReq: (serial, data) => api.call("post", apiConfig.suppliersUrl + `/reject-reg-req?serial=${serial}`, data),

    setRegReqToPending: (serial, data) => api.call("post", apiConfig.suppliersUrl + `/set-reg-req-to-pending?serial=${serial}`, data),

    wfGetRegReq: (wfInstanceSerial) => api.call("post", apiConfig.suppliersUrl + `/wf-get-reg-req?wfInstanceSerial=${wfInstanceSerial}`),

    getRegReq: (serial) => api.call("post", apiConfig.suppliersUrl + `/get-reg-req?serial=${serial}`),

    initCreateCompany: () => api.call("post", apiConfig.suppliersUrl + `/init-create-company`),

    initRegReqProjectView: (docSerial) => api.call("post", apiConfig.suppliersUrl + `/init-reg-req-project-view?doc=${docSerial}`),

    authenticateCompanyMember: (serial) => api.call("post", apiConfig.suppliersUrl + `/authenticate-company-member?serial=${serial}`),

    getCompanyFull: (nid) => api.call("post", apiConfig.suppliersUrl + `/get-company-full?nationalId=${nid}`),

    changeApprovmentStatus: (dto) => api.call("post", apiConfig.suppliersUrl + `/change-relation-status`, dto),
    exportToExcel: (dto) => api.call("post", apiConfig.suppliersUrl + `/export-to-excel`, dto),

    initPublicProfile: (uniqueId) => api.call("post", apiConfig.suppliersUrl + `/init-public-profile?uniqueId=${uniqueId}`),
};
