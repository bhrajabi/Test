import { api } from "./api";
import { apiConfig } from "./config";

export const porjectContactApi = {
    initProjectContacts: (projectSerial) =>
        api.call("post", `${apiConfig.projectContactUrl}/init-project-contacts?projectSerial=${projectSerial}`),

    saveContact: (data) => api.call("post", `${apiConfig.projectContactUrl}/save-contact`, data),

    deleteContacts: (data) => api.call("post", `${apiConfig.projectContactUrl}/delete-contacts`, data),
};
