import { api } from "./api";
import { auctionAttachmentApi } from "./auction-attachment-api";
import { apiConfig } from "./config";

export const aucitonContentApi = {
    initAuctionContents: (auctionId) => api.call("post", `${apiConfig.auctionContentUrl}/list?auctionId=${auctionId}`),

    userContentResponses: (auctionId, userName) =>
        api.call("post", `${apiConfig.auctionContentUrl}/get-auction-content-view?auctionId=${auctionId}&userName=${userName}`),

    addSection: (data) => api.call("post", `${apiConfig.auctionContentUrl}/add-section`, data),

    updateSection: (data) => api.call("post", `${apiConfig.auctionContentUrl}/update-section`, data),

    addContent: (data) => api.call("post", `${apiConfig.auctionContentUrl}/add-content`, data),

    updateContent: (data) => api.call("post", `${apiConfig.auctionContentUrl}/update-content`, data),

    deleteContent: (cId, auctionId) => api.call("post", `${apiConfig.auctionContentUrl}/delete-content?cId=${cId}&auctionId=${auctionId}`),

    deleteSection: (sId, auctionId) => api.call("post", `${apiConfig.auctionContentUrl}/delete-section?sId=${sId}&auctionId=${auctionId}`),

    getAuctionContentAttachments: (contentSerial) =>
        api.call("post", `${apiConfig.auctionContentUrl}/get-auction-content-attachments?contentSerial=${contentSerial}`),

    uploadAttachment: (e, contentSerial, auctionId, typeId) =>
        auctionAttachmentApi.attach(
            apiConfig.auctionContentUrl +
                `/upload-content-attachment?contentSerial=${contentSerial}&auctionId=${auctionId}&typeId=${typeId}`,
            e.target
        ),

    downloadAttachment: (contentSerial, id) =>
        auctionAttachmentApi.download(apiConfig.auctionContentUrl + `/download-content-attachment?contentSerial=${contentSerial}&id=${id}`),

    removeAttachment: (contentSerial, auctionId, attachmentId) =>
        api.call(
            "post",
            apiConfig.auctionContentUrl +
                `/remove-content-attachment?contentSerial=${contentSerial}&auctionId=${auctionId}&id=${attachmentId}`
        ),
};
