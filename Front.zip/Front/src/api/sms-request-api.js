import { api } from "./api";
import { apiConfig } from "./config";

export const smsRequestApi = {
    init: (documentSerial) => api.call("post", apiConfig.smsRequestUrl + `/init?documentSerial=${documentSerial}`),
    send: (documentSerial, data) => api.call("post", apiConfig.smsRequestUrl + `/send?documentSerial=${documentSerial}`, data),
    cancel: (documentSerial, requestSerial) =>
        api.call("post", apiConfig.smsRequestUrl + `/cancel?documentSerial=${documentSerial}&requestSerial=${requestSerial}`),
    smsRedirectToEvent: (requestSerial) => api.call("post", apiConfig.smsRequestUrl + `/redirect-to-event?requestSerial=${requestSerial}`),
};
