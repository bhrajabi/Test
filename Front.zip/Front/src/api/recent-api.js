import { api } from "./api";
import { apiConfig } from "./config";

export const recentsApi = {
    // recent users
    initializeRecentUsers: (companyId) => api.call("Post", apiConfig.recentsUrl + `/init-recent-users?companyId=${companyId ?? 0}`),
    toggleFavoriteUser: (companyId, userName) =>
        api.call("Post", apiConfig.recentsUrl + `/toggle-favorite-user?companyId=${companyId ?? 0}&userName=${userName}`),
    searchUsers: (companyId, userName, firstName, lastName) =>
        api.call(
            "Post",
            apiConfig.recentsUrl +
                `/search-users?companyId=${companyId ?? 0}&userName=${userName ?? ""}&firstName=${firstName ?? ""}&lastName=${
                    lastName ?? ""
                }`
        ),

    // recent docs
    initRecentDocs: () => api.call("Post", apiConfig.recentsUrl + `/init-recent-docs`),
    initSysMenu: () => api.call("Post", apiConfig.recentsUrl + `/init-sys-menu`),
    pinRecentDoc: (code, pin) => api.call("Post", apiConfig.recentsUrl + `/pin-recent-doc?code=${code}&pin=${pin}`),
    removeRecentDoc: (code) => api.call("Post", apiConfig.recentsUrl + `/remove-recent-doc?code=${code}`),
};
