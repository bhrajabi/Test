import { api } from "./api";
import { apiConfig } from "./config";

export const auctionSmsRequestApi = {
    init: (auctionId) => api.call("post", apiConfig.auctionSmsRequestUrl + `/init?auctionId=${auctionId}`),
    send: (auctionId, data) => api.call("post", apiConfig.auctionSmsRequestUrl + `/send?auctionId=${auctionId}`, data),
    cancel: (documentSerial, requestSerial) =>
        api.call("post", apiConfig.auctionSmsRequestUrl + `/cancel?documentSerial=${documentSerial}&requestSerial=${requestSerial}`),

    redirectToAuction: (requestSerial) =>
        api.call("post", apiConfig.auctionSmsRequestUrl + `/redirect-to-auction?requestSerial=${requestSerial}`),
};
