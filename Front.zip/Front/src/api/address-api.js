import { api } from "./api";
import { apiConfig } from "./config";

export const addressApi = {
    initAddressList: (companyId, usage) =>
        api.call("post", `${apiConfig.AddressUrl}/init-address-list?companyId=${companyId}&usage=${usage}`),
};
