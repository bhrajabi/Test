import { api } from "./api";
import { apiConfig } from "./config";

export const notificatonApi = {
    getNotifications: (data) => api.call("post", apiConfig.notificationUrl + "/get-notifications", data),
    
    getTasks: (data) => api.call("post", apiConfig.notificationUrl + "/get-tasks", data),

    getNotificationsByPaging: (data, page) =>
        api.call("post", apiConfig.notificationUrl + "/get-notifications-by-paging?page=" + page, data),

    sentNotifications: (data) => api.call("post", apiConfig.notificationUrl + "/get-sent-notifications", data),

    markAsVisited: (notifSerial) => api.call("post", apiConfig.notificationUrl + "/mark-as-viewed?notificationSerial=" + notifSerial),

    markAsArchive: (notifSerial) => api.call("post", apiConfig.notificationUrl + "/archive-notification?notificationSerial=" + notifSerial),

    forwardNotification: (data) => api.call("post", apiConfig.notificationUrl + "/forward", data),

    sendPermissionNotification: (title, message) =>
        api.call("post", apiConfig.notificationUrl + `/send-permission-notification?title=${title}&message=${message}`),

    userNotifications: () => api.call("post", apiConfig.notificationUrl + "/user-notifications"),
};
