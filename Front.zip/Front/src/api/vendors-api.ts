import { EvaluationMemberDTO } from "../types/evaluation-member-dto";
import { EvaluationRequestActivity } from "../types/evaluation-request-activity-dto";
import { EvaluationRequestSearchDTO } from "../types/evalueation-request-search-dto";
import { VendorCompanyDTO } from "../types/vendor-company-dto";
import { VendorEvaluation } from "../types/vendor-evaluation-response";
import { api } from "./api";
import { attachmentApi } from "./attachment-api";
import { apiConfig } from "./config";

export const vendorsApi = {
    initEvaluationRequests: (dto: EvaluationRequestSearchDTO | {}) =>
        api.call("post", apiConfig.evaluationRequestsUrl + `/init-evaluation-requests`, dto),

    initEvaluationRequest: (serial: number) => api.call("post", apiConfig.evaluationRequestsUrl + `/init-vendor-evaluation?id=${serial}`),

    initVendorCompany: (companyId: number, evaluationRequestSerial: number) =>
        api.call(
            "post",
            apiConfig.evaluationRequestsUrl + `/init-vendor-company?id=${companyId}&evaluationRequestSerial=${evaluationRequestSerial}`
        ),

    updateVendorCompany: (dto: VendorCompanyDTO) => api.call("post", apiConfig.evaluationRequestsUrl + `/update-vendor-company`, dto),

    saveEvaluationActivity: (saveCommodityActivity: EvaluationRequestActivity) =>
        api.call("post", apiConfig.evaluationRequestsUrl + `/save-evaluation-activity`, saveCommodityActivity),

    updateVendorEvaluation: (dto: VendorEvaluation) => api.call("post", apiConfig.evaluationRequestsUrl + `/update-vendor-evaluation`, dto),

    deleteEvaluation: (serial: number) =>
        api.call("post", apiConfig.evaluationRequestsUrl + `/delete-evaluation-activity?serial=${serial}`),

    saveChanges: (dto: any | {}) => api.call("post", apiConfig.evaluationRequestsUrl + `/save-changes`, dto),

    initEvaluationActivities: (serial: number) =>
        api.call("post", apiConfig.evaluationRequestsUrl + `/init-evaluation-activities?serial=${serial}`),

    saveEvaluationMember: (dto: EvaluationMemberDTO) => api.call("post", apiConfig.evaluationRequestsUrl + `/save-evaluation-member`, dto),

    deleteEvaluationMember: (userName: string, commodityCode: string) =>
        api.call("post", apiConfig.evaluationRequestsUrl + `/delete-evaluation-member`, { userName, commodityCode }),

    loadChildren: (code: string) => api.call("post", apiConfig.evaluationRequestsUrl + "/load-children?code=" + code),

    initVendorAccess: () => api.call("post", apiConfig.evaluationRequestsUrl + "/init-vendor-access"),

    registerCompany: (dto: any) => api.call("post", apiConfig.evaluationRequestsUrl + "/register-company", dto),

    downloadVendorAttachments: (attachmentId: number) => {
        attachmentApi.download(apiConfig.evaluationRequestsUrl + `/download-vendor-attachments?attachmentId=${attachmentId}`);
    },

    getEvaluationAprocData: (serial: number | null) =>
        api.call("post", apiConfig.evaluationRequestsUrl + `/get-evaluation-aproc-list?evalSerial=${serial}`),

    changeEvalStatus: (serial: number | null, destStatus: string) =>
        api.call("post", apiConfig.evaluationRequestsUrl + `/change-status?evalSerial=${serial}&destStatus=${destStatus}`),

};
