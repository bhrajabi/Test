import { api } from "./api";
import { apiConfig } from "./config";

export const userLogsApi = {
    initUserLogs: (serial, pageNo, trackingSerial, logType) =>
        api.call(
            "post",
            apiConfig.userlogsUrl + `/init-user-logs?serial=${serial}&logType=${logType}&trackingSerial=${trackingSerial}&pageNo=${pageNo}`
        ),
};
