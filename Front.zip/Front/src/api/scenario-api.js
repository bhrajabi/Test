import { api } from "./api";
import { apiConfig } from "./config";

export const scenarioApi = {
    initScenario: (documentSerial) => api.call("post", `${apiConfig.ScenariogUrl}/init-scenario?documentSerial=${documentSerial}`),

    saveScenario: (documentSerial, scenario, scenarioItems) =>
        api.call("post", `${apiConfig.ScenariogUrl}/save-scenario?documentSerial=${documentSerial}`, { scenario, scenarioItems }),

    //addScenario: (documentSerial, scenario) =>
    //api.call("post", `${apiConfig.ScenariogUrl}/add-scenario?documentSerial=${documentSerial}`, scenario),
    // insertScenarioItems: (documentSerial, scenarioSerial, scenarioItems) =>
    //     api.call(
    //         "post",
    //         `${apiConfig.ScenariogUrl}/insert-scenario-items?documentSerial=${documentSerial}&scenarioSerial=${scenarioSerial}`,
    //         scenarioItems
    //     ),

    deleteScenario: (documentSerial, scenarioSerial) =>
        api.call("post", `${apiConfig.ScenariogUrl}/delete-scenario?documentSerial=${documentSerial}&scenarioSerial=${scenarioSerial}`),

    // awardScenario: (documentSerial, scenario) =>
    //     api.call("post", `${apiConfig.ScenariogUrl}/award-scenario?documentSerial=${documentSerial}`, scenario),
    setAsAward: (documentSerial) => api.call("post", `${apiConfig.ScenariogUrl}/set-as-award?documentSerial=${documentSerial}`),
    // changeScenarioStatus: (documentSerial, scenarionSerial, statusId) =>
    //     api.call(
    //         "post",
    //         `${apiConfig.ScenariogUrl}/change-scenario-status?documentSerial=${documentSerial}&scenarionSerial=${scenarionSerial}&statusId=${statusId}`
    //     ),

    wfInitMatrix: (wfInstanceSerial) => api.call("post", `${apiConfig.ScenariogUrl}/wf-init-matrix?wfInstanceSerial=${wfInstanceSerial}`),

    updateScenarioApprove: (data, wfInstanceSerial) =>
        api.call("post", `${apiConfig.ScenariogUrl}/update-scenario-approve?wfInstanceSerial=${wfInstanceSerial}`, data),
};
