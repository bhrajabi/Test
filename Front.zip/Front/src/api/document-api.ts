import { useApi } from "../pages/seller/home/api/use-api-call";
import { api } from "./api";
import { attachmentApi } from "./attachment-api";
import { apiConfig } from "./config";

export const documentsApi = {
    assignTo: (documentSerial: number, userName: string) =>
        api.call("post", `${apiConfig.documentUrl}/assign-to?documentSerial=${documentSerial}&userName=${userName}`),

    search: (data: any) => api.call("post", `${apiConfig.documentUrl}/search-documents`, data),

    userDocumets: () => api.call("post", `${apiConfig.documentUrl}/user-documents`),

    //initSearch: () => api.call("post", `${apiConfig.documentUrl}/init-search`),

    initCreateEvent: (parentSerial: number, eventTypedId: string, cnfSerial: number) =>
        api.call(
            "post",
            apiConfig.documentUrl + `/init-create-event?parentSerial=${parentSerial}&eventTypeId=${eventTypedId}&cnfSerial=${cnfSerial}`
        ),

    initCreateQuickEvent: (requestSerial: number) =>
        api.call("post", apiConfig.documentUrl + `/init-create-quick-rfp?requestSerial=${requestSerial}`),

    createEvent: (data: any) => api.call("post", `${apiConfig.documentUrl}/create-event`, data),

    initEditEvent: (documentSerial: number) =>
        api.call("post", apiConfig.documentUrl + `/init-edit-event?documentSerial=${documentSerial}`),

    saveEvent: (data: any) => api.call("post", `${apiConfig.documentUrl}/save-event`, data),

    saveEventRules: (data: any) => api.call("post", `${apiConfig.documentUrl}/save-event-rules`, data),

    documentAProcList: (documentSerial: any) =>
        api.call("post", apiConfig.documentUrl + `/get-document-aproc-list?documentSerial=${documentSerial}`),

    changeDocumentAproc: (documentSerial: any, action: any, aprocSerial: any) =>
        api.call(
            "post",
            apiConfig.documentUrl +
                `/change-document-aproc?documentSerial=${documentSerial}&aprocAction=${action}&aprocSerial=${aprocSerial}`
        ),

    restoreToPreviousStatus: (docSerial: any) =>
        api.call("post", apiConfig.documentUrl + `/restore-to-previous-status?documentSerial=${docSerial}`),

    createNewRound: (docSerial: number, data: any) =>
        api.call("post", apiConfig.documentUrl + `/create-new-round?documentSerial=${docSerial}`, data),

    completeSurvEvent: (docSerial: number) => api.call("post", apiConfig.documentUrl + `/complete-event-surv?documentSerial=${docSerial}`),

    markAsCmplEventAndProject: (docSerial: number) => api.call("post", apiConfig.documentUrl + `/mark-as-cmpl?documentSerial=${docSerial}`),

    cancelCurrentRound: (docSerial: number) =>
        api.call("post", apiConfig.documentUrl + `/cancell-current-round?documentSerial=${docSerial}`),

    getEventRuleFromTemplate: (documentSeria: number) =>
        api.call("post", apiConfig.documentUrl + `/get-event-rule-from-template?documentSerial=${documentSeria}`),

    initDocumentFlow: (templateSerial: number) =>
        api.call("post", apiConfig.documentUrl + `/init-document-flow?templateSerial=${templateSerial}`),

    getEventTemplates: (projectSerial: number) =>
        api.call("post", apiConfig.documentUrl + `/get-event-templates?projectSerial=${projectSerial}`),

    createQuickEvent: (data: any) => api.call("post", `${apiConfig.documentUrl}/create-quick-event`, data),

    sendFileMessageBySeller: (e: any, documentSerial: number, sellerId: number, participantName: string) =>
        attachmentApi.attach(
            apiConfig.eventUrl +
                `/send-seller-file-message?documentSerial=${documentSerial}&sellerId=${sellerId}&participantName=${participantName}`,
            e.target
        ),

    sendFileMessageByBuyer: (e: any, documentSerial: number, sellerId: number, participantName: string) =>
        attachmentApi.attach(
            apiConfig.documentUrl +
                `/send-buyer-file-message?documentSerial=${documentSerial}&sellerId=${sellerId}&participantName=${participantName}`,
            e.target
        ),

    downloadMsgAttachmentByBuyer: (serial: number, attachmentId: number) =>
        attachmentApi.download(apiConfig.eventUrl + `/download-msg-attachment-by-buyer?serial=${serial}&attachmentId=${attachmentId}`),

    downloadMsgAttachment: (serial: number, attachmentId: number) =>
        attachmentApi.download(apiConfig.eventUrl + `/download-msg-attachment-by-seller?serial=${serial}&attachmentId=${attachmentId}`),

    initBuyerMessaging: (documentSerial: number) =>
        api.call("post", apiConfig.documentUrl + `/init-buyer-messaging?documentSerial=${documentSerial}`),

    getParticipantsMessages: (data: any) => api.call("post", apiConfig.documentUrl + `/get-participant-messages`, data),

    getPriceHistoryFromOrders: (documentSerial: number) =>
        api.call("post", apiConfig.eventUrl + `/get-price-history-from-orders?documentSerial=${documentSerial}`),

    getPriceHistoryFromEvents: (documentSerial: number) =>
        api.call("post", apiConfig.eventUrl + `/get-price-history-from-events?documentSerial=${documentSerial}`),

    awardDocument: (documentSerial: number) => api.call("post", apiConfig.eventUrl + `/award-event?serial=${documentSerial}`),
};

//////////
export const useSearchExternalEventsApi = () => useApi<SearchEvents_DTO>("/documents/search-external-events");

export type SearchEvents_DTO = {
    documents: any[];
    eventCategories: any[];
};
