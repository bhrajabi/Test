import { api } from "./api";
import { apiConfig } from "./config";

export const wfApi = {
    getInbox: (statuses, title) => api.call("post", `${apiConfig.baseUrl}/wf/get-inbox?statuses=${statuses}&t=${title}`),
    getOutbox: (statuses, title) => api.call("post", `${apiConfig.baseUrl}/wf/get-outbox?statuses=${statuses}&t=${title}`),
    getMessageActions: (serial) => api.call("post", `${apiConfig.baseUrl}/wf/get-message-actions?serial=${serial}`),

    trigger: (action) => api.call("post", `${apiConfig.baseUrl}/wf/trigger`, action),
    getWorkflowSteps: (instanceSerial) => api.call("post", `${apiConfig.baseUrl}/wf/get-wf-steps?instanceSerial=${instanceSerial}`),
    getWorkflowInfoByMessage: (messageSerial) => api.call("post", `${apiConfig.baseUrl}/wf/get-wf-by-message?serial=${messageSerial}`),
    markAsCompleted: (messageSerial) => api.call("post", `${apiConfig.baseUrl}/wf/mark-msg-as-completed?serial=${messageSerial}`),
    markMsgAsRead: (messageSerial) => api.call("post", `${apiConfig.baseUrl}/wf/mark-msg-as-read?serial=${messageSerial}`),

    deleteMessage: (serial, lastMessage) =>
        api.call("post", `${apiConfig.baseUrl}/wf/delete-message?serial=${serial}&lastInstance=${lastMessage}`),
    changeMessageStatus: (serial) => api.call("post", `${apiConfig.baseUrl}/wf/change-message-status?serial=${serial}`),

    initMBM: (data) => api.call("post", `${apiConfig.baseUrl}/wf/init-manage-by-massage`, data),
    loadMBM: (serial, objectKey, user) =>
        api.call("post", `${apiConfig.baseUrl}/wf/get-message?serial=${serial}&objectKey=${objectKey}&user=${user}`),
    searchMBM: (serial) => api.call("post", `${apiConfig.baseUrl}/wf/manage-by-massage?serial=${serial}`),
    forwardMessege: (msgSerial, toChartUserRole) =>
        api.call("post", `${apiConfig.baseUrl}/wf/forward?msgSerial=${msgSerial}&toChartUserRole=${toChartUserRole}`),
    getWFInfo: (toUserName, fromUserName) =>
        api.call("post", `${apiConfig.baseUrl}/wf/get-worflow-information?toUserName=${toUserName}&fromUserName=${fromUserName}`),
};
