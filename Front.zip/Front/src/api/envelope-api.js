import { api } from "./api";
import { apiConfig } from "./config";

export const envelopeApi = {
    openEnvelope: (documentSerial, meetingSerial, data) =>
        api.call("post", `${apiConfig.envelopeUrl}/open-envelope?documentSerial=${documentSerial}&meetingSerial=${meetingSerial}`, data),

    saveEventEnvelope: (documentSerial, data) =>
        api.call("post", `${apiConfig.envelopeUrl}/save-event-envelope?documentSerial=${documentSerial}`, data),

    deleteEventEnvelopes: (documentSerial, seq) =>
        api.call("post", `${apiConfig.envelopeUrl}/delete-event-envelope?documentSerial=${documentSerial}&seq=${seq}`),

    eventEnvelopeTestKey: (documentSerial, data) =>
        api.call("post", `${apiConfig.envelopeUrl}/envelope-test-key?documentSerial=${documentSerial}`, data),

    genarateRsaKeys: (documentSerial) => api.call("post", `${apiConfig.envelopeUrl}/genarate-rsa-keys?documentSerial=${documentSerial}`),

    savePublicKey: (documentSerial, data) =>
        api.call("post", `${apiConfig.envelopeUrl}/save-public-key?documentSerial=${documentSerial}`, data),

    getApproverUsers: (documentSerial) => api.call("post", `${apiConfig.envelopeUrl}/get-approver-users?documentSerial=${documentSerial}`),

    sendVcToApprovers: (documentSerial) =>
        api.call("post", `${apiConfig.envelopeUrl}/send-vc-to-approvers?documentSerial=${documentSerial}`),
};
