import { api } from "./api";
import { apiConfig } from "./config";

export const commodityApi = {
    // commodity component apis
    initCommodities: () => api.call("post", apiConfig.commodityUrl + "/init-commodities"),
    //getParents: (typeId) => api.call("post", apiConfig.commodityUrl + `/get-parents?typeId=${typeId}`),
    getChildren: (code) => api.call("post", apiConfig.commodityUrl + `/get-children?code=${code}`),
    getAllChildren: (codes) => api.call("post", apiConfig.commodityUrl + `/get-all-children`, { codes }),
    getAllParents: (codes) => api.call("post", apiConfig.commodityUrl + `/get-all-parents`, { codes }),
    search: (dto) => api.call("post", apiConfig.commodityUrl + "/search", dto),
    toggleFavorite: (code) => api.call("post", apiConfig.commodityUrl + "/toggle-favorite?code=" + code),
    getCommodity: (code) => api.call("post", apiConfig.commodityUrl + "/get-commodity?code=" + code),
    saveMyRecentCommodity: (code) => api.call("post", apiConfig.commodityUrl + "/save-my-recent-commodity?code=" + code),
    saveMyRecentCommodities: (data) => api.call("post", apiConfig.commodityUrl + "/save-my-recent-commodities", data),

    //
    getMaterialCommodities: (materialNo) => {
        const url = `${apiConfig.commodityUrl}/get-material-commodities?materialNo=${materialNo}`;
        return api.call("post", url);
    },

    getMaterialBase: (code) => api.call("post", apiConfig.commodityUrl + "/get-material-base?code=" + code),
};
