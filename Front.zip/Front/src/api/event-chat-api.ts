import { api } from "./api";
import { apiConfig } from "./config";

export const eventChatApi = {
    initEventChats: (eventSerial: number) => api.call("post", apiConfig.eventMessagingUrl + `/init-event-chats?serial=${eventSerial}`),
    initEventMessages: () => api.call("post", apiConfig.eventMessagingUrl + `/init-message`),
    sendEventMessage: (dto: SendMessageDTO) => api.call("post", apiConfig.eventMessagingUrl + `/send-message`, dto),
    inviteNewChatMember: (dto: InviteNewChatMemberDTO) => api.call("post", apiConfig.eventMessagingUrl + `/invite-event-chat-member`, dto),
    initEventChatMessages: (chatSerial: number) =>
        api.call("post", apiConfig.eventMessagingUrl + `/init-event-chat-messages?chatSerial=${chatSerial}`),

    leftFromChat: (chatSerial: number) => api.call("post", apiConfig.eventMessagingUrl + `/left-from-chat?chatSerial=${chatSerial}`),
    removeChatMessage: (chatSerial: number, messageSerial: number) =>
        api.call("post", apiConfig.eventMessagingUrl + `/remove-chat-message?messageSerial=${messageSerial}&chatSerial=${chatSerial}`),
};

type SendMessageDTO = {
    chatSerial: number;
    message: string;
};

type InviteNewChatMemberDTO = {
    userName: string;
    chatSerial: number;
    documentSerial: number;
};
