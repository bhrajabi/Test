import { api } from "./api";
import { apiConfig } from "./config";

export const beApi = {
    prepareAwardEvent: (serial) => api.call("post", `${apiConfig.baseUrl}/be/prepare-award-event?serial=${serial}`),
    executeAwardEvent: (serial, actions) => api.call("post", `${apiConfig.baseUrl}/be/execute-award-event?serial=${serial}`, { actions }),

    prepareSubmitConf: (serial) => api.call("post", `${apiConfig.baseUrl}/be/prepare-submit-cnf?serial=${serial}`),
    executeSubmitConf: (serial, actions) => api.call("post", `${apiConfig.baseUrl}/be/execute-submit-cnf?serial=${serial}`, { actions }),

    prepareRegReqWF: (serial) => api.call("post", `${apiConfig.baseUrl}/be/prepare-registration-request?serial=${serial}`),
    executeRegReqWF: (serial, actions) => api.call("post", `${apiConfig.baseUrl}/be/execute-registration-request?serial=${serial}`, { actions }),

    prepareRequestWF: (serial) => api.call("post", `${apiConfig.baseUrl}/be/prepare-request-workflow?serial=${serial}`),
    executeRequestWF: (serial, actions) => api.call("post", `${apiConfig.baseUrl}/be/execute-request-workflow?serial=${serial}`, { actions }),

    preparePublishEvent: (serial) => api.call("post", `${apiConfig.baseUrl}/be/prepare-publish-event?serial=${serial}`),
    executePublishEvent: (serial, actions) => api.call("post", `${apiConfig.baseUrl}/be/execute-publish-event?serial=${serial}`, { actions }),

    prepareCloseEvent: (serial) => api.call("post", `${apiConfig.baseUrl}/be/prepare-close-event?serial=${serial}`),
    executeCloseEvent: (serial, actions) => api.call("post", `${apiConfig.baseUrl}/be/execute-close-event?serial=${serial}`, { actions }),

    prepareGradeEvent: (serial) => api.call("post", `${apiConfig.baseUrl}/be/prepare-grade-event?serial=${serial}`),
    executeGradeEvent: (serial, actions) => api.call("post", `${apiConfig.baseUrl}/be/execute-grade-event?serial=${serial}`, { actions }),
    
    prepareFormWF: (serial) => api.call("post", `${apiConfig.baseUrl}/be/prepare-form-workflow?serial=${serial}`),
    executeFormWF: (serial, actions) => api.call("post", `${apiConfig.baseUrl}/be/execute-form-workflow?serial=${serial}`, { actions }),
};
