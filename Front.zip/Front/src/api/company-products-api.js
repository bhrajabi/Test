import { api } from "./api";
import { attachmentApi } from "./attachment-api";
import { apiConfig } from "./config";

export const companyProductsApi = {
    initProducts: (uniqueId) => api.call("post", apiConfig.companyProductsUrl + `/init-product-prices?uniqueId=${uniqueId}`),

    previewProducts: (file) => attachmentApi.attach(apiConfig.companyProductsUrl + `/preview-product-prices`, undefined, undefined, file),

    saveProducts: (dto) => api.call("post", apiConfig.companyProductsUrl + `/save-product-prices`, dto),

    downloadProducts: (uniqueId) => apiConfig.companyProductsUrl + `/download-product-prices/${uniqueId}`,
};
