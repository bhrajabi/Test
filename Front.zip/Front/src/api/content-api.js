import { api } from "./api";
import { attachmentApi } from "./attachment-api";
import { apiConfig } from "./config";

export const contentApi = {
    initContents: (documentSerial) => api.call("post", `${apiConfig.contentUrl}/init-contents?documentSerial=${documentSerial}`),

    moveHorizontal: (contentSerial, delta) => {
        return api.call("post", `${apiConfig.contentUrl}/move-horizontal?contentSerial=${contentSerial}&delta=${delta}`);
    },
    moveVertical: (contentSerial, delta) => {
        return api.call("post", `${apiConfig.contentUrl}/move-vertical?contentSerial=${contentSerial}&delta=${delta}`);
    },

    cloneContent: (contentSerial) => {
        return api.call("post", `${apiConfig.contentUrl}/clone-content?contentSerial=${contentSerial}`);
    },

    deleteContent: (contentSerial) => {
        return api.call("post", `${apiConfig.contentUrl}/delete-content?contentSerial=${contentSerial}`);
    },

    saveContentScore: (documentSerial, contentSerial, scoreImportance) =>
        api.call(
            "post",
            `${apiConfig.contentUrl}/save-content-score?documentSerial=${documentSerial}&contentSerial=${contentSerial}&scoreImportance=${scoreImportance}`
        ),

    addContent: (documentSerial, values) =>
        api.call("post", `${apiConfig.contentUrl}/add-content?documentSerial=${documentSerial}`, values),

    addContents: (documentSerial, parentSerial, data) =>
        api.call("post", `${apiConfig.contentUrl}/import-contents?documentSerial=${documentSerial}&parentSerial=${parentSerial}`, data),

    updateContent: (documentSerial, values) =>
        api.call("post", `${apiConfig.contentUrl}/update-content?documentSerial=${documentSerial}`, values),

    makeReport: (documentSerial, reportSerial) =>
        api.call("post", `${apiConfig.contentUrl}/make-report?documentSerial=${documentSerial}&reportSerial=${reportSerial}`),

    makeCntResponseReport: (documentSerial, sellerId, reportSerial, selectedRound) =>
        api.call(
            "post",
            `${apiConfig.contentUrl}/make-content-response-report?documentSerial=${documentSerial}&sellerId=${sellerId}&reportSerial=${reportSerial}&selectedRound=${selectedRound}`
        ),

    getSrlibAndSknaDocuments: (documentSerial) => {
        return api.call("post", `${apiConfig.contentUrl}/get-srlib-skna-documents?documentSerial=${documentSerial}`);
    },

    ///

    uploadFile: (documentSerial, file) => {
        const form_data = new FormData();
        form_data.append(`file`, file);
        return api.call("post", apiConfig.contentUrl + `/upload-content-attachment?documentSerial=${documentSerial}`, form_data, {
            "Content-Type": "multipart/form-data",
        });
    },

    downloadFile: (documentSerial, attachmentId) => {
        attachmentApi.download(
            `${apiConfig.contentUrl}/download-content-attachment?documentSerial=${documentSerial}&attachmentId=${attachmentId}`
        );
    },
};
