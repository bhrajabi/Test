import { api } from "./api";
import { apiConfig } from "./config";
export const documentSupplierApi = {
    updateDocumentSupplierExchangeRate: (documentSerial) =>
        api.call("post", `${apiConfig.documentSupplierUrl}/update-document-supplier-exchange-rate?documentSerial=${documentSerial}`),

    toggleApprove: (documentSerial, data) =>
        api.call("post", apiConfig.documentSupplierUrl + `/toggle-approve?documentSerial=${documentSerial}`, data),

    sendSmsToSupplier: (documentSerial, sellerId, data) =>
        api.call(
            "post",
            apiConfig.documentSupplierUrl + `/send-sms-to-supplier?documentSerial=${documentSerial}&sellerId=${sellerId}`,
            data
        ),
    // toggleBuyerCanResponse: (documentSerial, data) =>
    //     api.call("post", apiConfig.documentSupplierUrl + `/toggle-buyer-response?documentSerial=${documentSerial}`, data),

    toggleLocked: (documentSerial, data) =>
        api.call("post", apiConfig.documentSupplierUrl + `/toggle-locked?documentSerial=${documentSerial}`, data),

    InviteEvent: (documentSerial, data) =>
        api.call("post", apiConfig.documentSupplierUrl + `/invite-event?documentSerial=${documentSerial}`, data),

    DeleteEvent: (documentSerial, data) =>
        api.call("post", apiConfig.documentSupplierUrl + `/delete-invitation?documentSerial=${documentSerial}`, data),

    initDocumentSuppliers: (documentSerial) =>
        api.call("post", apiConfig.documentSupplierUrl + `/init-document-suppliers?documentSerial=${documentSerial}`),

    // initContentResponseView: (documentSerial) =>
    //     api.call("post", apiConfig.documentSupplierUrl + `/init-content-response-view?documentSerial=${documentSerial}`),

    makeReport: (documentSerial, reportSerial) =>
        api.call(
            "post",
            apiConfig.documentSupplierUrl + `/supplier-discovery-report?documentSerial=${documentSerial}&reportSerial=${reportSerial}`
        ),

    makeEventSuppliersReport: (documentSerial, reportSerial) =>
        api.call("post", apiConfig.documentSupplierUrl + `/supplier-report?documentSerial=${documentSerial}&reportSerial=${reportSerial}`),

    setCompanyProposers: (documentSerial, sellerId, proposerSerial) =>
        api.call(
            "post",
            apiConfig.documentSupplierUrl +
                `/set-company-proposer?documentSerial=${documentSerial}&sellerId=${sellerId}&proposerSerial=${proposerSerial}`
        ),
    applyOverheadCost: (documentSerial, dto) =>
        api.call("post", apiConfig.documentSupplierUrl + `/apply-overhead-cost?documentSerial=${documentSerial}`, dto),

    inquiryPrintRequest: (documentSerial) =>
        api.call("post", `${apiConfig.documentSupplierUrl}/inquiry-form-print-request?documentSerial=${documentSerial}`),
};
