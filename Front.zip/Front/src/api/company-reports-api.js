import { api } from "./api";
import { apiConfig } from "./config";

export const companyReportsApi = {
    initCompanyReports: (companyId) => api.call("post", `${apiConfig.companyReportsUrl}/init-company-reports?companyId=${companyId}`),
    initCompanyReportsByCode: (code) => api.call("post", `${apiConfig.companyReportsUrl}/init-company-reports-by-code?reportCode=${code}`),
    initWfCompanyReportsByCode: (wfInstanceSerial, code) =>
        api.call(
            "post",
            `${apiConfig.companyReportsUrl}/init-wf-company-reports-by-code?wfInstanceSerial=${wfInstanceSerial}&reportCode=${code}`
        ),
    saveReport: (dto) => api.call("post", `${apiConfig.companyReportsUrl}/save-report`, dto),
    deleteCompanyReports: (serial) => api.call("post", `${apiConfig.companyReportsUrl}/delete-company-reports?serial=${serial}`),
};
