﻿using System.IO;
using System.Net;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Tamin.Controllers
{
    //[Controller]
    [Route("[controller]")]
    public class SystemController : ControllerBase
    {
        
        public SystemController()
        {
        }


        [AllowAnonymous]
        [HttpGet]
        [Route("/appmon.html")]
        public void AppMon(long id)
        {
            var content = "<html><body><h1>App Mon is OK.</h1></body></html>";
            Response.ContentType = "text/html";
            Response.StatusCode = (int)HttpStatusCode.OK;
            Response.WriteAsync(content);
        }
    }
}
