﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using AProc.Services;
using Authentication.Core;
using Authentication.Services;
using Chat.Services;
using Common;
using Common.Security;
using CommonServices.Core;
using IPG.Core;
using IPG.Services.Data;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using Serilog;
using SoapCore;
using Stimulsoft.Base;
using Tamin.Core;
using Tamin.Core.Services;
using Tamin.Services;
using Tamin.Services.DocumentMessaging.Hubs;
using WorkFlow.Services;

namespace Tamin.Host
{
    public class Startup
    {
        private IWebHostEnvironment env;
        public IConfiguration Configuration { get; }

        public bool IsSecurity { get => env.EnvironmentName == "Security"; }



        public Startup(IConfiguration configuration, IWebHostEnvironment env)
        {
            this.env = env;
            Configuration = configuration;
            Log.Logger = new LoggerConfiguration()
            .ReadFrom.Configuration(configuration)
            .CreateLogger();
        }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            //Live event
            services.AddSignalR();
            services.AddSingleton<IDictionary<string, UserConnection>>(opt => new Dictionary<string, UserConnection>());
            services.AddSingleton<IDictionary<string, EventRoom>>(opt => new Dictionary<string, EventRoom>());

            //document messaging
            services.AddSingleton<IDictionary<string, DocumentMessagingUserConnection>>(opt => new Dictionary<string, DocumentMessagingUserConnection>());
            // services.AddSingleton<IDictionary<string, EventRoom>>(opt => new Dictionary<string, EventRoom>());

            services.Configure<WebApiConfig>(Configuration.GetSection(WebApiConfig.SectionName));
            services.Configure<MailConfig>(Configuration.GetSection(MailConfig.SectionName));
            services.Configure<JwtConfig>(Configuration.GetSection(JwtConfig.SectionName));
            services.Configure<StimulsoftConfig>(Configuration.GetSection(StimulsoftConfig.SectionName));
            services.Configure<AuthenticationConfig>(Configuration.GetSection(AuthenticationConfig.SectionName));
            services.Configure<CommonServiceConfig>(Configuration.GetSection(CommonServiceConfig.SectionName));
            services.Configure<PgsbServiceConfig>(Configuration.GetSection(PgsbServiceConfig.SectionName));


            services.AddControllers(options =>
                {
                    options.UseValidateMaxLength(env).UseArabicToString();
                    options.SuppressImplicitRequiredAttributeForNonNullableReferenceTypes = true;
                })
                .AddNewtonsoftJson(options =>
                {
                    options.SerializerSettings.ContractResolver = new CamelCasePropertyNamesContractResolver();
                    options.SerializerSettings.ReferenceLoopHandling = ReferenceLoopHandling.Ignore;
                });

            services.AddHttpContextAccessor();

            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo { Title = "Tamin.Host", Version = "v2.6" });
                c.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
                {
                    In = ParameterLocation.Header,
                    Description = "Please enter a valid token",
                    Name = "Authorizations",
                    Type = SecuritySchemeType.Http,
                    BearerFormat = "JWT",
                    Scheme = "Bearer"
                });

                c.AddSecurityRequirement(new OpenApiSecurityRequirement
                {
                    {
                        new OpenApiSecurityScheme
                        {
                            Reference = new OpenApiReference
                            {
                                Type=ReferenceType.SecurityScheme,
                                Id="Bearer"
                            }
                        },
                        new string[]{}
                    }
                });

                /*
                // Set the comments path for the Swagger JSON and UI.
                if (env.IsDevelopment())
                {
                    var xmlFile = $"{Assembly.GetExec+ utingAssembly().GetName().Name}.xml";
                    var xmlPath = Path.Combine(AppContext.BaseDirectory, xmlFile);
                    c.IncludeXmlComments(xmlPath);
                    c.IncludeXmlComments(Path.Combine(AppContext.BaseDirectory, "Authentication.Controllers.xml"));
                    c.IncludeXmlComments(Path.Combine(AppContext.BaseDirectory, "Tamin.Controllers.xml"));
                    c.IncludeXmlComments(Path.Combine(AppContext.BaseDirectory, "AProc.Controllers.xml"));
                }
                */
            });


            //-- JWT
            services.AddAuthentication(option =>
                {
                    option.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                    option.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
                }).AddJwtBearer(options =>
                {
                    options.TokenValidationParameters = new TokenValidationParameters
                    {
                        ValidateIssuer = true,
                        ValidateAudience = true,
                        ValidateLifetime = true,
                        ValidIssuer = Configuration["Jwt:Issuer"],
                        ValidAudience = Configuration["Jwt:Audience"],
                        IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(Configuration["Jwt:SecretKey"])),
                        ClockSkew = new TimeSpan(0)
                    };
                    options.Events = new JwtBearerEvents
                    {
                        OnMessageReceived = context =>
                        {
                            var accessToken = context.Request.Query["access_token"];

                            var path = context.HttpContext.Request.Path;
                            if (!string.IsNullOrEmpty(accessToken) &&
                                (path.StartsWithSegments("")))
                            {
                                context.Token = accessToken;
                            }
                            return Task.CompletedTask;
                        }
                    };
                });

            //-- CORS
            var cors_origins = new string[]
            {
                #region front
                //-----------ipn front (development)-----------------
                "https://localhost:3001",
                "https://localhost:3002",

                //-----------ipn front (production)-----------------
                "https://ipn.ikco.ir",
                "http://ipn.ikco.ir",

                //-----------ipn front (test)-----------------
                "https://ipntest.ikco.ir",
                "http://ipntest.ikco.ir",

                //-----------ipn front (sec)-----------------
                "https://ipntest.ikco.sec",
                "http://ipntest.ikco.sec",

                //-----------ipn front (stg)-----------------
                "https://ipnstg.ikco.ir",
                "http://ipnstg.ikco.ir",
                #endregion

                #region back
                //-----------ipn back (test)-----------------
                "https://wsipntest.ikco.ir",
                "https://wsipntest.ikco.ir",
                #endregion

                #region servicemonitoring
                "https://servicemonitoringtest.ikco.com",
                #endregion
            };

            services.AddCors(o => o.AddPolicy("react", builder =>
            {
                builder.WithOrigins(cors_origins)
                    .SetIsOriginAllowedToAllowWildcardSubdomains()
                    .AllowAnyMethod()
                    .AllowCredentials()
                    .AllowAnyHeader();
            }));


            //-- Common
            services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();
            services.AddSingleton<IHttpContextService, HttpContextService>();

            //--modelState
            // TODO
            services.AddControllers().ConfigureApiBehaviorOptions(options =>
            {
                options.SuppressModelStateInvalidFilter = true;
            });

            //services.Configure<Microsoft.AspNetCore.Http.Json.JsonOptions>(options =>
            //{
            //    options.SerializerOptions.DefaultIgnoreCondition = System.Text.Json.Serialization.JsonIgnoreCondition.WhenWritingNull;
            //});

            //-- Accounts 
            var connectionString = Configuration["ConnectionString"];
            services.AddAuthenticationServices(connectionString);


            //-- CommonServices
            services.AddCommonServicesService(connectionString);


            services.AddTaminData(connectionString);
            services.AddTaminServices();

            services.AddAttachmentData(connectionString);
            services.AddAttachmentServices();

            //-- chat service dependencies
            services.AddChat(connectionString);

            //-- add ipg
            services.AddIPG(options =>
            {
                options.ConnectionString = connectionString;
                options.ConfigSection = Configuration.GetSection(IPGServiceConfig.SectionName);
            });

            //
            services.AddAProcServices(connectionString);
            services.AddWFServices(connectionString);


            //-- 
            services.AddControllers();

            // Soap services
            services.AddSoapCore();

            StiLicense.Key = "6vJhGtLLLz2GNviWmUTrhSqnOItdDwjBylQzQcAOiHkcgIvwL0jnpsDqRpWg5FI5kt2G7A0tYIcUygBh1sPs7sUZct1/USoUgY9XBwlar38S6cneciUIxW2fNCDuEQxH+YsZ3av3XB9ANA1ky5svdTCkz8cpYIDcdGLGIWE76CjGIxA2sDA09veSwsJnNcow901SYAFjoDMinyUIHQRPcmVo9clh7Tl3T4yqZnTemwtQAssvvsnhBsvSmZhVGEw2d+b/835Q4ZgwOii29RvKn9CoIuI5mxETV3DcNugq5FDqOjYjuAMfTE4n26zhuaEaRrtxeYZk/Z854LcFoKkBTPkJb/o0glIJQKvN+YzaNMzRuTVGQvc1qJZZC7KonTEehGRUkT1dTqWVlKDkv1uxNZ+/WtH8hDZj40ioWqc2cp0yAGkI5ItFDZ0FlFfhqMOiE0Wk/EaVTjAeo9sdfmHxuzby0hU2qUSa77ItCAbjL5yudrcAzWUHlPLESyy2Sa/20KxzU7qeUemem6ersrSbGmTfmv1BSlFMn6fDQjD/2G97K3FZriV5BC0bM3awRA1Z";
        }


        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env, IServiceProvider serviceProvider)
        {
            if (env.IsProduction() || env.EnvironmentName == "Security")
            {
                app.UseExceptionHandler("/Error");
                app.UseHsts();
            }
            else
            {
                app.UseDeveloperExceptionPage();
                app.UseSwagger();
                app.UseSwaggerUI(c => c.SwaggerEndpoint("/swagger/v1/swagger.json", "Tamin.Host v2 - TEST"));
            }

            //app.UseHttpsRedirection();
            app.UseRouting();
            app.UseStaticFiles();

            if (IsSecurity)
            {
                app.UseCors(opt => opt.AllowAnyOrigin().AllowAnyHeader().AllowAnyMethod());
            }
            else
            {
                app.UseCors("react");
            }

            app.UseAuthorization();
            app.UseAuthentication();


            app.UseMiddleware<VisitLogMiddleware>();
            app.UseMiddleware<ExceptionMiddleware>();
            if (env.IsDevelopment()) app.UseMiddleware<DelayMiddleware>();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllerRoute(name: "default", pattern: "{controller}/{action=Index}/{id?}");
                endpoints.MapHub<LiveEventHub>("");
                endpoints.MapHub<DocumentMessageHub>("/event-message");
            });

            app.UseSoapEndpoint<ISoapService>("/PingService.asmx", new SoapEncoderOptions());

        }
    }
}
