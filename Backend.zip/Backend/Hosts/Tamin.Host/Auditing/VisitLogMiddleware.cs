﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using System;
using System.Threading.Tasks;
using Tamin.Core;
using static Stimulsoft.Data.Expressions.Antlr.Runtime.Tree.TreeWizard;

namespace Tamin.Host
{
    public class VisitLogMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly IConfiguration _Configuration;


        public VisitLogMiddleware(RequestDelegate next, IConfiguration configuration)
        {
            _next = next;
            _Configuration = configuration;
        }

        public async Task InvokeAsync(HttpContext httpContext, ILogService logger)
        {
            await WriteLogAsync(logger);
            await _next(httpContext);
        }

        private async Task WriteLogAsync(ILogService logger)
        {
            var VisitLog = _Configuration["VisitLog"];
            if (VisitLog.eq("true"))
            {
                 await logger.WriteVisitAsync("visited");
            }
        }

    }
}
