﻿using Common;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Hosting;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using System;
using System.Net;
using System.Threading.Tasks;
using Tamin.Core;

namespace Tamin.Host
{
    public class ExceptionMiddleware
    {
        private readonly RequestDelegate _next;

        public ExceptionMiddleware(RequestDelegate next)
        {
            _next = next;
        }

        public async Task InvokeAsync(HttpContext httpContext, ILogService logger, IWebHostEnvironment env)
        {
            try
            {
                await _next(httpContext);
            }
            catch (Exception ex)
            {
                HandleException(httpContext, ex, logger, env);
            }
        }




        private string GetErrorMessage(Exception exception, IWebHostEnvironment env)
        {
            if (exception is Error) return exception.Message;
            var ex_str = exception.ToString();

            if (ex_str.Contains("A network-related or instance-specific error occurred while establishing a connection to SQL Server."))
                return Responses.DbAccessError().ErrorMessage;
            else if (ex_str.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
                return Responses.CannotDeleteBecauseOfForignKeyConstraint().ErrorMessage;
            else if (ex_str.Contains("Cannot insert duplicate key"))
            {
                if (ex_str.Contains("_NationalCode")) return Responses.DuplicateNationalCode().ErrorMessage;
                if (ex_str.Contains("_PhoneNumber")) return Responses.DuplicatePhoneNumber().ErrorMessage;
                else return Responses.CannotInsertDuplicateKey().ErrorMessage;
            }

            if (env.IsProduction() || env.EnvironmentName == "Security")
                return "500-server-error";

            return Error.Translate(exception);
        }

        private void HandleException(HttpContext context, Exception exception, ILogService logger, IWebHostEnvironment env)
        {
            var msg = GetErrorMessage(exception, env);
            if (exception is not Error) logger.WriteSysLog(exception, msg);
            
            context.Response.ContentType = "application/json";
            context.Response.StatusCode = (int)HttpStatusCode.OK;
            var resp = new Response
            {
                IsSuccess = false,
                ErrorCode = "500",
                ErrorMessage = msg,
                ErrorParams = (exception as Error)?.Parameters
            };

            var Content = JsonConvert.SerializeObject(resp, new JsonSerializerSettings { ContractResolver = new CamelCasePropertyNamesContractResolver() });
            context.Response.WriteAsync(Content);
        }


    }
}
