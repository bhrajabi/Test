﻿using Common;
using CommonServices.Core;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using System;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace Tamin.Host
{
    public class DelayMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly IConfiguration _Configuration;


        public DelayMiddleware(RequestDelegate next, IConfiguration configuration)
        {
            _next = next;
            _Configuration = configuration;
        }

        public async Task InvokeAsync(HttpContext httpContext)
        {
            var is_userInfo = httpContext.Request.Path.ToString().Contains("user-info");
            var is_getEn = httpContext.Request.Path.ToString().Contains("/locales/get-en");
            if (!is_userInfo && !is_getEn)
            {
                var d = _Configuration["ApiDelay"].ToInt(0);
                if (d > 0) Thread.Sleep(d);
            }
            await _next(httpContext);
        }

    }
}
