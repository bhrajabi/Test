﻿using AProc.Services;
using Authentication.Core;
using Authentication.Services;
using Chat.Services;
using Common.Security;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Server.Kestrel.Core;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using Serilog;
using System;
using System.Collections.Generic;
using System.Text;
using Tamin.Core;
using Tamin.Services;

namespace Tamin.Integration.Host
{
    public class Startup
    {
        private IWebHostEnvironment env;
        public IConfiguration Configuration { get; }


        public Startup(IConfiguration configuration, IWebHostEnvironment env)
        {
            this.env = env;
            Configuration = configuration;
            Log.Logger = new LoggerConfiguration()
            .ReadFrom.Configuration(configuration)
            .CreateLogger();
        }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            //services.Configure<KestrelServerOptions>(options => { options.AllowSynchronousIO = true; });
            //services.Configure<IISServerOptions>(options => { options.AllowSynchronousIO = true; });


            //Live event
            services.AddSignalR();
            services.AddSingleton<IDictionary<string, UserConnection>>(opt => new Dictionary<string, UserConnection>());
            services.AddSingleton<IDictionary<string, EventRoom>>(opt => new Dictionary<string, EventRoom>());

            services.Configure<WebApiConfig>(Configuration.GetSection(WebApiConfig.SectionName));
            services.Configure<JwtConfig>(Configuration.GetSection(JwtConfig.SectionName));
            services.Configure<AuthenticationConfig>(Configuration.GetSection(AuthenticationConfig.SectionName));
            services.Configure<CommonServiceConfig>(Configuration.GetSection(CommonServiceConfig.SectionName));


            services.AddControllers().AddNewtonsoftJson(options =>
            {
                options.SerializerSettings.ContractResolver = new CamelCasePropertyNamesContractResolver();
                options.SerializerSettings.ReferenceLoopHandling = ReferenceLoopHandling.Ignore;
            });

            services.AddHttpContextAccessor();

            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo { Title = "Tamin.Integration.Host", Version = "v4.10" });
                c.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
                {
                    In = ParameterLocation.Header,
                    Description = "Please enter a valid token",
                    Name = "Authorizations",
                    Type = SecuritySchemeType.Http,
                    BearerFormat = "JWT",
                    Scheme = "Bearer"
                });
                c.AddSecurityRequirement(new OpenApiSecurityRequirement
                {
                    {
                        new OpenApiSecurityScheme
                        {
                            Reference = new OpenApiReference
                            {
                                Type=ReferenceType.SecurityScheme,
                                Id="Bearer"
                            }
                        },
                        new string[]{}
                    }
                });
            });


            //-- JWT
            services.AddAuthentication(option =>
                {
                    option.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                    option.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
                }).AddJwtBearer(options =>
                {
                    options.TokenValidationParameters = new TokenValidationParameters
                    {
                        ValidateIssuer = true,
                        ValidateAudience = true,
                        ValidateLifetime = true,
                        ValidIssuer = Configuration["Jwt:Issuer"],
                        ValidAudience = Configuration["Jwt:Audience"],
                        IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(Configuration["Jwt:SecretKey"])),
                        ClockSkew = new TimeSpan(0)
                    };
                });


            //-- CORS
            var cors_origins = new string[]
            {
                "https://localhost:3001",
                "https://localhost:3002",
                "https://tamin.ikco.ir",
                "https://tamintest.ikco.ir",
                "https://tamintest.ikco.sec",
                "https://servicemonitoringtest.ikco.com",
                "*",
            };



            services.AddCors(o => o.AddPolicy("react", builder =>
            {
                builder.WithOrigins(cors_origins)
                    .SetIsOriginAllowedToAllowWildcardSubdomains()
                    .AllowAnyMethod()
                    .AllowCredentials()
                    .AllowAnyHeader();
            }));


            //-- Common
            services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();
            services.AddSingleton<IHttpContextService, HttpContextService>();

            var connectionString = Configuration["ConnectionString"];

            // Tamin
            services.AddTaminData(connectionString);
            services.AddTaminServices();
            services.AddAttachmentData(connectionString);
            services.AddAttachmentServices();

            // Authentication
            services.AddAuthenticationServices(connectionString);

            // AProc
            services.AddAProcServices(connectionString);

            // CommonServices
            services.AddCommonServicesService(connectionString);

            //-- chat service dependencies
            services.AddChat(connectionString);
           

        }


        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsProduction())
            {
                app.UseExceptionHandler("/Error");
                app.UseHsts();
                app.Use(async (context, next) =>
                {
                    if (context.Request.Path.Value.Contains("test/"))
                    {
                        context.Response.StatusCode = 404;
                        return;
                    }
                    else
                    {
                        await next.Invoke();
                    }
                });
            }
            else
            {
                app.UseDeveloperExceptionPage();
                app.UseSwagger();
                app.UseSwaggerUI(c => c.SwaggerEndpoint("/swagger/v1/swagger.json", "Tamin.Integration.Host v4.10"));
            }

            //app.UseHttpsRedirection();
            app.UseRouting();
            app.UseStaticFiles();

            app.UseCors("react");

            app.UseAuthorization();
            app.UseAuthentication();

            //app.UseMiddleware<LogProfilerMiddleware>();
            app.UseMiddleware<ExceptionMiddleware>();
            if (env.IsDevelopment()) app.UseMiddleware<DelayMiddleware>();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllerRoute(
                    name: "default",
                    pattern: "{controller}/{action=Index}/{id?}");

                endpoints.MapHub<LiveEventHub>("");
            });
        }

    }
}
