﻿using Common;
using Tamin.Core;
using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using System;
using System.Net;
using System.Threading.Tasks;

namespace Tamin.Integration.Host
{
    public class ExceptionMiddleware
    {
        private readonly RequestDelegate _next;

        public ExceptionMiddleware(RequestDelegate next)
        {
            _next = next;
        }

        public async Task InvokeAsync(HttpContext httpContext, ILogService logger)
        {
            try
            {
                await _next(httpContext);
            }
            catch (Exception ex)
            {
                HandleException(httpContext, ex, logger);
            }
        }

        private void HandleException(HttpContext context, Exception exception, ILogService logger)
        {
            var msg = ExceptionTranslator.Translate(exception);
            var ex_str = exception.ToString();
            if (ex_str.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
                msg = "cannot-delete-because-of-forign-key-constraint";
            else if (ex_str.Contains("Cannot insert duplicate key"))
            {
                if (ex_str.Contains("_NationalCode")) msg = "duplicate-national-code";
                if (ex_str.Contains("_PhoneNumber")) msg = "duplicate-phone-number";
                else msg = "cannot-insert-duplicate-key";
            }

            logger.WriteSysLog(exception, msg);

            context.Response.ContentType = "application/json";
            context.Response.StatusCode = (int)HttpStatusCode.OK;
            var resp = new Response
            {
                IsSuccess = false,
                ErrorCode = "500",
                ErrorMessage = msg,
            };

            var Content = JsonConvert.SerializeObject(resp, new JsonSerializerSettings { ContractResolver = new CamelCasePropertyNamesContractResolver() });
            context.Response.WriteAsync(Content);
        }


    }
}
