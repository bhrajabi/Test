﻿using Common;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;

namespace Tamin.Integration.Host
{
    [ApiController]
    [EnableCors("react")]
    [Route("[controller]/[action]")]
    public class SwagerController
    {
        public IConfiguration Configuration { get; }

        public SwagerController(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        [HttpGet]
        [EnableCors("react")]
        [AllowAnonymous]
        [Route("~/test/swagger.json")]
        public Response InitSwager()
        {
            var ServiceAdrress = Configuration["ServiceAdrress"];

            //https://localhost:44346/swagger/v1/swagger.json
            var a = ServiceAdrress.ToString() + "/swagger/v1/swagger.json";
            var result = new { data = new Rest(ServiceAdrress.ToString() + "/swagger/v1/swagger.json").Get() };

            return new Response(result);
        }
    }
}
