﻿using Amazon.Runtime;
using Amazon.S3;
using Amazon.S3.Model;
using Amazon.S3.Transfer;
using Attachments.Core;

namespace Attachments.Service
{
    public class S3Service : IS3Service
    {
        private readonly string _bucketName;
        private readonly IAmazonS3 _s3Client;

        public S3Service()
        {
            string accessKey = "62cb3ddd-7dc5-4cd5-9611-508f98856f56";
            string secretKey = "ba6b810b715cabe6c94612e9f96b40e20a847d583d1972bc8cf09d3c10071f89";
            string serviceUrl = "https://s3.ir-thr-at1.arvanstorage.ir";
            string bucketName = "mahanmarket";

            var config = new AmazonS3Config
            {
                ServiceURL = serviceUrl,
                ForcePathStyle = true 
            };

            var credentials = new BasicAWSCredentials(accessKey, secretKey);
            _s3Client = new AmazonS3Client(credentials, config);
            _bucketName = bucketName;
        }

        public async Task<S3UploadResponse> UploadFileAsync(Stream stream, string keyName)
        {
            try
            {
                var fileTransferUtility = new TransferUtility(_s3Client);
                await fileTransferUtility.UploadAsync(stream, _bucketName, keyName);
                return new S3UploadResponse { Uploaded = true };
            }
            catch (AmazonS3Exception e)
            {
                return new S3UploadResponse { Uploaded = false, Message = $"Error uploading file: {e.Message}" };
            }
        }

        public async Task<S3DownloadResponse> DownloadFileAsync(string keyName)
        {
            try
            {
                var getObjectRequest = new GetObjectRequest
                {
                    BucketName = _bucketName,
                    Key = keyName
                };
                
                var response=await _s3Client.GetObjectAsync(getObjectRequest);
                return new S3DownloadResponse { Stream = response.ResponseStream, ContentType = response.Headers.ContentType };
            }
            catch (AmazonS3Exception e)
            {
                return new S3DownloadResponse { Message = $"Error downloading file: {e.Message}" };
            }
        }

        public async Task<S3DeleteResponse> DeleteFileAsync(string keyName)
        {
            try
            {
                var deleteObjectRequest = new DeleteObjectRequest
                {
                    BucketName = _bucketName,
                    Key = keyName
                };

                await _s3Client.DeleteObjectAsync(deleteObjectRequest);
                return new S3DeleteResponse { Deleted = true };
            }
            catch (AmazonS3Exception e)
            {
                return new S3DeleteResponse { Deleted = false, Message = $"Error deleting file: {e.Message}" };
            }
        }
    }
}
