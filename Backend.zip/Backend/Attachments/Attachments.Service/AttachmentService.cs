﻿using Attachments.Core;
using Common.Security;
using Main.Core;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Options;

namespace Attachments.Service
{
    public class AttachmentService : IAttachmentService
    {
        private IHttpContextService _ContextService;
        private readonly AttachmentConfig attachmentConfig;
        private readonly AttachmentDbContext db;
        private readonly IS3Service s3Service;

        public AttachmentService(IOptions<AttachmentConfig> attachmentConfig, AttachmentDbContext context, IHttpContextService contextService, IS3Service s3Service)
        {
            this.attachmentConfig = attachmentConfig.Value;
            this.db = context;
            _ContextService = contextService;
            this.s3Service = s3Service;
        }


        public IList<Attachment> GetAttachmentsByKey(object objectKey)
        {
            if (objectKey == null) return new List<Attachment>();
            var q = from a in db.Attachments
                    where a.ObjectKey == objectKey.ToString()
                    select a;

            return q.ToList();
        }

        public Attachment GetAttachmentById(long serial)
        {
            try
            {
                return db.Attachments.Where(x => x.Id == serial).FirstOrDefault();
            }
            catch (Exception ex)
            {

                throw;
            }

        }

        public async Task<S3DownloadResponse> Download(string key)
        {
            return await s3Service.DownloadFileAsync(key);
        }

        public async Task<Attachment> AddAttachment(long? refrenceId, IFormFile file, string fileName)
        {
            if (file == null || file.Length == 0)
                throw new Exception("Invalid attachment!");

            if (fileName == null || fileName == string.Empty)
                throw new Exception("Invalid File Name");

            using (var ms = new MemoryStream())
            {
                file.CopyTo(ms);

                var a = new Attachment
                {
                    ReferenceId = refrenceId,
                    Category = "F",
                    MimeType = file.ContentType,
                    FileName = fileName,
                };

                db.Add(a);
                db.SaveChanges();

                byte[] data = ms.ToArray();
                var stream = new MemoryStream(data);
                await s3Service.UploadFileAsync(stream, a.Id.ToString());
                return a;
            };
        }

        public Attachment AddDirectory(long? refrenceId, string name)
        {
            if (name == null || name == string.Empty)
                throw new Exception("Invalid Category Name");

            using (var ms = new MemoryStream())
            {
                var a = new Attachment
                {
                    ReferenceId = refrenceId,
                    Category = "C",
                };

                db.Add(a);
                db.SaveChanges();
                return a;
            };
        }

        public Attachment UpdateAttachment(long id, string objectHeader, object objectKey, string typeId)
        {
            var attachment = GetAttachmentById(id);
            if (attachment == null) throw new Exception(Messages.AttachmentNotFound);

            var t = db.AttachmentTypes.Where(x => x.Id == attachment.TypeId).FirstOrDefault();

            if (t == null)
                throw new Exception("The attachment type '" + attachment.TypeId + "' is not defined");

            if (!string.IsNullOrEmpty(t.ValidTypes))
            {
                var matched = false;
                foreach (var typ in t.ValidTypes.Replace(" ", "").Split(','))
                {
                    matched = IsValidType(typ.ToLower(), attachment.MimeType, attachment.FileName);
                    if (matched)
                        break;
                }
                if (!matched) throw new Exception("Attachment: Invalid file type!");
            }

            var attachments = db.Attachments.Where(x => x.ObjectHeader == objectHeader && x.ObjectKey == objectKey).ToList();
            if (attachments.Count >= t.Count) throw new Exception("Maximum attachments count is:" + t.Count);

            if (t.Count > 0)
            {
                var list = db.Attachments
                    .Where(x =>
                        x.ObjectHeader == objectHeader &&
                        x.ObjectKey == attachment.ObjectKey &&
                        x.TypeId == attachment.TypeId)
                    .ToList();

                if (list.Count > t.Count)
                    throw new Exception("Attachment: Maximum number of attachments = " + t.Count);
            }

            attachment.ObjectHeader = objectHeader;
            attachment.ObjectKey = objectKey.ToString();
            attachment.TypeId = typeId;
            db.Update(attachment);
            db.SaveChanges();

            return attachment;
        }

        public void DeleteAttachments(IList<Attachment> attachments)
        {
            if (attachments.Count == 0) return;

            db.Attachments.RemoveRange(attachments);
            db.SaveChanges();
        }

        public void DeleteAttachments(object objectKey)
        {
            var attachments = GetAttachmentsByKey(objectKey);
            DeleteAttachments(attachments);
        }

        private bool IsValidType(string typ, string mimeType, string fileName)
        {
            var ext = string.IsNullOrEmpty(fileName) ? null : Path.GetExtension(fileName);
            if (!string.IsNullOrEmpty(ext) && ext[0] == '.')
                ext = ext.Substring(1);
            switch (typ)
            {
                case "xml":
                    return mimeType.eq("application/xml") && (ext == null || ext.eq("xml"));
                case "pdf":
                    return mimeType.eq("application/pdf") && (ext == null || ext.eq("pdf"));

                case "word":
                    return (mimeType.eq("application/msword") || mimeType.eq("application/vnd.openxmlformats-officedocument.wordprocessingml.document")) &&
                        (ext == null || ext.eq("doc") || ext.eq("docx") || ext.eq("dot") || ext.eq("dotx"));

                case "excel":
                    return (mimeType.eq("application/vnd.ms-excel") || mimeType.eq("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")) &&
                        (ext == null || ext.eq("xls") || ext.eq("xlsx") || ext.eq("xlt") || ext.eq("xltx"));

                case "powerpoint":
                    return (mimeType.eq("application/vnd.ms-powerpoint") || mimeType.eq("application/vnd.openxmlformats-officedocument.presentationml.presentation")) &&
                        (ext == null || ext.eq("pps") || ext.eq("ppsx") || ext.eq("ppt") || ext.eq("pptx"));

                case "zip":
                    return (mimeType.eq("application/vnd.rar") || mimeType.eq("application/zip")) &&
                        (ext == null || ext.eq("zip") || ext.eq("rar"));

                case "font":
                    return (mimeType.StartsWith("font/") || mimeType.eq("application/zip")) &&
                        (ext == null || ext.eq("woff") || ext.eq("woff2") || ext.eq("ttf") || ext.eq("eot") || ext.eq("otf"));

                case "image":
                    return (mimeType.StartsWith("image/")) &&
                        (ext == null || "tif,tiff,webp,bmp,gif,ico,jpeg,jpg,png,svg".Split(',').Any(x => x.eq(ext)));

                case "svg":
                    return (mimeType.StartsWith("image/svg+xml")) && (ext == null || "svg".eq(ext));
                case "jpg":
                    return (mimeType.StartsWith("image/jpeg")) && (ext == null || "jpg".eq(ext) || "jpeg".eq(ext));
                case "gif":
                    return (mimeType.StartsWith("image/gif")) && (ext == null || "gif".eq(ext));
                case "png":
                    return (mimeType.StartsWith("image/png")) && (ext == null || "png".eq(ext));
                case "bmp":
                    return (mimeType.StartsWith("image/bmp")) && (ext == null || "bmp".eq(ext));
                case "ico":
                    return (mimeType.StartsWith("image/vnd.microsoft.icon")) && (ext == null || "ico".eq(ext));

                case "mp4":
                    return (mimeType.StartsWith("video/mp4")) && (ext == null || "mp4".eq(ext));
                case "mpeg":
                    return (mimeType.StartsWith("video/mpeg")) && (ext == null || "mpeg".eq(ext));
                case "webm":
                    return (mimeType.StartsWith("video/webm")) && (ext == null || "webm".eq(ext));
                case "3gp":
                    return (mimeType.StartsWith("video/3gpp")) && (ext == null || "3gp".eq(ext));

                case "mp3":
                    return (mimeType.StartsWith("audio/mpeg")) && (ext == null || "mp3".eq(ext));
            }
            return false;
        }

        public void DeleteAttachmentById(long serial)
        {
            var a = db.Attachments.FirstOrDefault(x => x.Id == serial);
            db.Attachments.Remove(a);
            db.SaveChanges();
            s3Service.DeleteFileAsync(serial.ToString());
        }

        public IList<Attachment> GetAttachments(long? refrenceId)
        {
            return db.Attachments.Where(x => x.ReferenceId == refrenceId).ToList();
        }
    }
}