﻿using Attachments.Core;
using Common.Data;
using Common.Security;
using Microsoft.EntityFrameworkCore;

namespace Attachments.Service
{
    public class AttachmentDbContext : BaseDbContext
    {
        public DbSet<Attachment> Attachments { get; set; }
        public DbSet<AttachmentType> AttachmentTypes { get; set; }

        public AttachmentDbContext(DbContextOptions<AttachmentDbContext> options, IHttpContextService currentUserNameService) : base(options, currentUserNameService)
        {

        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
        }
    }
}
