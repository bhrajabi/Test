﻿using Attachments.Core;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;

namespace Attachments.Service
{
    public static class DependencyInjection
    {
        public static void AddAttachmentData(this IServiceCollection services, string connectionString)
        {
            services.AddDbContext<AttachmentDbContext>(options => options
                        .UseSqlServer(connectionString)
                        .UseQueryTrackingBehavior(QueryTrackingBehavior.NoTracking)
                        );
        }

        public static void AddAttachmentrServices(this IServiceCollection services)
        {
            services.AddScoped<IAttachmentService, AttachmentService>();
            services.AddScoped<IS3Service, S3Service>();
        }
    }
}