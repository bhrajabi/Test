namespace Attachments.Controllers
{
    public class AttachmentDTO 
    {
        public long Id { get; set; }
        public long? ReferenceId { get; set; }
        public string? Title { get; set; }
        public string? MimeType { get; set; }
        public string? FileName { get; set; }
        public int? Size { get; set; }
        public DateTime CreatedAt { get; set; }
    }
}
