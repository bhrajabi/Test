﻿using Attachments.Controllers;
using Attachments.Core;
using Common;
using Main.Core;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Master.Controllers
{
    [ApiController]
    [EnableCors("react")]
    [Route("[controller]/[action]")]
    [Authorize(AuthenticationSchemes = "Bearer")]
    public class AttachmentController : ControllerBase
    {
        private readonly IAttachmentService attachmentService;


        public AttachmentController(IAttachmentService attachmentService)
        {
            this.attachmentService = attachmentService;
        }

        [HttpPost]
        [Route("~/attachment/get-attachments")]
        public Response getAttachments(long? referenceId)
        {
            var attachments = attachmentService.GetAttachments(referenceId);

            var result = new
            {
                Attachments = attachments.MapTo<AttachmentDTO>()
            };
            return new Response(result);
        }


        //[AllowAnonymous]
        [HttpGet]
        [Route("~/attachment/get-file")]
        public async Task<IActionResult> GetFile(long attachmentId)
        {
            var attachment = attachmentService.GetAttachmentById(attachmentId);
            if (attachment == null) return NotFound();

            var stream = await attachmentService.Download(attachmentId.ToString());
            if (stream == null || stream.Stream == null) return NotFound();

            return base.File(stream.Stream, attachment.MimeType, attachment.FileName);
        }

        [HttpPost]
        [Route("~/attachment/add-attachment")]
        public async Task<Response> AddAttachment(long? referenceId, IFormFile file)
        {
            var attachment = await attachmentService.AddAttachment(referenceId, file, file.FileName);
            return new Response(attachment);
        }

        [HttpPost]
        [Route("~/attachment/add-directory")]
        public Response AddDirectory(long? referenceId, string name)
        {
            var directory = attachmentService.AddDirectory(referenceId, name);
            return new Response(directory);
        }

        [HttpPost]
        [Route("~/attachment/delete-attachment")]
        public Response DeleteAttachment(long? id)
        {
            if (!id.HasValue) return Responses.BadRequest();
            var attachment = attachmentService.GetAttachmentById(id.Value);
            if (attachment == null) return Responses.AttachmentNotFound();

             attachmentService.DeleteAttachmentById(id.Value);
            return new Response();
        }
    }
}
