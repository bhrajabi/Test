﻿namespace Attachments.Core
{
    public interface IS3Service
    {
        Task<S3DeleteResponse> DeleteFileAsync(string keyName);
        Task<S3DownloadResponse> DownloadFileAsync(string keyName);
        Task<S3UploadResponse> UploadFileAsync(Stream stream, string keyName);
    }
}
