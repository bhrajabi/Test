﻿using Microsoft.AspNetCore.Http;

namespace Attachments.Core
{
    public interface IAttachmentService
    {
        IList<Attachment> GetAttachmentsByKey(object objectKey);

        Attachment GetAttachmentById(long serial);
        void DeleteAttachments(IList<Attachment> attachments);
        void DeleteAttachments(object objectKey);
        void DeleteAttachmentById(long serial);
        Task<S3DownloadResponse> Download(string key);

        Attachment UpdateAttachment(long id, string objectHeader, object objectKey, string typeId);
        Task<Attachment> AddAttachment(long? refrenceId, IFormFile file, string fileName);
        Attachment AddDirectory(long? refrenceId, string name);
        IList<Attachment> GetAttachments(long? refrenceId);
    }
}