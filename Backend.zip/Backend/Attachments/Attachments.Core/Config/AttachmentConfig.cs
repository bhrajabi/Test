﻿namespace Attachments.Core
{
    public class AttachmentConfig
    {
        public const string SectionName = "Attachments";

        public int RequestExpiry { get; set; } = 600; 
    }
}