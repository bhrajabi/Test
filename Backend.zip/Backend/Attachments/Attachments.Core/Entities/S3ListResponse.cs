﻿namespace Attachments.Core
{
    public class S3ListResponse
    {
        public List<S3ObjectResponse> List { get; set; } = new List<S3ObjectResponse>();
        public string Message { get; set; } = string.Empty;
    }
}
