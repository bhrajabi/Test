﻿namespace Attachments.Core
{
    public class S3UploadResponse
    {
        public bool Uploaded { get; set; }
        public string Message { get; set; } = string.Empty;
    }
}
