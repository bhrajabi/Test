using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Attachments.Core
{
    [Table("AttachmentTypes", Schema = "dbo")]
    public class AttachmentType
    {
        [Key]
        public string Id { get; set; }

        public string Title { get; set; }
        public bool IsRequired { get; set; }
        public long MaxSize { get; set; }
        public string ValidTypes { get; set; }
        public int Count { get; set; }

    }
}
