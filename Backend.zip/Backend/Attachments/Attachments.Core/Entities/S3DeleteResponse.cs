﻿namespace Attachments.Core
{
    public class S3DeleteResponse
    {
        public bool Deleted { get; set; }
        public string Message { get; set; } = string.Empty;
    }
}
