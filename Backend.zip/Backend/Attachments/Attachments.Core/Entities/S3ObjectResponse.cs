﻿namespace Attachments.Core
{
    public class S3ObjectResponse
    {
        public string Name { get; set; }
        public long Size { get; set; }
        public string Type { get; set; }
    }
}
