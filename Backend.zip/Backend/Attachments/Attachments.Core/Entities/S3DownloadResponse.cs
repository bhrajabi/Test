﻿namespace Attachments.Core
{
    public class S3DownloadResponse
    {
        public Stream? Stream { get; set; }
        public string Message { get; set; } = string.Empty;
        public string ContentType { get; set; }
    }
}
