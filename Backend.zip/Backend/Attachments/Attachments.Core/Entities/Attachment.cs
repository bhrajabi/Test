using Common.Data;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Attachments.Core
{
    [Table("Attachments", Schema = "dbo")]
    public class Attachment : IHasCreator
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Id { get; set; }

        public long? ReferenceId { get; set; }
        public string? ObjectHeader { get; set; }
        public string? ObjectKey { get; set; }
        public string? TypeId { get; set; }
        public string? Category { get; set; }
        public string? Title { get; set; }
        public string? Description { get; set; }
        public string? MimeType { get; set; }
        public string? FileName { get; set; }
        public int? Size { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedAt { get; set; }
    }
}
