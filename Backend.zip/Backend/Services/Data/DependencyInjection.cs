﻿using Main.Core;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;

namespace Main.Service
{
    public static class DependencyInjection
    {
        public static void AddMainData(this IServiceCollection services, string connectionString)
        {
            services.AddDbContext<MainDbContext>(options => options
                        .UseSqlServer(connectionString)
                        .UseQueryTrackingBehavior(QueryTrackingBehavior.NoTracking)
                        );
        }

        public static void AddMainServices(this IServiceCollection services)
        {
            services.AddScoped<ILogService, LogService>();
          
        }
    }
}