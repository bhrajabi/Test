﻿using Common.Data;
using Common.Security;
using Main.Core;
using Microsoft.EntityFrameworkCore;

namespace Main.Service
{
    public class MainDbContext : BaseDbContext
    {
        public DbSet<SysLog> SysLogs { get; set; }

        public MainDbContext(DbContextOptions<MainDbContext> options, IHttpContextService currentUserNameService) : base(options, currentUserNameService)
        {

        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
        }
    }
}
