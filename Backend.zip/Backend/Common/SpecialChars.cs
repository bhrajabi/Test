﻿namespace Common
{
    public static class SpecialChars
    {
        //public const string Str50 = "!@#$%^&_=`~[]{}<>\\|'\";:?";
        //public const string Str100 = "!@#$%^&_=`~[]{}<>\\|'\";:?";
        //public const string Str1000 = "!@#$%^&_=`~[]{}<>\\|'\";:?";

        //public const string All = "!@#$%^&_=`~[]{}<>\\|'\";:?";
        //public const string Password = "!@#$%^&_=`~[]{}<>\\|'\";:?";
        //public const string Email = "@_";
        //public const string Url = "!@#$%^&_=`~[]{}<>\\|'\";:?";
        //public const string Normal = "!$%&_=~[]<>\\|'\";:?\t،؟";
        //public const string File = "_#$=-@!&%";

        public const string Str50 = "";
        public const string Str100 = "";
        public const string Str1000 = "";

        public const string All = "";
        public const string Password = "";
        public const string Email = "";
        public const string Url = "";
        public const string Normal = "";
        public const string File = "";
    }
}
