﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.ComponentModel.DataAnnotations;
using System.Globalization;
using System.Linq;

namespace Common
{
    public class AllowSpecialCharsAttribute : ValidationAttribute
    {

        public string SpecialChars { get; set; }

        public AllowSpecialCharsAttribute() { }

        public AllowSpecialCharsAttribute(string value)
        {
            this.SpecialChars = value;
        }

        public override bool IsValid(object value)
        {
            return true;
        }
    }
}
