﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Reflection;
using System.Text;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Controllers;
using Microsoft.AspNetCore.Mvc.Filters;

namespace Common
{
    public class ValidateMaxLengthAttribute : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext actionContext)
        {
            var ct = actionContext.HttpContext.Request.ContentType;
            if (ct?.ToLower().Contains("multipart") == true)
            {
                return;
            }

            var states = new List<ValidateErrorModel>();

            foreach (var arg in actionContext.ActionArguments)
            {
                var obj = arg.Value;

                if (obj is null) continue;

                Type type = obj.GetType();
                if (type == typeof(string))
                {
                    var parameter = actionContext.ActionDescriptor.Parameters.Where(x => x.Name == arg.Key).FirstOrDefault() as ControllerParameterDescriptor;
                    if (parameter is null) continue;

                    var mxLengthAttrValue = GetMaxLengthAttributeValue(parameter.ParameterInfo);

                    if (!mxLengthAttrValue.HasValue)
                    {
                        var errorModel = states.FirstOrDefault(x => x.ModelName.Equals(arg.Key));

                        if (errorModel is null)
                        {
                            errorModel = new ValidateErrorModel { ModelName = arg.Key, Errors = new List<string>() };
                            states.Add(errorModel);
                        }
                        errorModel.Errors.Add(arg.Key);
                        continue;
                    }

                    //var truncatedValue = obj.ToString().Length > mxLengthAttrValue ? obj.ToString()[..mxLengthAttrValue.Value] : obj;
                    //actionContext.ActionArguments[arg.Key] = truncatedValue;
                }
                else
                {
                    var model = actionContext.ActionDescriptor.Parameters.Where(x => x.Name == arg.Key).FirstOrDefault() as ControllerParameterDescriptor;
                    var stringProperties = type.GetProperties().Where(prop => prop.PropertyType == typeof(string)).ToList();

                    for (int i = 0; i < stringProperties.Count(); i++)
                    {

                        var prop = stringProperties[i];

                        var value = prop.GetValue(obj);
                        var maxLengthValue = GetMaxLengthAttributeValue(prop);
                        if (!maxLengthValue.HasValue)
                        {
                            var errorModel = states.FirstOrDefault(x => x.ModelName.Equals(type.Name));

                            if (errorModel is null)
                            {
                                errorModel = new ValidateErrorModel { ModelName = type.Name, Errors = new List<string>() };
                                states.Add(errorModel);
                            }

                            errorModel.Errors.Add(prop.Name);

                            continue;
                        }

                        //if (value is null) continue;
                        //prop.SetValue(obj, value.ToString().Length > maxLengthValue.Value ? value.ToString()[..maxLengthValue.Value] : value);
                        prop.SetValue(obj, value);
                    }
                }
            }

            if (states.Any())
            {
                var dc = new Dictionary<string, string>();
                var sb = new StringBuilder();


                states.ForEach(state =>
                {
                    state.Errors.ForEach(error => sb.AppendLine($"{state.ModelName}:{error}"));
                });

                dc.Add("maxlengthErrors", sb.ToString());

                var resp = new Response("maxlength-error-@maxlengthErrors", null, dc);
                actionContext.Result = new JsonResult(resp);
                base.OnActionExecuting(actionContext);
            }
        }

        public int? GetMaxLengthAttributeValue(PropertyInfo info)
        {

            var attrs = info.GetCustomAttributes(false);
            if (!attrs.Any()) return null;

            foreach (object attr in attrs)
            {
                MaxLengthAttribute maxLengthAttribute = attr as MaxLengthAttribute;
                if (maxLengthAttribute != null)
                {
                    return maxLengthAttribute.Length;
                }
            }

            return null;
        }

        public int? GetMaxLengthAttributeValue(ParameterInfo info)
        {

            var attrs = info.GetCustomAttributes(false);
            if (!attrs.Any()) return null;

            foreach (object attr in attrs)
            {
                MaxLengthAttribute maxLengthAttribute = attr as MaxLengthAttribute;
                if (maxLengthAttribute != null)
                {
                    return maxLengthAttribute.Length;
                }
            }

            return null;
        }
    }

    public class ValidateErrorModel
    {

        public string ModelName { get; set; }
        public List<string> Errors { get; set; }
    }
}
