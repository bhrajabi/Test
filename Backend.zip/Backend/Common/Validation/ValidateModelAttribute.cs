﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;

namespace Common
{
    public class ValidateModelAttribute : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext actionContext)
        {
            foreach (var arg in actionContext.ActionArguments)
            {
                var obj = arg.Value;

                if (obj is null) continue;

                Type type = obj.GetType();
                var stringProperties = type.GetProperties()
                    .Where(prop => prop.PropertyType == typeof(string)
                        && !prop.GetCustomAttributes(typeof(DefaultValueAttribute), true).Any());

                foreach (var prop in stringProperties)
                {
                    if (obj.GetType() == typeof(List<string>))
                    {
                        foreach (var item in ((obj) as List<string>))
                        {
                            if (HasSpecialChars(item.ToString(), ""))
                            {
                                actionContext.ModelState.AddModelError(prop.Name, "bad-request");
                            }
                        }
                    }
                    else
                    {
                        var value = prop.GetValue(obj);
                        var defaultValue = prop.GetCustomAttributes(typeof(DefaultValueAttribute), true);
                        if (HasSpecialChars(value?.ToString(), defaultValue.ToString()))
                        {
                            actionContext.ModelState.AddModelError(prop.Name, "bad-request");
                        }
                    }
                }
            }

            if (!actionContext.ModelState.IsValid)
            {
                var resp = new Response(actionContext.ModelState);
                actionContext.Result = new JsonResult(resp);
                base.OnActionExecuting(actionContext);
            }
        }

        public static bool HasSpecialChars(string value, string defaultValue)
        {
            if (string.IsNullOrWhiteSpace(value)) return false;
            //var valid_chars = "()*-/,.\r\n\t0123456789".ToArray();
            var valid_chars = "\r\n\t".ToList();
            valid_chars.AddRange(defaultValue.ToList());


            foreach (var c in value)
            {
                if (c < ' ' && !valid_chars.Contains(c)) return true;
            }
            return false;
        }
    }
}
