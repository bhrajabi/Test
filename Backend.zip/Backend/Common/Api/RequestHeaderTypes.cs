﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common.Api
{
    public static class RequestHeaderTypes
    {
        public const string ContentType = "contentType";
    }
}
