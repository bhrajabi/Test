﻿
using Common.Api;
using Newtonsoft.Json;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace Common
{
    public class Rest
    {
        private readonly RestRequest _request;

        public string DefaultProductionProxyUrl = "http://172.18.1.67:443";
        public string DefaultClientProxyUrl = "http://intsrv01.ikco.com:8080";

        public string ProxyUrl { get; set; } = "http://172.18.1.67:443";
        public string ProxyExceptions { get; set; } = "*ikco.com;*ikco.ir;172.*;dcc-iran.renault.fr*;gwx-iran.renault.fr*;*Tamco.eng*;*Isaco.ir*;*Sapco*;*tps*;*iseikco.com;172.26.121.*;karkard.ip-co.net;*.ikcopress.com;*.itrac*;172.26.3.*;*.ikk.com;*.iranfava.*;10.18.32.*;192.168.*;*.ikco.sec;*.ikido.*;*.ikap.co.ir;*.ikcopress.ir;*.ikdomsec.com;*.vcns.dc;*.ikco.com;*.iseikco.com";
        public string RequestUrl { get; set; }

        public List<RequestHeader> RequestHeaders { get; set; }

        public Rest(string requestUrl)
        {
            RequestUrl = requestUrl;

            RequestHeaders = new List<RequestHeader>();
            _request = new RestRequest(RequestUrl);
        }

        public Rest()
        {
            RequestHeaders = new List<RequestHeader>();
            _request = new RestRequest();
        }

        public void SetUrl(string url)
        {
            RequestUrl = url;
            _request.Resource = RequestUrl;
        }

        public void AddHeader(string name, string value)
        {
            RequestHeaders.Add(new RequestHeader(name, value));
        }

        public WebProxy GetProxy()
        {
            if (string.IsNullOrEmpty(ProxyUrl)) return null;

            var proxy = new WebProxy(ProxyUrl)
            {
                BypassProxyOnLocal = true,
                Credentials = CredentialCache.DefaultCredentials,
            };

            ProxyExceptions
                .Split(';')
                .ToList()
                .ForEach(x => proxy.BypassArrayList.Add(x));

            return proxy;
        }

        public RestClient GetRestClient()
        {
            var clientOptions = new RestClientOptions() { Proxy = GetProxy() };
            var client = new RestClient(clientOptions);

            RequestHeaders?.ForEach(x => _request.AddHeader(x.Name, x.Value));

            return client;
        }

        public void ResetProductionProxy()
        {
            ProxyUrl = DefaultProductionProxyUrl;
        }

        public void ResetClientProxyUrl()
        {
            ProxyUrl = DefaultClientProxyUrl;
        }

        public async Task<RestSharp.RestResponse> GetAsync()
        {
            return await RequestAsync(Method.Get, null);
        }

        public async Task<T> GetAsync<T>() where T : class
        {
            return await RequestAsync<T>(Method.Get, null);
        }

        public RestSharp.RestResponse Get()
        {
            return Request(Method.Get, null);
        }

        public T Get<T>() where T : class
        {
            return Request<T>(Method.Get, null);
        }

        public async Task<RestSharp.RestResponse> PostAsync(object body)
        {
            return await RequestAsync(Method.Post, body);
        }

        public async Task<T> PostAsync<T>(object body) where T : class
        {
            return await RequestAsync<T>(Method.Post, body);
        }

        public RestSharp.RestResponse Post(object body)
        {
            return Request(Method.Post, body);
        }

        public T Post<T>(object body) where T : class
        {
            return Request<T>(Method.Post, body);
        }

        public RestSharp.RestResponse Delete(object body)
        {
            return Request(Method.Delete, body);
        }

        public T Delete<T>(object body) where T : class
        {
            return Request<T>(Method.Delete, body);
        }

        public async Task<RestSharp.RestResponse> DeleteAsync(object body)
        {
            return await RequestAsync(Method.Delete, body);
        }

        public async Task<T> DeleteAsync<T>(object body) where T : class
        {
            return await RequestAsync<T>(Method.Delete, body);
        }

        public RestSharp.RestResponse Put(object body)
        {
            return Request(Method.Put, body);
        }

        public T Put<T>(object body) where T : class
        {
            return Request<T>(Method.Put, body);
        }

        public async Task<RestSharp.RestResponse> PutAsync(object body)
        {
            return await RequestAsync(Method.Put, body);
        }

        public async Task<T> PutAsync<T>(object body) where T : class
        {
            return await RequestAsync<T>(Method.Put, body);
        }


        public RestSharp.RestResponse Head()
        {
            return Request(Method.Head);
        }

        public T Head<T>() where T : class
        {
            return Request<T>(Method.Head);
        }

        public async Task<RestSharp.RestResponse> HeadAsync()
        {
            return await RequestAsync(Method.Head);
        }

        public async Task<T> HeadAsync<T>() where T : class
        {
            return await RequestAsync<T>(Method.Head);
        }

        public RestSharp.RestResponse Request(Method method, object body = null)
        {
            if (string.IsNullOrEmpty(RequestUrl))
            {
                throw new Exception("requested-url-can-not-be-null");
            }

            _request.Method = method;

            if (body != null)
                _request.AddJsonBody(JsonConvert.SerializeObject(body));

            var client = GetRestClient();

            var response = client.Execute(_request);
            
            return response;
        }

        public async Task<RestSharp.RestResponse> RequestAsync(Method method, object body = null)
        {
            if (string.IsNullOrEmpty(RequestUrl))
            {
                throw new Exception("requested-url-can-not-be-null");
            }

            _request.Method = method;

            if (body != null)
                _request.AddJsonBody(JsonConvert.SerializeObject(body));

            var client = GetRestClient();

            var response = await client.ExecuteAsync(_request);

            return response;
        }

        public T Request<T>(Method method, object body = null) where T : class
        {
            var response = Request(method, body);

            if (response.IsSuccessful)
            {
                var content = response.Content;
                return JsonConvert.DeserializeObject<T>(content);
            }

            return null;
        }

        public async Task<T> RequestAsync<T>(Method method, object body = null) where T : class
        {
            var response = await RequestAsync(method, body);

            if (response.IsSuccessful)
            {
                var content = response.Content;
                return JsonConvert.DeserializeObject<T>(content);
            }

            return null;
        }
    }
}