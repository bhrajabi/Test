﻿using RestSharp;

namespace Common
{
    public static class Rest
    {
        public static string Get(string url)
        {
            return Request(Method.Get, url);
        }

        public static T Get<T>(string url) where T : class
        {
            return Request<T>(Method.Get, url);
        }

        public static string Post(string url, object body)
        {
            return Request(Method.Post, url, body);
        }

        public static T Post<T>(string url, object body) where T : class
        {
            return Request<T>(Method.Post, url, body);
        }

        public static string Delete(string url, object body)
        {
            return Request(Method.Delete, url, body);
        }

        public static T Delete<T>(string url, object body) where T : class
        {
            return Request<T>(Method.Delete, url, body);
        }

        public static string Put(string url, object body)
        {
            return Request(Method.Put, url, body);
        }

        public static T Put<T>(string url, object body) where T : class
        {
            return Request<T>(Method.Put, url, body);
        }

        public static string Request(Method method, string url, object body = null)
        {
            using var client = new RestClient(new RestClientOptions()
            {
                //Proxy = new WebProxy("http://intsrv01.ikco.com:8080")
                //{
                //Credentials = CredentialCache.DefaultCredentials
                //}
            });

            var request = new RestRequest(url);
            request.Method = method;

            if (method != Method.Get)
                request.AddParameter("application/json", body, ParameterType.RequestBody);

            var response = client.Execute(request);

            return response.Content;
        }

        public static T Request<T>(Method method, string url, object body = null) where T : class
        {
            using var client = new RestClient(new RestClientOptions()
            {
                //Proxy = new WebProxy("http://intsrv01.ikco.com:8080")
                //{
                //Credentials = CredentialCache.DefaultCredentials
                //}
            });

            var request = new RestRequest(url);
            request.Method = method;

            if (method != Method.Get)
                request.AddParameter("application/json", body, ParameterType.RequestBody);

            var response = client.Execute<T>(request);

            return response.Data;
        }


    }
}
