﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common.Api
{
    public class RestResponse
    {
        public bool Status { get; set; }
        public string ErrorCode { get; set; }
        public string ErrorMessage { get; set; }
        public string Response { get; set; }

        public RestResponse(string content)
        {
            Status = true;
            Response = content;
        }

        public RestResponse(string errorCode, string errorMessage)
        {
            Status = false;
            ErrorCode = errorCode;
            ErrorMessage = errorMessage;
        }
        public RestResponse Error(string errorCode, string errorMessage)
        {
            return new RestResponse(errorCode, errorMessage);
        }
    }
}
