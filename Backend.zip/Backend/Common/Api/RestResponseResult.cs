﻿namespace Common.Api
{
    public class RestResponseResult
    {
        public string Data { get; set; }
        public string ErrorMessage { get; set; }
    }
}
