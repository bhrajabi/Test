﻿namespace Common.Security
{
    public interface IHttpContextService
    {
        string UserName { get; }

        string GetHeader(string name);
        string GetCookie(string name);
        string GetQuery();
        string GetRequestIP();
        string GetItemValue(string itemName);
    }

}
