﻿using System.Linq;
using System.Net;
using Microsoft.AspNetCore.Http;

namespace Common.Security
{
    public class HttpContextService : IHttpContextService
    {
        private readonly IHttpContextAccessor _httpContextAccessor;


        public string UserName
        {
            get
            {
                return _httpContextAccessor.HttpContext?.User.Identity.Name;
            }
        }

        public string GetRequestIP()
        {
            var xForwardedFor = _httpContextAccessor.HttpContext.Request.Headers["X-Forwarded-For"].FirstOrDefault();
            if (!string.IsNullOrEmpty(xForwardedFor)) return xForwardedFor;

            var remoteIpAddress = _httpContextAccessor.HttpContext.Connection.RemoteIpAddress;
            if (remoteIpAddress.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork) return remoteIpAddress.ToString();

            var hostEntry = Dns.GetHostEntry(Dns.GetHostName());

            if (remoteIpAddress.IsIPv6LinkLocal)
            {
                var ip = hostEntry.AddressList.FirstOrDefault(a => !a.IsIPv6LinkLocal)?.ToString();
                if (!string.IsNullOrEmpty(ip)) 
                    return ip;
            }

            return hostEntry.AddressList.FirstOrDefault(a => a.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork)?.ToString() ?? string.Empty;
        }



        public HttpContextService(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
        }

        public string GetHeader(string name)
        {
            _httpContextAccessor.HttpContext.Request.Headers.TryGetValue(name, out var value);
            return value;
        }

        public string GetCookie(string name)
        {
            _httpContextAccessor.HttpContext.Request.Cookies.TryGetValue(name, out var value);
            return value;
        }

        public string GetQuery()
        {
            return _httpContextAccessor.HttpContext.Request.QueryString.Value;
        }

        public string GetItemValue(string itemName)
        {
            return _httpContextAccessor.HttpContext?.Items[itemName]?.ToString();
        }
    }
}
