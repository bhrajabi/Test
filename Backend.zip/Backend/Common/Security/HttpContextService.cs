﻿using Microsoft.AspNetCore.Http;
using System.Security.Claims;

namespace Common.Security
{
    public class HttpContextService : IHttpContextService
    {
        private readonly IHttpContextAccessor _httpContextAccessor;


        public string UserName
        {
            get
            {
                return _httpContextAccessor.HttpContext.User.Identity.Name;
            }
        }



        public HttpContextService(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
        }

        public string GetHeader(string name)
        {
            _httpContextAccessor.HttpContext.Request.Headers.TryGetValue(name, out var value);
            return value;
        }

        public string GetCookie(string name)
        {
            _httpContextAccessor.HttpContext.Request.Cookies.TryGetValue(name, out var value);
            return value;
        }

        public string GetQuery()
        {
            return _httpContextAccessor.HttpContext.Request.QueryString.Value;
        }

    }
}
