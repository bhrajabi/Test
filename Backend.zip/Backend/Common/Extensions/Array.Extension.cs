﻿using System.Collections.Generic;
using System.Linq;

namespace System
{
    public static class ArrayExtensions
    {

        public static bool eq(this IEnumerable<string> source, IEnumerable<string> value)
        {
            return eq(source.ToArray(), value.ToArray(), true);
        }

        public static bool eq(this string[] source, string[] value)
        {
            return eq(source, value, true);
        }

        public static bool eq(this string[] source, string[] value, bool ignoreCase)
        {
            if (source == null && value == null) return true;
            if ((source == null && value != null) || (source != null && value == null)) return false;
            if (source.Length != value.Length) return false;
            var hs = new HashSet<string>();
            foreach (var src in source)
            {
                if (!hs.Contains(src)) hs.Add(src);
            }
            foreach (var val in value)
            {
                if (!hs.Contains(val)) return false;
            }
            return true;
        }
    }
}