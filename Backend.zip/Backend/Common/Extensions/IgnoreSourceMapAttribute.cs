﻿namespace System
{
    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Property)]
    public class IgnoreSourceMapAttribute : Attribute
    {
    }
}