﻿namespace System
{
    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Property)]
    public class IgnoreMapAttribute : Attribute
    {
    }
}