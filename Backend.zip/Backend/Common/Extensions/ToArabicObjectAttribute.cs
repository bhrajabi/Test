﻿using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using Microsoft.AspNetCore.Mvc.Filters;

namespace System
{
    public class ToArabicObjectAttribute : ActionFilterAttribute
    {
        private HashSet<object> visitedValues = new();


        public override void OnActionExecuting(ActionExecutingContext actionContext)
        {
            var ct = actionContext.HttpContext.Request.ContentType;
            if (ct?.ToLower().Contains("multipart") == true) return;

            foreach (var arg in actionContext.ActionArguments.Where(aa => aa.Value != null))
            {
                if (arg.Value == null) continue;
                actionContext.ActionArguments[arg.Key] = ToArabicObject(arg.Value);
            }
        }

        private object? ToArabicObject(object? value)
        {
            if (value is null) return value;
            lock (visitedValues)
            {
                if (visitedValues.Contains(value)) return value;
                visitedValues.Add(value);
            }
            var type = value.GetType();

            //----------
            if (value is string string_value) return string_value.ToArabicString();

            //----------
            if (value is IList<string> valueList)
            {
                for (var i = 0; i < valueList.Count; ++i)
                {
                    valueList[i] = valueList[i].ToArabicString();
                }
                return value;
            }

            //----------
            if (value is string[] valueArray)
            {
                for (var i = 0; i < valueArray.Length; ++i)
                {
                    valueArray[i] = valueArray[i].ToArabicString();
                }
                return value;
            }

            //----------
            if (typeof(IEnumerable).IsAssignableFrom(type))
            {
                foreach (var item in value as IEnumerable)
                {
                    if (item is string) throw new NotImplementedException();
                    ToArabicObject(item);
                }
                return value;
            }

            //----------
            foreach (var pi in type.GetProperties(BindingFlags.Public | BindingFlags.Instance))
            {
                if (!pi.CanRead || !pi.CanWrite) continue;
                var pValue = pi.GetValue(value);
                if (pValue != null)
                {
                    if (pValue is string pValueString)
                    {
                        pi.SetValue(value, pValueString.ToArabicString());
                    }
                    else
                    {
                        var propertyType = pi.PropertyType;
                        if (!propertyType.IsPrimitive && !propertyType.IsEnum && propertyType != typeof(DateTime))
                        {
                            ToArabicObject(pValue);
                        }
                    }
                }
            }

            return value;
        }
    }
}
