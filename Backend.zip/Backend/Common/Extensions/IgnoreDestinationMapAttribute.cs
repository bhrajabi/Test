﻿namespace System
{
    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Property)]
    public class IgnoreDestinationMapAttribute : Attribute
    {
    }
}