﻿using System;

namespace Common.Data
{
    public interface IHasModifier
    {
        [IgnoreDestinationMap]
        string ModifiedBy { get; }

        [IgnoreDestinationMap]
        DateTime ModifiedAt { get; }
    }

}
