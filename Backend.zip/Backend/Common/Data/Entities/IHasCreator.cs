﻿using System;

namespace Common.Data
{
    public interface IHasCreator
    {
        [IgnoreDestinationMap] 
        string CreatedBy { get; }

        [IgnoreDestinationMap] 
        DateTime CreatedAt { get; }
    }

}
