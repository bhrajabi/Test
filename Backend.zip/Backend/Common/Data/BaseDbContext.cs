﻿using Common.Security;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using Microsoft.Extensions.Options;
using System;
using System.Data;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Common.Data
{
    public class BaseDbContext : DbContext
    {
        private IHttpContextService _CurrentUserNameService;

        public DbSet<GetDateResult> DbDate { get; set; }



        public BaseDbContext(DbContextOptions options, IHttpContextService currentUserNameService) : base(options)
        {
            _CurrentUserNameService = currentUserNameService;
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            modelBuilder.Entity<GetDateResult>().HasNoKey();
        }

        public override int SaveChanges(bool acceptAllChangesOnSuccess)
        {
            OnBeforeSave();
            return base.SaveChanges(acceptAllChangesOnSuccess);
        }

        public override Task<int> SaveChangesAsync(bool acceptAllChangesOnSuccess, CancellationToken cancellationToken = default)
        {
            OnBeforeSave();
            return base.SaveChangesAsync(acceptAllChangesOnSuccess, cancellationToken);
        }


        private DateTime LazyGetDate(ref DateTime? now)
        {
            if (!now.HasValue) now = GetDate();
            return now.Value;
        }

        protected virtual void OnBeforeSave()
        {
            DateTime? now = null;

            var entries = ChangeTracker.Entries();
            var user_name = _CurrentUserNameService.UserName;
            var list = entries.ToList();

            foreach (var entry in list)
            {
                if (entry.Entity is IHasCreator)
                {
                    switch (entry.State)
                    {
                        case EntityState.Added:
                            entry.CurrentValues["CreatedAt"] = LazyGetDate(ref now);
                            if (user_name != null) entry.CurrentValues["CreatedBy"] = user_name;
                            break;
                    }
                }

                if (entry.Entity is IHasModifier)
                {
                    switch (entry.State)
                    {
                        case EntityState.Added:
                        case EntityState.Modified:
                            entry.CurrentValues["ModifiedAt"] = LazyGetDate(ref now);
                            if (user_name != null) entry.CurrentValues["ModifiedBy"] = user_name;
                            break;
                    }
                }
            }
        }

        public DataTable GetDataTable(string sql, params SqlParameter[] parameters)
        {
            var connection = Database.GetDbConnection();
            var is_closed = connection.State == ConnectionState.Closed;
            try
            {
                var tb = new DataTable();
                using var cmd = connection.CreateCommand();
                using var da = new SqlDataAdapter(cmd as Microsoft.Data.SqlClient.SqlCommand);

                cmd.CommandText = sql;
                cmd.Parameters.AddRange(parameters);
                if (is_closed) connection.Open();
                da.Fill(tb);
                return tb;
            }
            finally
            {
                if (is_closed && connection.State == ConnectionState.Open) connection.Close();
            }
        }

        public int Execute(string sql, params SqlParameter[] parameters)
        {
            return Execute(sql, null, parameters);
        }

        public int Execute(string sql, System.Data.Common.DbTransaction transaction, params SqlParameter[] parameters)
        {
            var connection = Database.GetDbConnection();
            var is_closed = connection.State == ConnectionState.Closed;
            try
            {
                using var cmd = connection.CreateCommand();
                cmd.CommandText = sql;
                cmd.Transaction = transaction;
                cmd.Parameters.AddRange(parameters);
                if (is_closed) connection.Open();
                return cmd.ExecuteNonQuery();
            }
            finally
            {
                if (is_closed && connection.State == ConnectionState.Open) { connection.Close(); }
            }
        }

        public object ExecuteScalar(string sql, params SqlParameter[] parameters)
        {
            var connection = Database.GetDbConnection();
            var is_closed = connection.State == ConnectionState.Closed;
            try
            {
                using var cmd = connection.CreateCommand();
                cmd.CommandText = sql;
                cmd.Parameters.AddRange(parameters);
                if (is_closed) connection.Open();
                return cmd.ExecuteScalar();
            }
            finally
            {
                if (is_closed && connection.State == ConnectionState.Open) { connection.Close(); }
            }
        }

        public DateTime GetDate()
        {
            //return (DateTime)ExecuteScalar("select getdate()");
            var now = DbDate.FromSqlRaw("select getdate() as date").FirstOrDefault();
            return now.Date;
        }

        //public async Task<DateTime> GetDateAsync()
        //{
        //    var now = await DbDate.FromSqlRaw("select getdate() as date").FirstOrDefaultAsync();
        //    return now.Date;
        //}

        //public DateTime GetDate2()
        //{
        //    var now = DbDate.FromSqlRaw("select getdate() as date").FirstOrDefault();
        //    return now.Date;
        //}


        //public async Task<UserInfo> ExecuteSP(string username, string password)
        //{
        //    var res = Set<UserInfo>()
        //        .FromSqlRaw($"EXEC dbo.sp @username, @password",
        //            new SqlParameter("username", username ?? ""),
        //            new SqlParameter("password", password ?? "")
        //         );
        //    var list = await res.ToListAsync();
        //    return list.FirstOrDefault();
        //}


    }
}