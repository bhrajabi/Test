﻿using System;

namespace Common.Data
{
    public class GetDateResult
    {
        public DateTime Date { get; set; }
    }
}