﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace Common.Data
{
    public class NewRepository<TEntity> : INewRepository<TEntity> where TEntity : class
    {
        protected virtual DbContext Context { get; }

        protected DbSet<TEntity> Entities { get { return Context.Set<TEntity>(); } }


        public NewRepository(DbContext context)
        {
            Context = context;
        }

        public virtual TEntity FindById(int id)
        {
            return Entities.Find(id);
        }

        public virtual ValueTask<TEntity> FindByIdAsync(int id)
        {
            return Entities.FindAsync(id);
        }

        public virtual TEntity Get(object key)
        {
            return Entities.Find(key);
        }

        public virtual ValueTask<TEntity> GetAsync(object key)
        {
            return Entities.FindAsync(key);
        }


        public virtual IList<TEntity> GetAll()
        {
            return Entities.ToList();
        }

        public virtual Task<List<TEntity>> GetAllAsync()
        {
            return Entities.ToListAsync();
        }


        public virtual TEntity FirstOrDefault(Expression<Func<TEntity, bool>> predicate)
        {
            return Entities.Where(predicate).FirstOrDefault();
        }

        public virtual Task<TEntity> FirstOrDefaultAsync(Expression<Func<TEntity, bool>> predicate)
        {
            return Entities.Where(predicate).FirstOrDefaultAsync();
        }


        public virtual TEntity SingleOrDefault(Expression<Func<TEntity, bool>> predicate)
        {
            return Entities.Where(predicate).SingleOrDefault();
        }

        public virtual Task<TEntity> SingleOrDefaultAsync(Expression<Func<TEntity, bool>> predicate)
        {
            return Entities.Where(predicate).SingleOrDefaultAsync(predicate);
        }


        public virtual IList<TEntity> Where(Expression<Func<TEntity, bool>> predicate)
        {
            return Entities.Where(predicate).ToList();
        }

        public virtual Task<List<TEntity>> WhereAsync(Expression<Func<TEntity, bool>> predicate)
        {
            return Entities.Where(predicate).ToListAsync();
        }

        public virtual bool Any(Expression<Func<TEntity, bool>> predicate)
        {
            return Entities.Any(predicate);
        }

        public virtual Task<bool> AnyAsync(Expression<Func<TEntity, bool>> predicate)
        {
            return Entities.AnyAsync(predicate);
        }


        public virtual EntityEntry<TEntity> Add(TEntity entity)
        {
            return Entities.Add(entity);
        }

        public virtual ValueTask<EntityEntry<TEntity>> AddAsync(TEntity entity)
        {
            return Entities.AddAsync(entity);
        }


        public virtual void AddRange(IEnumerable<TEntity> entities)
        {
            Entities.AddRange(entities);
        }

        public virtual Task AddRangeAsync(IEnumerable<TEntity> entities)
        {
            return Entities.AddRangeAsync(entities);
        }


        public virtual void Update(TEntity entity)
        {
            Entities.Update(entity);
        }

        public virtual void UpdateRange(IEnumerable<TEntity> entities)
        {
            Entities.UpdateRange(entities);
        }


        public virtual void Remove(TEntity entity)
        {
            Entities.Remove(entity);
        }

        public virtual void RemoveRange(IEnumerable<TEntity> entities)
        {
            Entities.RemoveRange(entities);
        }

        public virtual IList<TEntity> SqlQuery(string sql, params object[] parameters)
        {
            return Entities.FromSqlRaw(sql, parameters).ToList();
        }

        public virtual void SaveChanges()
        {
            Context.SaveChanges();
        }
    }
}