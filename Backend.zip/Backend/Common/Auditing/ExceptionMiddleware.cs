﻿using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using Serilog.Context;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace Common
{
    public class ExceptionMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly IExceptionTextTranslator _textTranslator;
        private readonly IHttpContextAccessor _httpContextAccessor;


        public ExceptionMiddleware(RequestDelegate next, IExceptionTextTranslator textTranslator, IHttpContextAccessor httpContextAccessor)
        {
            _next = next;
            _textTranslator = textTranslator;
            _httpContextAccessor = httpContextAccessor;

        }

        public async Task InvokeAsync(HttpContext httpContext)
        {
            try
            {
                await _next(httpContext);
            }
            catch (Exception ex)
            {
                Logger.PushUserInfo(_httpContextAccessor);
                Logger.Error(ex, ExceptionTranslator.GetErrorMessage(ex));
                await HandleExceptionAsync(httpContext, ex);
            }
        }

        private async Task HandleExceptionAsync(HttpContext context, Exception exception)
        {
            var msg = ExceptionTranslator.Translate(exception);
            if (!string.IsNullOrEmpty(msg))
            {
                msg = _textTranslator.Translate(msg);
            }
            context.Response.ContentType = "application/json";
            context.Response.StatusCode = (int)HttpStatusCode.OK;
            var resp = new Response
            {
                IsSuccess = false,
                ErrorCode = "500",
                ErrorMessage = msg
            };

            var Content = JsonConvert.SerializeObject(resp, new JsonSerializerSettings { ContractResolver = new CamelCasePropertyNamesContractResolver() });

            await context.Response.WriteAsync(Content);

        }


    }
}
