﻿using Common.Security;
using Microsoft.AspNetCore.Http;
using Serilog.Context;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common
{
    public static class Logger
    {

        public static void PushUserInfo(IHttpContextAccessor accessor)
        {
            accessor.HttpContext.Request.Cookies.TryGetValue("x-session-id", out var sessionId);
            string userName = accessor.HttpContext.User.Identity.Name;
            if (!string.IsNullOrEmpty(sessionId))
            {
                LogContext.PushProperty("SessionId", sessionId.ToInt32());
                if (!string.IsNullOrEmpty(userName))
                    LogContext.PushProperty("UserName", userName);
            }
        }


        public static void Info(string message, string projectId = null, string userName = null, params object[] args)
        {
            var msg = message;
            foreach (var item in args)
            {
                msg += "  " + item == null ? null : item.ToString();
            }
            if (projectId is not null)
                LogContext.PushProperty("ProjectId", projectId);
            if (userName is not null)
                LogContext.PushProperty("UserName", userName);

            Serilog.Log.Information(msg);
        }

        public static void Error(Exception ex, string transalteEx, string projectId = null, string userName = null)
        {
            if (projectId is not null)
                LogContext.PushProperty("ProjectId", projectId);
            if (userName is not null)
                LogContext.PushProperty("UserName", userName);

            Serilog.Log.Error(ex, transalteEx);
        }

        public static void Warning(string message, string projectId = null, string userName = null, params object[] args)
        {
            var msg = message;
            if (args is not null)
            {
                foreach (var item in args)
                {
                    msg += " " + item.ToString();
                }
            }
            if (projectId is not null)
                LogContext.PushProperty("ProjectId", projectId);
            if (userName is not null)
                LogContext.PushProperty("UserName", userName);

            Serilog.Log.Warning(msg);
        }

        public static void Fatal(Exception ex, string text, string projectId = null, string userName = null)
        {
            if (projectId is not null)
                LogContext.PushProperty("ProjectId", projectId);

            if (userName is not null)
                LogContext.PushProperty("UserName", userName);

            Serilog.Log.Fatal(ex, text);
        }

    }
}
