﻿using Common.Security;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Http;
using Serilog.Context;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common
{
    public class LogUserNameMiddleware
    {
        private readonly RequestDelegate next;
        public LogUserNameMiddleware(RequestDelegate next)
        {
            this.next = next;
        }
        public async Task Invoke(HttpContext context, IHttpContextAccessor httpContextAccessor)
        {
            Logger.PushUserInfo(httpContextAccessor);
            await next.Invoke(context);
        }
        
    }
}
