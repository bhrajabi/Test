﻿using System;

namespace Common.Cryptography
{
    public class InvalidPasswordException : Error
    {
        public InvalidPasswordException() : base("invalid-password")
        {

        }
    }
}
