﻿using Microsoft.AspNetCore.Cryptography.KeyDerivation;
using System.Linq;
using System.Text.RegularExpressions;

namespace Common.Cryptography
{
    public static class Helper
    {

        public static string HashPassword(string password)
        {
            var salt = System.Convert.FromBase64String("7Vm1lSD7Q0dFEQXq784OOQ==");
            // derive a 256-bit subkey (use HMACSHA1 with 10,000 iterations)
            var bytes = KeyDerivation.Pbkdf2(
                password: password,
                salt: salt,
                prf: KeyDerivationPrf.HMACSHA1,
                iterationCount: 10000,
                numBytesRequested: 256 / 8);
            return System.Convert.ToBase64String(bytes);
        }

        public static bool PasswordComplexity(string password)
        {
            if (password.Length < 6) return false;
            var valid_symbols = "\"|/,.<>{}[]():;+-_*&^%$#@!".ToCharArray();
            var has_symbol = false;
            var has_alpha = false;
            var has_digits = false;
            foreach (var c in password)
            {
                if (char.IsDigit(c)) has_digits = true;
                else if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z')) has_alpha = true;
                else if (valid_symbols.Contains(c)) has_symbol = true;
                else throw new InvalidPasswordException();
            }
            return has_digits && has_alpha && has_symbol;
        }
    }
}