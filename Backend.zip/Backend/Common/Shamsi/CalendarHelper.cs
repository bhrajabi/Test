﻿using System;
using System.Data;

namespace Common
{
    public static class CalendarHelper
    {
        public static string ToSapDate(DateTime? date)
        {
            if (!date.HasValue) return null;
            var d = date.Value;
            return $"{d.Year}{d.Month:00}{d.Day:00}";
        }

        public static string ToSapTime(DateTime? date)
        {
            if (!date.HasValue) return null;
            var d = date.Value;
            return $"{d.Hour:00}{d.Minute:00}{d.Second:00}";
        }


        public static string ToSapDate(string calendarId, string date)
        {
            if (string.IsNullOrEmpty(date)) return date;
            if (calendarId.eq("shamsi"))
            {
                var dt = Common.Shamsi.ToDateTime(date);
                return $"{dt.Year:0000}{dt.Month:00}{dt.Day:00}";
            }
            else if (calendarId.eq("miladi"))
            {
                var dt = DateTime.Parse(date);
                return $"{dt.Year:0000}{dt.Month:00}{dt.Day:00}";
            }
            return date;
        }

        public static string FromSapDate(string calendarId, string date)
        {
            if (date == "00000000") return null;
            if (string.IsNullOrEmpty(date) || date.Length != 8) return date;
            var y = date.Substring(0, 4).ToInt(1);
            var m = date.Substring(4, 2).ToInt(1);
            var d = date.Substring(6, 2).ToInt(1);
            date = $"{y}/{m}/{d}";
            if (calendarId.eq("shamsi"))
            {
                var dt = new DateTime(y, m, d);
                return Common.Shamsi.ToString("yyyy/MM/dd", dt);
            }
            return date;
        }

        public static void SapToCalendar(string calendarId, DataTable tb, string fields)
        {
            if (string.IsNullOrEmpty(fields)) return;
            SapToCalendar(calendarId, tb, fields.Replace(" ", "").Split(','));
        }

        public static void SapToCalendar(string calendarId, DataTable tb, string[] fields)
        {
            foreach (var f in fields)
            {
                if (tb.Columns.Contains(f))
                {
                    foreach (DataRow r in tb.Rows)
                        try
                        {
                            var v = FromSapDate(calendarId, r.AsString(f));
                            //if (!string.IsNullOrEmpty(v))
                            r[f] = v;
                        }
                        catch
                        {
                        }
                }
            }

        }


        public static void ToSapDate(string calendarId, DataTable tb, string fields)
        {
            if (string.IsNullOrEmpty(fields)) return;
            foreach (var f in fields.Replace(" ", "").Split(','))
            {
                if (tb.Columns.Contains(f))
                {
                    foreach (DataRow r in tb.Rows)
                        try
                        {
                            var v = ToSapDate(calendarId, r.AsString(f));
                            if (!string.IsNullOrEmpty(v)) r[f] = v;
                        }
                        catch
                        {
                            throw new Exception($"فرمت تاریخ {f} نامعتبر است");
                        }
                }
            }

        }

    }
}


/*
 * using System;
using System.Data;

namespace Common
{
    public static class CalendarHelper
    {
        public static string ToSapDate(DateTime? date)
        {
            if (!date.HasValue) return null;
            var d = date.Value;
            return $"{d.Year}{d.Month:00}{d.Day:00}";
        }

        public static string ToSapTime(DateTime? date)
        {
            if (!date.HasValue) return null;
            var d = date.Value;
            return $"{d.Hour:00}{d.Minute:00}{d.Second:00}";
        }

        public static string ToSapDate(string calendarId, string date)
        {
            if (string.IsNullOrEmpty(date)) return date;
            if (calendarId.eq("shamsi"))
            {
                var dt = Common.Shamsi.ToDateTime(date);
                return $"{dt.Year:0000}{dt.Month:00}{dt.Day:00}";
            }
            else if (calendarId.eq("miladi"))
            {
                var dt = DateTime.Parse(date);
                return $"{dt.Year:0000}{dt.Month:00}{dt.Day:00}";
            }
            return date;
        }

        public static string FromSapDate(string calendarId, string date)
        {
            if (string.IsNullOrEmpty(date) || date.Length != 8) return date;
            var y = date.Substring(0, 4);
            var m = date.Substring(4, 2);
            var d = date.Substring(6, 2);
            date = $"{y}/{m}/{d}";
            if (calendarId.eq("shamsi"))
            {
                var dt = DateTime.Parse(date);
                return Common.Shamsi.ToString("yyyy/MM/dd", dt);
            }
            return date;
        }

        public static void ToCalendar(string calendarId, DataTable tb, string fields)
        {
            if (string.IsNullOrEmpty(fields)) return;
            foreach (var f in fields.Replace(" ", "").Split(','))
            {
                if (tb.Columns.Contains(f))
                {
                    foreach (DataRow r in tb.Rows)
                        try
                        {
                            var v = FromSapDate(calendarId, r.AsString(f));
                            if (!string.IsNullOrEmpty(v)) r[f] = v;
                        }
                        catch
                        {

                        }
                }
            }

        }

        public static void ToCalendar(string calendarId, DataTable tb, string[] fields)
        {
            if (fields.Length > 0 ) return;
            foreach (var f in fields)
            {
                if (tb.Columns.Contains(f))
                {
                    foreach (DataRow r in tb.Rows)
                        try
                        {
                            var v = FromSapDate(calendarId, r.AsString(f));
                            if (!string.IsNullOrEmpty(v)) r[f] = v;
                        }
                        catch
                        {

                        }
                }
            }

        }
    }
}*/
