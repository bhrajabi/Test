﻿using System.Globalization;

namespace System
{
    public static class ShamsiExtension
    {
        public static DateTime ToDate(this DateTime d)
        {
            return new DateTime(d.Year, d.Month, d.Day);
        }

        public static DateTime? ToDate(this DateTime? d)
        {
            return d == null ? null : d.Value.ToDate();
        }

        public static string ToHtmlDate(this DateTime? dateTime)
        {
            if (dateTime == null) return "";
            return dateTime.Value.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture);
        }

        public static string ToHtmlDateTime(this DateTime? dateTime)
        {
            if (dateTime == null) return "";
            return dateTime.Value.ToString("yyyy-MM-ddTHH:mm:ss", CultureInfo.InvariantCulture);
        }

        public static string ToHtmlDate(this DateTime dateTime)
        {
            return dateTime.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture);
        }

        public static string ToHtmlDateTime(this DateTime dateTime)
        {
            return dateTime.ToString("yyyy-MM-ddTHH:mm:ss", CultureInfo.InvariantCulture);
        }


        public static string ToYMD(this DateTime dateTime)
        {
            return dateTime.ToString("yyyy/MM/dd", CultureInfo.InvariantCulture);
        }

        public static string ToYMDHHMMSS(this DateTime dateTime)
        {
            return dateTime.ToString("yyyy/MM/dd HH:mm:ss", CultureInfo.InvariantCulture);
        }

        public static string ToYMDHHMM(this DateTime dateTime)
        {
            return dateTime.ToString("yyyy/MM/dd HH:mm", CultureInfo.InvariantCulture);
        }


        public static string ToHHMM(this DateTime dateTime)
        {
            return dateTime.ToString("HH:mm", CultureInfo.InvariantCulture);
        }

        public static string ToHHMMSS(this DateTime dateTime)
        {
            return dateTime.ToString("HH:mm:ss", CultureInfo.InvariantCulture);
        }

        public static int ShamsiYear(this DateTime dateTime)
        {
            var pc = new PersianCalendar();
            return pc.GetYear(dateTime);
        }



        public static string ToShamsi(this DateTime dateTime, string format)
        {
            return Common.Shamsi.ToString(format, dateTime);
        }

        public static string ToShamsi(this DateTime dateTime)
        {
            return Common.Shamsi.ToString("yyyy/MM/dd", dateTime);
        }

        public static string ToShamsiHHMM(this DateTime dateTime)
        {
            return Common.Shamsi.ToString("yyyy/MM/dd, HH:mm", dateTime);
        }

        public static string ToShamsiHHMMSS(this DateTime dateTime)
        {
            return Common.Shamsi.ToString("yyyy/MM/dd, HH:mm:ss", dateTime);
        }


        public static string SapDateToShamsi(this string sapDate)
        {
            sapDate = sapDate?.Trim();
            if (sapDate?.Length != 8) return null;
            var y = sapDate.Substring(0, 4);
            var m = sapDate.Substring(4, 2);
            var d = sapDate.Substring(6, 2);
            var date = DateTime.Parse($"{y}/{m}/{d}");
            return date.ToShamsi();
        }



        public static string ToShamsi(this DateTime? dateTime, string format)
        {
            return Common.Shamsi.ToString(format, dateTime);
        }

        public static string ToShamsi(this DateTime? dateTime)
        {
            return Common.Shamsi.ToString("yyyy/MM/dd", dateTime);
        }

        public static string ToShamsiHHMM(this DateTime? dateTime)
        {
            return Common.Shamsi.ToString("yyyy/MM/dd, HH:mm", dateTime);
        }

        public static string ToShamsiHHMMSS(this DateTime? dateTime)
        {
            return Common.Shamsi.ToString("yyyy/MM/dd, HH:mm:ss", dateTime);
        }

    }
}