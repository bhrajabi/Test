﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;

namespace Common
{
    public static class Captcha
    {
        public static Bitmap GenerateImage(string code)
        {
            return GenerateImage(code, 170, 50);
        }

        public static Bitmap GenerateImage(string code, int width, int height)
        {
            var random = new Random(System.DateTime.Now.Millisecond);
            var padding = 5; // تعیین اندازه padding

            // محاسبه ابعاد تصویر جدید با اعمال padding
            var newWidth = width + 2 * padding;
            var newHeight = height + 2 * padding;

            var bmp = new Bitmap(newWidth, newHeight);

            using (var gfx = Graphics.FromImage((Image)bmp))
            {
                gfx.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
                gfx.SmoothingMode = SmoothingMode.AntiAlias;
                gfx.FillRectangle(Brushes.White, new Rectangle(0, 0, bmp.Width, bmp.Height)); // تغییر رنگ پس‌زمینه به خاکستری روشن

                float fontSize = Math.Min(width / (code.Length + 1), height * 0.8f); // محاسبه سایز فونت بر اساس اندازه تصویر
                                                                                     // fontSize *= 0.8f; // تنظیم اندازه فونت به 80 درصد اندازه اصلی

                FontFamily[] fontFamilies = { new FontFamily("Arial"), new FontFamily("Verdana") }; // تغییر فونت‌ها
                Color textColor = Color.FromArgb(127, Color.Black);// تغییر رنگ‌های متن به خاکستری تیره

                Font font = new Font(fontFamilies[random.Next(0, fontFamilies.Length)], fontSize, FontStyle.Bold); // استفاده از fontSize برای سایز فونت

                // محاسبه ابعاد متن
                var stringSize = gfx.MeasureString(code, font);

                // مختصات وسط‌چین
                var textX = (newWidth - stringSize.Width) / 2;
                var textY = (newHeight - stringSize.Height) / 2;

                gfx.DrawString(code, font, new SolidBrush(textColor), textX + random.Next(0, 10), textY + random.Next(0, 10)); // تغییر رنگ متن به textColor

                ImageFilter.Water(bmp, 12, false);
                ImageFilter.RandomJitter(bmp, 3);
                return bmp;
            }
        }

    }
}