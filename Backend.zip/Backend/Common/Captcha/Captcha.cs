﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;

namespace Common
{
    public static class Captcha
    {
        
        public static Bitmap GenerateImage_old(string code, int width, int height)
        {
            var random = new Random(System.DateTime.Now.Millisecond);
            var noisy = true;
            var bmp = new Bitmap(width, height);

            using (var gfx = Graphics.FromImage((Image)bmp))
            {
                gfx.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
                gfx.SmoothingMode = SmoothingMode.AntiAlias;
                gfx.FillRectangle(Brushes.White, new Rectangle(0, 0, bmp.Width, bmp.Height));

                //add noise
                if (noisy)
                {
                    int i, r, x, y;
                    var pen = new Pen(Color.Yellow);
                    for (i = 1; i < 20; i++)
                    {
                        pen.Color = Color.FromArgb(
                        (random.Next(0, 255)),
                        (random.Next(0, 255)),
                        (random.Next(0, 255)));

                        r = random.Next(0, (130 / 3));
                        x = random.Next(0, 130);
                        y = random.Next(0, 30);

                        gfx.DrawEllipse(pen, x - r, y - r, r, r);
                    }
                }

                //add captcha
                var textX = random.Next(0, 10 * 2);
                var textY = random.Next(2, 7 * 2 - 0);
                gfx.DrawString(code, new Font("Tahoma", 14), Brushes.DarkBlue, textX, textY);
                ImageFilter.Sphere(bmp, false);
                return bmp;
            }
        }


        public static Bitmap GenerateSimpleImage(string txt, int width, int hight, string fontFamilyName="arial")
        {
            //make the bitmap and the associated Graphics object
            var bm = new Bitmap(width, hight);
            var gr = Graphics.FromImage(bm);
            gr.SmoothingMode = SmoothingMode.HighQuality;
            var recF = new RectangleF(0, 0, width, hight);
            var br = new HatchBrush(HatchStyle.SmallConfetti, Color.LightGray, Color.White);
            gr.FillRectangle(br, recF);
            SizeF text_size;
            Font the_font;
            float font_size = hight + 1;
            do
            {
                font_size -= 1;
                the_font = new Font(fontFamilyName, font_size, FontStyle.Bold, GraphicsUnit.Pixel);
                text_size = gr.MeasureString(txt, the_font);
            }
            while ((text_size.Width > width) || (text_size.Height > hight));
            // Center the text.
            StringFormat string_format = new StringFormat();
            string_format.Alignment = StringAlignment.Center;
            string_format.LineAlignment = StringAlignment.Center;

            // Convert the text into a path.
            GraphicsPath graphics_path = new GraphicsPath();
            graphics_path.AddString(txt, the_font.FontFamily, 1, the_font.Size, recF, string_format);

            //Make random warping parameters.
            Random rnd = new Random();
            PointF[] pts = { new PointF((float)rnd.Next(width) / 4, (float)rnd.Next(hight) / 4), new PointF(width - (float)rnd.Next(width) / 4, (float)rnd.Next(hight) / 4), new PointF((float)rnd.Next(width) / 4, hight - (float)rnd.Next(hight) / 4), new PointF(width - (float)rnd.Next(width) / 4, hight - (float)rnd.Next(hight) / 4) };
            Matrix mat = new Matrix();
            graphics_path.Warp(pts, recF, mat, WarpMode.Perspective, 0);

            // Draw the text.
            br = new HatchBrush(HatchStyle.LargeConfetti, Color.LightGray, Color.DarkGray);
            gr.FillPath(br, graphics_path);

            // Mess things up a bit.
            int max_dimension = System.Math.Max(width, hight);
            for (int i = 0; i <= (int)width * hight / 30; i++)
            {
                int X = rnd.Next(width);
                int Y = rnd.Next(hight);
                int W = (int)rnd.Next(max_dimension) / 50;
                int H = (int)rnd.Next(max_dimension) / 50;
                gr.FillEllipse(br, X, Y, W, H);
            }
            for (int i = 1; i <= 5; i++)
            {
                int x1 = rnd.Next(width);
                int y1 = rnd.Next(hight);
                int x2 = rnd.Next(width);
                int y2 = rnd.Next(hight);
                gr.DrawLine(Pens.DarkGray, x1, y1, x2, y2);
            }
            for (int i = 1; i <= 5; i++)
            {
                int x1 = rnd.Next(width);
                int y1 = rnd.Next(hight);
                int x2 = rnd.Next(width);
                int y2 = rnd.Next(hight);
                gr.DrawLine(Pens.LightGray, x1, y1, x2, y2);
            }
            graphics_path.Dispose();
            br.Dispose();
            the_font.Dispose();
            gr.Dispose();

            //ImageFilter.EmbossLaplacian(bm);
            return bm;
        }


        public static Bitmap GenerateComplexImage(string code, int width, int height)
        {
            var random = new Random(System.DateTime.Now.Millisecond);
            var bmp = new Bitmap(width, height);
            var mask = new Bitmap(width, height);

            using var gMask = Graphics.FromImage((Image)mask);
            using var gfx = Graphics.FromImage((Image)bmp);

            gfx.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
            gfx.SmoothingMode = SmoothingMode.AntiAlias;
            gfx.FillRectangle(Brushes.White, new Rectangle(0, 0, bmp.Width, bmp.Height));

            // Draw Text
            using var fnt_text = new Font("Verdana", 36, FontStyle.Bold);
            using var br_txt = new LinearGradientBrush(new Point(0, 0), new Point(20, 20), Color.Black, Color.Silver);
            var textX = (width - gfx.MeasureString(code, fnt_text).Width) / 2 - 10;
            foreach (var c in code)
            {

                var size = gfx.MeasureString(c.ToString(), fnt_text);
                var textY = (int)(height - size.Height) / 2 + random.Next(-5, 5);
                gfx.DrawString(c.ToString(), fnt_text, br_txt, textX, textY);
                textX += (int)(size.Width * 0.8);
            }
            ImageFilter.RandomJitter(bmp, 2);

            // Create Mask
            gMask.FillRectangle(Brushes.Black, 0, 0, width, height);
            for (int i = 0; i < width; i += 10)
            {
                gMask.FillRectangle(Brushes.DarkGray, i, 00, 5, height);
            }
            ImageFilter.Sphere(mask, false);
            //MergeAdd(mask, bmp);

            using var gbr = new LinearGradientBrush(new Point(0, 0), new Point(width, height), Color.Wheat, Color.Silver);
            gMask.FillRectangle(gbr, 0, 0, width, height);
            DrawTopText(gMask);
            ImageFilter.RandomJitter(mask, 5);
            DestOverSrc(mask, bmp);

            return bmp;

        }


        private static void DrawTopText(Graphics gfx)
        {
            using var fn = new Font("arial", 14, FontStyle.Bold);
            using var br = new LinearGradientBrush(new Point(250, 200), new Point(0, 0), Color.Silver, Color.DarkGoldenrod);
            gfx.DrawString("IKCO - S E C U R I T Y C O D E \nIKCO - S E C U R I T Y C O D E ", fn, br, 10, 10);
        }

        private static byte Add(byte a, byte b)
        {
            int x = a + b;
            return x > 255 ? (byte)255 : (byte)x;
        }

        private static Color ColorAdd(Color c1, Color c2)
        {
            return Color.FromArgb(255, Add(c1.R, c2.R), Add(c1.G, c2.G), Add(c1.B, c2.B));
        }

        private static void MergeAdd(Bitmap src, Bitmap dest)
        {
            for (int y = 0; y < src.Height; y++)
            {
                for (int x = 0; x < src.Width; x++)
                {
                    var c1 = src.GetPixel(x, y);
                    var c2 = dest.GetPixel(x, y);
                    dest.SetPixel(x, y, ColorAdd(c1, c2));
                }
            }
        }

        private static void DestOverSrc(Bitmap src, Bitmap dest)
        {
            for (int y = 0; y < src.Height; y++)
            {
                for (int x = 0; x < src.Width; x++)
                {
                    var cs = src.GetPixel(x, y);
                    var cd = dest.GetPixel(x, y);
                    var isWhite = cd.R == 255 && cd.G == 255 && cd.B == 255;
                    dest.SetPixel(x, y, isWhite ? cs : cd);
                }
            }
        }
    }
}