﻿using System;

namespace Common
{
    public class Response
    {
        public bool IsSuccess { get; set; }
        public string ErrorMessage { get; set; }
        public string ErrorCode { get; set; }
        public object Result { get; set; }
        

        public Response()
        {
            IsSuccess = true;
            Result = null;
        }

        public Response(Exception ex)
        {
            IsSuccess = false;
            ErrorMessage= Common.ExceptionTranslator.GetErrorMessage(ex);
        }

        public Response(object result)
        {
            IsSuccess = true;
            Result = result;
        }

        public Response(string errorMessage, string errorCode = null)
        {
            IsSuccess = false;
            ErrorMessage = errorMessage;
            ErrorCode = errorCode;
        }

        public static Response Error403()
        {
            return new Response("403", "403");
        }
    }


    public class Response<T> where T : class
    {
        public bool IsSuccess { get; set; }
        public string ErrorMessage { get; set; }
        public string ErrorCode { get; set; }
        public T Result { get; set; }


        public Response(string errorMessage, string errorCode = null)
        {
            IsSuccess = false;
            Result = default;
            ErrorMessage = errorMessage;
            ErrorCode = errorCode;
        }

        public Response(bool isSuccess, T result = default, string errorMessage = "")
        {
            IsSuccess = isSuccess;
            Result = result;
            ErrorMessage = errorMessage;
        }

        public Response(Exception ex)
        {
            IsSuccess = false;
            ErrorMessage = Common.ExceptionTranslator.GetErrorMessage(ex);
        }
        
        public Response(T result)
        {
            IsSuccess = true;
            Result = result;
            ErrorMessage = null;
        }

        public static Response<T>  Error403()
        {
            return new Response<T>("403", "403");
        }
    }
}