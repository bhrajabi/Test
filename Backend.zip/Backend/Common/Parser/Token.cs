﻿using System;

namespace Common.GenericParser
{

    public class Token
    {
        public string Text { get;private set; }
        public TokenType Type { get; set; }
        public bool IsNumber { get { return Type == TokenType.Number; } }
        public bool IsSymbol { get { return Type == TokenType.Symbol; } }



        public Token(string text,TokenType tokenType)
        {
            this.Type=  tokenType;
            this.Text = text.ToStandardString();
        }

        public int? ToInt32()
        {
            var d = Convert.ToDouble(Text);
            if (!d.HasValue) return null;
            return (int)d.Value;
        }

        public int ToInt32(int defaultValue)
        {
            return (int)Convert.ToDouble(Text, defaultValue);
        }


        public double? ToDouble()
        {
            return Convert.ToDouble(Text);
        }

        public double ToDouble(double defaultValue)
        {
            return Convert.ToDouble(Text, defaultValue);
        }


        internal int? ToMonthNumber()
        {
            string[] MonthNames1 = { "فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور", "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند" };
            string[] MonthNames2 = { "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" };
            string[] MonthNames3 = { "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December" };
            if (Type == TokenType.Number) return ToInt32();
            if (Type == TokenType.Text)
            {
                for (int i = 0; i < 12; i++)
                    if (MonthNames1[i].eq(Text, true))
                        return i + 1;
                for (int i = 0; i < 12; i++)
                    if (MonthNames2[i].Equals(Text, StringComparison.OrdinalIgnoreCase))
                        return i + 1;
                for (int i = 0; i < 12; i++)
                    if (MonthNames3[i].Equals(Text, StringComparison.OrdinalIgnoreCase))
                        return i + 1;
            }
            return null;
        }

        public override string ToString()
        {
            return Text;
        }
    }

}