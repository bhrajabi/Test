﻿namespace Common.GenericParser
{
    public enum TokenType
    {
        Text = 0,
        Number = 1,
        Symbol = 2,
    }
}