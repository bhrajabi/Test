﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Common.GenericParser
{

    public class Parser
    {
        public string InputText { get; set; }
        public List<Token> Tokens { get; private set; }

        public int Position { get; set; }
        public int Count { get { return Tokens.Count; } }
        public bool EOF { get { return Position >= Count; } }




        public Parser(string inputText)
        {
            this.InputText = inputText;
            this.Tokens = (new Tokenizer(inputText)).Tokens;
        }

        public Parser Remove(TokenType tokenType)
        {
            for (int i = Tokens.Count - 1; i >= 0; --i)
                if (Tokens[i].Type == tokenType)
                    Tokens.RemoveAt(i);
            return this;
        }
        public Parser RemoveNumbers()
        {
            return Remove(TokenType.Number);
        }
        public Parser RemoveTexts()
        {
            return Remove(TokenType.Text);
        }
        public Parser RemoveSymbols()
        {
            return Remove(TokenType.Symbol);
        }


        public int FirstInt(int defaultValue)
        {
            foreach (var t in Tokens)
                if (t.Type == TokenType.Number)
                    return t.ToInt32(defaultValue);
            return defaultValue;
        }

        public int LastInt(int defaultValue)
        {
            for (int i = Tokens.Count - 1; i >= 0; --i)
                if (Tokens[i].Type == TokenType.Number)
                    return Tokens[i].ToInt32(defaultValue);
            return defaultValue;
        }

        public int[] ToIntArray()
        {
            var list = new List<int>();
            foreach (var t in Tokens)
                if (t.Type == TokenType.Number)
                    list.Add(t.ToInt32().Value);
            return list.ToArray();
        }

        public double[] ToNumberArray()
        {
            var list = new List<double>();
            foreach (var t in Tokens)
                if (t.Type == TokenType.Number)
                    list.Add(t.ToDouble(0));
            return list.ToArray();
        }

        private int NextToken(TokenType tokenType, int fromIndex)
        {
            for (int i = fromIndex; i < Tokens.Count; i++)
                if (Tokens[i].Type == tokenType) return i;
            return -1;
        }

        private string GetTokenText(int i)
        {
            return i >= 0 && i < Tokens.Count ? Tokens[i].Text : null;
        }

        public string ToDateTime(string datePartsOrders)
        {
            var d = ToDate(datePartsOrders);
            var t = ToTime();
            if (string.IsNullOrEmpty(d) || string.IsNullOrEmpty(t))
                return d + t;
            return d + " " + t;
        }

        public string ToDate(string datePartsOrders)
        {
            int? y = null, m = null, d = null;
            int i = 0;
            //----------------------
            if (string.IsNullOrEmpty(datePartsOrders)) datePartsOrders = "YMD";
            else datePartsOrders = datePartsOrders.ToUpper();
            //----------------------
            //skip time
            //----------------------
            if (datePartsOrders == "YMD")
            {
                i = FirstNumberSkipTime();
                if (i >= 0)
                {
                    y = Tokens[i].ToInt32();
                    i = SkipSymbols(i + 1);
                    m = token(i) == null ? null : token(i).ToMonthNumber();
                    i = SkipSymbols(i + 1);
                    d = token(i) == null ? null : token(i).ToInt32();
                }
            }
            else if (datePartsOrders == "DMY")
            {
                i = FirstNumberSkipTime();
                if (i >= 0)
                {
                    d = Tokens[i].ToInt32();
                    i = SkipSymbols(i + 1);
                    m = token(i) == null ? null : token(i).ToMonthNumber();
                    i = SkipSymbols(i + 1);
                    y = token(i) == null ? null : token(i).ToInt32();
                }
            }
            else if (datePartsOrders == "DM_SHAMSI")
            {
                i = FirstNumberSkipTime();
                if (i >= 0)
                {
                    d = Tokens[i].ToInt32();
                    i = SkipSymbols(i + 1);
                    m = token(i) == null ? null : token(i).ToMonthNumber();
                    i = SkipSymbols(i + 1);
                    y = token(i) == null ? null : token(i).ToInt32();
                    ValidateYMD(ref y, ref m, ref d, Shamsi.Year, Shamsi.Month, Shamsi.Day);
                }
            }
            else if (datePartsOrders == "DM_MILADI")
            {
                i = FirstNumberSkipTime();
                if (i >= 0)
                {
                    d = Tokens[i].ToInt32();
                    i = SkipSymbols(i + 1);
                    m = token(i) == null ? null : token(i).ToMonthNumber();
                    i = SkipSymbols(i + 1);
                    y = token(i) == null ? null : token(i).ToInt32();
                    ValidateYMD(ref y, ref m, ref d, DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day);
                }
            }
            else if (datePartsOrders == "MDY")
            {
                for (i = 0; i < Tokens.Count; i++)
                {
                    m = Tokens[i].ToMonthNumber();
                    if (m != null)
                    {
                        i = SkipSymbols(i + 1);
                        d = token(i) == null ? null : token(i).ToInt32();
                        i = SkipSymbols(i + 1);
                        y = token(i) == null ? null : token(i).ToInt32();
                        break;
                    }
                }
            }
            else throw new ApplicationException("Invalid date-time format: " + datePartsOrders);
            //------------------------------------
            ValidateYMD(ref y, ref m, ref d, null, null, null);
            //------------------------------------
            if (y == null) return null;
            if (m == null) return y.ToString();
            if (d == null) return string.Format("{0}/{1:00}", y, m.Value);
            return string.Format("{0}/{1:00}/{2:00}", y, m.Value, d.Value);
        }

        private void ValidateYMD(ref int? y, ref int? m, ref int? d, int? def_year, int? def_month, int? def_day)
        {
            if (m.HasValue && m.Value > 31)
            {
                var t = y;
                y = m;
                m = t;
            }
            if (d.HasValue && d.Value > 31)
            {
                var t = y;
                y = d;
                d = t;
            }
            if (m.HasValue && m.Value > 12 && m.Value <= 31 && (!d.HasValue || d.Value <= 12))
            {
                var t = m;
                m = d;
                d = t;
            }
            if (y == null || y == 0) y = def_year;
            if (m == null || m == 0) m = def_month;
            if (d == null || d == 0) d = def_day;
        }

        private int FirstNumberSkipTime()
        {
            var i = 0;
            while (true)
            {
                i = NextToken(TokenType.Number, i);
                if (i < 0 || GetTokenText(i + 1) != ":") return i;
                var i2 = NextToken(TokenType.Number, i + 1);
                if (i2 < 0 || i2 != i + 2) return i;
                if (GetTokenText(i2 + 1) == ":") i2 += 2;
                //------------------
                i = i2 + 1;
            }
        }

        public string ToTime()
        {
            int? hh = null, mm = null, ss = null;
            ReadTime(ref hh, ref mm, ref ss);
            if (hh == null || mm == null) return null;
            if (ss == null) return string.Format("{0:00}:{1:00}", hh.Value, mm.Value);
            else return string.Format("{0:00}:{1:00}:{2:00}", hh.Value, mm.Value, ss.Value);
        }

        private int SkipSymbols(int i)
        {
            for (; i < Tokens.Count; i++)
            {
                if (Tokens[i].Type != TokenType.Symbol)
                    return i;
            }
            return Tokens.Count;
        }

        private Token token(int i)
        {
            return i < Tokens.Count ? Tokens[i] : null;
        }

        private void ReadTime(ref int? hh, ref int? mm, ref int? ss)
        {
            for (int start = 0; start < Tokens.Count; start++)
            {
                if (Tokens[start].Type == TokenType.Number && NextTokenIs(start, ":"))
                {
                    var i = start;
                    hh = Tokens[i].ToInt32();
                    i += 1;
                    if (NextTokenIs(i, TokenType.Number))
                    {
                        i += 1;
                        mm = Tokens[i].ToInt32();
                        if (NextTokenIs(i, ":"))
                        {
                            i += 1;
                            if (NextTokenIs(i, TokenType.Number))
                            {
                                i += 1;
                                ss = Tokens[i].ToInt32();
                            }
                        }
                    }
                    //----------------------
                    while (i >= start)
                    {
                        if (i < Tokens.Count)
                            Tokens.RemoveAt(i);
                        i -= 1;
                    }
                    return;
                }
            }
        }

        private bool NextTokenIs(int i, string text)
        {
            return i + 1 < Tokens.Count && string.Equals(text, Tokens[i + 1].Text);
        }

        private bool NextTokenIs(int i, TokenType tokenType)
        {
            return i + 1 < Tokens.Count && Tokens[i + 1].Type == tokenType;
        }



        public bool CanRead(string text)
        {
            return !EOF && Tokens[Position].Text.Equals(text, StringComparison.OrdinalIgnoreCase);
        }

        public Parser Read(string text)
        {
            if (Position < Count && Tokens[Position].Text.Equals(text, StringComparison.OrdinalIgnoreCase))
                Position += 1;
            else
                Position = Count;
            return this;
        }

        public Parser Read(string text, params string[] args)
        {
            Read(text);
            foreach (var s in args) Read(s);
            return this;
        }

        public Parser SkipUntil(string text)
        {
            while (!EOF && !Tokens[Position].Text.Equals(text, StringComparison.OrdinalIgnoreCase))
                ++Position;
            return this;
        }

        public Parser SkipUntil(string text, params string[] args)
        {
            if (args == null || args.Length < 0) return SkipUntil(text);
            while (!EOF)
            {
                SkipUntil(text);
                var SavedPosition = Position;
                Position += 1;
                bool AllMatched = true;
                foreach (var t in args)
                {
                    if (!CanRead(t))
                    {
                        AllMatched = false;
                        break;
                    }
                    Position += 1;
                }
                //------------------
                Position = SavedPosition;
                if (AllMatched) break;
                else if (!EOF) Position += 1;
            }
            return this;
        }


        public string ReadUntil(string token, string separator)
        {
            if (EOF) return null;
            var i = Position;
            SkipUntil(token);
            var sb = new StringBuilder();
            var IsFirst = true;
            for (; i < Position; i++)
            {
                if (IsFirst) IsFirst = false;
                else sb.Append(separator);
                sb.Append(Tokens[i]);
            }
            return sb.ToString();
        }

        public bool Contains(string text)
        {
            foreach (var t in Tokens)
                if (t.Text.eq(text))
                    return true;
            return false;
        }
    }
}
