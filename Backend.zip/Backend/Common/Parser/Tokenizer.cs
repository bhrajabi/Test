﻿using System;
using System.Collections.Generic;

namespace Common.GenericParser
{

    public class Tokenizer
    {
        public string InputText { get; set; }
        public List<Token> Tokens { get; private set; }
        private int Index { get; set; }



        public Tokenizer(string txt)
        {
            this.Tokens = new List<Token>();
            this.InputText = txt == null ? string.Empty : txt;
            Index = 0;
            while (Index < InputText.Length)
            {
                var c = InputText[Index];
                if (char.IsWhiteSpace(c))
                    ++Index;
                else
                {
                    c = c.ToStandardChar();
                    int StartIndex = Index;
                    Index += 1;
                    //-------------------------
                    if (char.IsDigit(c))
                    {
                        SkipDisgits();
                        if (Skip('.'))
                        {
                            if (!SkipDisgits())
                                Index -= 1;
                        }
                        AddToken(TokenType.Number, StartIndex);
                    }
                    //-------------------------
                    else if (c == '.' && SkipDisgits())
                    {
                        AddToken(TokenType.Number, StartIndex);
                    }
                    //-------------------------
                    else if (IsSymbol(c))
                    {
                        AddToken(TokenType.Symbol, StartIndex);
                    }
                    //-------------------------
                    else
                    {
                        SkipText();
                        AddToken(TokenType.Text, StartIndex);
                    }
                }
            }
        }

        private bool IsSymbol(char c)
        {
            return char.IsSymbol(c) || char.IsPunctuation(c);
        }

        private void AddToken(TokenType tokenType, int startIndex)
        {
            var token = new Token(InputText.Substring(startIndex, Index - startIndex), tokenType);
            Tokens.Add(token);
        }

        private bool Skip(char c)
        {
            if (Index < InputText.Length && InputText[Index] == c)
            {
                Index += 1;
                return true;
            }
            return false;
        }

        private bool SkipDisgits()
        {
            int old_index = Index;
            while (Index < InputText.Length)
            {
                var c = InputText[Index].ToStandardChar();
                if (!char.IsDigit(c)) break;
                ++Index;
            }
            return Index > old_index;
        }

        private bool SkipText()
        {
            int old_index = Index;
            while (Index < InputText.Length)
            {
                var c = InputText[Index].ToStandardChar();
                //if (char.IsWhiteSpace(c) || char.IsDigit(c) || IsSymbol(c)) break;
                if (!char.IsLetter(c)) break;
                ++Index;
            }
            return Index > old_index;
        }

    }

}