﻿namespace CommonServices.Core
{
    public class RestSms
    {
        public string Token { get; set; }
        public string ErrorDesc { get; set; }
    }
}
