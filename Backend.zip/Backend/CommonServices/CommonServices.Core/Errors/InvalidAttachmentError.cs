using Common;
namespace CommonServices.Core
{
    public class InvalidAttachmentError : Error
    {
        public InvalidAttachmentError() : base("invalid-attachment")
        {

        }
    }
}
