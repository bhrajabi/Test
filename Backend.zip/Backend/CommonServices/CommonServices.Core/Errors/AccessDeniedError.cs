using Common;

namespace CommonServices.Core
{
    public class AccessDeniedError : Error
    {
        public AccessDeniedError() : base("access-denied")
        {

        }
    }
}
