using Common;
namespace CommonServices.Core
{
    public class InvalidAccessError: Error
    {
        public InvalidAccessError() : base("invalid-access")
        {
                            
        }
    }
}
