﻿using Common;

namespace CommonServices.Core
{
    public class InvalidSMSMessageError : Error
    {
        public InvalidSMSMessageError() : base("invalid-sms-message")
        {
        }
    }
}
