using Common;
namespace CommonServices.Core
{
    public class InvalidFileNameError : Error
    {
        public InvalidFileNameError() : base("invalid-file-name")
        {

        }
    }
}
