using Common;
namespace CommonServices.Core
{
    public class MaximumNumberOfAttachmentError : Error
    {
        public MaximumNumberOfAttachmentError(int count) : base("maximum-number-of-attachment-@count")
        {
            Add("count", count.ToString());
        }
    }
}
