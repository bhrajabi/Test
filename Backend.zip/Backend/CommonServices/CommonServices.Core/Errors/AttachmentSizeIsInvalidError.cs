using Common;
namespace CommonServices.Core
{
    public class AttachmentSizeIsInvalidError: Error
    {
        public AttachmentSizeIsInvalidError(long maxSize) : base("attachment-size-is-invalid-max-size-is-@maxSize")
        {
            Add("maxSize", maxSize);
        }
    }
}
