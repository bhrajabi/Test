﻿using Common;

namespace CommonServices.Core
{
    public class InvalidPhoneNumberError : Error
    {
        public InvalidPhoneNumberError() : base("invalid-phone-number")
        {
        }
    }
}
