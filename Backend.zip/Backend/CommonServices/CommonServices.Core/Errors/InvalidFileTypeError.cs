using Common;
namespace CommonServices.Core
{
    public class InvalidFileTypeError: Error
    {
        public InvalidFileTypeError() : base("invalid-file-type")
        {
                            
        }
    }
}
