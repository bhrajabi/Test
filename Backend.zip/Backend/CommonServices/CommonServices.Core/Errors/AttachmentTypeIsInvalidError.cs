﻿using Common;

namespace CommonServices.Core
{
    public class AttachmentTypeIsInvalidError: Error
    {
        public AttachmentTypeIsInvalidError() : base("attachment-type-is-invalid")
        {
        }
    }
}
