﻿using System.Collections.Generic;

namespace CommonServices.Core
{
    public class TableSchema
    {
        public List<TableColumn> Columns { get; set; }
        public List<string> PrimaryKey { get; set; }
        public List<string> UniqueConstraints { get; set; }
    }
}