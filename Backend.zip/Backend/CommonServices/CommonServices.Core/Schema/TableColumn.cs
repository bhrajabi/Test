﻿namespace CommonServices.Core
{
    public class TableColumn
    {
        public string Name { get; set; }
        public string DataType { get; set; }
        public int? MaxLength { get; set; }
        public bool IsNullable { get; set; }
        public byte? Precision { get; set; }
        public byte? Scale { get; set; }
        public bool IsIdentity { get; set; }
    }
}