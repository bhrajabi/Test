﻿using System.Collections.Generic;
using System.Data;

namespace CommonServices.Core
{
    public interface IDbSchemaService
    {
        string ConnectionString { get; set; }

        List<string> GetTables();
        public List<string> GetViews();
        TableSchema GetTableSchema(string tableName);
        List<ForeignKeyRelationship> GetForeignKeyRelationships();
        DataTable ExecSql(string sql);
    }
}