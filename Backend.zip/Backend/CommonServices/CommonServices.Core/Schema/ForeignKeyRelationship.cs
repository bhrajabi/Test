﻿namespace CommonServices.Core
{
    public class ForeignKeyRelationship
    {
        public string FKName { get; set; }
        public string ParentTable { get; set; }
        public string ReferencedTable { get; set; }
        public string ParentColumn { get; set; }
        public string ReferencedColumn { get; set; }
    }
}