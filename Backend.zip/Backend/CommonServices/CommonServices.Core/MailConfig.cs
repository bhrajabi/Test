﻿namespace CommonServices.Core
{
    public class MailConfig
    {
        public const string SectionName = "Mail";

        public string DisplayName { get; set; } = string.Empty;
        
        public string Mail { get; set; } = string.Empty;
        public string Password { get; set; } = string.Empty;
        public string Host { get; set; } = string.Empty;
        public int Port { get; set; }
    }
}
