﻿namespace CommonServices.Core
{
    public static class DraftStatuses
    {
        public const string NEW = "NEW";
        public const string COMMIT = "COMMIT";
        public const string DISCARD = "DISCARD";
    }
}
