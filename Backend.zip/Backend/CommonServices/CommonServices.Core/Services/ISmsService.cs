﻿using System.Threading.Tasks;

namespace CommonServices.Core
{
    public interface ISmsService
    {
        Task<string> SendAsync(string phone, string message, int expireAtMinuites);
        string Send(string phone, string message);
    }
}
