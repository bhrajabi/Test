﻿using System.Threading.Tasks;

namespace CommonServices.Interfaces
{
    public interface IEmailService
    {
        Task SendEmailAsync(string email, string subject, string body);
    }
}