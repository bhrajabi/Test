﻿using System.IO;

namespace CommonServices.Core
{
    public class MessageTemplate
    {

        public string Subject { get; set; }
        public string Body { get; set; }

        public MessageTemplate()
        {
            Subject = string.Empty;
            Body = string.Empty;
        }

        public MessageTemplate(string fileName)
        {

            string contentRootPath = System.AppDomain.CurrentDomain.BaseDirectory;
            string filePath = Path.Combine(contentRootPath, "Templates", fileName);

            var s = File.ReadAllText(filePath, System.Text.Encoding.UTF8);

            var i1 = s.IndexOf("<h1>");
            var i2 = s.IndexOf("</h1>");
            if (i1 >= 0)
            {
                Subject = s.Substring(i1 + 4, i2 - i1 - 4);
                Body = s[(i2 + 5)..];
            }
            else
            {
                Body = s;
            }
        }
    }
}