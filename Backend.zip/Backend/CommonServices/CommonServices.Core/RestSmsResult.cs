﻿namespace CommonServices.Core
{
    public class RestSmsResult
    {
        public string Vid { get; set; }
        public bool SmsResult { get; set; }
        public string ErrorDesc { get; set; }
    }
}
