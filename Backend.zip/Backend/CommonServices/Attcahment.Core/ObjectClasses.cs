﻿namespace Attcahment.Core
{
    public class ObjectClasses
    {
        public const string Company = "Company";
        public const string Project = "Project";
        public const string Document = "Document";
        public const string Form = "FORM";
        public const string Discovery = "Discovery";
        public const string Content = "Content";
        public const string RfxResponseComment = "RfxResponseComment";
        public const string RfxResponse = "RfxResponse";
        public const string PO = "PO";
        public const string Order = "ORDER";
        public const string Users = "Users";
        public const string Request = "Request";
        public const string Meeting = "Meeting";
        public const string DiscoveryItems = "DiscoveryItems";
        public const string EvaluationRequests = "EvaluationRequests";
        public const string Auction = "Auction";
        public const string AuctionPack = "AuctionPack";
        public const string ProjectLogo = "ProjectLogo";
        public const string AuctionLogo = "AuctionLogo";
        public const string ProjectAddressImage = "ProjectAddress";
        public const string AuctionAddressImage = "AuctionAddress";
        public const string AuctionContent = "AuctionContent";
        public const string Shipment = "Shipment";
        public const string DocumentMessage = "DocumentMessage";
        public const string ChatMessage = "ChatMessage";
        public const string REQ = "REQ";
        public const string CNF = "CNF";
        public const string REGSPQ = "REGSPQ";
        public const string REGREQ = "REGREQ";
        public const string Customizing = "Customizing";
        public const string ComapnyTacAttach = "ComapnyTacAttach";
        public const string Material = "Material";
        public const string RFPAttachment = "RFPAttachment";

        public static string COMPANY_PROFILE { get => "COMPANY-PROFILE"; }

        public static string RelationCommodities { get => "RelationCommodities"; }

    }
}
