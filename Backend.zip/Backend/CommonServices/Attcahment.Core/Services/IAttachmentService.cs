﻿using Microsoft.AspNetCore.Http;
using System.Collections.Generic;

namespace Attcahment.Core
{
    public interface IAttachmentService
    {
        IList<ZAttachment> GetAttachmentsByHeader(long? draftId, string objectClass, object objectHeader);
        IList<ZAttachment> GetAttachmentsByKey(long? draftId, string objectClass, object objectKey);

        ZAttachment GetNoImage();
        ZAttachment GetAttachmentById(long serial);
        ZAttachment GetAttachmentById(long id, string objectClass);
        ZAttachment GetAttachmentById(long serial, string objectClass, object objectKey);
        ZAttachment GetAttachmentByRequestId(long requestId, string sessionId);
        ZAttachmentData GetAttachmentDataBySerial(long? serial);

        //void Insert(ZAttachment attachment, byte[] data);
        //ZAttachment Insert(Int64? draftId, string objectClass, object objectHeader, object objectKey, string typeId, IFormFile file);
        ZAttachment Insert(long? draftId, string objectClass, object objectHeader, object objectKey, string typeId, IFormFile file, string fileName = null);
        ZAttachment InsertAnonymous(long? draftId, string objectClass, object objectHeader, object objectKey, string typeId, IFormFile file, string fileName = null);
        ZAttachment Insert(long? draftId, string objectClass, object objectHeader, object objectKey, string typeId, byte[] data, string mimeType = null, string fileName = null);

        void ChangeObjectKey(string objectClass, string fromObjectKey, string toObjectKey);
        void ChangeObjectKey(long attachmentId, string toObjectKey);
        void ChangeObjectHeader(long attachmentId, string toObjectHeader);


        void DeleteAttachments(IList<ZAttachment> attachments);
        void DeleteAttachments(string objectClass, object objectKey);
        void DeleteAttachmentById(long serial);

        long CreateDownloadRequest(ZAttachment attachment);
        long CreateDownloadRequestAnonymous(ZAttachment attachment, string mobile);

        ZAttachmentDraft GetDraft(long draftId, string objectClass);
        IList<ZAttachment> CreateDraft(string objectClass, object objectHeader, object objectKey, out long draftId);
        void CommitDraft(long draftId);
        IList<ZAttachment> Clone(string objectClass, object objectKey, object newObjectHeader, object newObjectKey);
        IList<ZAttachment> Clone(string objectClass, object objectKey, string NewObjectClass, object newObjectHeader, object newObjectKey);
        bool IsValidFileName(string fileName);
    }
}