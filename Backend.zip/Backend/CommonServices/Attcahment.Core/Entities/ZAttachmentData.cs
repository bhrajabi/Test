using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Attcahment.Core
{
    [Table("ZAttachmentData", Schema = "PUR")]
    public class ZAttachmentData
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public Int64 Serial { get; set; }

        public byte[] Data { get; set; }
        public string MimeType { get; set; }
        public string FileName { get; set; }
        public int Size { get; set; }
    }
}
