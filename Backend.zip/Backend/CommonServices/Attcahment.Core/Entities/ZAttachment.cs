using Common.Data;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Attcahment.Core
{
    [Table("ZAttachments", Schema = "PUR")]
    public class ZAttachment : IHasCreator
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Id { get; set; }
        public string ObjectClass { get; set; }
        public string ObjectHeader { get; set; }
        public string ObjectKey { get; set; }
        public long DataSerial { get; set; }
        public long? DraftId { get; set; }
        public string TypeId { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public string MimeType { get; set; }
        public string FileName { get; set; }
        public int Size { get; set; }

        [NotMapped]
        public string Status { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedAt { get; set; }

        public override string ToString()
        {
            return $"{ObjectHeader}-{ObjectKey}-{FileName}";
        }
    }
}
