﻿namespace Attcahment.Core
{
    public static class AttachmentTypes
    {
        public static string LOGO { get => "LOGO"; }
        public static string CompanyBanner { get => "company-banner"; }
        public static string PrjDoc { get => "prj-doc"; }
        public static string Attachment { get => "attachment"; }
        public static string Content { get => "content"; }
        public static string Confirmation { get => "confirmation"; }
        public static string RfxComment { get => "rfx-comment"; }
        public static string AuctionTicket { get => "auction-ticket"; }
        public static string RfxContentResponse { get => "rfx-content-response"; }
        public static string DocumentDiscovery { get => "document-discovery"; }
        public static string DiscoveryItem { get => "discovery-item"; }
        public static string VendorEvalInfo { get => "vendor-eval-info"; }
        public static string Meeting { get => "meeting"; }
        public static string AddressImage { get => "address-image"; }
        public static string Shipment { get => "shipment"; }
        public static string SignedOrder { get => "signed-order"; }
        public static string DocumentMessage { get => "document-message"; }
        public static string ChatMessage { get => "chat-message"; }
        public static string RegReqImage { get => "reg-req-image"; }
        public static string CompanyTacAttachment { get => "company-tac-attachment"; }
        public static string FormAttachment { get => "form-attachment"; }

        public static string MaterialImage { get => "material-image"; }
        public static string PrImage { get => "pr-image"; }
        public static string RFPAttachment { get => "rfp-attachment"; }
    }
}
