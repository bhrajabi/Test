﻿using Attcahment.Core;
using Attcahment.Services;
using CommonServices.Services.Data;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;

namespace Tamin.Services
{
    public static class DependencyInjection
    {
        public static void AddAttachmentData(this IServiceCollection services, string connectionString)
        {
            services.AddDbContext<CommonAtchDbContext>(options => options
                        .UseSqlServer(connectionString)
                        .UseQueryTrackingBehavior(QueryTrackingBehavior.NoTracking)
                        );
        }

        public static void AddAttachmentServices(this IServiceCollection services)
        {
            services.AddScoped<IAttachmentService, AttachmentService>();
        }
    }
}