﻿using Attcahment.Core;
using Common.Data;
using Common.Security;
using Microsoft.EntityFrameworkCore;

namespace CommonServices.Services.Data
{
    public class CommonAtchDbContext : BaseDbContext
    {
        public DbSet<ZAttachment> Attachments { get; set; }
        public DbSet<ZAttachmentData> AttachmentData { get; set; }
        public DbSet<ZAttachmentDraft> AttachmentDrafts { get; set; }
        public DbSet<ZAttachmentRequest> AttachmentRequests { get; set; }
        public DbSet<ZAttachmentType> AttachmentTypes { get; set; }

        public CommonAtchDbContext(DbContextOptions<CommonAtchDbContext> options, IHttpContextService currentUserNameService) : base(options, currentUserNameService)
        {
            //var qs = currentUserNameService.GetQuery();
            //var i = qs.IndexOf("&i=");
            //if (i > 0) qs = qs.Substring(i + 3);
            //QId = qs;
            //CommonServices.Core.Tracker.List.Add($"Tamin: {qs}: {Ticks}"); 
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);


        }


    }
}
