﻿using Common.Security;
using CommonServices.Core;
using Attcahment.Core;
using CommonServices.Services.Data;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace Attcahment.Services
{
    public class AttachmentService : IAttachmentService
    {
        private IHttpContextService _ContextService;
        private readonly AttachmentConfig attachmentConfig;
        private readonly CommonAtchDbContext db;


        public AttachmentService(IOptions<AttachmentConfig> attachmentConfig, CommonAtchDbContext context, IHttpContextService contextService)
        {
            this.attachmentConfig = attachmentConfig.Value;
            db = context;
            _ContextService = contextService;
        }

        public IList<ZAttachment> GetAttachmentsByHeader(long? draftId, string objectClass, object objectHeader)
        {
            var q = from a in db.Attachments
                    where a.DraftId == draftId && a.ObjectClass == objectClass && a.ObjectHeader == objectHeader.ToString()
                    select a;
            return q.ToList();
        }

        public IList<ZAttachment> GetAttachmentsByKey(long? draftId, string objectClass, object objectKey)
        {
            if (objectKey == null) return new List<ZAttachment>();
            var q = from a in db.Attachments
                    where a.DraftId == draftId && a.ObjectClass == objectClass && a.ObjectKey == objectKey.ToString()
                    select a;

            return q.ToList();
        }

        public ZAttachment GetAttachmentById(long serial)
        {
            return db.Attachments.FirstOrDefault(x => x.Id == serial);
        }

        public ZAttachment GetNoImage()
        {
            return db.Attachments.FirstOrDefault(x => x.Id == 1);
        }

        public ZAttachment GetAttachmentById(long id, string objectClass)
        {
            if (id <= 0)
                return null;
            return db.Attachments.FirstOrDefault(x => x.Id == id && x.ObjectClass == objectClass);
        }

        public ZAttachment GetAttachmentById(long serial, string objectClass, object objectKey)
        {
            var a = db.Attachments.FirstOrDefault(x => x.Id == serial);
            return a == null || !a.ObjectClass.eq(objectClass) || !a.ObjectKey.eq(objectKey?.ToString()) ? null : a;
        }

        public ZAttachment GetAttachmentByRequestId(long requestId, string sessionId)
        {
            var r = db.AttachmentRequests.FirstOrDefault(x => x.Id == requestId);
            if (r == null || r.SessionId != sessionId)
                return null;
            if (DateTime.UtcNow.Subtract(r.CreatedAt).TotalSeconds > attachmentConfig.RequestExpiry)
                return null;
            return GetAttachmentById(r.AttachmentId);
        }


        public ZAttachmentData GetAttachmentDataBySerial(long? serial)
        {
            return !serial.HasValue ? null : db.AttachmentData.FirstOrDefault(x => x.Serial == serial);
        }

        public ZAttachment InsertAnonymous(long? draftId, string objectClass, object objectHeader, object objectKey, string typeId, IFormFile file, string fileName = null)
        {
            if (file == null || file.Length == 0)
                throw new InvalidAttachmentError();

            if (string.IsNullOrEmpty(fileName))
            {
                fileName = file.FileName;
                if (string.IsNullOrEmpty(fileName))
                    throw new InvalidFileNameError();
            }

            using (var ms = new MemoryStream())
            {
                file.CopyTo(ms);

                var a = new ZAttachment
                {
                    ObjectClass = objectClass,
                    ObjectHeader = objectHeader.ToString(),
                    ObjectKey = objectKey.ToString(),
                    DraftId = draftId,
                    TypeId = typeId,
                    MimeType = file.ContentType,
                    FileName = fileName,
                    CreatedBy = "service"
                };
                Insert(a, ms.ToArray());
                return a;
            };
        }

        public ZAttachment Insert(long? draftId, string objectClass, object objectHeader, object objectKey, string typeId, IFormFile file, string fileName = null)
        {
            if (file == null || file.Length == 0)
                throw new InvalidAttachmentError();

            if (string.IsNullOrEmpty(fileName))
            {
                fileName = file.FileName;
                if (string.IsNullOrEmpty(fileName))
                    throw new InvalidFileNameError();
            }

            using (var ms = new MemoryStream())
            {
                file.CopyTo(ms);

                var a = new ZAttachment
                {
                    ObjectClass = objectClass,
                    ObjectHeader = objectHeader.ToString(),
                    ObjectKey = objectKey.ToString(),
                    DraftId = draftId,
                    TypeId = typeId,
                    MimeType = file.ContentType,
                    FileName = fileName,
                };
                Insert(a, ms.ToArray());
                return a;
            };
        }

        public ZAttachment Insert(long? draftId, string objectClass, object objectHeader, object objectKey, string typeId, byte[] data, string mimeType = null, string fileName = null)
        {
            if (data == null || data.Length == 0)
                throw new InvalidAttachmentError();

            using (var ms = new MemoryStream())
            {
                ms.Write(data, 0, data.Length);

                var a = new ZAttachment
                {
                    ObjectClass = objectClass,
                    ObjectHeader = objectHeader.ToString(),
                    ObjectKey = objectKey.ToString(),
                    DraftId = draftId,
                    TypeId = typeId,
                    MimeType = mimeType,
                    FileName = fileName,
                };
                Insert(a, ms.ToArray());
                return a;
            };
        }

        private void Insert(ZAttachment attachment, byte[] data)
        {
            if (data == null) throw new ArgumentNullException(nameof(data));
            var t = db.AttachmentTypes.Where(x => x.Id == attachment.TypeId).FirstOrDefault();
            if (t == null) throw new AttachmentTypeIsInvalidError();
            //------
            if (!IsValidFileName(attachment.FileName))
                throw new InvalidFileNameError();
            //------
            if (t.MaxSize * 1024 < data.Length)
                throw new AttachmentSizeIsInvalidError(t.MaxSize);
            //------
            if (!string.IsNullOrEmpty(t.ValidTypes))
            {
                var matched = false;
                foreach (var typ in t.ValidTypes.Replace(" ", "").Split(','))
                {
                    matched = IsValidType(typ.ToLower(), attachment.MimeType, attachment.FileName);
                    if (matched)
                        break;
                }
                if (!matched)
                    throw new InvalidFileTypeError();
            }
            //------
            if (t.Count > 0)
            {
                var list = db.Attachments
                    .Where(x =>
                        x.ObjectClass == attachment.ObjectClass &&
                        x.ObjectKey == attachment.ObjectKey &&
                        x.DraftId == attachment.DraftId &&
                        x.TypeId == attachment.TypeId)
                    .ToList();
                if (list.Count >= t.Count)
                    throw new MaximumNumberOfAttachmentError(t.Count);
            }

            attachment.Size = data.Length;

            var attachment_data = new ZAttachmentData()
            {
                Data = data,
                MimeType = attachment.MimeType,
                FileName = attachment.FileName,
                Size = attachment.Size,
            };

            db.AttachmentData.Add(attachment_data);
            db.SaveChanges();

            attachment.DataSerial = attachment_data.Serial;
            db.Attachments.Add(attachment);

            db.SaveChanges();
        }



        public bool IsValidFileName(string fileName)
        {
            if (string.IsNullOrEmpty(fileName) || fileName.Length > 150) return false;
            if (fileName.EndsWith(".exe") || fileName.EndsWith(".bat") || fileName.EndsWith(".cmd") || fileName.EndsWith(".ps1")) return false;
            if (fileName.Count(x => x == '.') > 1) return false;
            var invalid_chars = new List<char>();
            invalid_chars.AddRange(";~$%".ToCharArray());
            invalid_chars.AddRange(Path.GetInvalidFileNameChars());
            invalid_chars.Add((char)0);
            return fileName.IndexOfAny(invalid_chars.ToArray()) == -1;
        }

        public void ChangeObjectKey(string objectClass, string fromObjectKey, string toObjectKey)
        {
            objectClass = objectClass.Replace("'", "''");
            fromObjectKey = fromObjectKey.Replace("'", "''");
            toObjectKey = toObjectKey.Replace("'", "''");
            var sql = $"update PUR.ZAttachments  set ObjectKey='{toObjectKey}'  where ObjectClass='{objectClass}'  and  ObjectKey='{fromObjectKey}'";
            db.Execute(sql);
        }

        public void ChangeObjectHeader(long attachmentId, string toObjectHeader)
        {
            var a = GetAttachmentById(attachmentId);
            if (a != null)
            {
                a.ObjectHeader = toObjectHeader;

                var local = db.Set<ZAttachment>()
                    .Local
                    .FirstOrDefault(entry => entry.Id.Equals(a.Id));

                if (local != null)
                    db.Entry(local).State = EntityState.Detached;

                db.Entry(a).State = EntityState.Modified;
                db.Update(a);
                db.SaveChanges();
            }
        }

        public void ChangeObjectKey(long attachmentId, string toObjectKey)
        {
            var a = GetAttachmentById(attachmentId);
            if (a != null)
            {
                a.ObjectKey = toObjectKey;

                var local = db.Set<ZAttachment>()
                    .Local
                    .FirstOrDefault(entry => entry.Id.Equals(a.Id));

                if (local != null)
                    db.Entry(local).State = EntityState.Detached;

                db.Entry(a).State = EntityState.Modified;
                db.Update(a);
                db.SaveChanges();
            }
        }



        public void DeleteAttachments(IList<ZAttachment> attachments)
        {
            if (attachments.Count == 0)
                return;
            var dataSerials = attachments.Select(x => x.DataSerial);
            db.Attachments.RemoveRange(attachments);
            //db.AttachmentData.RemoveRange(dataSerials.Select(serial => new ZAttachmentData { Serial = serial }));
            db.SaveChanges();
        }

        public void DeleteAttachments(string objectClass, object objectKey)
        {
            var attachments = GetAttachmentsByKey(null, objectClass, objectKey);
            DeleteAttachments(attachments);
        }

        private bool IsValidType(string typ, string mimeType, string fileName)
        {
            var ext = string.IsNullOrEmpty(fileName) ? null : Path.GetExtension(fileName);
            if (!string.IsNullOrEmpty(ext) && ext[0] == '.')
                ext = ext.Substring(1);
            switch (typ)
            {
                case "txt":
                    return mimeType.eq("text/plain") && (ext == null || ext.eq("txt"));
                case "xml":
                    return mimeType.eq("application/xml") && (ext == null || ext.eq("xml"));
                case "pdf":
                    return mimeType.eq("application/pdf") && (ext == null || ext.eq("pdf"));
                case "json":
                    return mimeType.eq("application/json") && (ext == null || ext.eq("json"));


                case "word":
                case "doc":
                case "docx":
                    return (mimeType.eq("application/msword") || mimeType.eq("application/vnd.openxmlformats-officedocument.wordprocessingml.document")) &&
                        (ext == null || ext.eq("doc") || ext.eq("docx") || ext.eq("dot") || ext.eq("dotx"));

                case "excel":
                case "xls":
                case "xlsx":
                    return (mimeType.eq("application/vnd.ms-excel") || mimeType.eq("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")) &&
                        (ext == null || ext.eq("xls") || ext.eq("xlsx") || ext.eq("xlt") || ext.eq("xltx"));

                case "powerpoint":
                    return (mimeType.eq("application/vnd.ms-powerpoint") || mimeType.eq("application/vnd.openxmlformats-officedocument.presentationml.presentation")) &&
                        (ext == null || ext.eq("pps") || ext.eq("ppsx") || ext.eq("ppt") || ext.eq("pptx"));

                case "zip":
                case "rar":
                    return (mimeType.eq("application/vnd.rar") || mimeType.eq("application/zip")) &&
                        (ext == null || ext.eq("zip") || ext.eq("rar"));

                case "font":
                    return (mimeType.StartsWith("font/") || mimeType.eq("application/zip")) &&
                        (ext == null || ext.eq("woff") || ext.eq("woff2") || ext.eq("ttf") || ext.eq("eot") || ext.eq("otf"));

                case "image":
                    return mimeType.StartsWith("image/") &&
                        (ext == null || "tif,tiff,webp,bmp,gif,ico,jpeg,jpg,png,svg".Split(',').Any(x => x.eq(ext)));

                case "svg":
                    return mimeType.StartsWith("image/svg+xml") && (ext == null || "svg".eq(ext));
                case "jpg":
                case "jpeg":
                    return mimeType.StartsWith("image/jpeg") && (ext == null || "jpg".eq(ext) || "jpeg".eq(ext));
                case "gif":
                    return mimeType.StartsWith("image/gif") && (ext == null || "gif".eq(ext));
                case "png":
                    return mimeType.StartsWith("image/png") && (ext == null || "png".eq(ext));
                case "bmp":
                    return mimeType.StartsWith("image/bmp") && (ext == null || "bmp".eq(ext));
                case "ico":
                    return mimeType.StartsWith("image/vnd.microsoft.icon") && (ext == null || "ico".eq(ext));

                case "mp4":
                    return mimeType.StartsWith("video/mp4") && (ext == null || "mp4".eq(ext));
                case "mpeg":
                    return mimeType.StartsWith("video/mpeg") && (ext == null || "mpeg".eq(ext));
                case "webm":
                    return mimeType.StartsWith("video/webm") && (ext == null || "webm".eq(ext));
                case "3gp":
                    return mimeType.StartsWith("video/3gpp") && (ext == null || "3gp".eq(ext));

                case "mp3":
                    return mimeType.StartsWith("audio/mpeg") && (ext == null || "mp3".eq(ext));
            }
            return false;
        }

        public void DeleteAttachmentById(long serial)
        {
            var a = db.Attachments.FirstOrDefault(x => x.Id == serial);
            if (a == null) return;
            db.Attachments.Remove(a);
            //db.AttachmentData.Remove(new ZAttachmentData { Serial = a.DataSerial });
            db.SaveChanges();
        }

        public long CreateDownloadRequest(ZAttachment attachment)
        {
            var sessionId = _ContextService.GetCookie("x-session-id");
            if (string.IsNullOrEmpty(sessionId))
                throw new InvalidAccessError();
            var req = new ZAttachmentRequest
            {
                AttachmentId = attachment.Id,
                SessionId = sessionId,
            };
            db.AttachmentRequests.Add(req);
            db.SaveChanges();
            return req.Id;
        }

        public long CreateDownloadRequestAnonymous(ZAttachment attachment, string mobile)
        {
            var req = new ZAttachmentRequest
            {
                AttachmentId = attachment.Id,
                SessionId = mobile,
                CreatedBy = "service"
            };
            db.AttachmentRequests.Add(req);
            db.SaveChanges();
            return req.Id;
        }



        public ZAttachmentDraft GetDraft(long draftId, string objectClass)
        {
            if (draftId <= 0)
                return null;
            return db.AttachmentDrafts.FirstOrDefault(x => x.Id == draftId && x.ObjectClass == objectClass);
        }

        public IList<ZAttachment> CreateDraft(string objectClass, object objectHeader, object objectKey, out long draftId)
        {
            var draft = new ZAttachmentDraft
            {
                ObjectClass = objectClass,
                ObjectHeader = objectHeader.ToString(),
                ObjectKey = objectKey.ToString(),
                StatusId = DraftStatuses.NEW,
                UserName = _ContextService.UserName,
            };
            db.Add(draft);
            db.SaveChanges();

            //-----
            var obj_header = objectHeader == null ? null : objectHeader.ToString();

            var q = from a in db.Attachments
                    where a.DraftId == null && a.ObjectClass == objectClass && a.ObjectHeader == obj_header
                    select a;
            if (objectKey == null)
                q = q.Where(a => a.ObjectKey == objectKey.ToString());
            var attachments = q.ToList();

            //-----
            var result = new List<ZAttachment>();
            foreach (var a in attachments)
            {
                var atch = a.MapTo<ZAttachment>();
                atch.Id = 0;
                atch.DraftId = draft.Id;
                result.Add(atch);
            }
            db.AddRange(result);
            db.SaveChanges();

            draftId = draft.Id;
            return result;
        }

        public IList<ZAttachment> Clone(string objectClass, object objectKey, object newObjectHeader, object newObjectKey)
        {
            var attachments = GetAttachmentsByKey(null, objectClass, objectKey);
            var result = new List<ZAttachment>();
            foreach (var a in attachments)
            {
                var atch = a.MapTo<ZAttachment>();
                atch.Id = 0;
                atch.ObjectHeader = newObjectHeader.ToString();
                atch.ObjectKey = newObjectKey.ToString();
                result.Add(atch);
            }
            db.AddRange(result);
            db.SaveChanges();

            return result;
        }


        public IList<ZAttachment> Clone(string objectClass, object objectKey, string NewObjectClass, object newObjectHeader, object newObjectKey)
        {
            var attachments = GetAttachmentsByKey(null, objectClass, objectKey);
            var result = new List<ZAttachment>();
            foreach (var a in attachments)
            {
                var atch = a.MapTo<ZAttachment>();
                atch.Id = 0;
                atch.ObjectHeader = newObjectHeader.ToString();
                atch.ObjectKey = newObjectKey.ToString();
                atch.ObjectClass = NewObjectClass;

                result.Add(atch);
            }
            db.AddRange(result);
            db.SaveChanges();

            return result;
        }


        public void CommitDraft(long draftId)
        {
            var d = db.AttachmentDrafts.Where(x => x.Id == draftId).FirstOrDefault();
            if (d.UserName != _ContextService.UserName)
                throw new AccessDeniedError();
            d.StatusId = DraftStatuses.COMMIT;
            d.StatusDate = db.GetDate();

            var a_curr = db.Attachments.Where(x => x.DraftId == null && x.ObjectClass == d.ObjectClass && x.ObjectKey == d.ObjectKey).ToList();
            db.RemoveRange(a_curr);

            var a_draft = db.Attachments.Where(x => x.DraftId == draftId).ToList();
            foreach (var a in a_draft)
            {
                a.Id = 0;
                a.DraftId = null;
            }
            db.AddRange(a_draft);

            db.SaveChanges();
        }
    }
}