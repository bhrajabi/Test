﻿using Common;
using Common.Security;
using CommonServices.Core;
using CommonServices.Services.Data;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.ServiceModel;
using System.Threading.Tasks;
using Tamin.Core;

namespace CommonServices.Services
{
    public class sample_code
    {
        public IServiceProvider serviceProvider { get; set; }
        public IHttpContextService httpContextService { get; set; }


        public void CreateDBContext()
        {
            var options = serviceProvider.GetRequiredService<DbContextOptions<CommonDbContext>>();
            using (var db = new CommonDbContext(options, httpContextService))
            {
            }
        }
    }
}