﻿using CommonServices.Core;
using CommonServices.Interfaces;
using Microsoft.Extensions.Options;
using System.Net;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;

namespace CommonServices.Services
{
    public class EmailService : IEmailService
    {
        private readonly MailConfig _mailConfig;


        public EmailService(IOptions<MailConfig> mailSettings)
        {
            _mailConfig = mailSettings.Value;
        }

        public async Task SendEmailAsync(string email, string subject, string body)
        {
            var mail = new MailMessage();
            mail.From = new MailAddress(_mailConfig.Mail);
            mail.To.Add(email);
            mail.Subject = subject;
            mail.BodyEncoding = Encoding.UTF8;
            mail.Body = body;
            mail.IsBodyHtml = true;

            var smtp = new SmtpClient(_mailConfig.Host, _mailConfig.Port);
            smtp.Credentials = new NetworkCredential(_mailConfig.Mail, _mailConfig.Password);
            await smtp.SendMailAsync(mail);
        }
    }
}