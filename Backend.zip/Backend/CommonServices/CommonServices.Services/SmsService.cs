﻿using Common;
using CommonServices.Core;
using CommonServices.Services.Data;
using System;
using System.ServiceModel;
using System.Threading.Tasks;
using Tamin.Core;

namespace CommonServices.Services
{
    public class SmsService : ISmsService
    {
        //"http://wsiiksmsTest.ikco.com:8117/IkSmsService.svc/IkSmsService";
        const string TestModeServiceUrl = "http://wsiiksms.ikco.com:8117/IkSmsService.svc/IkSmsService";
        const string ProductionModeServiceUrl = "http://wsiiksms.ikco.com:8117/IkSmsService.svc/IkSmsService";
        private readonly string IkSmsServiceUser = "13990807";
        private readonly string IkSmsServicePass = "#dgrt%iiuu&";
        private IkSmsService.SrvIkSmsServiceClient Client;


        private readonly string BaseUrl = "https://wsiiksmsapi.ikco.com";

        private readonly CommonDbContext db;

        public SmsService(CommonDbContext db)
        {
            this.db = db;
        }

        public bool TestMode
        {
            get
            {
                return !Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT").eq("production");
            }
        }

        #region Old

        private IkSmsService.SrvIkSmsServiceClient CreateClient()
        {
            var binding = new BasicHttpBinding();
            //var serverUrl = TestMode ? TestModeServiceUrl : ProductionModeServiceUrl;
            var serverUrl = ProductionModeServiceUrl;
            var address = new EndpointAddress(serverUrl);
            return new IkSmsService.SrvIkSmsServiceClient(binding, address);
        }

        private IkSmsService.EntityAaa CreateAAA()
        {
            var aaa = new IkSmsService.EntityAaa();
            aaa._p1 = IkcoUtilities.Encoding(IkSmsServiceUser).ToString();
            aaa._p2 = IkcoUtilities.Encoding(IkSmsServicePass).ToString();
            aaa._p3 = IkcoUtilities.Encoding(DateTime.Now.ToString("MM/dd/yyyy HH:mm:ss")).ToString();
            return aaa;
        }

        private async Task<string> IkSale_SMS_WCF_Async(string phoneNumber, string text, int expireAtMinuites)
        {
            try
            {
                var expire_at = DateTime.Now.AddMinutes(expireAtMinuites);
                var req = new IkSmsService.SendSmsContentRequest()
                {
                    aaa = CreateAAA(),
                    mobile = phoneNumber,
                    context = text,
                    dateSend = Shamsi.ToLongString(DateTime.Now).Substring(0, 10),
                    timeSend = TestMode ? DateTime.Now.AddHours(-1).ToString("HH:mm:ss") : DateTime.Now.AddMinutes(-10).ToString("HH:mm:ss"),
                    userId = 13990807,
                    objectId = "",
                    expiredDate = Shamsi.ToLongString(expire_at).Substring(0, 10),
                    expiredTime = expire_at.ToString("HH:mm:ss"),
                };


                using (var c = CreateClient())
                {

                    await c.OpenAsync();
                    var res = await c.SendSmsContentAsync(req);

                    if (!string.IsNullOrEmpty(res.errDesc))
                        throw new AnErrorOccurredWhileSendingSmsPleaseContactAdministratorError();
                    return res.vid;
                }

            }
            catch
            {
                throw new AnErrorOccurredWhileSendingSmsPleaseContactAdministratorError();

                //throw new Exception("error-while-sending-sms");
            }
        }

        #endregion

        /*
        public async Task<string> SendAsync(string phoneNumber, string message, int expireAtMinuites)
        {
            var vid = await db.SendSMSAsync(phoneNumber, message);
            return vid.ToString();
        }
        */

        public string Send(string phoneNumber, string message)
        {
            var vid = db.SendSMS(phoneNumber, message);
            return vid.ToString();
        }


        /*******************************/
        public async Task<string> SendAsync(string phoneNumber, string text, int expireAtMinuites)
        {
            var expire_at = DateTime.Now.AddHours(1);

            var req = new
            {
                mobile = phoneNumber,
                context = text,
                dateSend = Shamsi.ToLongString(DateTime.Now).Substring(0, 10),
                timeSend = DateTime.Now.AddMinutes(-10).ToString("HH:mm:ss"),
                objectId = "",
                expiredDate = Shamsi.ToLongString(expire_at).Substring(0, 10),
                expiredTime = expire_at.ToString("HH:mm:ss"),
            };

            try
            {
                var parameters = $"mobile={req.mobile}&" +
                                 $"context={req.context}&" +
                                 $"dateSend={req.dateSend}&" +
                                 $"timeSend={req.timeSend}&" +
                                 $"objectId={req.objectId}&" +
                                 $"expiredDate={req.expiredDate}&" +
                                 $"expiredTime={req.expiredTime}&" +
                                 $"userName={IkSmsServiceUser}";


                var rest = new Rest($"{BaseUrl}/SMS/SendSmsContent?{parameters}");
                rest.AddHeader("Authorization", "Bearer " + GetToken());

                var res = await rest.GetAsync<RestSmsResult>();

                if (res == null || !string.IsNullOrEmpty(res?.ErrorDesc))
                    throw new Exception(res.ErrorDesc);

                return res.Vid;
            }
            catch (Exception ex)
            {
                var err = new Exception($"{ex.Message}\r\n{req.dateSend} {req.timeSend}  ~  {req.expiredDate} {req.expiredTime}");
                throw;
            }
        }

        private string GetToken()
        {
            var rest = new Rest($"{BaseUrl}/Account/Login");

            var body = new { username = IkSmsServiceUser, password = IkSmsServicePass };
            var res = rest.Post<RestSms>(body);
            if (res == null || !string.IsNullOrEmpty(res?.ErrorDesc))
                throw new Exception(res.ErrorDesc);

            return res.Token;
        }

    }
}
