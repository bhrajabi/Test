using System;
using System.IO;
using System.Runtime.InteropServices;
using System.Security.Cryptography;

public partial class IkcoUtilities
{
    [DllImport("kernel32", EntryPoint = "GetComputerNameA")]
    static extern long GetComputerName(string lpBuffer, long nSize);
    [DllImport("user32", EntryPoint = "LoadKeyboardLayoutA")]
    private static extern int LoadKeyboardLayout(string pwszKLID, int flags);
    private const string TempCoderIkcoUtilities = "45hd!%dksds5478$xds78!";
    private sealed partial class Simple3Des
    {

        private TripleDESCryptoServiceProvider TripleDes = new TripleDESCryptoServiceProvider();

        private byte[] TruncateHash(string key, int length)
        {

            var sha1 = new SHA1CryptoServiceProvider();

            // Hash the key.
            var keyBytes = System.Text.Encoding.Unicode.GetBytes(key);
            var hash = sha1.ComputeHash(keyBytes);

            // Truncate or pad the hash.
            Array.Resize(ref hash, length);
            return hash;
        }

        public Simple3Des(string key)
        {
            // Initialize the crypto provider.
            TripleDes.Key = TruncateHash(key, TripleDes.KeySize / 8);
            TripleDes.IV = TruncateHash("", TripleDes.BlockSize / 8);
        }

        internal string EncryptData(string plaintext)
        {

            // Convert the plaintext string to a byte array.
            var plaintextBytes = System.Text.Encoding.Unicode.GetBytes(plaintext);

            // Create the stream.
            var ms = new MemoryStream();
            // Create the encoder to write to the stream.
            var encStream = new CryptoStream(ms, TripleDes.CreateEncryptor(), CryptoStreamMode.Write);


            // Use the crypto stream to write the byte array to the stream.
            encStream.Write(plaintextBytes, 0, plaintextBytes.Length);
            encStream.FlushFinalBlock();

            // Convert the encrypted stream to a printable string.
            return Convert.ToBase64String(ms.ToArray());
        }

        internal string DecryptData(string encryptedtext)
        {

            // Convert the encrypted text string to a byte array.
            var encryptedBytes = Convert.FromBase64String(encryptedtext);

            // Create the stream.
            var ms = new MemoryStream();
            // Create the decoder to write to the stream.
            var decStream = new CryptoStream(ms, TripleDes.CreateDecryptor(), CryptoStreamMode.Write);


            // Use the crypto stream to write the byte array to the stream.
            decStream.Write(encryptedBytes, 0, encryptedBytes.Length);
            decStream.FlushFinalBlock();

            // Convert the plaintext stream to a string.
            return System.Text.Encoding.Unicode.GetString(ms.ToArray());
        }

    }



    public static object Encoding(string strplain)
    {

        string plainText = strplain;
        string password = TempCoderIkcoUtilities;

        var wrapper = new Simple3Des(password);
        string cipherText = wrapper.EncryptData(plainText);
        return cipherText;
    }

    public static object Decoding(string cipherText)
    {
        var wrapper = new Simple3Des(TempCoderIkcoUtilities);

        string plainText = wrapper.DecryptData(cipherText);
        return plainText;
    }






}