﻿using System;
using System.Threading.Tasks;
using Attcahment.Core;
using Common.Data;
using Common.Security;
using CommonServices.Core;
using Microsoft.EntityFrameworkCore;

namespace CommonServices.Services.Data
{
    public class CommonDbContext : BaseDbContext
    {

        public CommonDbContext(DbContextOptions<CommonDbContext> options, IHttpContextService currentUserNameService) : base(options, currentUserNameService)
        {
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
        }


        public long SendSMS(string mobileNo, string message)
        {
            if (string.IsNullOrEmpty(mobileNo)) throw new InvalidPhoneNumberError();
            if (string.IsNullOrEmpty(message) || message.Length > 500) throw new InvalidSMSMessageError();

            var sql = $"declare @VID bigint\r\n" +
                $"exec PUR.SP_SendSMS  '{mobileNo}', '{message}' , @VID output \r\n" +
                "select @VID";
            var tb = GetDataTable(sql);
            return tb.Rows[0][0].ToLong(0);
        }


        public async Task<long> SendSMSAsync(string mobileNo, string message)
        {
            if (string.IsNullOrEmpty(mobileNo)) throw new InvalidPhoneNumberError();
            if (string.IsNullOrEmpty(message) || message.Length > 500) throw new InvalidSMSMessageError();

            var sql = $"declare @VID bigint\r\n" +
                $"exec PUR.SP_SendSMS  '{mobileNo}', '{message}' , @VID output \r\n" +
                "select @VID";
            var tb = await GetDataTableAsync(sql);
            return tb.Rows[0][0].ToLong(0);
        }

    }
}
