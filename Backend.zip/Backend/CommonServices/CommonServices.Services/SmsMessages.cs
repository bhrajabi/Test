﻿namespace CommonServices.Services
{
    public static class SmsMessages
    {
        public const string Public = " {0} \n شبكه خريد ایران خودرو";

        public const string Otp = "کد تایید {0} شبكه خريد ایران خودرو";

        public const string RegisterAccount = "ثبت نام شما با موفقیت انجام شد.نام کاربری شما: {0} شبكه خريد ایران خودرو";

        public const string NewComment = "يك نظر جديد براي شما ثبت شد";

        public const string Login = "شبكه خريد ایران خودرو\n" + "ورود به پنل کاربری\n {0}";

        public const string UserInvitation =
            "شبكه خريد ایران خودرو\n" +
            "از شما دعوت مي شود با لينك زير وارد شبكه تامين شويد\n" +
            "ipn.ikco.ir\n";

        public const string SourcingRequestItemRejected =
           "درخواست منبع يابي با شماره مرجع {0} و رديف {1} رد شد.\n" +
           "شبكه خريد ایران خودرو";

        public const string SourcingRequestItemAssigned =
         "كاربر محترم {0}\n" +
         "درخواست منبع يابي با شماره مرجع {1} و رديف {2} به شما اختصاص داده شد.\n" +
         "شبكه خريد ایران خودرو";

        public const string SourcingRequestItemCanceled = "شبكه خريد ایران خودرو\n" + "درخواست منبع يابي با شماره مرجع {0} آيتم {1} توسط درخواست كننده كنسل شد";
    }
}
