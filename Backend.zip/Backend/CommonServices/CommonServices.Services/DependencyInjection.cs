﻿using CommonServices.Core;
using CommonServices.Interfaces;
using CommonServices.Services;
using CommonServices.Services.Data;
using Microsoft.EntityFrameworkCore;

namespace Microsoft.Extensions.DependencyInjection
{
    public static class DependencyInjection
    {

        public static void AddCommonServicesService(this IServiceCollection services, string connectionString)
        {
            services.AddDbContext<CommonDbContext>(options => options
                        .UseSqlServer(connectionString)
                        .UseQueryTrackingBehavior(QueryTrackingBehavior.NoTracking)
                        );

            services.AddScoped<ISmsService, SmsService>();
            services.AddScoped<IEmailService, EmailService>();
            services.AddScoped<IDbSchemaService, DbSchemaService>();
        }
    }
}