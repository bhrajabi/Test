﻿using System;
using System.Collections.Generic;
using System.Data;
using Common.Data;
using CommonServices.Core;
using LiteDB;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore.Metadata.Internal;

namespace CommonServices.Services
{
    public class DbSchemaService : IDbSchemaService
    {
        public string ConnectionString { get; set; }



        public DbSchemaService()
        {
        }


        public List<string> GetTables()
        {
            return GetTables("BASE TABLE");
        }

        public List<string> GetViews()
        {
            return GetTables("VIEW");
        }

        private List<string> GetTables(string type)
        {
            var tables = new List<string>();
            var query = $"SELECT TABLE_SCHEMA, TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_TYPE = '{type}'";

            using (var connection = new SqlConnection(ConnectionString))
            {
                connection.Open();
                using var command = new SqlCommand(query, connection);
                using var reader = command.ExecuteReader();
                while (reader.Read())
                {
                    var s = reader["TABLE_SCHEMA"];
                    var t = reader["TABLE_NAME"];
                    tables.Add($"{s}.{t}");
                }
            }

            return tables;
        }


        public TableSchema GetTableSchema(string tableName)
        {
            var p = tableName.Split('.');
            var schemaName = p.Length == 2 ? p[0] : "dbo";
            tableName = p.Length == 2 ? p[1] : tableName;


            var tableSchema = new TableSchema
            {
                Columns = new List<TableColumn>(),
                PrimaryKey = new List<string>(),
                UniqueConstraints = new List<string>()
            };

            string columnQuery = @"
            SELECT COLUMN_NAME, DATA_TYPE, CHARACTER_MAXIMUM_LENGTH, IS_NULLABLE, 
                   NUMERIC_PRECISION, NUMERIC_SCALE, 
                   COLUMNPROPERTY( object_id(TABLE_SCHEMA+'.'+TABLE_NAME), COLUMN_NAME, 'IsIdentity') as IsIdentity
            FROM INFORMATION_SCHEMA.COLUMNS
            WHERE TABLE_SCHEMA = @TableSchema and TABLE_NAME = @TableName";

            string primaryKeyQuery = @"
            SELECT COLUMN_NAME
            FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE
            WHERE TABLE_SCHEMA = @TableSchema  and  TABLE_NAME = @TableName AND CONSTRAINT_NAME = (
                SELECT CONSTRAINT_NAME 
                FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS
                WHERE TABLE_SCHEMA = @TableSchema and TABLE_NAME = @TableName AND CONSTRAINT_TYPE = 'PRIMARY KEY')";

            string uniqueConstraintQuery = @"
            SELECT COLUMN_NAME
            FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE
            WHERE TABLE_SCHEMA = @TableSchema  and  TABLE_NAME = @TableName AND CONSTRAINT_NAME IN (
                SELECT CONSTRAINT_NAME 
                FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS
                WHERE TABLE_SCHEMA = @TableSchema and TABLE_NAME = @TableName AND CONSTRAINT_TYPE = 'UNIQUE')";

            using (var connection = new SqlConnection(ConnectionString))
            {
                connection.Open();

                // Fetch Columns
                using (var command = new SqlCommand(columnQuery, connection))
                {
                    command.Parameters.AddWithValue("@TableName", tableName);
                    command.Parameters.AddWithValue("@TableSchema", schemaName);
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            var column = new TableColumn
                            {
                                Name = reader["COLUMN_NAME"].ToString(),
                                DataType = reader["DATA_TYPE"].ToString(),
                                MaxLength = reader["CHARACTER_MAXIMUM_LENGTH"].ToInt(),
                                IsNullable = reader["IS_NULLABLE"].ToString() == "YES",
                                Precision = reader["NUMERIC_PRECISION"].ToByte(),
                                Scale = reader["NUMERIC_SCALE"].ToByte(),
                                IsIdentity = reader["IsIdentity"].ToBool(false),
                            };
                            tableSchema.Columns.Add(column);
                        }
                    }
                }

                // Fetch Primary Key Columns
                using (var command = new SqlCommand(primaryKeyQuery, connection))
                {
                    command.Parameters.AddWithValue("@TableName", tableName);
                    command.Parameters.AddWithValue("@TableSchema", schemaName);
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            tableSchema.PrimaryKey.Add(reader["COLUMN_NAME"].ToString());
                        }
                    }
                }

                // Fetch Unique Constraint Columns
                using (var command = new SqlCommand(uniqueConstraintQuery, connection))
                {
                    command.Parameters.AddWithValue("@TableName", tableName);
                    command.Parameters.AddWithValue("@TableSchema", schemaName);
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            tableSchema.UniqueConstraints.Add(reader["COLUMN_NAME"].ToString());
                        }
                    }
                }
            }

            return tableSchema;
        }


        public List<ForeignKeyRelationship> GetForeignKeyRelationships()
        {
            var relationships = new List<ForeignKeyRelationship>();

            string query = @"
            SELECT   
                fk.name AS FK_Name,  
                s_parent.name AS ParentSchema,  
                tp.name AS ParentTable,  
                s_referenced.name AS ReferencedSchema,  
                ref.name AS ReferencedTable,  
                cp.name AS ParentColumn,  
                cref.name AS ReferencedColumn  
            FROM 
                sys.foreign_keys AS fk  
                INNER JOIN   sys.tables AS tp ON fk.parent_object_id = tp.object_id  
                INNER JOIN   sys.schemas AS s_parent ON tp.schema_id = s_parent.schema_id  
                INNER JOIN   sys.tables AS ref ON fk.referenced_object_id = ref.object_id  
                INNER JOIN   sys.schemas AS s_referenced ON ref.schema_id = s_referenced.schema_id  
                INNER JOIN   sys.foreign_key_columns AS fkc ON fkc.constraint_object_id = fk.object_id  
                INNER JOIN   sys.columns AS cp ON fkc.parent_column_id = cp.column_id AND cp.object_id = tp.object_id  
                INNER JOIN   sys.columns AS cref ON fkc.referenced_column_id = cref.column_id AND cref.object_id = ref.object_id;";

            using (var connection = new SqlConnection(ConnectionString))
            {
                connection.Open();
                using var command = new SqlCommand(query, connection);
                using var reader = command.ExecuteReader();
                while (reader.Read())
                {
                    var relationship = new ForeignKeyRelationship
                    {
                        FKName = reader["FK_Name"].ToString(),
                        ParentTable = $"{reader["ParentSchema"]}.{reader["ParentTable"]}",
                        ReferencedTable = $"{reader["ReferencedSchema"]}.{reader["ReferencedTable"]}",
                        ParentColumn = reader["ParentColumn"].ToString(),
                        ReferencedColumn = reader["ReferencedColumn"].ToString()
                    };
                    relationships.Add(relationship);
                }
            }

            return relationships;
        }


        public DataTable ExecSql(string sql)
        {
            using (var connection = new SqlConnection(ConnectionString))
            {
                connection.Open();

                var tb = new DataTable();
                using var cmd = connection.CreateCommand();
                using var da = new SqlDataAdapter(cmd as SqlCommand);

                cmd.CommandText = sql;
                da.Fill(tb);
                return tb;
            }
        }
    }
}