﻿using Common;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Chat.Controllers
{
    public class SendMessageDTO
    {
        public long ChatSerial { get; set; }

        public bool JustForAdmin { get; set; }

        [MaxLength(50000)]
        [DefaultValue(SpecialChars.All)]
        public string Message { get; set; } = string.Empty;
    }
}
