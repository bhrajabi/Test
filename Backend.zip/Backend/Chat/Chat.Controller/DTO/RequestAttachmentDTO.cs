﻿namespace Chat.Controllers
{
    public class RequestAttachmentDTO
    {
        public long Id { get; set; }
        public long? DraftId { get; set; }
        public string TypeId { get; set; }
        public string FileName { get; set; }
    }
}
