﻿namespace Chat.Controllers
{
    public class InviteNewChatMemberDTO
    {
        public string UserName { get; set; }
        public long ChatSerial { get; set; }

        public bool IsAdmin { get; set; }
        public string UserGroupAlias { get; set; }
        public string UserGroupImageUrl { get; set; }
    }
}
