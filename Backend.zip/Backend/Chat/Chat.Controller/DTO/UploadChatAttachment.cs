﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using Common;
using Microsoft.AspNetCore.Http;

namespace Chat.Controllers
{
    public class UploadChatAttachment
    {
        [MaxLength(50000)]
        [DefaultValue(SpecialChars.All)]
        public string Message { get; set; } = string.Empty;

        public IFormFile File { get; set; }
    }
}
