﻿using Attcahment.Core;
using Chat.Core;
using Common;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;

namespace Chat.Controllers
{
    [ApiController]
    [Route("[controller]/[action]")]
    [Authorize(AuthenticationSchemes = "Bearer")]
    [ValidateModel]
    public class ChatController : ControllerBase
    {
        private readonly IMessageService messageService;
        private readonly IAttachmentService attachmentService;

        public ChatController(IMessageService messageService, IAttachmentService attachmentService)
        {
            this.messageService = messageService;
            this.attachmentService = attachmentService;
        }

        [HttpPost]
        [EnableCors("react")]
        [Route("~/chat/send-message")]
        public Response SendMessage(SendMessageDTO dto)
        {
            if (dto.ChatSerial == 0) return new Response("chat-not-found");

            var chatUser = messageService.GetChatUser(dto.ChatSerial, messageService.MyUserName) ?? throw new ChatUserNotFoundError();
            var senderSerial = chatUser.Serial;

            var message = new NewMessage
            {
                ChatSerial = dto.ChatSerial,
                SenderSerial = senderSerial,
                Message = dto.Message,
                JustForAdmin = dto.JustForAdmin,
                MessageTypeId = MessageTypes.TEXT.ToString()
            };

            var newMessage = messageService.SendMessage(message);

            var result = new { Message = newMessage };

            return new Response(result);
        }


        [HttpPost]
        [EnableCors("react")]
        [Route("~/chat/init-my-chat-messages")]
        public Response InitChatMessages(long chatSerial)
        {
            var messages = messageService.GetChatMessages(chatSerial);
            var result = new { Messages = messages };

            return new Response(result);
        }

        [HttpPost]
        [EnableCors("react")]
        [Route("~/chat/init-chat-messages")]
        public Response InitAdminChatMessages(long chatSerial)
        {
            var messages = messageService.GetAdminChatMessages(chatSerial);
            var result = new { Messages = messages };
            return new Response(result);
        }

        [HttpPost]
        [EnableCors("react")]
        [Route("~/chat/invite-new-chat-member")]
        public Response InviteNewChatMember(InviteNewChatMemberDTO dto)
        {
            if (dto.ChatSerial <= 0) return new Response("chat-not-found");
            if(string.IsNullOrEmpty(dto.UserName)) return new Response("user-not-found");

            var invitedUser = messageService.GetUserByUsername(dto.UserName);
            if(invitedUser == null) return new Response("user-not-found");

            var myChatUser = messageService.GetChatUser(dto.ChatSerial, messageService.MyUserName);
            if (myChatUser is null) return new Response("chat-not-found");

            var user = messageService.InviteChatMember(dto.UserName, dto.ChatSerial, myChatUser.IsAdmin, myChatUser.UserGroupAlias, myChatUser.UserGroupImageUrl, messageService.MyUserName);
            var result = new { user };

            return new Response(result);
        }


        [HttpPost]
        [EnableCors("react")]
        [Route("~/chat/left-from-chat")]
        public Response LeftFromChat(long chatSerial)
        {
            messageService.LeftFromChat(chatSerial, messageService.MyUserName);

            var result = new { };
            return new Response(result);
        }

        [HttpPost]
        [EnableCors("react")]
        [Route("~/chat/remove-chat-message")]
        public Response RemoveChatMessage(long chatSerial, long messageSerial)
        {
            messageService.RemoveChatMessage(chatSerial, messageSerial, messageService.MyUserName);

            var result = new { };
            return new Response(result);
        }

        [HttpGet]
        [EnableCors("react")]
        [AllowAnonymous]
        [Route("~/chat/download-attachment")]
        public IActionResult DownloadAttachment(long messageSerial)
        {
            var attachments = attachmentService.GetAttachmentsByKey(null, ObjectClasses.ChatMessage, messageSerial);
            if (attachments is null || !attachments.Any()) return BadRequest();

            var attachment = attachments.LastOrDefault();
            if (attachment is null) return BadRequest();

            var attachmentData = attachmentService.GetAttachmentDataBySerial(attachment.DataSerial);

            return base.File(attachmentData.Data, attachment.MimeType, attachment.FileName);
        }

        [HttpPost]
        [EnableCors("react")]
        [Route("~/chat/upload-attachment")]
        public Response UploadAttachment(long chatSerial, UploadChatAttachment dto)
        {
            if (dto is null) return new Response("invalid-model");
            if (dto.File is null || dto.File.Length == 0) return new Response("file-is-empty");

            var chatUser = messageService.GetChatUser(chatSerial, messageService.MyUserName);
            if (chatUser is null) return new Response("chat-user-not-found");

            if (!attachmentService.IsValidFileName(dto.File.FileName)) return new Response("invalid-file-name");

            var new_message = messageService.SendMessage(chatSerial, chatUser.Serial, dto.Message, dto.File);

            _ = attachmentService.Insert(null, ObjectClasses.ChatMessage, new_message.Serial, new_message.Serial, AttachmentTypes.ChatMessage, dto.File);

            var result = new
            {
                message = new_message
            };

            return new Response(result);
        }

        [HttpPost]
        [EnableCors("react")]
        [Route("~/chat/init-my-chats")]
        public Response InitChats()
        {
            var chats = messageService.GetChats(messageService.MyUserName);
            var result = new { Chats = chats };

            return new Response(result);
        }
    }
}
