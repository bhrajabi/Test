﻿using System.Text.RegularExpressions;

namespace Chat.Core.Extentions
{
    public static class StringExtentions
    {
        public static string MakeString(this string input) => input.IsBase64() ? Common.Convert.FromBase64(input) : input;

        public static string ToBase64(this string input) => Common.Convert.ToBase64(input);

        public static bool IsBase64(this string input)
        {
            if (string.IsNullOrEmpty(input) || input.Length % 4 != 0) return false;
            return Regex.IsMatch(input, @"^[a-zA-Z0-9\+/]*={0,3}$");
        }
    }
}
