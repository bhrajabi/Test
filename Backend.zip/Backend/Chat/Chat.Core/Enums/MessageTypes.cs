﻿namespace Chat.Core
{
    public enum MessageTypes
    {
        FILE,
        HTML,
        IMG,
        JSON,
        PDF,
        TEXT,
        VIDEO,
        VOICE,
        ZIP,
        XLSX,
        DOCX,
        TXT,
    }
}
