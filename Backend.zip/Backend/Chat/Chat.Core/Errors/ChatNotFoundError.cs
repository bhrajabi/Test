﻿using Common;

namespace Chat.Core
{
    public class ChatNotFoundError : Error
    {
        public ChatNotFoundError() : base("chat-not-found")
        {
        }
    }
}
