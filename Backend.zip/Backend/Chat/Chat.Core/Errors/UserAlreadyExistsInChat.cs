﻿using Common;

namespace Chat.Core
{
    public class UserAlreadyExistsInChat : Error
    {
        public UserAlreadyExistsInChat() : base("user-already-exists-in-chat")
        {
        }
    }
}
