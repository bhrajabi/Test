﻿using Common;

namespace Chat.Core
{
    public class AtleastOneUserRequiredError : Error
    {
        public AtleastOneUserRequiredError() : base("atleast-one-user-required")
        {
        }
    }
}
