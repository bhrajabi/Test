﻿using Common;

namespace Chat.Core
{
    public class ApplicationIdNotDefinedError : Error
    {
        public ApplicationIdNotDefinedError() : base("application-id-not-defined")
        {
        }
    }
}
