﻿using Common;

namespace Chat.Core
{
    public class ChatUserNotFoundError : Error
    {
        public ChatUserNotFoundError() : base("chat-user-not-found")
        {
        }
    }
}
