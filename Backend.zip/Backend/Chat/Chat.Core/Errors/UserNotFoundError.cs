﻿using Common;

namespace Chat.Core
{
    public class UserNotFoundError : Error
    {
        public UserNotFoundError() : base("user-not-found")
        {
        }
    }
}
