﻿using Common;

namespace Chat.Core
{
    public class ChatAlreadyExistsError : Error
    {
        public ChatAlreadyExistsError() : base("chat-already-exists-error")
        {
        }
    }
}
