﻿using Common;

namespace Chat.Core
{
    public class UserAlreadyExistsError : Error
    {
        public UserAlreadyExistsError() : base("user-already-exists")
        {
        }
    }
}
