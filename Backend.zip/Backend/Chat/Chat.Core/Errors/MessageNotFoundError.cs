﻿using Common;

namespace Chat.Core
{
    public class MessageNotFoundError : Error
    {
        public MessageNotFoundError() : base("message-not-found")
        {
        }
    }
}
