﻿using Common;

namespace Chat.Core
{
    public class ApplicationNotFoundError : Error
    {
        public ApplicationNotFoundError() : base("application-not-found")
        {
        }
    }
}
