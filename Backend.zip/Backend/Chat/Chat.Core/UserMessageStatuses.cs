﻿namespace Chat.Core
{
    public class UserMessageStatuses
    {
        public const string DLV = "DLV";
        public const string NEW = "NEW";
        public const string READ = "READ";
    }
}
