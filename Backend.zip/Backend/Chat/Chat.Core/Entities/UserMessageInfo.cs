﻿using System.ComponentModel.DataAnnotations.Schema;

namespace Chat.Core
{
    [Table("UserMessageInfo", Schema = "MSG")]
    public class UserMessageInfo
    {
        public long UserSerial { get; set; }
        public long MessageSerial { get; set; }

        public string StatusId { get; set; }
        public DateTime? DeliveredAt { get; set; }
        public DateTime? ReadAt { get; set; }
        public DateTime? DeletedAt { get; set; }
        public bool IsOwner { get; set; }
        public bool IsDeleted { get; set; }
        public bool IsStarred { get; set; }
    }
}
