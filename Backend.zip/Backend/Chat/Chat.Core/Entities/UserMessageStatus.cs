﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Chat.Core
{
    [Table("UserMessageStatuses", Schema = "MSG")]
    public class UserMessageStatus
    {
        [Key]
        public string Id { get; set; }

        public string Title { get; set; }

    }
}
