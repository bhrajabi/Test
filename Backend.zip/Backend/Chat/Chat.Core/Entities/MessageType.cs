﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Chat.Core
{
    [Table("MessageTypes", Schema = "MSG")]
    public class MessageType
    {
        [Key]
        public string Id { get; set; }

        public string Title { get; set; }

    }
}
