﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Chat.Core
{
    [Table("Messages", Schema = "MSG")]
    public class Messages
    {
        [Key]
        public long Serial { get; set; }

        public long ChatSerial { get; set; }
        public long? ReplyTo { get; set; }
        public long? ForwardedFrom { get; set; }
        public string Message { get; set; }
        public long? AttachmentId { get; set; }
        public string Thumbnail { get; set; }
        public double? AspectRatio { get; set; }
        public string MessageTypeId { get; set; }
        public bool? JustForAdmin { get; set; }
        public bool? IsDelivered { get; set; }
        public bool? IsRead { get; set; }
        public bool? IsSystemMessage { get; set; }
        public long SenderSerial { get; set; }
        
        public DateTime CreatedAt { get; set; }
    }
}
