﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Chat.Core
{
    [Table("Chats", Schema = "MSG")]
    public class Chat
    {
        [Key]
        public long Serial { get; set; }

        public string ApplicationId { get; set; }
        public string ChatKey { get; set; }
        public string Title { get; set; }
        public string SubTitle { get; set; }
        public string LinkUrl { get; set; }
        public string ImageUrl { get; set; }
        public long? LastMessageSerial { get; set; }
        public bool? IsChatGroup { get; set; }
        public bool IsClosed { get; set; }
        
        [MaxLength(50)]
        public string ReferenceKey { get; set; }

        public DateTime CreatedAt { get; set; }
        public string CreatedBy { get; set; }
    }
}
