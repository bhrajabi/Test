﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Chat.Core
{
    [Table("Users", Schema = "MSG")]
    public class User
    {
        [Key]
        public long Serial { get; set; }

        public string ApplicationId { get; set; }
        public string UserName { get; set; }
        public string DisplayName { get; set; }
        public string ImageUrl { get; set; }
    }
}
