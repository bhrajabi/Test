﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Chat.Core
{
    [Table("Applications", Schema = "MSG")]
    public class Application
    {
        [Key]
        public string Id { get; set; }

        public string Title { get; set; }
    }
}
