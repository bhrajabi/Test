﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Chat.Core
{
    [Table("ChatUsers", Schema = "MSG")]
    public class ChatUser
    {
        [Key]
        public long Serial { get; set; }

        public long ChatSerial { get; set; }
        public long UserSerial { get; set; }
        public string UserGroupId { get; set; }
        public string UserGroupAlias { get; set; }
        public string UserGroupImageUrl { get; set; }
        public long? LastReadMessageSerial { get; set; }
        public bool IsAdmin { get; set; }
        public bool IsMuted { get; set; }
        public bool IsLeft { get; set; }
        public bool IsArchived { get; set; }
        public int UnreadCount { get; set; }
        public DateTime CreatedAt { get; set; }
        public string CreatedBy { get; set; }
    }
}
