﻿using Microsoft.AspNetCore.Http;

namespace Chat.Core
{
    public interface IMessageService
    {
        string MyUserName { get; }

        bool CloseChat(string chatKey);
        Chat? CreateChat(string chatKey, string createdBy, string subTitle, string imageUrl, bool isChatGroup, string title, string linkUrl = "", string referenceKey = "");
        Chat? GetChatByKey(string chatKey);
        List<Messages> GetChatMessages(long chatSerial);
        List<Messages> GetChatMessages(long chatSerial , string userName);

        List<ChatView> GetChats(string userName);

        User? AddUser(User user);
        User? GetUserByUsername(string username);
        bool RemoveChatUser(string chatKey, string userName);
        User? AddChatUser(string chatKey, bool isAdmin, string aliasName, string aliasImageUrl, string createdBy, User user);
        List<ChatUser>? AddChatUsers(long chatSerial, List<ChatUser> chatUsers, string createdBy);

        ChatUser? GetChatUser(long chatSerial, string userName);
        bool AddSystemMessage(long chatSerial, string messageText, string createdBy, MessageTypes messageType = MessageTypes.TEXT);
        void LeftFromChat(long chatSerial, string username);
        void RemoveChatMessage(long chatSerial, long messageSerial, string username);
        List<ChatView> GetAdminChats();
        User GetAdminUser();
        List<Messages> GetAdminChatMessages(long chatSerial);

        Messages SendMessage(long chatSerial, long senderSerial, string message, IFormFile file);
        Messages SendMessage(NewMessage messages);
        List<ChatView> GetChatsByReferenceKey(string referenceKey);
        Chat GetChatBySerial(long chatSerial);
        User? InviteChatMember(string userName, long chatSerial, bool isAdmin, string userGroupAlias, string userGroupImageUrl, string createdBy);
        User SafeGetUser(User user);
        List<User> GetChatUsersList(string chatKey);
        List<User> GetChatUsersList(long chatSerial);
        bool ExistsReferenceKey(string refKey);
    }
}
