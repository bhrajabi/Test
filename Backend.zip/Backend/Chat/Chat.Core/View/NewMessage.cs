﻿using Chat.Core.Extentions;

namespace Chat.Core
{
    public class NewMessage
    {
        private string _message = "";

        public long ChatSerial { get; set; }
        public long? ReplyTo { get; set; }
        public long? ForwardedFrom { get; set; }
        public long? AttachmentId { get; set; }
        public string Thumbnail { get; set; }
        public double? AspectRatio { get; set; }
        public string MessageTypeId { get; set; }
        public bool? JustForAdmin { get; set; }
        public bool? IsDelivered { get; set; }
        public bool? IsRead { get; set; }
        public bool? IsSystemMessage { get; set; }
        public long SenderSerial { get; set; }
        public string Message
        {
            get => _message;
            set => _message = value.MakeString();
        }
    }
}
