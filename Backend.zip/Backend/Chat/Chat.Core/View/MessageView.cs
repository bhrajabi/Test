﻿namespace Chat.Core
{
    public class MessageView
    {
        public string Message { get; set; } = string.Empty;
        public long? ReplyTo { get; set; }
        public long? ForwardedFrom { get; set; }
        public long? AttachmentId { get; set; }
        public string MessageTypeId { get; set; } = string.Empty;
        public bool? IsDelivered { get; set; }
        public bool? IsRead { get; set; }
        public long SenderSerial { get; set; }
        public DateTime CreatedAt { get; set; }
    }
}
