﻿namespace Chat.Core
{
    public class ChatUserView
    {
        public long ChatUserSerial { get; set; }
        public long ChatSerial { get; set; }
        public long UserSerial { get; set; }

        public bool IsArchived { get; set; }
        public int UnreadCount { get; set; }

        // user info
        public string UserName { get; set; }
        public string DisplayName { get; set; }
        public string ImageUrl { get; set; }
    }
}
