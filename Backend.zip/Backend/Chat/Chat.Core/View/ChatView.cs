﻿namespace Chat.Core
{
    public class ChatView 
    {
        public long Serial { get; set; }
        public string Title { get; set; } = string.Empty;
        public string SubTitle { get; set; } = string.Empty;
        public string? LinkUrl { get; set; } = string.Empty;
        public string? ImageUrl { get; set; } = string.Empty;
        public bool? IsChatGroup { get; set; }
        public bool IsArchived { get; set; }
        public bool IsClosed { get; set; }
        public int NewMessageCount { get; set; }
        public bool IsSavedMessageChat { get; set; }
        
        #region last message
        public Messages? LastMessage { get; set; }
        public DateTime? LastMessageCreatedAt { get; set; }
        #endregion

        public DateTime CreatedAt { get; set; }
        public long CurrentUserSerial { get; set; }
    }
}
