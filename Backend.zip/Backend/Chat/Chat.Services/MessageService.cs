﻿using System;
using Chat.Core;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using SixLabors.ImageSharp;
using SixLabors.ImageSharp.Formats.Png;
using SixLabors.ImageSharp.Processing;


namespace Chat.Services
{
    public class MessageService : IMessageService
    {
        private readonly IHttpContextAccessor _httpContextAccessor;

        private readonly ChatDbContext db;
        public string ApplicationId { get; set; }
        public string MyUserName
        {
            get
            {
                return _httpContextAccessor.HttpContext?.User.Identity.Name;
            }
        }
        private readonly string admin_username = "admin";



        public MessageService(ChatDbContext db, IConfiguration configuration, IHttpContextAccessor httpContextAccessor)
        {
            this.db = db;
            _httpContextAccessor = httpContextAccessor;
            ApplicationId = configuration["applicationId"];
        }

        public bool CloseChat(string chatKey)
        {
            var chat = db.Chats.FirstOrDefault(x => x.ChatKey == chatKey && x.ApplicationId == ApplicationId) ?? throw new ChatNotFoundError();
            chat.IsClosed = true;
            db.Chats.Update(chat);
            return db.SaveChanges() > 0;
        }

        public Core.Chat CreateChat(string chatKey, string createdBy, string subTitle, string imageUrl, bool isChatGroup, string title, string linkUrl = "", string referenceKey = "")
        {
            var dbChat = db.Chats.FirstOrDefault(x => x.ApplicationId == ApplicationId && x.ChatKey.ToLower() == chatKey.ToLower());
            if (dbChat != null) return dbChat; //throw new ChatAlreadyExistsError();


            var chat = new Core.Chat
            {
                Title = title,
                SubTitle = subTitle,
                ApplicationId = ApplicationId,
                ChatKey = chatKey,
                LinkUrl = linkUrl,
                ImageUrl = imageUrl,
                IsClosed = false,
                IsChatGroup = isChatGroup,
                ReferenceKey = referenceKey,
                CreatedBy = createdBy,
                CreatedAt = db.Now
            };

            db.Chats.Add(chat);
            if (db.SaveChanges() > 0) return chat;

            return null;
        }

        public List<ChatUser>? AddChatUsers(long chatSerial, List<ChatUser> chatUsers, string createdBy)
        {
            if (!chatUsers.Any()) throw new AtleastOneUserRequiredError();

            var chat = db.Chats.FirstOrDefault(x => x.ApplicationId == ApplicationId && x.Serial == chatSerial) ?? throw new ChatNotFoundError();

            var dbChatUsers = db.ChatUsers.Where(x => x.ChatSerial == chatSerial).ToList();

            foreach (var chatUser in chatUsers)
            {
                if (dbChatUsers.Any(x => x.UserSerial == chatUser.UserSerial)) continue;

                chatUser.ChatSerial = chatSerial;
                chatUser.CreatedAt = db.Now;
                chatUser.UnreadCount = 0;
                db.ChatUsers.Add(chatUser);
            };

            if (db.ChangeTracker.HasChanges())
                if (db.SaveChanges() > 0) return chatUsers;

            return dbChatUsers;
        }

        public bool AddSystemMessage(long chatSerial, string messageText, string createdBy, MessageTypes messageType)
        {
            var chat = db.Chats.FirstOrDefault(x => x.Serial == chatSerial) ?? throw new ChatNotFoundError();

            var senderQuery = from u in db.Users
                              join cu in db.ChatUsers on u.Serial equals cu.UserSerial
                              where u.UserName == createdBy && cu.ChatSerial == chat.Serial
                              select new { cu, u };

            var senderUser = senderQuery.FirstOrDefault() ?? throw new UserNotFoundError(); ;

            var message = new Messages
            {
                ChatSerial = chatSerial,
                SenderSerial = senderUser.cu.Serial,
                Message = messageText,
                IsSystemMessage = true,
                CreatedAt = db.Now,
                MessageTypeId = messageType.ToString()
            };

            db.Messages.Add(message);
            return db.SaveChanges() > 0;
        }

        public User AddChatUser(string chatKey, bool isAdmin, string userGroupAlias, string userGroupImageUrl, string createdBy, User user)
        {
            if (user is null) throw new UserNotFoundError();

            var dbUser = db.Users.FirstOrDefault(x => x.Serial == user.Serial && x.UserName == user.UserName) ?? throw new UserNotFoundError();

            var chat = db.Chats.FirstOrDefault(x => x.ChatKey == chatKey && x.ApplicationId == ApplicationId) ?? throw new ChatNotFoundError();

            var chatUser = db.ChatUsers.FirstOrDefault(x => x.ChatSerial == chat.Serial && x.UserSerial == user.Serial);
            if (chatUser is not null) return dbUser;//throw new UserAlreadyExistsInChat();

            var newChatUser = new ChatUser
            {
                IsMuted = false,
                IsLeft = false,
                IsAdmin = isAdmin,
                UserGroupId = "",
                UserGroupImageUrl = userGroupImageUrl,
                UserGroupAlias = userGroupAlias,
                ChatSerial = chat.Serial,
                UserSerial = user.Serial,
                CreatedBy = createdBy,
                CreatedAt = db.Now
            };

            db.ChatUsers.Add(newChatUser);
            if (db.SaveChanges() > 0) return dbUser;
            return null;
        }

        public Core.Chat GetChatBySerial(long chatSerial) => db.Chats.FirstOrDefault(x => x.Serial == chatSerial) ?? throw new ChatNotFoundError();
        public Core.Chat? GetChatByKey(string chatKey) => db.Chats.FirstOrDefault(x => x.ChatKey == chatKey);

        public List<ChatView> GetChats(string userName)
        {
            var chats = (from c in db.Chats
                         join cu in db.ChatUsers on c.Serial equals cu.ChatSerial
                         join u in db.Users on cu.UserSerial equals u.Serial
                         join m in db.Messages on cu.LastReadMessageSerial equals m.Serial into messages
                         from m in messages.DefaultIfEmpty()

                         where
                              !c.IsClosed &&
                              c.ApplicationId == ApplicationId &&
                              u.UserName == userName && !cu.IsLeft

                         orderby m.CreatedAt descending
                         select new ChatView
                         {
                             Serial = c.Serial,
                             SubTitle = c.SubTitle,
                             IsSavedMessageChat = c.ChatKey == $"saved-messages-{userName}",
                             LinkUrl = c.LinkUrl,
                             ImageUrl = c.ImageUrl,
                             IsClosed = c.IsClosed,
                             IsChatGroup = c.IsChatGroup,
                             LastMessage = m,
                             CurrentUserSerial = m != null ? m.SenderSerial : 0,
                             NewMessageCount = cu.UnreadCount,
                             IsArchived = cu.IsArchived,
                             LastMessageCreatedAt = m != null ? m.CreatedAt : new DateTime(),
                             CreatedAt = c.CreatedAt,
                         })
                        .ToList();

            var chatUsers = (from c in chats
                             join cu in db.ChatUsers on c.Serial equals cu.ChatSerial
                             join u in db.Users on cu.UserSerial equals u.Serial
                             where chats.Select(x => x.Serial).Contains(c.Serial)
                             select new
                             {
                                 ChatSerial = c.Serial,
                                 cu.UserSerial,
                                 cu.IsArchived,
                                 cu.UnreadCount,
                                 u.DisplayName,
                                 u.UserName
                             }).ToList();

            chats.ForEach((chat) =>
            {
                if ((chat.IsChatGroup.HasValue && chat.IsChatGroup.Value))
                {
                    var destinationUser = chatUsers.FirstOrDefault(x => x.ChatSerial == chat.Serial && x.UserName != userName);
                    if(destinationUser != null) chat.Title = destinationUser.DisplayName;
                }
                
                if (chat.IsSavedMessageChat)
                {
                    chat.Title = "saved-messages";
                }

                var myChatUser = chatUsers.FirstOrDefault(x => x.ChatSerial == chat.Serial && x.UserName == userName);
                chat.IsArchived = myChatUser.IsArchived;
                chat.NewMessageCount = myChatUser.UnreadCount;
            });

            return chats.OrderByDescending(x => x.LastMessageCreatedAt.Value).ToList();

        }

        public List<ChatView> GetAdminChats()
        {

            var all_chats = db.Chats.Where(x => x.ChatKey.StartsWith("net-")).ToList();
            if (all_chats.Count == 0) return new List<ChatView>();

            var all_chats_serial = all_chats.Select(ac => ac.Serial).ToList();

            var all_chat_users = db.ChatUsers.Where(x => all_chats_serial.Contains(x.ChatSerial)).ToList();
            var all_chat_users_serial = all_chat_users.Select(acu => acu.UserSerial).ToList();

            var all_users = db.Users.Where(x => all_chat_users_serial.Contains(x.Serial)).ToList();
            var admin_user = all_users.FirstOrDefault(x => x.UserName == admin_username) ?? throw new UserNotFoundError();


            var lastMessages = from c in all_chats
                               join m in db.Messages on c.LastMessageSerial equals m.Serial
                               select m;

            var chats = new List<ChatView>();

            foreach (var c in all_chats.ToList())
            {
                var lastMessage = lastMessages.Where(m => m.Serial == c.LastMessageSerial).FirstOrDefault();
                chats.Add(new ChatView
                {
                    // chat
                    Serial = c.Serial,
                    Title = c.Title,
                    SubTitle = c.SubTitle,
                    LinkUrl = c.LinkUrl,
                    ImageUrl = c.ImageUrl,
                    IsClosed = c.IsClosed,
                    IsChatGroup = c.IsChatGroup,
                    CreatedAt = c.CreatedAt,
                    LastMessageCreatedAt = lastMessage?.CreatedAt,
                    LastMessage = lastMessage,
                });
            }

            HandleChats(chats, all_chat_users, all_users, admin_user);

            return chats.OrderByDescending(x => x.LastMessageCreatedAt).ToList();
        }

        private void HandleChats(List<ChatView> chats, List<ChatUser> chat_users, List<User> users, User ownerUser)
        {
            foreach (var chat in chats)
            {
                var _chat_users = chat_users.Where(x => x.ChatSerial == chat.Serial).ToList();
                var _user_serials = _chat_users.Select(x => x.UserSerial).ToList();

                var _users = users.Where(x => _user_serials.Contains(x.Serial)).ToList();

                HandleChat(chat, _chat_users, _users, ownerUser);
            }
        }

        private void HandleChat(ChatView chat, List<ChatUser> chat_users, List<User> users, User ownerUser)
        {

            var ownerChatUser = chat_users.FirstOrDefault(x => x.UserSerial == ownerUser.Serial);
            if (ownerChatUser != null) chat.CurrentUserSerial = ownerChatUser.Serial;

            if (chat_users.Any() && chat_users.Count <= 2)
            {
                if (chat_users.Count == 1)
                {
                    var chat_user = chat_users.FirstOrDefault();
                    if (chat_user != null)
                    {
                        var user = users.FirstOrDefault(x => x.Serial == chat_user.UserSerial);
                        chat.NewMessageCount = chat_user.UnreadCount;

                        if (chat.IsChatGroup.HasValue && chat.IsChatGroup.Value && !string.IsNullOrEmpty(chat_user.UserGroupImageUrl))
                            chat.ImageUrl = chat_user.UserGroupImageUrl;
                        else chat.ImageUrl = user?.ImageUrl;

                        if (chat.IsChatGroup.HasValue && chat.IsChatGroup.Value && !string.IsNullOrEmpty(chat_user.UserGroupAlias))
                            chat.Title = chat_user.UserGroupAlias;
                        else if (!chat.IsChatGroup.HasValue || !chat.IsChatGroup.Value && string.IsNullOrEmpty(chat.Title))
                        {
                            chat.Title = user?.DisplayName;
                        }
                    }
                }
                if (chat_users.Count == 2)
                {
                    var user = users.FirstOrDefault(x => x.UserName != ownerUser.UserName);
                    var chatUser = chat_users.FirstOrDefault(x => x.UserSerial != ownerUser.Serial);
                    var admin_chat_user = chat_users.FirstOrDefault(x => x.UserSerial == ownerUser.Serial);
                    if (user != null && chatUser != null && admin_chat_user != null)
                    {
                        chat.NewMessageCount = admin_chat_user.UnreadCount;

                        if (chat.IsChatGroup.HasValue && chat.IsChatGroup.Value && !string.IsNullOrEmpty(chatUser.UserGroupImageUrl))
                            chat.ImageUrl = chatUser.UserGroupImageUrl;
                        else
                            chat.ImageUrl = user.ImageUrl;

                        if (chat.IsChatGroup.HasValue && chat.IsChatGroup.Value && !string.IsNullOrEmpty(chatUser.UserGroupAlias))
                            chat.Title = chatUser.UserGroupAlias;
                        else if (!chat.IsChatGroup.HasValue || !chat.IsChatGroup.Value && string.IsNullOrEmpty(chat.Title))
                        {
                            chat.Title = user.DisplayName;
                        }
                    }
                }
            }
        }

        public List<Messages> GetAdminChatMessages(long chatSerial)
        {
            var now = db.GetDate();

            var messages = (from c in db.Chats
                            join cm in db.Messages on c.Serial equals cm.ChatSerial
                            join umi in db.UserMessageInfos on cm.Serial equals umi.MessageSerial
                            where c.Serial == chatSerial && !c.IsClosed && !umi.IsDeleted
                            select cm).Distinct().ToList();



            var myChatUser = (from cu in db.ChatUsers
                              join u in db.Users on cu.UserSerial equals u.Serial
                              where u.UserName == admin_username && cu.ChatSerial == chatSerial
                              select cu).FirstOrDefault() ?? throw new UserNotFoundError();


            myChatUser.UnreadCount = 0;

            db.ChatUsers.Update(myChatUser);


            var otherMessages = messages.Where(x =>
                                                    x.SenderSerial != myChatUser.Serial &&
                                                    x.ChatSerial == chatSerial &&
                                                    (!x.IsSystemMessage.HasValue || (x.IsSystemMessage.HasValue && !x.IsSystemMessage.Value)) &&
                                                    (!x.IsRead.HasValue || (x.IsRead.HasValue && !x.IsRead.Value))
                                               ).ToList();

            if (otherMessages.Any())
            {
                otherMessages.ForEach(message => message.IsRead = true);
                db.Messages.UpdateRange(otherMessages);
                db.SaveChanges();

            }


            var messageInfos = db.UserMessageInfos.Where(x =>
                messages.Select(x => x.Serial).Contains(x.MessageSerial)
                && x.UserSerial == myChatUser.Serial
                && (x.StatusId == UserMessageStatuses.NEW || x.StatusId == UserMessageStatuses.DLV)
            ).ToList();

            if (messageInfos.Any())
            {
                messageInfos.ForEach(x =>
                {
                    x.ReadAt = now;
                    x.DeliveredAt = now;
                    x.StatusId = UserMessageStatuses.READ;
                });
                db.UserMessageInfos.UpdateRange(messageInfos);
                db.SaveChanges();
            }

            return messages;
        }

        public bool RemoveChatUser(string chatKey, string userName)
        {
            var chat = db.Chats.FirstOrDefault(x => x.ChatKey == chatKey) ?? throw new ChatNotFoundError();

            var user = db.Users.FirstOrDefault(x => x.UserName == userName) ?? throw new UserNotFoundError();

            var chatUser = db.ChatUsers.FirstOrDefault(x => x.ChatSerial == chat.Serial && x.UserSerial == user.Serial) ?? throw new ChatUserNotFoundError();
            chatUser.IsLeft = true;

            var umiQuery = from m in db.Messages
                           join c in db.Chats on m.ChatSerial equals c.Serial
                           join cu in db.ChatUsers on c.Serial equals cu.ChatSerial
                           join umi in db.UserMessageInfos on cu.UserSerial equals umi.UserSerial
                           where cu.Serial == chatUser.Serial && c.ChatKey == chatKey
                           select umi;

            umiQuery.ToList().ForEach(x => x.IsDeleted = true);
            db.Update(umiQuery);

            db.Update(chatUser);
            return db.SaveChanges() > 0;
        }

        public Messages SendImageMessage(long chatSerial, long senderSerial, string message, IFormFile file)
        {
            using var image = Image.Load(file.OpenReadStream());
            var aspectRatio = (double)image.Width / image.Height;

            var newWidth = 20; // Maximum width of 5 pixels
            var newHeight = (int)(newWidth / aspectRatio);

            image.Mutate(x => x.Resize(newWidth, newHeight));

            using var thumbStream = new MemoryStream();
            var encoder = new PngEncoder
            {
                ColorType = PngColorType.Rgb,
                BitDepth = PngBitDepth.Bit8,
                CompressionLevel = PngCompressionLevel.BestCompression,
                SkipMetadata = true,
            };

            image.SaveAsPng(thumbStream, encoder);
            var base64String = $"data:image/png;base64,{System.Convert.ToBase64String(thumbStream.ToArray())}";

            return SendMessage(new NewMessage
            {
                ChatSerial = chatSerial,
                SenderSerial = senderSerial,
                Message = message ?? "",
                Thumbnail = base64String,
                MessageTypeId = MessageTypes.IMG.ToString(),
                AspectRatio = aspectRatio
            });
        }

        public Messages SendMessage(long chatSerial, long senderSerial, string message, IFormFile file)
        {
            var fileExtention = Path.GetExtension(file.FileName);
            MessageTypes messageType;

            switch (fileExtention)
            {
                case ".png":
                case ".jpg":
                case ".jpeg":
                    {
                        messageType = MessageTypes.IMG;
                        break;
                    }
                case ".json":
                    {
                        messageType = MessageTypes.JSON;
                        break;

                    }

                case ".txt":
                    {
                        messageType = MessageTypes.TXT;
                        break;
                    }
                case ".pdf":
                    {
                        messageType = MessageTypes.PDF;
                        break;
                    }
                case ".zip":
                    {
                        messageType = MessageTypes.ZIP;
                        break;
                    }
                case ".docx":
                case ".doc":
                    {
                        messageType = MessageTypes.DOCX;
                        break;
                    }
                case ".xlsx":
                case ".xls":
                    {
                        messageType = MessageTypes.XLSX;
                        break;
                    }
                default:
                    throw new Exception("file-type-not-found");
            }
            if (messageType == MessageTypes.IMG) return SendImageMessage(chatSerial, senderSerial, message, file);

            return SendMessage(new NewMessage
            {
                ChatSerial = chatSerial,
                SenderSerial = senderSerial,
                Message = message ?? "",
                MessageTypeId = messageType.ToString(),
                Thumbnail = ""
            });
        }

        public Messages SendMessage(NewMessage newMessage)
        {
            var message = newMessage.MapTo<Messages>();

            var chat = db.Chats.FirstOrDefault(x => x.Serial == message.ChatSerial) ?? throw new ChatNotFoundError();

            var now = db.GetDate();

            message.CreatedAt = now;

            var chatUsers = db.ChatUsers.Where(x => x.ChatSerial == message.ChatSerial).ToList();

            var senderChatUser = chatUsers.FirstOrDefault(x => x.Serial == message.SenderSerial) ?? throw new ChatUserNotFoundError();

            var senderUser = db.Users.FirstOrDefault(x => x.Serial == senderChatUser.UserSerial) ?? throw new UserNotFoundError();

            var isOwner = chat.CreatedBy == senderUser.UserName;

            var otherChatUsers = chatUsers.Where(x => x.Serial != message.SenderSerial).ToList();

            otherChatUsers.ForEach((chatUser) => chatUser.UnreadCount++);

            //using var transaction = db.Database.BeginTransaction();
            try
            {
                db.Messages.Add(message);
                db.ChatUsers.UpdateRange(otherChatUsers);
                db.SaveChanges();

                chatUsers.ForEach((chatUser) =>
                {
                    var userMessageInfo = new UserMessageInfo
                    {
                        IsDeleted = false,
                        IsOwner = chatUser.Serial == message.SenderSerial,
                        MessageSerial = message.Serial,
                        StatusId = chatUser.Serial == message.SenderSerial ? UserMessageStatuses.READ : UserMessageStatuses.NEW,
                        DeliveredAt = chatUser.Serial == message.SenderSerial ? now : null,
                        ReadAt = chatUser.Serial == message.SenderSerial ? now : null,
                        UserSerial = chatUser.Serial,
                    };
                    db.UserMessageInfos.Add(userMessageInfo);
                });
                db.SaveChanges();

                chat.LastMessageSerial = message.Serial;
                db.Chats.Update(chat);
                db.SaveChanges();

                if (!chat.IsChatGroup.HasValue || (chat.IsChatGroup.HasValue && !chat.IsChatGroup.Value))
                {
                    var myOlderMessages = db.Messages.Where(msg =>
                                                                    msg.SenderSerial != message.SenderSerial &&
                                                                    msg.ChatSerial == chat.Serial &&
                                                                    (!msg.IsSystemMessage.HasValue || (msg.IsSystemMessage.HasValue && !msg.IsSystemMessage.Value)) &&
                                                                    (!msg.IsRead.HasValue || (msg.IsRead.HasValue && !msg.IsRead.Value))
                                                            ).ToList();
                    if (myOlderMessages.Count != 0)
                    {
                        myOlderMessages.ForEach(msg => { msg.IsRead = true; });
                        db.Messages.UpdateRange(myOlderMessages);
                        db.SaveChanges();
                    }
                }

                //transaction.Commit();
                return message;
            }
            catch (Exception e)
            {
                //transaction.Rollback();
                throw;
            }
        }

        public User SafeGetUser(User user) => GetUserByUsername(user.UserName) ?? AddUser(user);

        public User? AddUser(User user)
        {
            var dbUser = db.Users.FirstOrDefault(x => x.UserName == user.UserName);
            if (dbUser is not null) return dbUser;// throw new UserAlreadyExistsError();

            var newUser = new User
            {
                UserName = user.UserName,
                DisplayName = user.DisplayName,
                ImageUrl = user.ImageUrl,
                ApplicationId = ApplicationId
            };

            db.Users.Add(newUser);

            return db.SaveChanges() > 0 ? newUser : null;
        }

        public User? GetAdminUser() => GetUserByUsername(admin_username);

        public User? GetUserByUsername(string username) => db.Users.FirstOrDefault(x => x.UserName == username);

        public List<ChatUserView> GetUsersChats(string? referenceKey, long? chatSerial = null, string? userName = null, bool? isLeft = null, bool? isArchived = null)
        {
            var q = from c in db.Chats
                    join cu in db.ChatUsers on c.Serial equals cu.ChatSerial
                    join u in db.Users on cu.UserSerial equals u.Serial
                    select new { c.Serial, c.ReferenceKey, cu.IsArchived, cu.UnreadCount, u.UserName, u.DisplayName, u.ImageUrl, ChatUserSerial = cu.Serial, UserSerial = u.Serial, cu.IsLeft };

            if (!string.IsNullOrEmpty(userName)) q = q.Where(x => x.UserName == userName);
            if (!string.IsNullOrEmpty(referenceKey)) q = q.Where(x => x.ReferenceKey == referenceKey);

            if (chatSerial.HasValue) q = q.Where(x => x.Serial == chatSerial.Value);
            if (isLeft.HasValue) q = q.Where(x => x.IsLeft == isLeft.Value);
            if (isArchived.HasValue) q = q.Where(x => x.IsArchived == isArchived.Value);


            return (from x in q
                    select new ChatUserView
                    {
                        ChatSerial = x.Serial,
                        ChatUserSerial = x.ChatUserSerial,
                        IsArchived = x.IsArchived,
                        UnreadCount = x.UnreadCount,
                        UserName = x.UserName,
                        UserSerial = x.UserSerial,
                        DisplayName = x.DisplayName,
                        ImageUrl = x.ImageUrl
                    }).ToList();
        }

        public ChatUser? GetChatUser(long chatSerial, string userName)
        {
            var q = from cu in db.ChatUsers
                    join u in db.Users on cu.UserSerial equals u.Serial
                    where u.UserName == userName && cu.ChatSerial == chatSerial
                    select cu;
            return q.ToList().FirstOrDefault();
        }

        public void LeftFromChat(long chatSerial, string username)
        {
            var chat = db.Chats.FirstOrDefault(x => x.Serial == chatSerial) ?? throw new ChatNotFoundError();

            var user = GetUserByUsername(username) ?? throw new UserNotFoundError();

            var chatUser = db.ChatUsers.FirstOrDefault(x => x.ChatSerial == chat.Serial && x.UserSerial == user.Serial) ?? throw new ChatUserNotFoundError();

            chatUser.IsLeft = true;
            db.Update(chatUser);
            db.SaveChanges();
        }

        public void RemoveChatMessage(long chatSerial, long messageSerial, string username)
        {
            var userMessageInfos = (from c in db.Chats
                                    join cu in db.ChatUsers on c.Serial equals cu.ChatSerial
                                    join u in db.Users on cu.UserSerial equals u.Serial
                                    join m in db.Messages on c.Serial equals m.ChatSerial
                                    join umi in db.UserMessageInfos on m.Serial equals umi.MessageSerial
                                    where c.Serial == chatSerial && m.Serial == messageSerial //&& u.UserName == username
                                    select umi).Distinct().ToList() ?? throw new MessageNotFoundError();


            userMessageInfos.ForEach(userMessageInfo =>
            {
                userMessageInfo.IsDeleted = true;
                userMessageInfo.DeletedAt = db.GetDate();
            });

            db.UpdateRange(userMessageInfos);

            var chat = db.Chats.FirstOrDefault(x => x.Serial == chatSerial) ?? throw new ChatNotFoundError();

            if (chat.LastMessageSerial == messageSerial)
            {
                chat.LastMessageSerial = null;
                db.Update(chat);
            }

            db.SaveChanges();
        }

        public List<ChatView> GetChatsByReferenceKey(string referenceKey)
        {
            var chatUsers = GetUsersChats(referenceKey);
            if (!chatUsers.Any(x => x.UserName == MyUserName)) throw new ChatNotFoundError();

            var chats = db.Chats.Where(x => x.ReferenceKey == referenceKey).ToList();

            return chats.Select(c =>
            {
                var cu = chatUsers.FirstOrDefault(x => x.ChatSerial == c.Serial && x.UserName == MyUserName);

                return new ChatView
                {
                    Serial = c.Serial,
                    Title = c.Title,
                    SubTitle = c.SubTitle,
                    IsSavedMessageChat = false,
                    LinkUrl = c.LinkUrl,
                    ImageUrl = c.ImageUrl,
                    IsClosed = c.IsClosed,
                    IsChatGroup = c.IsChatGroup,
                    CurrentUserSerial = cu.ChatUserSerial,
                    CreatedAt = c.CreatedAt,
                    IsArchived = cu.IsArchived,
                    NewMessageCount = cu.UnreadCount,
                };
            }).ToList();
        }


        public List<Messages> GetChatMessages(long chatSerial) => GetChatMessages(chatSerial, MyUserName);

        public User? InviteChatMember(string userName, long chatSerial, bool isAdmin, string userGroupAlias, string userGroupImageUrl, string createdBy)
        {
            var user = GetUserByUsername(userName);
            var chat = GetChatBySerial(chatSerial);
            var chatUser = GetChatUser(chatSerial, user.UserName);

            if (chatUser != null) return null;

            return AddChatUser(chat.ChatKey, isAdmin, userGroupAlias, userGroupImageUrl, createdBy, user);
        }

        public List<Messages> GetChatMessages(long chatSerial, string userName)
        {
            var now = db.GetDate();

            var messages = (from c in db.Chats
                            join cm in db.Messages on c.Serial equals cm.ChatSerial
                            join umi in db.UserMessageInfos on cm.Serial equals umi.MessageSerial into messageInfo
                            from umi in messageInfo.DefaultIfEmpty()


                            where c.Serial == chatSerial &&
                                  !c.IsClosed &&
                                  (
                                    (umi == null && cm.IsSystemMessage.HasValue && cm.IsSystemMessage.Value) ||
                                    (umi != null && !umi.IsDeleted))

                            select cm).Distinct().ToList();



            var myChatUser = (from cu in db.ChatUsers
                              join u in db.Users on cu.UserSerial equals u.Serial
                              where u.UserName == userName && cu.ChatSerial == chatSerial
                              select cu).FirstOrDefault() ?? throw new UserNotFoundError();


            myChatUser.UnreadCount = 0;

            db.ChatUsers.Update(myChatUser);


            var otherMessages = messages.Where(x =>
                                                    x.SenderSerial != myChatUser.Serial &&
                                                    x.ChatSerial == chatSerial &&
                                                    (!x.IsSystemMessage.HasValue || (x.IsSystemMessage.HasValue && !x.IsSystemMessage.Value)) &&
                                                    (!x.IsRead.HasValue || (x.IsRead.HasValue && !x.IsRead.Value))
                                               ).ToList();

            if (otherMessages.Any())
            {
                otherMessages.ForEach(message => message.IsRead = true);
                db.Messages.UpdateRange(otherMessages);
                db.SaveChanges();

            }


            var messageInfos = db.UserMessageInfos.Where(x =>
                messages.Select(x => x.Serial).Contains(x.MessageSerial)
                && x.UserSerial == myChatUser.Serial
                && (x.StatusId == UserMessageStatuses.NEW || x.StatusId == UserMessageStatuses.DLV)
            ).ToList();

            if (messageInfos.Any())
            {
                messageInfos.ForEach(x =>
                {
                    x.ReadAt = now;
                    x.DeliveredAt = now;
                    x.StatusId = UserMessageStatuses.READ;
                });
                db.UserMessageInfos.UpdateRange(messageInfos);
                db.SaveChanges();
            }

            return messages;
        }

        public List<User> GetChatUsersList(string chatKey)
        {
            var query = from c in db.Chats
                        join cu in db.ChatUsers on c.Serial equals cu.ChatSerial
                        join u in db.Users on cu.UserSerial equals u.Serial
                        where c.ChatKey == chatKey
                        select u;

            return query.ToList();
        }

        public List<User> GetChatUsersList(long chatSerial)
        {
            var query = from c in db.Chats
                        join cu in db.ChatUsers on c.Serial equals cu.ChatSerial
                        join u in db.Users on cu.UserSerial equals u.Serial
                        where c.Serial == chatSerial
                        select u;

            return query.ToList();
        }

        public bool ExistsReferenceKey(string refKey) => db.Chats.Any(x => x.ReferenceKey == refKey);

    }
}
