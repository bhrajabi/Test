﻿using Chat.Core;
using Common.Data;
using Common.Security;
using Microsoft.EntityFrameworkCore;

namespace Chat.Services
{
    public class ChatDbContext : BaseDbContext
    {

        public ChatDbContext(DbContextOptions<ChatDbContext> options, IHttpContextService currentUserNameService) : base(options, currentUserNameService)
        {
            //var qs = currentUserNameService.GetQuery();
            //var i = qs.IndexOf("&i=");
            //if (i > 0) qs = qs.Substring(i + 3);
            //QId = qs;
            //CommonServices.Core.Tracker.List.Add($"Tamin: {qs}: {Ticks}"); 
        }

        public DbSet<Application> Applications { get; set; }
        public DbSet<Core.Chat> Chats { get; set; }
        public DbSet<ChatUser> ChatUsers { get; set; }
        public DbSet<Messages> Messages { get; set; }
        public DbSet<MessageType> MessageTypes { get; set; }
        public DbSet<User> Users { get; set; }
        public DbSet<UserMessageInfo> UserMessageInfos { get; set; }
        public DbSet<UserMessageStatus> UserMessageStatuses { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            modelBuilder.Entity<UserMessageInfo>().HasKey(x => new { x.UserSerial, x.MessageSerial });
        }

        public DateTime Now { get => GetDate(); }
    }
}
