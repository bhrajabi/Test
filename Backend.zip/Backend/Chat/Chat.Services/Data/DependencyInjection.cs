﻿using Chat.Core;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;

namespace Chat.Services
{
    public static class DependencyInjection
    {
        public static void AddChat(this IServiceCollection services, string connectionString)
        {
            services.AddDbContext<ChatDbContext>(options => options
                        .UseSqlServer(connectionString)
                        .UseQueryTrackingBehavior(QueryTrackingBehavior.NoTracking)
                        );

            services.AddScoped<IMessageService, MessageService>();
        }
    }
}