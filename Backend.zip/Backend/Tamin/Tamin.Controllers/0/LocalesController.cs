﻿/*
using Tamin.Core;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System.Collections.Generic;
using System.Text;

namespace Tamin.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class LocalesController : ControllerBase
    {
        private readonly ILocaleService service;
        private readonly IConfiguration _Configuration;

        public LocalesController(ILocaleService localeService, IConfiguration configuration)
        {
            this.service = localeService;
            _Configuration = configuration;
        }


        [AllowAnonymous]
        [EnableCors("react")]
        [HttpGet("get-{language}")]
        public Dictionary<string, string> Get(string language)
        {
            var type = 'F';
            var list = service.GetTexts(language, type, true);
            return list;
        }


        [AllowAnonymous]
        [EnableCors("react")]
        [HttpPost("add-{language}")]
        public void Add(string language, [FromBody] Dictionary<string, string> words)
        {
            if (words == null) return;
            var type = 'F';
            foreach (var w in words.Keys)
            {
                service.AddText(language, w, type, null);
            }
        }

    }
}
*/