﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using Attcahment.Core;
using Authentication.Core;
using Common;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Tamin.Core;

namespace Tamin.Controllers
{
    //[Controller]
    //[ApiController]
    [Authorize(AuthenticationSchemes = "Bearer")]
    [EnableCors("react")]
    [Route("[controller]")]
    public class AttachmentController : ControllerBase
    {
        const string no_pic = "<svg id=\"Layer_1\" data-name=\"Layer 1\" xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 122.88 122.88\"><defs><style>.cls-1{fill:#b3b3b3;fill-rule:evenodd;}.cls-2{fill:#fff;}</style></defs><title>no-profile-picture</title><polygon class=\"cls-1\" points=\"0 0 122.88 0 122.88 122.88 0 122.88 0 0 0 0\"/><path class=\"cls-2\" d=\"M48.64,77.72c.65-1.48,1.24-3.1,1.61-4.19a52.43,52.43,0,0,1-4.22-6L41.76,60.7a12.55,12.55,0,0,1-2.43-6.21,4.94,4.94,0,0,1,.43-2.23,4.1,4.1,0,0,1,1.47-1.71,4.73,4.73,0,0,1,1-.52,107.7,107.7,0,0,1-.2-12.23A16.87,16.87,0,0,1,42.58,35a16.39,16.39,0,0,1,7.22-9.2,22.79,22.79,0,0,1,6.05-2.69c1.37-.39-1.15-4.72.25-4.87,6.79-.7,17.77,5.5,22.51,10.62A16.63,16.63,0,0,1,82.8,39.37l-.27,11.1h0a3.06,3.06,0,0,1,2.25,2.32c.35,1.36,0,3.25-1.18,5.84h0a.37.37,0,0,1-.07.14l-4.87,8a41.6,41.6,0,0,1-6,8.24c.23.32.45.63.66.94,8.25,12.11,19.38,5.88,32.32,15.36l-.38.51v12.82H17.22V91.47h.24a1.14,1.14,0,0,1,.56-.61C26.4,86,45.72,84.35,48.64,77.72Z\"/></svg>";
        public IAttachmentService AttachmentService { get; }

        private readonly IUserService userService;

        public AttachmentController(IAttachmentService attachmentService, IUserService userService)
        {
            AttachmentService = attachmentService;
            this.userService = userService;
        }


        [AllowAnonymous]
        [HttpGet]
        [Route("/attachment/download")]
        public ActionResult Download(long id, [MaxLength(16)] string mobile)
        {
            Request.Cookies.TryGetValue(Settings.SessionIdCookieName, out var sessionId);
            var a = AttachmentService.GetAttachmentByRequestId(id, string.IsNullOrEmpty(mobile) ? sessionId : mobile);
            if (a == null)
            {
                return StatusCode(404);
            }
            var d = AttachmentService.GetAttachmentDataBySerial(a.DataSerial);
            var encodedFileName = Uri.EscapeDataString(a.FileName);
            Response.Headers.ContentDisposition = $"inline; filename*=UTF8''{encodedFileName}";
            return base.File(d.Data, a.MimeType);
        }


        [AllowAnonymous]
        [HttpGet]
        [Route("/attachment/download-image")]
        public ActionResult Download(long id, [MaxLength(16)] string mobile, int z)
        {
            Request.Cookies.TryGetValue(Settings.SessionIdCookieName, out var sessionId);
            var a = AttachmentService.GetAttachmentByRequestId(id, string.IsNullOrEmpty(mobile) ? sessionId : mobile);
            var d = AttachmentService.GetAttachmentDataBySerial(a?.DataSerial);
            if (d == null) return NotFound();

            if (z <= 0) return base.File(d.Data, d.MimeType);
            if (z > 200) z = 200;

            using (var st = new MemoryStream(d.Data))
            {
                var img = Image.FromStream(st);
                var bmp = new Bitmap(img);
                bmp = ImageFilter.Resize(bmp, z, z, true);

                var out_st = new MemoryStream();
                bmp.Save(out_st, ImageFormat.Jpeg);
                return File(out_st.ToArray(), "image/jpeg");
            }
        }



        [HttpPost]
        [Route("/attachment/download-request")]
        public Response CreateDownloadRequest(Int64 id)
        {
            var a = AttachmentService.GetAttachmentById(id);
            if (a == null || a.CreatedBy != User.Identity.Name) return Responses.Error403();
            var requestId = AttachmentService.CreateDownloadRequest(a);
            return new Response(requestId);
        }

        [HttpGet]
        [Route("/attachment/user-profile-image")]
        public ActionResult UserProfileImage()
        {
            var userName = User.Identity.IsAuthenticated ? User.Identity.Name : "";

            var user = userService.GetUserByUserName(userName);
            if (user == null) return NotFound();

            var d = AttachmentService.GetAttachmentDataBySerial((long?)user.ImageAttachmentId);

            if (d == null)
            {
                var content = no_pic;
                return Content(content, "image/svg+xml");
            }

            using (var st = new MemoryStream(d.Data))
            {
                var img = Image.FromStream(st);
                img = ImageFilter.ResizeImageCenter(img, 150, 150);

                var out_st = new MemoryStream();
                img.Save(out_st, ImageFormat.Jpeg);
                return File(out_st.ToArray(), "image/jpeg");
            }
        }




        [HttpPost]
        [Route("/attachment/upload-user-profile-image")]
        public Response UploadUserProfileImage(Int64? draftId, [FromForm] IFormFile file)
        {
            if (file == null || file.Length == 0) return new Response("Invalid attachment!");
            var userName = User.Identity.Name;

            var a = AttachmentService.Insert(draftId, "user-profile", userName, userName, "profile-image", file, file.FileName);

            var user = userService.GetUserByUserName(userName);
            user.ImageAttachmentId = a.DataSerial;

            userService.UpdateUser(user);

            return new Response();
        }

        //[HttpGet]
        //[Route("/attachment/auction-pack-image")]
        //public ActionResult AuctionPackImage(long auctionId,int rowId)
        //{
        //    var userName = User.Identity.IsAuthenticated ? User.Identity.Name : "";

        //    var list = AttachmentService
        //        .GetAttachmentsByKey(null, "user-profile", userName)
        //        .Where(x => x.TypeId == "profile-image")
        //        .ToList();
        //    if (list.Count < 1) return File(Encoding.UTF8.GetBytes(no_pic), "image/svg+xml");
        //    var a = list[list.Count - 1];
        //    var d = AttachmentService.GetAttachmentDataBySerial(a.DataSerial);
        //    return base.File(d.Data, d.MimeType);
        //}

    }
}
