﻿using Common;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Tamin.Controllers.DTO;
using Tamin.Core;

namespace Tamin.Controllers
{
    [ApiController]
    [EnableCors("react")]
    [Route("[controller]/[action]")]
    [Authorize(AuthenticationSchemes = "Bearer")]
    public class AnnouncementController : Controller
    {
        private readonly IAnnouncementService announcementService;
        private readonly IAccessService accessService;



        public AnnouncementController(IAccessService accessService, IAnnouncementService announcementService)
        {
            this.accessService = accessService;
            this.announcementService = announcementService;
        }


        [HttpPost]
        [Route("~/announcement/search-announcements")]
        public Response SearchAnnouncements([FromBody] AnnouncementsFilterDTO filter)
        {
            if (filter == null) return Responses.BadRequest();
            if (!accessService.CanViewAnnouncements()) return Responses.Error403();

            var list = announcementService.GetAnnouncements(filter.Serial, filter.CompanyId, filter.Title, filter.Description, filter.ImageAttachmentId, filter.AttachmentId, filter.StartDate, filter.EndDate, filter.SellerAccess, filter.PublicAccess, filter.CreatedBy, filter.CreatedAt);

            var result = new
            {
                List = list.MapTo<AnnouncementDTO>(),
            };
            return new Response(result);
        }


        [HttpPost]
        [Route("~/announcement/save-announcement")]
        public Response SaveAnnouncement([FromBody] AnnouncementDTO model)
        {
            if (model == null) return Responses.BadRequest();
            if (!accessService.CanMaintainAnnouncements()) return Responses.Error403();

            //var announcement = announcementService.SaveAnnouncement(model.Serial, model.CompanyId, model.Title, model.Description, model.ImageAttachmentId, model.AttachmentId, model.StartDate, model.EndDate, model.SellerAccess, model.PublicAccess, model.CreatedBy, model.CreatedAt));
            var announcement = model.MapTo<Announcement>();
            announcement = announcementService.SaveAnnouncement(announcement);

            var result = new
            {
                Announcement = announcement.MapTo<AnnouncementDTO>(),
            };
            return new Response(result);
        }


        [HttpPost]
        [Route("~/announcement/delete-announcement")]
        public Response DeleteAnnouncement(long serial)
        {
            if (!accessService.CanMaintainAnnouncements()) return Responses.Error403();

            announcementService.DeleteAnnouncement(serial);

            var result = new { };
            return new Response(result);
        }
    }
}