﻿using Common;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Tamin.Controllers
{
    public class UpdateDiscoveryDocumentDTO
    {
        [MaxLength(500)]
        [DefaultValue(SpecialChars.Str1000)]
        public string Title { get; set; }
        [MaxLength(1000)]
        [DefaultValue(SpecialChars.Str1000)]
        public string Description { get; set; }
        [MaxLength(10)]
        public string PlantId { get; set; }
    }
}
