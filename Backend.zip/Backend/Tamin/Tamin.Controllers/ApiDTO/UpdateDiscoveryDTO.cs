﻿using System.ComponentModel.DataAnnotations;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using Common;

namespace Tamin.Controllers
{
    public class UpdateDiscoveryDTO
    {
        [MaxLength(20)]
        public string Number { get; set; }
        public long DraftId { get; set; }
        [MaxLength(10)]
        public string PlantId { get; set; }
        public long RequestSerial { get; set; }
        public long Serial { get; set; }
        [MaxLength(500)]
        [DefaultValue(SpecialChars.Str1000)]
        public string Title { get; set; }
        [MaxLength(1000)]
        [DefaultValue(SpecialChars.Str1000)]
        public string Description { get; set; }
        [MaxLength(10)]
        public string StatusId { get; set; }
        public UpdateDiscoveryRuleDTO DiscoveryRule { get; set; }
        public UpdateDiscoveryDocumentDTO Discovery { get; set; }
    }
}
