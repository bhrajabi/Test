﻿using Common;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Tamin.Controllers
{
    public class SearchSuppliersDTO
    {
        public bool IsForSelection { get; set; }

        public int? CompanyId { get; set; }

        [MaxLength(400)]
        public string SupplierName { get; set; }

        public long? WorkingGroupSerial { get; set; }

        [MaxLength(30)]
        public string NationalCode { get; set; }

        [MaxLength(20)]
        public string SupplierNationalId { get; set; }
        
        [MaxLength(20)]
        public string SupplierNationalCode { get; set; }

        [MaxLength(50)]
        public string ErpNumber { get; set; }

        [MaxLength(10)]
        public string VendorCodeValue { get; set; }
        
        [MaxLength(20)]
        public string ParticipationRateTypeId { get; set; }

        [MaxLength(20)]
        public string CountryId { get; set; }
        
        [MaxLength(100)]
        public string City { get; set; }

        [MaxLength(100)]
        [DefaultValue(SpecialChars.Str100)]
        public string ContactFirstName { get; set; }

        [MaxLength(100)]
        [DefaultValue(SpecialChars.Str100)]
        public string ContactLastName { get; set; }

        [MaxLength(24)]
        public string PhoneNumber { get; set; }

        [MaxLength(10)]
        public string ApprovementStatusId { get; set; }

        [MaxLength(10)]
        public string QualificationStatusId { get; set; }

        [MaxLength(10)]
        public string Grade { get; set; }

        [MaxLength(1500)]
        public List<string> MaterialCodes { get; set; }

        [MaxLength(1500)]
        public List<string> CompanyCommodities { get; set; }

        [MaxLength(1500)]
        public List<string> CategoryCommodities { get; set; }
    }
}
