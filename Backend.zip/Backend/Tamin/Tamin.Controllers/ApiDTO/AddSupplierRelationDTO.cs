﻿using System.ComponentModel.DataAnnotations;

namespace Tamin.Controllers
{
    public class AddSupplierRelationDTO
    {
        public int BuyerId { get; set; }
        public int SellerId { get; set; }
        [MaxLength(50)]
        public string MainContactUser { get; set; }

    }
}
