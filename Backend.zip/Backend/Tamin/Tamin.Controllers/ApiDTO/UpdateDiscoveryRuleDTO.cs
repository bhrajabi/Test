﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Tamin.Controllers
{
    public class UpdateDiscoveryRuleDTO
    {
        public bool PublicAccess { get; set; }

        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        //public DateTime? DueDate { get; set; }

        [MaxLength(50)]
        public string ReferenceNumber { get; set; }
        
        [MaxLength(20)]
        public string PRNumber { get; set; }
        public DateTime? PRDate { get; set; }
    }
}
