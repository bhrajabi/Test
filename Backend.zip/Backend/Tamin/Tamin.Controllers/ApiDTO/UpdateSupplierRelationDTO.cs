﻿using System.ComponentModel.DataAnnotations;
using System;
using System.ComponentModel;
using Common;

namespace Tamin.Controllers
{
    public class UpdateSupplierRelationDTO
    {
        public int BuyerId { get; set; }
        public int SellerId { get; set; }
        public DateTime? ValidFrom { get; set; }
        public DateTime? ValidTo { get; set; }

        [MaxLength(50)]
        public string MainContactUser { get; set; }

        [MaxLength(50)]
        public string ERPNumber { get; set; }

        [MaxLength(50000)]
        [DefaultValue(SpecialChars.Str1000)]
        public string Description { get; set; }

    }
}
