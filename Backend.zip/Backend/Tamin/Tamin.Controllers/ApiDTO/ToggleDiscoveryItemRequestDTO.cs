﻿using Common;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Tamin.Controllers
{
    public class ToggleDiscoveryItemRequestDTO
    {
        public long ItemSerial { get; set; }
        [MaxLength(18)]
        public string MaterialNo { get; set; }
        [AllowSpecialChars(SpecialChars.Str100)]
        [MaxLength(150)]
        [DefaultValue(SpecialChars.Str100)]
        public string MaterialText { get; set; }
    }
}
