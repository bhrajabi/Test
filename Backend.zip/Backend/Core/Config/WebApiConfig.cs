﻿namespace Main.Core
{
    public class WebApiConfig
    {
        public const string SectionName = "WebApi";

        public string ServiceUserName { get; set; }
        public int ApiCallInterval { get; set; }
        public int Expiry { get; set; }
    }
}