using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Main.Core
{
    [Table("SysLogs", Schema = "ASL")]
    public class SysLog
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Serial { get; set; }

        public string Type { get; set; }
        public string Message { get; set; }
        public string DisplayMessage { get; set; }
        public string Details { get; set; }
        public string Url { get; set; }
        public string QueryString { get; set; }
        public string Properties { get; set; }
        public long? SessionId { get; set; }
        public string Token { get; set; }
        public string UserName { get; set; }
        public DateTime CreatedAt { get; set; }

    }
}
