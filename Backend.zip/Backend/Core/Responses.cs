﻿using Common;

namespace Main.Core
{
    public static class Responses
    {
        public static Response Error403() => new(Messages.Error403);
        public static Response BadRequest() => new(Messages.BadRequest);
        public static Response InvalidCaptcha() => new(Messages.InvalidCaptcha);
        public static Response InvalidUserNameOrPassword() => new(Messages.InvalidUserNameOrPassword);
        public static Response InvalidUserOrVerificationCode() => new(Messages.InvalidUserOrVerificationCode);
        public static Response InvalidOldPassword() => new(Messages.InvalidOldPassword);
        public static Response AddressNotFound() => new(Messages.AddressNotFound);
        public static Response RecordNotFound() => new(Messages.RecordNotFound);
        public static Response AttachmentNotFound() => new(Messages.AttachmentNotFound);

    }
}
