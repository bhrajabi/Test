﻿using Main.Core;

namespace Main.Host
{
    public class LogProfilerMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly IConfiguration _Configuration;


        public LogProfilerMiddleware(RequestDelegate next, IConfiguration configuration)
        {
            _next = next;
            _Configuration = configuration;
        }

        public async Task InvokeAsync(HttpContext httpContext, ILogService logger)
        {
            WriteLog(logger);
            await _next(httpContext);
        }

        private void WriteLog(ILogService logger)
        {
            var LogProfiler = _Configuration["LogProfiler"];
            if (LogProfiler == "True")
            {
                logger.WriteVisit("");
            }
        }

    }
}
