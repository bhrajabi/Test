﻿namespace Main.Host
{
    public class DelayMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly IConfiguration _Configuration;


        public DelayMiddleware(RequestDelegate next, IConfiguration configuration)
        {
            _next = next;
            _Configuration = configuration;
        }

        public async Task Invoke(HttpContext httpContext)
        {
            var is_userInfo = httpContext.Request.Path.ToString().Contains("user-info");
            if (!is_userInfo)
            {
                var d = _Configuration["ApiDelay"].ToInt(0);
                if (d > 0) Thread.Sleep(d);
            }
            await _next(httpContext);
        }

    }
}
