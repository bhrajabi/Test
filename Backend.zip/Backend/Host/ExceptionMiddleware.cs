﻿using Common;
using Main.Core;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using System.Net;

namespace Main.Host
{
    public class ExceptionMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly ILogService _Logger;


        public ExceptionMiddleware(RequestDelegate next)
        {
            _next = next;
        }

        public async Task Invoke(HttpContext httpContext, ILogService logger)
        {
            try
            {
                await _next(httpContext);
            }
            catch (Exception ex)
            {
                HandleException(httpContext, ex, logger);
            }
        }

        private void HandleException(HttpContext context, Exception exception, ILogService logger)
        {
            var msg = ExceptionTranslator.Translate(exception);
            var ex_str = exception.ToString();
            if (ex_str.Contains("The DELETE statement conflicted with the REFERENCE constraint"))
                msg = Messages.CannotDeleteBecauseOfForignKeyConstraint;
            else if (ex_str.Contains("Cannot insert duplicate key"))
            {
                if (ex_str.Contains("_NationalCode")) msg = Messages.DuplicateNationalCode;
                if (ex_str.Contains("_PhoneNumber")) msg = Messages.DuplicatePhoneNumber;
                else msg = Messages.CannotInsertDuplicateKey;
            }

            logger.WriteSysLog(exception, msg);

            context.Response.ContentType = "application/json";
            context.Response.StatusCode = (int)HttpStatusCode.OK;

            var resp = new Response
            {
                IsSuccess = false,
                ErrorCode = "500",
                ErrorMessage = msg,
            };

            var Content = JsonConvert.SerializeObject(resp, new JsonSerializerSettings { ContractResolver = new CamelCasePropertyNamesContractResolver() });
            context.Response.WriteAsync(Content);
        }


    }
}
