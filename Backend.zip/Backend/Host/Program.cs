using Authentication.Core;
using Authentication.Service;
using Common.Security;
using Dashboard.Service;
using Main.Core;
using Main.Service;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using Serilog;
using System.Text;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddEndpointsApiExplorer();


builder.Services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();
builder.Services.AddSingleton<IHttpContextService, HttpContextService>();

ConfigurationManager configuration = builder.Configuration;
IWebHostEnvironment environment = builder.Environment;


builder.Services.Configure<WebApiConfig>(configuration.GetSection(WebApiConfig.SectionName));
builder.Services.Configure<JwtConfig>(configuration.GetSection(JwtConfig.SectionName));
builder.Services.Configure<AuthenticationConfig>(configuration.GetSection(AuthenticationConfig.SectionName));

builder.Services.AddAuthentication(option =>
{
    option.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
    option.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
}).AddJwtBearer(options =>
{
    options.TokenValidationParameters = new TokenValidationParameters
    {
        ValidateIssuer = true,
        ValidateAudience = true,
        ValidateLifetime = true,
        ValidIssuer = configuration["Jwt:Issuer"],
        ValidAudience = configuration["Jwt:Audience"],
        IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(configuration["Jwt:SecretKey"])),
        ClockSkew = new TimeSpan(0)
    };
    options.Events = new JwtBearerEvents
    {
        OnMessageReceived = context =>
        {
            var accessToken = context.Request.Query["access_token"];

            var path = context.HttpContext.Request.Path;
            if (!string.IsNullOrEmpty(accessToken) &&
                (path.StartsWithSegments("")))
            {
                context.Token = accessToken;
            }
            return Task.CompletedTask;
        }
    };
});

var cors_origins = new string[]
       {
                "https://localhost:3000",
                "https://amoodesalam.ir",
       };

builder.Services.AddCors(o => o.AddPolicy("react", builder =>
{
    builder.WithOrigins(cors_origins)
        .AllowAnyMethod()
        .AllowCredentials()
        .AllowAnyHeader();
}));


builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

builder.Services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();
builder.Services.AddSingleton<IHttpContextService, HttpContextService>();

var connectionString = configuration["ConnectionString"];

builder.Services.AddAuthenticationData(connectionString);
builder.Services.AddAuthenticationServices();

builder.Services.AddMainData(connectionString);
builder.Services.AddMainServices();

builder.Services.AddDashboardData(connectionString);
builder.Services.AddDashboardServices();

Log.Logger = new LoggerConfiguration()
           .ReadFrom.Configuration(configuration)
           .CreateLogger();


var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
