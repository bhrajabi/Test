﻿using Microsoft.EntityFrameworkCore;
using NewTamin.Core;
using System.Collections.Generic;
using System.Linq;


namespace NewTamin.Services
{
    public class CompanyUserSerivce 
    {
        private readonly NewTaminDbContext db;


        public CompanyUserSerivce(NewTaminDbContext db)
        {
            this.db = db;
        }

        public void SetUserAthenticateCompany(int userId, int companyCode, bool status)
        {
            var userCompany = db.CompanyUsers.Where(s => s.CompanyId == companyCode && s.UserId == userId).FirstOrDefault();

            if (userCompany != null)
            {
                db.SaveChanges();
            }

        }

        public IList<CompanyUser> GetAll(string userName)
        {
            return db.CompanyUsers.Where(c => c.CreatedBy == userName).Include(c => c.Company).ToList();
        }

        public void Insert(CompanyUser entity)
        {
            db.CompanyUsers.Add(entity);
            db.SaveChanges();
        }

        public void Remove(CompanyUser entity)
        {
            db.CompanyUsers.Remove(entity);
            db.SaveChanges();
        }

        public void Update(CompanyUser entity)
        {
            db.CompanyUsers.Update(entity);
            db.SaveChanges();
        }
    }
}
