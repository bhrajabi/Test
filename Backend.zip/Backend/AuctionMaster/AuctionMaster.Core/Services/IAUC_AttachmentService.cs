﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;

namespace Tamin.AuctionMaster
{
    public interface IAUC_AttachmentService
    {
        IList<AUC_ZAttachment> GetAttachmentsByHeader(Int64? draftId, string objectClass, object objectHeader);
        IList<AUC_ZAttachment> GetAttachmentsByKey(Int64? draftId, string objectClass, object objectKey);

        AUC_ZAttachment GetAttachmentById(Int64 serial);
        AUC_ZAttachment GetAttachmentById(Int64 id, string objectClass);
        AUC_ZAttachment GetAttachmentById(Int64 serial, string objectClass, object objectKey);
        AUC_ZAttachment GetAttachmentByRequestId(long requestId, string sessionId);
        AUC_ZAttachmentData GetAttachmentDataBySerial(Int64? serial);

        //void Insert(AUC_Attachment attachment, byte[] data);
        //AUC_Attachment Insert(Int64? draftId, string objectClass, object objectHeader, object objectKey, string typeId, IFormFile file);
        AUC_ZAttachment Insert(Int64? draftId, string objectClass, object objectHeader, object objectKey, string typeId, IFormFile file, string fileName = null);
        AUC_ZAttachment Insert(Int64? draftId, string objectClass, object objectHeader, object objectKey, string typeId, byte[] data, string mimeType = null, string fileName = null);

        void ChangeObjectKey(string objectClass, string fromObjectKey, string toObjectKey);
        void ChangeObjectKey(Int64 attachmentId, string toObjectKey);
        void ChangeObjectHeader(Int64 attachmentId, string toObjectHeader);


        void DeleteAttachments(IList<AUC_ZAttachment> attachments);
        void DeleteAttachments(string objectClass, object objectKey);
        void DeleteAttachmentById(Int64 serial);

        long CreateDownloadRequest(AUC_ZAttachment attachment);

        AUC_ZAttachmentDraft GetDraft(long draftId, string objectClass);
        IList<AUC_ZAttachment> CreateDraft(string objectClass, object objectHeader, object objectKey, out long draftId);
        void CommitDraft(Int64 draftId);
        IList<AUC_ZAttachment> Clone(string objectClass, object objectKey, object newObjectHeader, object newObjectKey);
        IList<AUC_ZAttachment> Clone(string objectClass, object objectKey, string NewObjectClass, object newObjectHeader, object newObjectKey);

    }
}