﻿using Common.Data;
using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace Tamin.Core
{
    [Table("AssignedRequestItems", Schema = "PUR")]
    public class AssignedPR2 : IHasCreator
    {
        public long ProjectSerial { get; set; }
        public long DocumentSerial { get; set; }
        public long PRSerial { get; set; }

        public string CreatedBy { get; set; }
        public DateTime CreatedAt { get; set; }
    }
}
