using Common.Data;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Tamin.AuctionMaster
{
    [Table("ZAttachmentRequests", Schema = "AUC")]
    public class AUC_ZAttachmentRequest: IHasCreator
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public Int64 Id { get; set; }

        public Int64 AttachmentId { get; set; }
        public string SessionId { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedAt { get; set; }
    }
}
