using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Tamin.AuctionMaster
{
    [Table("ZAttachmentTypes", Schema = "AUC")]
    public class AUC_ZAttachmentType
    {
        [Key]
        public string Id { get; set; }

        public string Title { get; set; }
        public bool IsRequired { get; set; }
        public long MaxSize { get; set; }
        public string ValidTypes { get; set; }
        public int Count { get; set; }

    }
}
