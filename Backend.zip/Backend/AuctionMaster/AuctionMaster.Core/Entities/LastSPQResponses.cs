﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tamin.Core
{
    [Table("LastSPQResponses", Schema = "PUR")]
    public class LastSPQResponses
    {
        public int SellerId { get; set; }
        public long SPQContentSerial { get; set; }
        public long EventAlternativeId { get; set; }
        public long EventContentSerial { get; set; }
    }
}
