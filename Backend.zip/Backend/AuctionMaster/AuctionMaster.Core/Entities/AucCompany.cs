﻿using Common.Data;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Tamin.AuctionMaster
{
    [Table("Companies", Schema = "AUC")]
    public class AucCompany : IHasCreator, IHasModifier
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        public string NationalId { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public int ProgressPercent { get; set; }
        public string WebSite { get; set; }
        public string CountryId { get; set; }
        public string StateId { get; set; }
        public string City { get; set; }
        public string Address { get; set; }
        public string PostalCode { get; set; }
        public string RegNumber { get; set; }
        public DateTime? RegDate { get; set; }
        public string EconomicCode { get; set; }
        public string Industry { get; set; }
        public string Mobile { get; set; }
        public string Email { get; set; }
        
        public bool IsApproved { get; set; }
        public bool IsRejected { get; set; }
        public string RejectReason { get; set; }


        public string ModifiedBy { get; set; }
        public DateTime ModifiedAt { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedAt { get; set; }
    }
}
