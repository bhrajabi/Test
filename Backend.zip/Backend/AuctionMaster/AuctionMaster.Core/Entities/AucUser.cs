﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Tamin.AuctionMaster
{
    [Table("ZUsers", Schema = "AUC")]
    public class AucUser
    {
        [Key]
        public string UserName { get; set; }

        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string NationalCode { get; set; }
        public string PasswordHash { get; set; }
        public string AuthenticationMethod { get; set; }
        public string Email { get; set; }
        public bool EmailConfirmed { get; set; }
        public string PhoneNumber { get; set; }
        public bool PhoneNumberConfirmed { get; set; }
        public int AccessFailedCount { get; set; }
        public DateTime? LastAccessFailedDate { get; set; }
        public string CountryId { get; set; }
        public string StateId { get; set; }
        public string City { get; set; }
        public string Address { get; set; }
        public string PostalCode { get; set; }
        public string DefaultLanguage { get; set; }
        public bool IsServiceUser { get; set; }
        public bool IsDeleted { get; set; }
        public bool IsDisabled { get; set; }
        public bool IsApproved { get; set; }
        public bool IsRejected { get; set; }
        public string RejectReason { get; set; }
        public Guid UniqueId { get; set; }
        public long? ImageAttachmentId { get; set; }
        public DateTime LastUpdate { get; set; }
        public DateTime CreatedAt { get; set; }

    }
}
