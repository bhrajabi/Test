using Common.Data;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Tamin.AuctionMaster
{
    [Table("ZAttachmentDrafts", Schema = "AUC")]
    public class AUC_ZAttachmentDraft : IHasCreator
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public Int64 Id { get; set; }

        public string ObjectClass { get; set; }
        public string ObjectHeader { get; set; }
        public string ObjectKey { get; set; }
        public string UserName { get; set; }
        public string StatusId { get; set; }
        public DateTime StatusDate { get; set; }

        public string CreatedBy { get; set; }
        public DateTime CreatedAt { get; set; }
    }
}
