﻿using AProc.Core;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;

namespace AProc.Services
{
    public static class DependencyInjection
    {
        public static void AddAProcServices(this IServiceCollection services, string connectionString)
        {
            services.AddDbContext<AProcDbContext>(options => options
                .UseSqlServer(connectionString).UseQueryTrackingBehavior(QueryTrackingBehavior.NoTracking));

            services.AddScoped<IAProcDefService, AProcDefService>();            
            services.AddScoped<IAProcService, AProcService>();
            services.AddScoped<IAProcActionService, AProcActionService>();
            services.AddScoped<INotificationService, NotificationService>();
            services.AddScoped<ILevelService, LevelService>();
        }
    }
}