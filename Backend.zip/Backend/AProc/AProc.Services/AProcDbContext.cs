﻿using AProc.Core;
using AProc.Core.Entities;
using Common.Data;
using Common.Security;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using System;

namespace AProc.Services
{
    public class AProcDbContext : BaseDbContext
    {
        public virtual DbSet<AProcess> AProcesses { get; set; }
        public virtual DbSet<AProcLevel> AProcLevels { get; set; }
        public virtual DbSet<AProcUser> AProcUsers { get; set; }

        //public virtual DbSet<APInbox> APInbox { get; set; }
        public virtual DbSet<APInboxStatus> APInboxStatuses { get; set; }

        public virtual DbSet<AZUser> ZUsers { get; set; }

        public virtual DbSet<TheProject> Projects { get; set; }
        public virtual DbSet<ProjectRole> ProjectRoles { get; set; }
        public virtual DbSet<ProjectTeamUser> ProjectTeamUsers { get; set; }
        public virtual DbSet<ProjectTeamRole> ProjectTeamRoles { get; set; }
        public virtual DbSet<ProjectTeam> ProjectTeams { get; set; }
        public virtual DbSet<TheDocument> Documents { get; set; }
        public virtual DbSet<TheRequest> Requests { get; set; }
        public virtual DbSet<TheEventRule> EventRules { get; set; }
        public virtual DbSet<TheDiscoveryRule> DiscoveryRules { get; set; }
        public virtual DbSet<Content> Contents { get; set; }
        public virtual DbSet<TheDocumentSupplier> DocumentSuppliers { get; set; }
        public virtual DbSet<ResponseAlternative> ResponseAlternatives { get; set; }

        public virtual DbSet<Notification> Notifications { get; set; }

        public virtual DbSet<TheAuction> Auctions { get; set; }
        public virtual DbSet<TheOrganizationChart> OrganizationCharts { get; set; }
        public virtual DbSet<TheOrganizationChartUser> OrganizationChartUsers { get; set; }
        public virtual DbSet<TheConfirmation> Confirmations { get; set; }

        public AProcDbContext(DbContextOptions<AProcDbContext> options, IHttpContextService currentUserNameService) : base(options, currentUserNameService)
        {

        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<AProcUser>().HasKey(x => new { x.ProcLevelSerial, x.UserName });
            modelBuilder.Entity<TheDocumentSupplier>().HasKey(x => new { x.DocumentSerial, x.SellerId, x.ParticipantName });
            modelBuilder.Entity<Content>().HasKey(x => new { x.Serial });
            modelBuilder.Entity<TheAuction>().HasKey(x => new { x.AuctionId });
            modelBuilder.Entity<Content>().Property(x => x.Serial).ValueGeneratedOnAdd().Metadata.SetBeforeSaveBehavior(PropertySaveBehavior.Ignore);
            modelBuilder.Entity<ProjectTeamUser>().HasKey(x => new { x.ProjectTeamSerial, x.UserName });
            modelBuilder.Entity<ProjectTeamRole>().HasKey(x => new { x.ProjectTeamSerial, x.RoleId });

            modelBuilder.Entity<TheOrganizationChart>().HasKey(x => new { x.CompanyId, x.ChartCode });
            modelBuilder.Entity<TheConfirmation>().HasKey(x => new { x.Serial });
            modelBuilder.Entity<TheDiscoveryRule>().HasKey(x => new { x.DocumentSerial });
            modelBuilder.Entity<TheOrganizationChartUser>().HasKey(x => new { x.CompanyId, x.ChartCode, x.UserName });
        }

        internal bool UserExistsInCompany(string userName, int companyId)
        {
            userName = userName?.Replace("'", "''");
            var q = $"select count(*) from PUR.CompanyUsers where companyId={companyId}  and  UserName='{userName}'";
            return ExecuteScalar(q).ToInt(0) > 0;
        }

        internal string GetUserFullName(string userName)
        {
            userName = userName?.Replace("'", "''");
            var q =
                $"select FirstName + ' ' + LastName" +
                " from PUR.ZUsers" +
                " where UserName = '" + userName + "'";
            return ExecuteScalar(q) as string;

        }

        internal void CloseInboxBySenderSerial(long senderSerial, System.Data.Common.DbTransaction transaction)
        {
            Execute($"update PUR.APInbox set IsClosedByOtherUser=1 where SenderSerial={senderSerial}", transaction);
        }



    }
}
