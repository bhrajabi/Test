﻿using AProc.Core;
using AProc.Core.Entities;
using AProc.Core.Views;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Tamin.Core;

namespace AProc.Services
{
    public class LevelService : ILevelService
    {
        private AProcDbContext db;
        private readonly IAccessService accessService;

        public LevelService(AProcDbContext context, IAccessService accessService)
        {
            db = context;
            this.accessService = accessService;
        }

        public IList<AProcLevel> GetLevels(int aprocSerial, bool? isPrintable = null)
        {
            var query = db.AProcLevels.Where(x => x.ProcSerial == aprocSerial);
            if (isPrintable.HasValue)
                query = query.Where(s => s.IsPrintable == isPrintable);
            return query.ToList();
        }

        public AProcLevel GetLevel(int? levelSerial)
        {
            if (levelSerial is null) return null;
            return db.AProcLevels.Where(x => x.Serial == levelSerial).FirstOrDefault();
        }

        public void AddUserToLevel(string userName, int levelSerial)
        {
            if (db.AProcUsers.Where(x => x.ProcLevelSerial == levelSerial && x.UserName == userName).Any()) return;
            var newLevelUser = new AProcUser()
            {
                IsActive = true,
                ProcLevelSerial = levelSerial,
                UserName = userName,
            };
            db.Add(newLevelUser);
            db.SaveChanges();
        }

        public LevelInfoView PrevLevelInfo(List<AProcLevel> levels, int currentLevelSerial)
        {
            if ((levels?.Count ?? 0) == 0) return null;
            var firstLevel = levels.FirstOrDefault();
            var previousLevel = new AProcLevel();
            if (!IsFirstLevel(currentLevelSerial, levels.Select(s => s.Serial).ToList()))
                previousLevel = levels[levels.FindIndex(s => s.Serial == currentLevelSerial) - 1];
            else return null;

            return new LevelInfoView()
            {
                LevelSerial = previousLevel.Serial,
                LevelTitle = previousLevel?.Title,
                SendToAll = previousLevel?.SendMessageToAll,
                Users = LevelUsers(previousLevel.Serial)
            };
        }

        public LevelInfoView FirstLevelInfo(List<AProcLevel> levels, int currentLevelSerial)
        {
            if ((levels?.Count ?? 0) == 0) return null;
            var firstLevel = levels.FirstOrDefault();

            return new LevelInfoView()
            {
                LevelSerial = firstLevel.Serial,
                LevelTitle = firstLevel?.Title,
                SendToAll = firstLevel?.SendMessageToAll,
                Users = LevelUsers(firstLevel.Serial)
            };
        }

        public LevelInfoView FirstSenderInfo(int aprocSerial)
        {
            var query = from a in db.AProcesses

                        join l in db.AProcLevels on a.Serial equals l.ProcSerial

                        join i in db.Notifications on l.Serial equals i.ToAPLevelSerial

                        where a.Serial == aprocSerial && i.SenderSerial == null
                        orderby i.CreatedAt descending
                        select new LevelInfoView()
                        {
                            LevelSerial = i.ToAPLevelSerial.Value,
                            LevelTitle = l.Title,
                            Users = (from u in db.ZUsers
                                     where u.UserName == i.ToUserName
                                     select new UserView()
                                     {
                                         UserName = u.UserName,
                                         FName = u.FirstName,
                                         LName = u.LastName
                                     }).ToList()
                        };

            return query.FirstOrDefault();
        }

        public bool IsFirstLevel(int currentLevel, List<int> allLevels)
        {
            if (allLevels.Count == 0 || currentLevel == 0)
                return false;
            return allLevels.First() == currentLevel;
        }

        public LevelInfoView NextLevelInfo(List<AProcLevel> levels, int levelSerial)
        {
            if (levels.Count > 0)
            {
                var firstLevel = levels.FirstOrDefault();
                var nextLevel = new AProcLevel();

                if (!IsLastLevel(levelSerial, levels.Select(s => s.Serial).ToList()))
                    nextLevel = levels[levels.FindIndex(s => s.Serial == levelSerial) + 1];
                else
                    return null;

                return new LevelInfoView()
                {
                    LevelSerial = nextLevel.Serial,
                    LevelTitle = nextLevel.Title,
                    SendToAll = nextLevel?.SendMessageToAll,
                    Users = LevelUsers(nextLevel.Serial)
                };
            }


            throw new AprocLevelsIsEmptyError();
        }
        public LevelInfoView LevelInfo(int levelSerial)
        {
            var procLevel = db.AProcLevels.Where(s => s.Serial == levelSerial).FirstOrDefault();
            if (procLevel is null) return null;

            return new LevelInfoView()
            {
                LevelSerial = levelSerial,
                LevelTitle = procLevel.Title,
                SendToAll = procLevel.SendMessageToAll,
                Users = LevelUsers(levelSerial)
            };

            throw new AprocLevelsIsEmptyError();
        }

        public List<UserView> LevelUsers(int levelSerial)
        {

            var lu = from l in db.AProcUsers
                     join u in db.ZUsers on l.UserName equals u.UserName
                     where l.ProcLevelSerial == levelSerial && l.IsActive
                     select u;

            var q = from l in db.AProcLevels
                    join c in db.OrganizationCharts on l.ChartCode equals c.ChartCode
                    join cu in db.OrganizationChartUsers on c.ChartCode equals cu.ChartCode
                    join u in db.ZUsers on cu.UserName equals u.UserName

                    where c.CompanyId == accessService.CompanyId && l.Serial == levelSerial

                    select u;

            var orgUsers = q.Select(s => new UserView()
            {
                FName = s.FirstName,
                UserName = s.UserName,
                LName = s.LastName,
                IsInOrganizationChart = true
            }).ToList();

            var levelUsers = lu.Select(s => new UserView()
            {
                FName = s.FirstName,
                UserName = s.UserName,
                LName = s.LastName
            }).ToList();

            levelUsers.AddRange(orgUsers);

            return levelUsers.DistinctBy(x => x.UserName).ToList();
        }

        public AProcLevel GetAProcLevel(int levelSerial)
        {
            return db.AProcLevels.Where(s => s.Serial == levelSerial).FirstOrDefault();
        }


        public AProcess GetAProcByLevelSerial(int levelSerial)
        {
            var query = from a in db.AProcesses
                        join l in db.AProcLevels on a.Serial equals l.ProcSerial
                        where l.Serial == levelSerial
                        select a;
            return query.FirstOrDefault();
        }

        private bool IsLastLevel(int currentLevel, List<int> allLevels)
        {
            if (allLevels.Count == 0 || currentLevel == 0)
                return false;
            return allLevels.Last() == currentLevel;
        }



    }
}