﻿using System.Collections.Generic;
using System.Linq;
using AProc.Core;
using AProc.Core.Entities;
using Authentication.Core;
using Tamin.Core;


namespace AProc.Services
{
    public class AProcDefService : IAProcDefService
    {
        private readonly AProcDbContext db;
        private readonly IUserService userService;
        private readonly IAccessService accessService;



        public AProcDefService(AProcDbContext context, IUserService userService, IAccessService accessService)
        {
            db = context;
            this.userService = userService;
            this.accessService = accessService;
        }



        public IList<AProcess> GetAProcess(int buyerId, bool isTemplate)
        {
            var q = from a in db.AProcesses
                    join u in db.ZUsers on a.CreatedBy equals u.UserName
                    join um in db.ZUsers on a.ModifiedBy equals um.UserName
                    where a.CompanyId == accessService.CompanyId && a.IsTemplate == isTemplate
                    select new AProcess
                    {
                        Serial = a.Serial,
                        Title = a.Title,
                        Version = a.Version,
                        ActionId = a.ActionId,
                        Active = a.Active,
                        CreatedAt = a.CreatedAt,
                        ModifiedAt = a.ModifiedAt,
                        CreatedBy = u.FirstName + " " + u.LastName,
                        ModifiedBy = um.FirstName + " " + um.LastName,
                    };

            return q.ToList();
        }

        public AProcess GetAProc(int serial, int companyId)
        {
            return db.AProcesses.Where(x => x.Serial == serial && x.CompanyId == companyId && x.IsTemplate).FirstOrDefault();
        }

        public AProcess GetAProc(int? serial, int companyId, bool isTemplate = false)
        {
            return db.AProcesses.Where(x => x.Serial == serial && x.CompanyId == companyId && x.IsTemplate == isTemplate).FirstOrDefault();
        }

        public IList<AProcLevel> GetLevels(int aprocSerial, bool? isPrintable = null)
        {
            var query = db.AProcLevels.Where(x => x.ProcSerial == aprocSerial);
            if (isPrintable.HasValue)
                query = query.Where(s => s.IsPrintable == isPrintable);
            return query.ToList();
        }

        public AProcLevel GetLevel(int levelSerial)
        {
            return db.AProcLevels.Where(x => x.Serial == levelSerial).FirstOrDefault();
        }


        public IList<AProcUser> GetUsers(int aprocSerial)
        {
            var q = from u in db.AProcUsers
                    join l in db.AProcLevels on u.ProcLevelSerial equals l.Serial
                    join a in db.AProcesses on l.ProcSerial equals a.Serial
                    where l.ProcSerial == aprocSerial && a.IsTemplate
                    select u;
            return q.ToList();
        }


        public void Delete(int serial, int companyId)
        {
            var p = db.AProcesses.Where(x => x.Serial == serial && x.CompanyId == companyId).FirstOrDefault();
            if (p == null) return;
            db.Remove(p);
            db.SaveChanges();
        }


        public AProcess AddAproc(int buyerId, bool active, string title)
        {
            var aproc = new AProcess()
            {
                CompanyId = buyerId,
                Active = active,
                Version = 0,
                Title = title,
                IsTemplate = true,
            };
            db.AProcesses.Add(aproc);
            db.SaveChanges();
            return aproc;
        }

        public int CreateAproc(int buyerId, bool active, string title, int? referenceSerial, bool isTemplate = false)
        {
            var aproc = new AProcess()
            {
                ReferenceSerial = referenceSerial,
                CompanyId = buyerId,
                Active = active,
                Title = title,
                IsTemplate = isTemplate,
                Version = 0,
            };
            db.AProcesses.Add(aproc);
            db.SaveChanges();
            return aproc.Serial;
        }


        public AProcess EditAproc(int serial, bool active, string title)
        {
            var aproc = db.AProcesses.SingleOrDefault(s => s.Serial == serial);
            aproc.Title = title;
            aproc.Active = active;
            aproc.Version++;

            db.AProcesses.Update(aproc);
            db.SaveChanges();
            return aproc;
        }

        public AProcess CloneAproc(int serial, bool active, string title)
        {
            var aproc = db.AProcesses.SingleOrDefault(s => s.Serial == serial);
            var aproceLevels = db.AProcLevels.Where(c => c.ProcSerial == serial).ToList();

            var transaction = db.Database.BeginTransaction();

            try
            {
                //Aproce
                var clone_aproc = new AProcess()
                {
                    ReferenceSerial = aproc.ReferenceSerial,
                    CompanyId = accessService.CompanyId,
                    Active = active,
                    Title = title,
                    IsTemplate = aproc.IsTemplate,
                    Version = 0,
                };

                db.Add(clone_aproc);
                db.SaveChanges();


                aproceLevels.ForEach(x =>
                {
                    //Levels
                    var aproce_level = new AProcLevel()
                    {
                        ProcSerial = clone_aproc.Serial,
                        Title = x.Title,
                        IsPrintable = x.IsPrintable,
                        LevelCode = x.LevelCode,
                        SendMessageToAll = x.SendMessageToAll,
                    };

                    db.Add(aproce_level);
                    db.SaveChanges();

                    //Users
                    var aproceUsers = db.AProcUsers.Where(u => u.ProcLevelSerial == x.Serial).ToList();
                    aproceUsers.ForEach(u =>
                    {
                        var aproce_user = new AProcUser()
                        {
                            ProcLevelSerial = aproce_level.Serial,
                            UserName = u.UserName,
                            IsActive = u.IsActive,
                            JustNotify = u.JustNotify,
                        };

                        db.Add(aproce_user);
                        db.SaveChanges();
                    });
                });

                db.SaveChanges();
                transaction.Commit();

                return clone_aproc;
            }
            catch
            {
                transaction.Rollback();
                throw;
            }
        }


        public void RemoveAProc(List<int> serials)
        {
            var aproces = db.AProcesses.Where(s => serials.Contains(s.Serial)).ToList();
            db.AProcesses.RemoveRange(aproces);
            db.SaveChanges();
        }


        public AProcLevel SaveAprocLevel(AProcLevel level)
        {
            if (level.Serial == 0)
            {
                if (db.AProcLevels.Any(s => s.ProcSerial == level.ProcSerial && s.LevelCode == level.LevelCode))
                    throw new LevelCodeIsDuplicateError();

                db.Add(level);
            }
            else
            {
                var entity = db.AProcLevels.Where(x => x.Serial == level.Serial).FirstOrDefault();
                entity.LevelCode = level.LevelCode;
                entity.Title = level.Title;
                entity.ChartCode = level.ChartCode;
                entity.IsOwner = level.IsOwner;
                entity.IsPrintable = level.IsPrintable;
                entity.IsReadonly = level.IsReadonly;
                entity.SystemTrigger = level.SystemTrigger;
                //db.Update(level);
                db.Update(entity);
            }
            db.SaveChanges();
            return level;
        }


        public IList<int> GetAprocLevels(int procSerial)
        {
            return (from l in db.AProcLevels
                    where l.Serial == procSerial
                    select l.Serial).ToList();

        }




        public void AddAprocLevel(int procSerial, string title, int levelCode)
        {
            if (db.AProcLevels.Any(s => s.ProcSerial == procSerial && s.LevelCode == levelCode))
                throw new LevelCodeIsDuplicateError();

            var aprocLevel = new AProcLevel()
            {
                ProcSerial = procSerial,
                LevelCode = levelCode,
                Title = title,
            };
            db.AProcLevels.Add(aprocLevel);
            db.SaveChanges();
        }


        public void EditAprocLevel(int serial, string title, int levelCode, int procSerial)
        {
            if (db.AProcLevels.Any(s => s.Serial != serial && s.LevelCode == levelCode && s.ProcSerial == procSerial))
                throw new LevelCodeIsDuplicateError();

            var aprocLevel = db.AProcLevels.SingleOrDefault(s => s.Serial == serial);

            if (aprocLevel == null)
                throw new NotFoundError();

            aprocLevel.Title = title;
            aprocLevel.LevelCode = levelCode;

            db.AProcLevels.Update(aprocLevel);
            db.SaveChanges();
        }


        public void RemoveAProcLevel(List<int> serials)
        {
            var aproclevels = db.AProcLevels.Where(s => serials.Contains(s.Serial)).ToList();
            db.AProcLevels.RemoveRange(aproclevels);
            db.SaveChanges();
        }


        public IList<AProcUser> UserLevels(int levelSerial)
        {
            return db.AProcUsers.Where(s => s.ProcLevelSerial == levelSerial).ToList();
        }


        public AProcUser AddUserLevel(int levelSerial, string userName, int companyId)
        {
            if (!db.UserExistsInCompany(userName, companyId))
                throw new InvalidUserNameError();

            var u = db.AProcUsers.FirstOrDefault(x => x.UserName == userName && x.ProcLevelSerial == levelSerial);
            if (u != null) throw new DuplicateUserError();
            u = new AProcUser()
            {
                ProcLevelSerial = levelSerial,
                UserName = userName,
                IsActive = true
            };
            db.AProcUsers.Add(u);
            db.SaveChanges();
            return u;
        }

        public void DeleteAprocLevel(int levelSerial)
        {
            var level = db.AProcLevels.FirstOrDefault(x => x.Serial == levelSerial);
            if (level == null) return;
            db.Remove(level);
            db.SaveChanges();
        }

        public void DeleteUserLevel(int levelSerial, string userName)
        {
            var u = db.AProcUsers.FirstOrDefault(x => x.UserName == userName && x.ProcLevelSerial == levelSerial);
            if (u == null) return;
            db.Remove(u);
            db.SaveChanges();
        }


        public void SetUserActive(int levelSerial, string userName, bool active)
        {
            var u = db.AProcUsers.FirstOrDefault(x => x.UserName == userName && x.ProcLevelSerial == levelSerial);
            if (u == null) return;
            u.IsActive = active;
            db.Update(u);
            db.SaveChanges();
        }


        public string GetUserFullName(string userName, int companyId)
        {
            if (string.IsNullOrEmpty(userName)) return null;
            return userService.GetFullName(userName, companyId);
        }


        private bool UserExistInLevel(int levelSerial, string userName)
        {
            return db.AProcUsers.Any(x => x.UserName == userName && x.ProcLevelSerial == levelSerial);
        }


        public IList<AProcess> GetBuyerAProces(int buyerId, int? authrizationGroupSerial)
        {
            return db.AProcesses.Where(s => s.CompanyId == buyerId && s.IsTemplate).ToList();
        }


    }
}