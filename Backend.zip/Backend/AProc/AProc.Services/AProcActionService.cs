﻿using AProc.Core;
using AProc.Core.Entities;
using AProc.Core.Views;
using Attcahment.Core;
using System;
using System.Linq;
using Tamin.Core;
using Tamin.Core.Errors;

namespace AProc.Services
{
    public class AProcActionService : IAProcActionService
    {
        private AProcDbContext db;
        private readonly IServiceProvider serviceProvider;


        public AProcActionService(AProcDbContext context, IServiceProvider serviceProvider)
        {
            db = context;
            this.serviceProvider = serviceProvider;
        }

        public string GetAprocAction(string objectClass, string action)
        {

            switch (objectClass)
            {
                case ObjectClasses.Document:

                    switch (action)
                    {
                        case AProcActions.PUB:
                            return AProcActions.EVENT_PUB;
                        case AProcActions.CLOSE:
                            return AProcActions.EVENT_CLOSE;
                        case AProcActions.GRADE:
                            return AProcActions.EVENT_GRADE;
                        case AProcActions.AWARD:
                            return AProcActions.EVENT_AWARD;

                        case AProcActions.DRFT:
                            return AProcActions.EVENT_DRFT;
                        case AProcActions.BPUB:
                            return AProcActions.EVENT_BPUB;
                        case AProcActions.BCLOSE:
                            return AProcActions.EVENT_BCLOSE;
                        case AProcActions.BGRADE:
                            return AProcActions.EVENT_BGRADE;
                        case AProcActions.CNF:
                            return AProcActions.EVENT_CNF;
                    }
                    break;
                case ObjectClasses.Project:

                    switch (action)
                    {
                        case AProcActions.SUBMIT:
                            return AProcActions.CNF_SUBMIT;
                    }
                    break;

                case ObjectClasses.Discovery:

                    switch (action)
                    {
                        case AProcActions.PUB:
                            return AProcActions.DISC_PUB;
                        case AProcActions.CLOSE:
                            return AProcActions.DISC_CLOSE;
                        case AProcActions.QUAL_RJCT:
                            return AProcActions.DISC_QUAL_RJCT;
                    }
                    break;

                case ObjectClasses.Auction:

                    switch (action)
                    {
                        case AProcActions.PUB:
                            return AProcActions.AUC_PUB;
                        case AProcActions.CLOSE:
                            return AProcActions.AUC_CLOSE;
                        case AProcActions.GRADE:
                            return AProcActions.AUC_GRADE;
                        case AProcActions.AWARD:
                            return AProcActions.AUC_AWARD;
                    }
                    break;
            }
            return null;
        }

        public NotificationActionView InitAProcAction(AProcess aproc, string aprocAction, string objectKey, string customizedParameter = "")
        {
            aprocAction = aproc?.ActionId ?? aprocAction;
            aprocAction = aprocAction.Replace(" ", "");

            var action = NotificationActions.Resolve(serviceProvider, aprocAction);
            if (action is null) throw new NotFoundAProcActionError();

            return action.InitStart(aproc?.ObjectKey ?? objectKey, aproc?.Serial, customizedParameter);
        }


        public void RunStartAProcAction(AProcess aproc, DateTime currentDate, string selectedUserName, string comment, string aprocAction, string objectKey, string customizedParameter = "")
        {
            aprocAction = aproc?.ActionId ?? aprocAction;

            var action = NotificationActions.Resolve(serviceProvider, aprocAction);
            if (action is null) throw new NotFoundAProcActionError();

            var statusOrKey = string.IsNullOrEmpty(customizedParameter) ? objectKey : customizedParameter;

            action.Start(aproc?.ObjectKey ?? objectKey, aproc?.Serial, currentDate, selectedUserName, comment, statusOrKey);
        }

        public void RunApproveAProcAction(AProcess aproc, DateTime currentDate, string userNote)
        {
            if (aproc is null) throw new NotFoundAProcError();

            var action = NotificationActions.Resolve(serviceProvider, aproc.ActionId);

            if (action is null) throw new NotFoundAProcActionError();

            action.Approve(aproc.ObjectKey, currentDate, aproc.ActionId, userNote);
        }

        public void RunRejectAProcAction(AProcess aproc, DateTime currentDate)
        {
            if (aproc is null) throw new NotFoundAProcError();

            var action = NotificationActions.Resolve(serviceProvider, aproc.ActionId);

            if (action is null) throw new NotFoundAProcActionError();

            action.Reject(aproc.ObjectKey, currentDate);
        }

    }
}