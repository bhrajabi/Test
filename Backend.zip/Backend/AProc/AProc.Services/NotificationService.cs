﻿using AProc.Core;
using AProc.Core.Entities;
using AProc.Core.Views;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Tamin.Core;
using Tamin.Core.Errors;

namespace AProc.Services
{
    public class NotificationService : Core.INotificationService
    {

        private AProcDbContext db;
        private readonly IAccessService accessService;
        private readonly ILevelService levelService;
        private readonly IAProcActionService aProcActionService;
        private readonly IServiceProvider serviceProvider;


        public NotificationService(AProcDbContext context, IAccessService accessService, IAProcActionService aProcActionService, ILevelService levelService, IServiceProvider serviceProvider)
        {
            db = context;
            this.accessService = accessService;
            this.levelService = levelService;
            this.aProcActionService = aProcActionService;
            this.serviceProvider = serviceProvider;
        }


        public Notification GetNotification(long notificationSerial)
        {
            return db.Notifications.Where(s => s.Serial == notificationSerial).FirstOrDefault();
        }


        public List<NotificationView> GetAprocFlowView(List<NotificationView> notificationFlows, List<LevelInfoView> levels)
        {
            if (notificationFlows is null || levels is null) return notificationFlows;
            if (!notificationFlows.Any() || !levels.Any()) return notificationFlows;

            var lastStarter = notificationFlows.Where(s => s.SenderUserName == null).FirstOrDefault();
            if (lastStarter is null) return notificationFlows;

            var lastStarterIndex = notificationFlows.IndexOf(lastStarter);

            var notificatonFlow = notificationFlows.Where((n, index) => index <= lastStarterIndex && n.Status != NotificationActionStatuses.NEW
            && n.Status != NotificationActionStatuses.VISITED).ToList();
            if (!notificatonFlow.Any()) return notificationFlows;

            foreach (var currentLevel in levels)
            {
                var notificationFlowsOfLevel = notificatonFlow.Where(x => x.LevelSerial == currentLevel.LevelSerial);
                if (notificationFlowsOfLevel.Any())
                {
                    if (currentLevel.SendToAll ?? false)
                    {
                        var lastActionOfLevel = notificationFlowsOfLevel.Where(x => x.Status != NotificationActionStatuses.CLOSED).ToList();

                        if (lastActionOfLevel.Where(s => s.Status == NotificationActionStatuses.REFERBACK).Any())
                        {
                            currentLevel.LastAction = NotificationActionStatuses.REFERBACK;
                        }
                        else if (lastActionOfLevel.Where(s => s.Status == NotificationActionStatuses.RJCT).Any())
                        {
                            currentLevel.LastAction = NotificationActionStatuses.RJCT;
                        }
                        else if (lastActionOfLevel.Where(s => s.Status == NotificationActionStatuses.NEW || s.Status == NotificationActionStatuses.VISITED).Any())
                        {
                            currentLevel.LastAction = NotificationActionStatuses.NEW;
                        }
                        else
                        {
                            currentLevel.LastAction = NotificationActionStatuses.APRV;
                        }
                    }
                    else
                    {
                        currentLevel.LastAction = notificationFlowsOfLevel.First().Status;
                    }
                }
                else
                {
                    currentLevel.LastAction = NotificationActionStatuses.NEW;
                }
            }

            return notificationFlows.OrderBy(x => x.InboxSerial).ToList();
        }


        public async Task<List<NotificationView>> GetAprocFlowViewAsync(List<NotificationView> notificationFlows, List<LevelInfoView> levels)
        {
            return await Task.Run(() =>
            {
                if (notificationFlows is null || levels is null) return notificationFlows;
                if (!notificationFlows.Any() || !levels.Any()) return notificationFlows;

                var lastStarter = notificationFlows.Where(s => s.SenderUserName == null).FirstOrDefault();
                if (lastStarter is null) return notificationFlows;

                var lastStarterIndex = notificationFlows.IndexOf(lastStarter);

                var notificatonFlow = notificationFlows.Where((n, index) => index <= lastStarterIndex && n.Status != NotificationActionStatuses.NEW
                && n.Status != NotificationActionStatuses.VISITED).ToList();
                if (!notificatonFlow.Any()) return notificationFlows;

                foreach (var currentLevel in levels)
                {
                    var notificationFlowsOfLevel = notificatonFlow.Where(x => x.LevelSerial == currentLevel.LevelSerial);
                    if (notificationFlowsOfLevel.Any())
                    {
                        if (currentLevel.SendToAll ?? false)
                        {
                            var lastActionOfLevel = notificationFlowsOfLevel.Where(x => x.Status != NotificationActionStatuses.CLOSED).ToList();

                            if (lastActionOfLevel.Where(s => s.Status == NotificationActionStatuses.REFERBACK).Any())
                            {
                                currentLevel.LastAction = NotificationActionStatuses.REFERBACK;
                            }
                            else if (lastActionOfLevel.Where(s => s.Status == NotificationActionStatuses.RJCT).Any())
                            {
                                currentLevel.LastAction = NotificationActionStatuses.RJCT;
                            }
                            else if (lastActionOfLevel.Where(s => s.Status == NotificationActionStatuses.NEW || s.Status == NotificationActionStatuses.VISITED).Any())
                            {
                                currentLevel.LastAction = NotificationActionStatuses.NEW;
                            }
                            else
                            {
                                currentLevel.LastAction = NotificationActionStatuses.APRV;
                            }
                        }
                        else
                        {
                            currentLevel.LastAction = notificationFlowsOfLevel.First().Status;
                        }
                    }
                    else
                    {
                        currentLevel.LastAction = NotificationActionStatuses.NEW;
                    }
                }

                return notificationFlows.OrderBy(x => x.InboxSerial).ToList();
            });
        }


        //public FlowReportView LastDocumentInboxViewByActionId(long documentSerial, string actionId)
        //{
        //    var document = db.Documents.Where(s => s.Serial == documentSerial).SingleOrDefault();

        //    actionId = document.DocumentType + "-" + actionId;

        //    //get last task serial from inbox table

        //    var lastInboxes = from i in db.APInbox

        //                      join t in db.ProjectTasks on i.TaskSerial equals t.Serial

        //                      orderby i.CreatedAt

        //                      where t.DocumentSerial == documentSerial && t.ActionId == actionId

        //                      select t;


        //    var result = new FlowReportView()
        //    {
        //        //Inboxes = TaskFlow(task.Serial, true),
        //        //Task = task
        //    };
        //    return result;
        //}


        public Task<List<NotificationView>> NotificationFlowByAprocSerialAsync(int? aprocSerial, bool? printable = null, bool showStarter = false)
        {
            if (aprocSerial == null) return Task.FromResult(new List<NotificationView>());

            var query = from inbox in db.Notifications

                        join level in db.AProcLevels on inbox.ToAPLevelSerial equals level.Serial

                        join sb in db.Notifications on inbox.SenderSerial equals sb.Serial into sbs
                        from senderInbox in sbs.DefaultIfEmpty()

                        join sl in db.AProcLevels on senderInbox.ToAPLevelSerial equals sl.Serial into sls
                        from senderLevel in sls.DefaultIfEmpty()

                        join tu in db.ZUsers on inbox.ToUserName equals tu.UserName into tus
                        from reciver in tus.DefaultIfEmpty()

                        join su in db.ZUsers on inbox.FromUserName equals su.UserName into sus
                        from sender in sus.DefaultIfEmpty()

                        where level.ProcSerial == aprocSerial && (showStarter ? true : inbox.SenderSerial != null)

                        select new NotificationView()
                        {
                            AProcSerial = level.ProcSerial,
                            InboxSerial = inbox.Serial,
                            InboxLink = inbox.MessageUrl,
                            Status = inbox.ActionStatusId,
                            Comment = inbox.Comment,
                            MessageType = inbox.TypeId,
                            CreatedAt = inbox.CreatedAt,
                            ActionAt = inbox.ActionAt,
                            LevelSerial = inbox.ToAPLevelSerial,
                            LevelChartCode = level.ChartCode,
                            VisitAt = inbox.VisitedAt,
                            Title = inbox.Title,

                            IsPrintable = level.IsPrintable,

                            SenderFullName = sender != null ? sender.FirstName + " " + sender.LastName : null,
                            SenderUserName = sender != null ? sender.UserName : null,
                            SenderLevelTitle = senderLevel != null ? senderLevel.Title : null,

                            ReciverUserName = reciver != null ? reciver.UserName : null,
                            ReciverFullName = reciver != null ? reciver.FirstName + " " + reciver.LastName : null,
                            ReciverLevelSerial = level.Serial,
                            ReciverLevelTitle = level.Title,
                        };

            if (printable.HasValue)
                query = query.Where(x => x.IsPrintable == printable.Value);

            return query.OrderBy(s => s.InboxSerial).ToListAsync();
        }

        public List<NotificationView> NotificationFlowByAprocSerial(int? aprocSerial, bool? printable = null, bool showStarter = false)
        {
            if (aprocSerial == null) return new List<NotificationView>();

            var query = from inbox in db.Notifications

                        join level in db.AProcLevels on inbox.ToAPLevelSerial equals level.Serial

                        join sb in db.Notifications on inbox.SenderSerial equals sb.Serial into sbs
                        from senderInbox in sbs.DefaultIfEmpty()

                        join sl in db.AProcLevels on senderInbox.ToAPLevelSerial equals sl.Serial into sls
                        from senderLevel in sls.DefaultIfEmpty()

                        join tu in db.ZUsers on inbox.ToUserName equals tu.UserName into tus
                        from reciver in tus.DefaultIfEmpty()

                        join su in db.ZUsers on inbox.FromUserName equals su.UserName into sus
                        from sender in sus.DefaultIfEmpty()

                        where level.ProcSerial == aprocSerial && (showStarter ? true : inbox.SenderSerial != null)

                        select new NotificationView()
                        {
                            AProcSerial = level.ProcSerial,
                            InboxSerial = inbox.Serial,
                            InboxLink = inbox.MessageUrl,
                            Status = inbox.ActionStatusId,
                            Comment = inbox.Comment,
                            MessageType = inbox.TypeId,
                            CreatedAt = inbox.CreatedAt,
                            ActionAt = inbox.ActionAt,
                            LevelSerial = inbox.ToAPLevelSerial,
                            LevelChartCode = level.ChartCode,
                            VisitAt = inbox.VisitedAt,
                            Title = inbox.Title,

                            IsPrintable = level.IsPrintable,

                            SenderFullName = sender != null ? sender.FirstName + " " + sender.LastName : null,
                            SenderUserName = sender != null ? sender.UserName : null,
                            SenderLevelTitle = senderLevel != null ? senderLevel.Title : null,

                            ReciverUserName = reciver != null ? reciver.UserName : null,
                            ReciverFullName = reciver != null ? reciver.FirstName + " " + reciver.LastName : null,
                            ReciverLevelSerial = level.Serial,
                            ReciverLevelTitle = level.Title,
                        };

            if (printable.HasValue)
                query = query.Where(x => x.IsPrintable == printable.Value);

            return query.OrderBy(s => s.InboxSerial).ToList();
        }


        public (IList<NotificationView>, int) UserNotificatonListByPagining(bool justArchived, string msgType, string title,
            DateTime? from, DateTime? to, string senderUserName, bool showUnVisiteds, bool showVisiteds, bool showDonedNotifications, int count = 15, int page = 0)
        {
            var statuses = new List<string>();
            if (showUnVisiteds) statuses.Add(NotificationActionStatuses.NEW);
            if (showVisiteds) statuses.Add(NotificationActionStatuses.VISITED);
            if (showDonedNotifications)
            {
                statuses.Add(NotificationActionStatuses.APRV);
                statuses.Add(NotificationActionStatuses.CLOSED);
                statuses.Add(NotificationActionStatuses.FORWARD);
                statuses.Add(NotificationActionStatuses.REFERBACK);
                statuses.Add(NotificationActionStatuses.RJCT);
            }
            var query = (from notification in db.Notifications

                         join level in db.AProcLevels on notification.ToAPLevelSerial equals level.Serial into ls
                         from currentLevel in ls.DefaultIfEmpty()

                         join sb in db.Notifications on notification.SenderSerial equals sb.Serial into sbs
                         from senderInbox in sbs.DefaultIfEmpty()

                         join sl in db.AProcLevels on senderInbox.ToAPLevelSerial equals sl.Serial into sls
                         from senderLevel in sls.DefaultIfEmpty()

                         join tu in db.ZUsers on notification.ToUserName equals tu.UserName into tus
                         from reciver in tus.DefaultIfEmpty()

                         join su in db.ZUsers on senderInbox.ToUserName equals su.UserName into sus
                         from sender in sus.DefaultIfEmpty()

                         join fu in db.ZUsers on notification.FromUserName equals fu.UserName into fus
                         from fromUser in fus.DefaultIfEmpty()


                         where notification.ToUserName == accessService.UserName
                         && notification.CompanyId == accessService.CompanyId
                         && statuses.Contains(notification.ActionStatusId)


                         select new
                         {
                             inbox = notification,
                             level = currentLevel,
                             senderInbox = senderInbox,
                             senderLevel = senderLevel,
                             reciver = reciver,
                             sender = fromUser

                         });

            if (justArchived)
                query = query.Where(s => s.inbox.IsArchived);
            else
                query = query.Where(s => !s.inbox.IsArchived);

            if (!string.IsNullOrEmpty(msgType))
                query = query.Where(s => s.inbox.TypeId == msgType.ToUpper());

            if (!string.IsNullOrEmpty(title))
                query = query.Where(s => s.inbox.Title.Contains(title));

            if (from.HasValue)
                query = query.Where(s => s.inbox.CreatedAt.Date >= from.Value.Date);

            if (to.HasValue)
                query = query.Where(s => s.inbox.CreatedAt.Date <= to.Value.Date);

            if (!string.IsNullOrEmpty(senderUserName))
                query = query.Where(s => s.sender.UserName == senderUserName);

            return (query.Select(s => new NotificationView()
            {
                AProcSerial = s.level != null ? s.level.ProcSerial : 0,
                InboxSerial = s.inbox.Serial,
                InboxLink = s.inbox.MessageUrl,
                Status = s.inbox.ActionStatusId,
                Title = s.inbox.Title,
                Comment = s.inbox.Comment,
                MessageType = s.inbox.TypeId,
                CreatedAt = s.inbox.CreatedAt,
                ActionAt = s.inbox.ActionAt,
                VisitAt = s.inbox.VisitedAt,

                SenderFullName = s.sender != null ? s.sender.FirstName + " " + s.sender.LastName : null,
                SenderUserName = s.sender != null ? s.sender.UserName : null,
                SenderLevelTitle = s.senderLevel != null ? s.senderLevel.Title : null,

                ReciverUserName = s.reciver != null ? s.reciver.UserName : null,
                ReciverFullName = s.reciver != null ? s.reciver.FirstName + " " + s.reciver.LastName : null,
                IsArchived = s.inbox.IsArchived

            }).OrderByDescending(s => s.CreatedAt).Skip(page * count).Take(count).AsEnumerable().DistinctBy(s => s.InboxSerial)
              .ToList(), query.Count());
        }


        private IQueryable<NotificationView> GetNotificatonsQuery(bool justArchived, string msgType, string title,
            DateTime? from, DateTime? to, string senderUserName, bool showUnvisiteds, bool showVisiteds, bool showCompletedNotifications)
        {
            var statuses = new List<string>();
            if (!justArchived)
            {
                if (showUnvisiteds) statuses.Add(NotificationActionStatuses.NEW);
                if (showVisiteds) statuses.Add(NotificationActionStatuses.VISITED);
                if (showCompletedNotifications)
                {
                    statuses.Add(NotificationActionStatuses.APRV);
                    statuses.Add(NotificationActionStatuses.CLOSED);
                    statuses.Add(NotificationActionStatuses.FORWARD);
                    statuses.Add(NotificationActionStatuses.REFERBACK);
                    statuses.Add(NotificationActionStatuses.RJCT);
                }
            }

            var query = from notification in db.Notifications

                        join level in db.AProcLevels on notification.ToAPLevelSerial equals level.Serial into ls
                        from toLevel in ls.DefaultIfEmpty()

                            //join sb in db.Notifications on notification.SenderSerial equals sb.Serial into sbs
                            //from senderInbox in sbs.DefaultIfEmpty()

                        join sl in db.AProcLevels on notification.FromAPLevelSerial equals sl.Serial into sls
                        from fromLevel in sls.DefaultIfEmpty()

                        join fromUser in db.ZUsers on notification.FromUserName equals fromUser.UserName


                        where notification.ToUserName == accessService.UserName
                           && notification.CompanyId == accessService.CompanyId


                        select new { inbox = notification, toLevel, fromLevel, fromUser };

            query = query.Where(s => s.inbox.IsArchived == justArchived);

            if (statuses.Any())
            {
                query = query.Where(s => statuses.Contains(s.inbox.ActionStatusId));
            }

            if (!string.IsNullOrEmpty(msgType))
            {
                query = query.Where(s => s.inbox.TypeId == msgType);
            }

            if (!string.IsNullOrEmpty(title))
            {
                query = query.Where(s => s.inbox.Title.Contains(title));
            }

            if (from.HasValue)
            {
                query = query.Where(s => s.inbox.CreatedAt.Date >= from.Value.Date);
            }

            if (to.HasValue)
            {
                query = query.Where(s => s.inbox.CreatedAt.Date <= to.Value.Date);
            }

            if (!string.IsNullOrEmpty(senderUserName))
            {
                query = query.Where(s => s.fromUser.UserName == senderUserName);
            }

            var q = query.Select(s => new NotificationView()
            {
                AProcSerial = s.toLevel != null ? s.toLevel.ProcSerial : 0,
                InboxSerial = s.inbox.Serial,
                InboxLink = s.inbox.MessageUrl,
                Status = s.inbox.ActionStatusId,
                Title = s.inbox.Title,
                Comment = s.inbox.Comment,
                MessageType = s.inbox.TypeId,
                CreatedAt = s.inbox.CreatedAt,
                ActionAt = s.inbox.ActionAt,
                VisitAt = s.inbox.VisitedAt,

                SenderFullName = s.fromUser != null ? s.fromUser.FirstName + " " + s.fromUser.LastName : null,
                SenderUserName = s.fromUser != null ? s.fromUser.UserName : null,
                SenderLevelTitle = s.fromLevel != null ? s.fromLevel.Title : null,

                IsArchived = s.inbox.IsArchived
            })
                .OrderByDescending(s => s.CreatedAt);
            return q;
        }


        public IList<NotificationView> GetNotificatons(bool justArchived, string msgType, string title, DateTime? from, DateTime? to, string senderUserName, bool showUnvisiteds, bool showVisiteds, bool showCompletedNotifications, int skip = 0, int count = 100)
        {
            var q = GetNotificatonsQuery(justArchived, msgType, title, from, to, senderUserName, showUnvisiteds, showVisiteds, showCompletedNotifications);
            return q.Skip(skip).Take(count).ToList();
        }

        public async Task<IList<NotificationView>> GetNotificatonsAsync(bool justArchived, string msgType, string title, DateTime? from, DateTime? to, string senderUserName, bool showUnvisiteds, bool showVisiteds, bool showCompletedNotifications, int skip = 0, int count = 100)
        {
            var q = GetNotificatonsQuery(justArchived, msgType, title, from, to, senderUserName, showUnvisiteds, showVisiteds, showCompletedNotifications);
            return await q.Skip(skip).Take(count).ToListAsync();
        }

        public int GetNotificatonsCount(bool justArchived, string msgType, string title, DateTime? from, DateTime? to, string senderUserName, bool showUnvisiteds, bool showVisiteds, bool showCompletedNotifications)
        {
            var q = GetNotificatonsQuery(justArchived, msgType, title, from, to, senderUserName, showUnvisiteds, showVisiteds, showCompletedNotifications);
            return q.Count();
        }


        public (IList<NotificationView>, int) UserNotificatonList(bool justArchived, string msgType, string title, DateTime? from, DateTime? to, string senderUserName, bool showUnVisiteds, bool showVisiteds, bool showDonedNotifications, int count)
        {
            var q = GetNotificatonsQuery(justArchived, msgType, title, from, to, senderUserName, showUnVisiteds, showVisiteds, showDonedNotifications);
            return (q.Take(count).ToList(), q.Count());
        }

        public IList<NotificationView> UserSentNotificatonList(bool justArchived, string msgType, string title,
           DateTime? from, DateTime? to, string reciverUserName, bool showUnVisiteds, bool showVisiteds, bool showDonedNotifications, int count = 100)
        {
            var statuses = new List<string>();
            if (showUnVisiteds) statuses.Add(NotificationActionStatuses.NEW);
            if (showVisiteds) statuses.Add(NotificationActionStatuses.VISITED);
            if (showDonedNotifications)
            {
                statuses.Add(NotificationActionStatuses.APRV);
                statuses.Add(NotificationActionStatuses.CLOSED);
                statuses.Add(NotificationActionStatuses.FORWARD);
                statuses.Add(NotificationActionStatuses.REFERBACK);
                statuses.Add(NotificationActionStatuses.RJCT);
            }
            var query = (from notification in db.Notifications

                         join level in db.AProcLevels on notification.ToAPLevelSerial equals level.Serial into ls
                         from currentLevel in ls.DefaultIfEmpty()

                         join sb in db.Notifications on notification.SenderSerial equals sb.Serial into sbs
                         from senderInbox in sbs.DefaultIfEmpty()

                         join sl in db.AProcLevels on senderInbox.ToAPLevelSerial equals sl.Serial into sls
                         from senderLevel in sls.DefaultIfEmpty()

                         join tu in db.ZUsers on notification.ToUserName equals tu.UserName into tus
                         from reciver in tus.DefaultIfEmpty()

                         join su in db.ZUsers on senderInbox.ToUserName equals su.UserName into sus
                         from sender in sus.DefaultIfEmpty()

                         join fu in db.ZUsers on notification.FromUserName equals fu.UserName into fus
                         from fromUser in fus.DefaultIfEmpty()


                         where notification.FromUserName == accessService.UserName && notification.CompanyId == accessService.CompanyId
                               && statuses.Contains(notification.ActionStatusId)


                         select new
                         {
                             inbox = notification,
                             level = currentLevel,
                             senderInbox = senderInbox,
                             senderLevel = senderLevel,
                             reciver = reciver,
                             sender = fromUser

                         });

            if (justArchived)
                query = query.Where(s => s.inbox.IsArchived);
            else
                query = query.Where(s => !s.inbox.IsArchived);

            if (!string.IsNullOrEmpty(msgType))
                query = query.Where(s => s.inbox.TypeId == msgType);
            else
                query = query.Where(s => s.inbox.TypeId != Core.NotificationTypes.SMS);

            if (!string.IsNullOrEmpty(title))
                query = query.Where(s => s.inbox.Title.Contains(title));

            if (from.HasValue)
                query = query.Where(s => s.inbox.CreatedAt.Date >= from.Value.Date);

            if (to.HasValue)
                query = query.Where(s => s.inbox.CreatedAt.Date <= to.Value.Date);

            if (!string.IsNullOrEmpty(reciverUserName))
                query = query.Where(s => s.reciver.UserName == reciverUserName);

            return query.Select(s => new NotificationView()
            {
                AProcSerial = s.level != null ? s.level.ProcSerial : 0,
                InboxSerial = s.inbox.Serial,
                InboxLink = s.inbox.MessageUrl,
                Status = s.inbox.ActionStatusId,
                Title = s.inbox.Title,
                Comment = s.inbox.Comment,
                MessageType = s.inbox.TypeId,
                CreatedAt = s.inbox.CreatedAt,
                ActionAt = s.inbox.ActionAt,
                VisitAt = s.inbox.VisitedAt,

                SenderFullName = s.sender != null ? s.sender.FirstName + " " + s.sender.LastName : null,
                SenderUserName = s.sender != null ? s.sender.UserName : null,
                SenderLevelTitle = s.senderLevel != null ? s.senderLevel.Title : null,

                ReciverUserName = s.reciver != null ? s.reciver.UserName : null,
                ReciverFullName = s.reciver != null ? s.reciver.FirstName + " " + s.reciver.LastName : null,
                IsArchived = s.inbox.IsArchived

            }).OrderByDescending(s => s.CreatedAt).Take(count).AsEnumerable().DistinctBy(s => s.InboxSerial)
              .ToList();
        }

        public IList<UserNotificatiosView> UserNotifications()
        {
            var query = from i in db.Notifications
                        join l in db.AProcLevels on i.ToAPLevelSerial equals l.Serial
                        join p in db.AProcesses on l.ProcSerial equals p.Serial
                        join u in db.ZUsers on i.FromUserName equals u.UserName into tus
                        from sender in tus.DefaultIfEmpty()
                        where p.CompanyId == accessService.CompanyId && i.ToUserName == accessService.UserName
                        && i.TypeId != Core.NotificationTypes.SMS && i.CompanyId == accessService.CompanyId
                        orderby i.CreatedAt descending
                        select new UserNotificatiosView
                        {
                            Title = i.Title,
                            CreatedAt = i.CreatedAt,
                            CreatedBy = sender != null ? sender.FirstName + " " + sender.LastName : null,
                            Comment = i.Comment,
                            InboxLink = i.MessageUrl,
                            Status = i.ActionStatusId
                        };

            return query.Take(50).ToList();
        }

        public Notification InsertNotification(long? senderSerial, AProcess aProce, string statusId, int levelSerial, string assignedUserName, bool isArchived,
          string fromUserName, string comment = "", DateTime? actionAt = null, string title = "", string type = Core.NotificationTypes.TASK)
        {
            if (string.IsNullOrEmpty(title)) title = aProce.ObjectTitle;

            var notification = new Notification()
            {
                ToAPLevelSerial = levelSerial,
                CompanyId = accessService.CompanyId,
                Comment = comment,
                FromUserName = fromUserName,
                ActionStatusId = statusId,
                TypeId = type,
                MessageUrl = aProce.ObjectUrl,
                Title = title,
                SenderSerial = senderSerial,
                ToUserName = assignedUserName,
                ActionAt = actionAt,
                IsArchived = isArchived,
            };

            db.Notifications.Add(notification);
            db.SaveChanges();
            return notification;
        }

        public void SendNotification(int? companyId, string fromUserName, string toUserName, string title, string body)
        {
            var notification = new Notification()
            {
                CompanyId = companyId.HasValue ? companyId.Value : accessService.CompanyId,
                TypeId = Core.NotificationTypes.NOTIFY,
                ActionStatusId = NotificationActionStatuses.NEW,
                Title = title,
                Comment = body,
                FromUserName = fromUserName,
                ToUserName = toUserName,
                CreatedBy = fromUserName,
                CreatedAt = db.GetDate()
            };

            db.Add(notification);
            db.SaveChanges();
        }

        public NotificatonActionView UserNotificationActionInitByAProcSerial(int? aprocSerial)
        {
            if (aprocSerial is null) return null;

            var inboxActionView = (from i in db.Notifications

                                   join currentLevel in db.AProcLevels on i.ToAPLevelSerial equals currentLevel.Serial

                                   join aproc in db.AProcesses on currentLevel.ProcSerial equals aproc.Serial

                                   join sender in db.Notifications on i.SenderSerial equals sender.Serial

                                   join senderUser in db.ZUsers on sender.ToUserName equals senderUser.UserName

                                   join senderLevel in db.AProcLevels on sender.ToAPLevelSerial equals senderLevel.Serial

                                   where
                                   i.ToUserName == accessService.UserName
                                   && i.TypeId == Core.NotificationTypes.TASK
                                   && (i.ActionStatusId == NotificationActionStatuses.NEW || i.ActionStatusId == NotificationActionStatuses.VISITED)
                                   && currentLevel.ProcSerial == aprocSerial
                                   && i.CompanyId == accessService.CompanyId

                                   select new NotificatonActionView()
                                   {
                                       AProcTitle = aproc.Title,
                                       NotificationTitle = i.Title,
                                       AProcSerial = aproc.Serial,
                                       AprocActionType = aproc.ActionId,

                                       NotificationSerial = i.Serial,

                                       CurrentLevelSerial = currentLevel.Serial,
                                       CurrentLevelTitle = currentLevel.Title,

                                       SenderFullName = senderUser.FirstName + " " + senderUser.LastName,
                                       SenderLevelSerial = senderLevel.Serial,
                                       SenderLevelTitle = senderLevel.Title,
                                       SenderUserName = senderUser.UserName,
                                       SystemTrigger = currentLevel.SystemTrigger,
                                       Comment = i.Comment
                                   }).FirstOrDefault();

            if (inboxActionView is null) return null;

            var levels = levelService.GetLevels(aprocSerial.Value).OrderBy(x => x.LevelCode).ToList();

            inboxActionView.PrevLevel = levelService.PrevLevelInfo(levels, inboxActionView.CurrentLevelSerial);
            inboxActionView.NextLevel = levelService.NextLevelInfo(levels, inboxActionView.CurrentLevelSerial);
            inboxActionView.FirstSenderInfo = levelService.FirstSenderInfo(aprocSerial.Value);

            MarkAsVisitNotification(inboxActionView.NotificationSerial);

            return inboxActionView;
        }


        public void MarkAsVisitNotification(long notificationSerial)
        {
            var inbox = db.Notifications.Where(s => s.Serial == notificationSerial).FirstOrDefault();

            if (inbox is null) return;
            if (inbox.VisitedAt is not null && inbox.ActionStatusId is NotificationActionStatuses.VISITED) return;

            inbox.ActionStatusId = NotificationActionStatuses.VISITED;
            inbox.VisitedAt = db.GetDate();

            db.Update(inbox);
            db.SaveChanges();
        }


        public void ToggleArchiveNotification(long notificationSerial)
        {
            var notification = db.Notifications.Where(s => s.Serial == notificationSerial).FirstOrDefault();
            if (notification is null) return;

            notification.IsArchived = !notification.IsArchived;
            notification.ArchivedAt = db.GetDate();

            db.Update(notification);
            db.SaveChanges();
        }


        private void UpdateNotification(Notification notification)
        {
            notification.CompanyId = accessService.CompanyId;
            db.Update(notification);
            db.SaveChanges();
        }


        public bool UserAccessToLevel(string userName, int levelSerial)
        {
            var chartUsers = from l in db.AProcLevels
                             join c in db.OrganizationCharts on l.ChartCode equals c.ChartCode
                             join cu in db.OrganizationChartUsers on c.ChartCode equals cu.ChartCode
                             where cu.UserName == userName && l.Serial == levelSerial && c.CompanyId == accessService.CompanyId
                             select cu;

            var q = from u in db.AProcUsers
                    where u.UserName == userName && u.ProcLevelSerial == levelSerial
                    select u;

            return q.Any() || chartUsers.Any();
        }


        public bool ForwardNotification(string reciverUsername, long notificationSerial, string comment)
        {
            var currentNotification = GetNotification(notificationSerial);
            if (currentNotification is null) return false;

            if (currentNotification.ActionStatusId != NotificationActionStatuses.NEW && currentNotification.ActionStatusId != NotificationActionStatuses.VISITED) return false;
            var currentLevelUsers = levelService.LevelUsers(currentNotification.ToAPLevelSerial.Value);
            if (currentLevelUsers == null) throw new CurrentLevelHasNotAnyUserError();

            var aproc = levelService.GetAProcByLevelSerial(currentNotification.ToAPLevelSerial.Value);
            if (aproc == null) throw new NotFoundAProcError();

            var action = NotificationActions.Resolve(serviceProvider, aproc.ActionId);
            if (action is null) throw new NotFoundAProcActionError();

            action.ForwardNotification(reciverUsername, notificationSerial, comment, aproc, currentNotification.Title);

            return false;
        }


        public void AproveInbox(Notification inbox, DateTime date)
        {
            inbox.ActionStatusId = NotificationActionStatuses.APRV;
            inbox.ActionAt = date;
            inbox.CompanyId = accessService.CompanyId;
            db.Update(inbox);
            db.SaveChanges();
        }


        public bool ReferBack(Notification currentInbox, List<AProcLevel> procLevels, AProcLevel currentLevel, AProcess aproc, LevelInfoView nextLevel,
            DateTime currentDate, string assignedUserName, string comment, IDbContextTransaction transaction)
        {
            if (levelService.IsFirstLevel(currentLevel.Serial, procLevels.Select(s => s.Serial).ToList()))
                throw new YouCantRefferToBackInFirstLevelError();

            if (currentLevel.SendMessageToAll)
            {
                // lock all other message                  
                var othersInboxes = OtherNotificationsBySenderSerial(currentInbox.SenderSerial.Value, currentInbox.Serial);
                foreach (var inbox in othersInboxes)
                {
                    inbox.ActionStatusId = NotificationActionStatuses.CLOSED;
                    inbox.CompanyId = accessService.CompanyId;
                    UpdateNotification(inbox);
                }
            }

            var previousLevel = levelService.PrevLevelInfo(procLevels, currentLevel.Serial);
            Notification newInbox = new Notification();

            var title = GetTitle(aproc, NotificationActionStatuses.REFERBACK, "");
            // get previous level and if is send message to all send to all again
            if (previousLevel.SendToAll == true)
                foreach (var user in levelService.LevelUsers(previousLevel.LevelSerial))
                {
                    newInbox = InsertNotification(currentInbox.Serial, aproc, NotificationActionStatuses.NEW, previousLevel.LevelSerial, user.UserName, false,
                        accessService.UserName, comment, title: title);
                }
            else
                newInbox = InsertNotification(currentInbox.Serial, aproc, NotificationActionStatuses.NEW, previousLevel.LevelSerial, assignedUserName, false,
                    accessService.UserName, comment, title: title);

            currentInbox.ActionStatusId = NotificationActionStatuses.REFERBACK;

            //if (!string.IsNullOrEmpty(comment))
            //    currentInbox.Comment = comment;

            currentInbox.ActionAt = currentDate;
            UpdateNotification(currentInbox);

            aproc.LastTaskSerial = newInbox?.Serial;
            db.Update(aproc);
            db.SaveChanges();

            transaction.Commit();
            return false;
        }



        private string GetTitle(AProcess aproc, string actionStatus, string previousTitle)
        {
            if (actionStatus == NotificationActionStatuses.FORWARD)
            {
                return previousTitle;
            }

            var auction = new TheAuction();
            var document = new TheDocument();

            string defaultText = "";
            string title = "";

            var actionId = aproc.ActionId.Split("-");

            var entity = actionId[0];
            var status = actionId[1];

            string entityTitle = GetEntityTitle(entity);
            string destinationStatusInFa = getDestinationStatusInFa(status, entity);


            if (actionStatus == NotificationActionStatuses.APRV)
            {
                defaultText = "درخواست تاييد " + entityTitle + " با شماره {0}";
            }
            else if (actionStatus == NotificationActionStatuses.REFERBACK || actionStatus == NotificationActionStatuses.RJCT)
            {
                if (entity == AProcActions.CNF)
                    defaultText = "بررسي مجدد " + entityTitle + " با شماره {0}";
                else
                    defaultText = "بررسي مجدد " + entityTitle + " با شماره {0} جهت {1}";
            }

            if (entity == AProcActions.EVENT)
            {
                document = db.Documents.Where(x => x.Serial == Convert.ToInt64(aproc.ObjectKey)).FirstOrDefault();
                title = string.Format(defaultText, document.Number, destinationStatusInFa);
            }
            else if (entity == AProcActions.AUC)
            {

                auction = db.Auctions.Where(x => x.AuctionId == Convert.ToInt64(aproc.ObjectKey)).FirstOrDefault();
                title = string.Format(defaultText, auction.AuctionNo, destinationStatusInFa);
            }
            else if (entity == AProcActions.CNF)
            {
                var cnf = db.Confirmations.Where(x => x.Serial == Convert.ToInt64(aproc.ObjectKey)).FirstOrDefault();
                if (cnf is null) return previousTitle;
                document = db.Documents.Where(x => x.Serial == cnf.DocumentSerial).FirstOrDefault();
                if (document is null) return previousTitle;
                title = string.Format(defaultText, document.Number);
            }



            return title;
        }

        private string getDestinationStatusInFa(string status, string entity)
        {
            switch (status)
            {
                case AProcActions.PUB:
                    return "انتشار";

                case AProcActions.CLOSE:
                    return entity == "EVENT" ? "بررسي پاسخ ها" : "بررسي پيشنهادات";

                case AProcActions.GRADE:
                    return "تاييد امتياز دهي";

                case AProcActions.AWARD:
                    return "اعلام برنده";

                case AProcActions.CMPL:
                    return "اتمام";
            }
            return "";
        }
        private string GetEntityTitle(string entity)
        {
            switch (entity)
            {
                case AProcActions.CNF:
                    return "كميسيون شناسايي منابع";
                case AProcActions.EVENT:
                    return "رويداد";
                case AProcActions.AUC:
                    return "مزايده";
            }
            return "";
        }

        // confirmation
        private string GetNotifyTitle(AProcess aproc, string actionStatus, string previousTitle)
        {
            if (actionStatus == NotificationActionStatuses.FORWARD)
            {
                return previousTitle;
            }

            var auction = new TheAuction();
            var document = new TheDocument();

            string destinationStatusInFa = "";
            string defaultText = "";
            string title = "";

            var actionId = aproc.ActionId.Split("-");

            var entity = actionId[0];
            var status = actionId[1];

            var entityTitle = entity == "EVENT" ? "رويداد" : "مزايده";
            //switch (entity)
            //{

            //}


            if (actionStatus == NotificationActionStatuses.APRV)
            {
                defaultText = "تبديل وضعيت " + entityTitle + "با شماره {0} به {1}";
            }
            else if (actionStatus == NotificationActionStatuses.REFERBACK || actionStatus == NotificationActionStatuses.RJCT)
            {
                defaultText = "بررسي مجدد " + entityTitle + " با شماره {0} جهت {1}";
            }

            switch (status)
            {
                case AProcActions.PUB:
                    destinationStatusInFa = "انتشار يافته";
                    break;
                case AProcActions.CLOSE:
                    destinationStatusInFa = entity == "EVENT" ? "بررسي پاسخ ها" : "بررسي پيشنهادات";
                    break;
                case AProcActions.GRADE:
                    destinationStatusInFa = "امتياز دهي شده";
                    break;
                case AProcActions.AWARD:
                    destinationStatusInFa = "اعلام برنده شده";
                    break;
                case AProcActions.CMPL:
                    destinationStatusInFa = "اتمام يافته";
                    break;
            }

            if (entity == "EVENT")
            {
                document = db.Documents.Where(x => x.Serial == Convert.ToInt64(aproc.ObjectKey)).FirstOrDefault();

                title = string.Format(defaultText, document.Number, destinationStatusInFa);
            }
            else if (entity == "AUC")
            {
                auction = db.Auctions.Where(x => x.AuctionId == Convert.ToInt64(aproc.ObjectKey)).FirstOrDefault();
                title = string.Format(defaultText, auction.AuctionNo, destinationStatusInFa);
            }

            return title;
        }

        // _______ ***************_________
        public void CheckNextLevelAccess(AProcess aproc, LevelInfoView nextLevel, string selectedUser)
        {
            var action = NotificationActions.Resolve(serviceProvider, aproc.ActionId);
            if (action is null) throw new NotFoundAProcActionError();

            action.CheckNextLevelAccess(aproc, nextLevel, selectedUser);
        }


        public bool Approve(Notification currentInbox, List<AProcLevel> procLevels, AProcLevel currentLevel, AProcess aproc, LevelInfoView nextLevel,
            DateTime currentDate, string assignedUserName, string comment, IDbContextTransaction transaction)
        {
            AproveInbox(currentInbox, currentDate);
            Notification newInbox = new Notification();

            if (nextLevel == null) // is last level
            {
                var notifyTitle = GetNotifyTitle(aproc, NotificationActionStatuses.APRV, currentInbox.Title);
                if (currentLevel.SendMessageToAll)
                {
                    //check is last accept
                    //if is last accept update document and tasks
                    if (IsAcceptedAllNotificationsSenderSerial(currentInbox.SenderSerial.Value, currentInbox.Serial))
                    {
                        aProcActionService.RunApproveAProcAction(aproc, currentDate, comment);
                        SendMsgToFirstUserStartedAProc(currentInbox, aproc, procLevels.Select(s => s.Serial).ToList(), comment, title: notifyTitle);
                        transaction.Commit();
                        return true;
                    }
                }
                else
                {
                    aProcActionService.RunApproveAProcAction(aproc, currentDate, comment);
                    SendMsgToFirstUserStartedAProc(currentInbox, aproc, procLevels.Select(s => s.Serial).ToList(), comment, title: notifyTitle);
                    transaction.Commit();
                    return true;
                }
            }
            else
            {
                CheckNextLevelAccess(aproc, nextLevel, assignedUserName);
                var notifyTitle = GetTitle(aproc, NotificationActionStatuses.APRV, currentInbox.Title);
                if (currentLevel.SendMessageToAll)
                {
                    if (IsAcceptedAllNotificationsSenderSerial(currentInbox.SenderSerial.Value, currentInbox.Serial))
                    {
                        if (nextLevel.SendToAll == true)
                        {
                            //send to all level users again                 
                            foreach (var user in levelService.LevelUsers(nextLevel.LevelSerial))
                            {
                                newInbox = InsertNotification(currentInbox.Serial, aproc, NotificationActionStatuses.NEW, nextLevel.LevelSerial, user.UserName, false, accessService.UserName, comment, title: notifyTitle);
                            }
                        }
                        else
                        {
                            newInbox = InsertNotification(currentInbox.Serial, aproc, NotificationActionStatuses.NEW, nextLevel.LevelSerial, assignedUserName, false, accessService.UserName, comment, title: notifyTitle);
                        }
                        aproc.LastTaskSerial = newInbox?.Serial;
                        db.Update(aproc);
                        db.SaveChanges();

                        transaction.Commit();
                        return false;
                    }
                }
                else
                {
                    if (nextLevel.SendToAll == true)
                    {
                        //send to all level users again                 
                        foreach (var user in levelService.LevelUsers(nextLevel.LevelSerial))
                        {
                            newInbox = InsertNotification(currentInbox.Serial, aproc, NotificationActionStatuses.NEW, nextLevel.LevelSerial, user.UserName, false, accessService.UserName, comment, title: notifyTitle);
                        }
                    }
                    else
                    {
                        newInbox = InsertNotification(currentInbox.Serial, aproc, NotificationActionStatuses.NEW, nextLevel.LevelSerial, assignedUserName, false, accessService.UserName, comment, title: notifyTitle);
                    }
                    aproc.LastTaskSerial = newInbox?.Serial;
                    db.Update(aproc);
                    db.SaveChanges();

                    transaction.Commit();
                    return false;
                }
            }
            transaction.Commit();
            return false;
        }


        public bool ActionOnNotification(string action, string currentUserName, int procSerial, int currentLevelSerial, long notificationSerial,
           string comment, string assignedUserName)
        {
            var currentNotification = GetNotification(notificationSerial);
            if (currentNotification == null) throw new NotFoundInboxError();
            if (currentNotification.ToUserName != currentUserName) throw new InboxNotAssignedToYouError();
            var procLevels = levelService.GetLevels(procSerial).OrderBy(s => s.LevelCode).ToList();
            //if (currentLevelSerial != procLevels.First().Serial)
            //    if (!UserAccessToLevel(currentUserName, currentLevelSerial) ) throw new UserIsNotInLevelsError();
            var currentDate = db.GetDate();
            var currentLevel = levelService.GetAProcLevel(currentLevelSerial);
            var nextLevel = levelService.NextLevelInfo(procLevels, currentNotification.ToAPLevelSerial.Value);
            var aproc = levelService.GetAProcByLevelSerial(currentLevelSerial);

            using var transaction = db.Database.BeginTransaction();
            try
            {
                switch (action)
                {
                    case NotificationActionStatuses.APRV:
                        return Approve(currentNotification, procLevels, currentLevel, aproc, nextLevel, currentDate, assignedUserName, comment, transaction);

                    case NotificationActionStatuses.REFERBACK:
                        return ReferBack(currentNotification, procLevels, currentLevel, aproc, nextLevel, currentDate, assignedUserName, comment, transaction);

                    default:
                        return false;
                }
            }
            catch
            {
                transaction.Rollback();
                throw;
            }
        }



        public void RejectNotification(string currentUserName, int procSerial, int currentLevelSerial, long notificationSerial, string comment)
        {
            var currentDate = db.GetDate();
            var currentNotification = GetNotification(notificationSerial);
            var procLevels = levelService.GetLevels(procSerial).OrderBy(s => s.LevelCode).ToList();
            var aproc = levelService.GetAProcByLevelSerial(currentLevelSerial);

            using var transaction = db.Database.BeginTransaction();
            try
            {
                if (currentLevelSerial != procLevels.Select(s => s.Serial).First())
                    if (!UserAccessToLevel(currentUserName, currentLevelSerial))
                        throw new UserIsNotInLevelsError();

                currentNotification.ActionStatusId = NotificationActionStatuses.RJCT;
                UpdateNotification(currentNotification);

                aproc.LastTaskSerial = null;
                db.Update(aproc);
                db.SaveChanges();

                var title = GetTitle(aproc, NotificationActionStatuses.RJCT, "");

                if (currentLevelSerial != procLevels.First().Serial)
                    SendMsgToFirstUserStartedAProc(currentNotification, aproc, procLevels.Select(s => s.Serial).ToList(), comment, title: title);

                var othersInboxes = OtherNotificationsBySenderSerial(currentNotification.SenderSerial.Value, notificationSerial);
                foreach (var notif in othersInboxes)
                {
                    notif.ActionStatusId = NotificationActionStatuses.CLOSED;
                    UpdateNotification(notif);
                }

                aProcActionService.RunRejectAProcAction(aproc, currentDate);

                transaction.Commit();
            }
            catch
            {
                transaction.Rollback();
                throw;
            }
        }


        public bool IsAcceptedAllNotificationsSenderSerial(long senderSerial, long currentNotificationSerial)
        {
            var otherInboxesInSameLevel = OtherNotificationsBySenderSerial(senderSerial, currentNotificationSerial);

            var acceptedCount = otherInboxesInSameLevel.Where(s => s.ActionStatusId == NotificationActionStatuses.APRV || s.ActionStatusId == NotificationActionStatuses.FORWARD).Count();

            return otherInboxesInSameLevel.Count == acceptedCount;
        }


        public IList<Notification> OtherNotificationsBySenderSerial(long senderSerial, long currentNotificationSerial)
        {
            return db.Notifications.Where(s => s.SenderSerial == senderSerial && s.Serial != currentNotificationSerial).ToList();
        }


        private void SendMsgToFirstUserStartedAProc(Notification currentInbox, AProcess aproc, List<int> levels, string comment, string title = "")
        {
            if (levels.Count > 0)
            {
                var firstLevel = levels[0];
                var firstUserUserName = FirstUserStartedAProc(aproc.Serial);

                if (firstUserUserName is null)
                    throw new DestinationUserNameIsEmty();

                InsertNotification(currentInbox.Serial, aproc, NotificationActionStatuses.NEW, firstLevel, firstUserUserName,
                    false, accessService.UserName, comment, type: Core.NotificationTypes.NOTIFY, title: title);
            }
        }


        public string FirstUserStartedAProc(int aprocSerial)
        {
            var query = from a in db.AProcesses

                        join l in db.AProcLevels on a.Serial equals l.ProcSerial

                        join i in db.Notifications on l.Serial equals i.ToAPLevelSerial

                        where a.Serial == aprocSerial && i.SenderSerial == null

                        select i;


            return query.FirstOrDefault()?.ToUserName;
        }


        public void ChangeNotificationStatus(Notification notification, string statusId)
        {
            notification.ActionStatusId = statusId;
            notification.CompanyId = accessService.CompanyId;

            db.Update(notification);
            db.SaveChanges();
        }

        public int SendPermissionNotification(string title, string message)
        {
            var adminRoles = (from p in db.Projects
                              join t in db.ProjectTeams on p.Serial equals t.ProjectSerial
                              join r in db.ProjectTeamRoles on t.Serial equals r.ProjectTeamSerial
                              join u in db.ProjectTeamUsers on t.Serial equals u.ProjectTeamSerial
                              where p.CompanyId == accessService.CompanyId && r.RoleId == ProjectRoles.ADMIN
                              select u).Distinct().ToList();

            adminRoles.ForEach((Action<Core.ProjectTeamUser>)(x =>
            {
                var notification = new Notification()
                {
                    CompanyId = accessService.CompanyId,
                    Comment = message,
                    Title = title,
                    FromUserName = accessService.UserName,
                    ActionStatusId = NotificationActionStatuses.NEW,
                    TypeId = Core.NotificationTypes.NOTIFY,
                    ToUserName = x.UserName,

                };
                db.Add(notification);
            }));

            db.SaveChanges();

            return adminRoles.Count;
        }

        public List<Notification> PermissionNotifications()
        {
            return db.Notifications.Where(x => x.CompanyId == accessService.CompanyId && x.FromUserName == accessService.UserName && x.TypeId == AProc.Core.NotificationTypes.NOTIFY).ToList();
        }
    }
}