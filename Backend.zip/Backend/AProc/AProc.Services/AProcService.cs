﻿using AProc.Core;
using AProc.Core.Entities;
using AProc.Core.Views;
using Attcahment.Core;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using Tamin.Core;
using Tamin.Core.Errors;

namespace AProc.Services
{
    public class AProcService : IAProcService
    {
        private readonly AProcDbContext db;
        private readonly IAProcDefService aProcDefService;
        private readonly IAccessService accessService;
        private readonly IAProcActionService aprocActionService;
        private readonly Core.INotificationService notificationService;
        private readonly IServiceProvider serviceProvider;
        private readonly ILevelService levelService;


        public AProcService(AProcDbContext context, IAProcDefService aProcDefService, IAccessService accessService,
           Core.INotificationService notificationService, IServiceProvider serviceProvider, IAProcActionService aprocActionService,
            ILevelService levelService)
        {
            db = context;
            this.aProcDefService = aProcDefService;
            this.accessService = accessService;
            this.aprocActionService = aprocActionService;
            this.notificationService = notificationService;
            this.serviceProvider = serviceProvider;
            this.levelService = levelService;
        }


        public void ValidateUserAccess(string userName, int aprocSerial)
        {
            if (userName is null) return;
            if (aprocSerial == 0) return;

            var aproc = db.AProcesses.Where(x => x.Serial == aprocSerial).FirstOrDefault();
            if (aproc is null) throw new NotFoundAProcError();

            switch (aproc.ObjectCalss)
            {
                case ObjectClasses.Project:

                    switch (aproc.ActionId)
                    {
                        case AProcActions.CNF_SUBMIT:
                            CheckUserAccessInCnf(userName, aproc.ObjectKey);
                            break;
                    }
                    break;

                case ObjectClasses.Document:
                    CheckUserAccessInEvent(userName, aproc.ObjectKey);
                    break;


                case ObjectClasses.Discovery:
                    // CheckUserAccessEvaluation(userName, aproc.ObjectKey);
                    break;

                case ObjectClasses.Auction:

                    break;

                case ObjectClasses.Request:

                    break;

            }
        }

        private void CheckUserAccessInCnf(string userName, string cnfSerial)
        {
            if (userName is null) return;
            if (string.IsNullOrEmpty(cnfSerial)) throw new BadRequestError();
            var key = Common.Convert.ToInt64(cnfSerial).Value;

            var confirmation = db.Confirmations.Where(x => x.Serial == key).FirstOrDefault();
            if (confirmation is null) throw new NotFoundError();

            var document = db.Documents.Where(x => x.Serial == confirmation.DocumentSerial).FirstOrDefault();
            if (document is null) throw new DocumentNotFoundError();
            var project = db.Projects.Where(x => x.Serial == document.ProjectSerial).FirstOrDefault();
            if (project is null) throw new DocumentNotFoundError();

            if (accessService.IsUserOwnerInProject(project.Serial, userName)) return;
            accessService.AddUserToProjectMemberOwner(project.Serial, userName);
        }

        private void CheckUserAccessEvaluation(string userName, string evaluationSerial)
        {
            if (userName is null) return;
            if (string.IsNullOrEmpty(evaluationSerial)) throw new BadRequestError();
            var key = Common.Convert.ToInt64(evaluationSerial).Value;

            var confirmation = db.Confirmations.Where(x => x.Serial == key).FirstOrDefault();
            if (confirmation is null) throw new NotFoundError();

            var document = db.Documents.Where(x => x.Serial == confirmation.DocumentSerial).FirstOrDefault();
            if (document is null) throw new DocumentNotFoundError();
            var project = db.Projects.Where(x => x.Serial == document.ProjectSerial).FirstOrDefault();
            if (project is null) throw new DocumentNotFoundError();

            if (accessService.IsUserOwnerInProject(project.Serial, userName)) return;
            accessService.AddUserToProjectMemberOwner(project.Serial, userName);
        }

        private void CheckUserAccessInEvent(string userName, string documentSerial)
        {
            if (userName is null) return;
            if (string.IsNullOrEmpty(documentSerial)) throw new BadRequestError();
            var key = Common.Convert.ToInt64(documentSerial).Value;

            var document = db.Documents.Where(x => x.Serial == key).FirstOrDefault();
            if (document is null) throw new NotFoundError();

            var project = db.Projects.Where(x => x.Serial == document.ProjectSerial).FirstOrDefault();
            if (project is null) throw new DocumentNotFoundError();

            if (accessService.IsUserOwnerInProject(project.Serial, userName)) return;
            accessService.AddUserToProjectMemberOwner(project.Serial, userName);
        }



        public void StartAProc(int? aprocSerial, string currentUsername, string selectedUsername, string comment, string title = "", bool makeNew = false)
        {
            if (aprocSerial.HasValue)
            {
                var aproc = db.AProcesses.Where(s => s.Serial == aprocSerial && s.CompanyId == accessService.CompanyId).FirstOrDefault();
                var procLevels = AProcLevels(aprocSerial.Value).DistinctBy(s => s.AProcLevel.Serial).OrderBy(x => x.AProcLevel.LevelCode).ToList();
                var currentDate = db.GetDate();
                if (!procLevels.Any()) throw new AprocLevelsIsEmptyError();

                using var transaction2 = db.Database.BeginTransaction();
                try
                {
                    var firstLevel = procLevels.First();
                    var firstInbox = notificationService.InsertNotification(null, aproc, NotificationActionStatuses.APRV, firstLevel.AProcLevel.Serial, accessService.UserName,
                                                                            false, null, "شروع فرآيند", currentDate);
                    var nextLevel = procLevels[1];
                    var levelInfoView = new LevelInfoView()
                    {
                        LevelSerial = nextLevel.AProcLevel.Serial,
                        ProcSerial = nextLevel.AProcLevel.ProcSerial,
                    };

                    notificationService.CheckNextLevelAccess(aproc, levelInfoView, selectedUsername);

                    if (nextLevel.AProcLevel.SendMessageToAll)
                    {
                        foreach (var user in nextLevel.AProcUsers)
                        {
                            notificationService.InsertNotification(firstInbox.Serial, aproc, NotificationActionStatuses.NEW, procLevels[1].AProcLevel.Serial, user.UserName, false, currentUsername, comment, null, title);
                        }
                    }
                    else
                    {
                        if (string.IsNullOrEmpty(selectedUsername)) throw new DestinationUserNameIsEmty();
                        notificationService.InsertNotification(firstInbox.Serial, aproc, NotificationActionStatuses.NEW, procLevels[1].AProcLevel.Serial, selectedUsername, false, currentUsername, comment, null, title);
                    }

                    transaction2.Commit();
                }
                catch
                {
                    transaction2.Rollback();
                    throw;
                }
            }

        }



        public IList<AProcLevelView> AProcLevels(int aprocSerial)
        {
            var query = (from l in db.AProcLevels

                         where l.ProcSerial == aprocSerial

                         select new
                         {
                             AProcLevel = l,
                             AProcUsers = (from users in db.AProcUsers
                                           join le in db.AProcLevels on users.ProcLevelSerial equals le.Serial
                                           where le.ProcSerial == aprocSerial && le.Serial == l.Serial
                                           select users).ToList()
                         }).AsNoTracking();

            var result = query.Select(s => new AProcLevelView()
            {
                AProcLevel = s.AProcLevel,
                AProcUsers = s.AProcUsers.ToList()
            }).ToList().Distinct().ToList();

            return result;
        }

        public int? GetAProceSerialByLevelSerial(int? levelSerial)
        {
            if (levelSerial is null) return null;
            var level = db.AProcLevels.Where(s => s.Serial == levelSerial.Value).FirstOrDefault();
            if (level is null) return null;
            return level.ProcSerial;
        }

        public AProcReportView AProcReport(string objectKey, string objectClass, string actionId)
        {
            var aproc = db.AProcesses.Where(s => s.ObjectKey == objectKey && s.ObjectCalss == objectClass && s.ActionId == actionId).OrderByDescending(s => s.Serial).FirstOrDefault();
            if (aproc is null) return null;

            var levels = db.AProcLevels.Where(s => s.ProcSerial == aproc.Serial && s.IsPrintable).OrderBy(s => s.LevelCode).ToList();
            var flows = notificationService.NotificationFlowByAprocSerial(aproc.Serial, null, true).OrderByDescending(x => x.InboxSerial).ToList();

            var lastStarter = flows.Where(s => s.SenderLevelTitle == null).FirstOrDefault();
            if (lastStarter is null) throw new RecordNotFoundError();

            var lastStarterIndex = flows.IndexOf(lastStarter);

            flows = flows.Where((n, index) => index <= lastStarterIndex && (n.Status != NotificationActionStatuses.NEW || n.Status != NotificationActionStatuses.VISITED) && n.IsPrintable).ToList();
            if (!flows.Any()) throw new RecordNotFoundError();

            return new AProcReportView()
            {
                AProc = aproc,
                Levels = levels,
                Flows = flows
            };
        }

        public AProcReportView AprocReportView(int aprocSerial)
        {
            var aproc = db.AProcesses.Where(s => s.Serial == aprocSerial).FirstOrDefault();
            if (aproc is null) return null;

            var levels = db.AProcLevels.Where(s => s.ProcSerial == aproc.Serial && s.IsPrintable).OrderBy(s => s.LevelCode).ToList();
            var flows = notificationService.NotificationFlowByAprocSerial(aproc.Serial, null, true).OrderByDescending(x => x.InboxSerial).ToList();

            var lastStarter = flows.Where(s => s.SenderLevelTitle == null).FirstOrDefault();
            if (lastStarter is null) throw new RecordNotFoundError();

            var lastStarterIndex = flows.IndexOf(lastStarter);

            //for (int i = 0; i < flows.Count - 1; i++)
            //{
            //    if (flows[i].Status == Core.NotificationStatuses.REFERBACK && flows[i].Status == Core.NotificationStatuses.REJECTED)
            //    {
            //        if (flows[i + 1] is not null)
            //        {
            //            flows[i].ReciverComment = flows[i + 1].Comment;
            //        }
            //    }
            //}

            flows = flows.Where((n, index) => index <= lastStarterIndex && (n.Status != NotificationActionStatuses.NEW || n.Status != NotificationActionStatuses.VISITED) && n.IsPrintable).ToList();
            if (!flows.Any()) throw new RecordNotFoundError();

            var flowReports = new List<NotificationView>();
            foreach (var level in levels)
            {
                var f = flows.Where(s => s.LevelSerial == level.Serial).OrderByDescending(s => s.ActionAt).FirstOrDefault();
                if (f != null)
                    flowReports.Add(f);
            }

            return new AProcReportView()
            {
                AProc = aproc,
                Levels = levels,
                Flows = flowReports
            };
        }


        public DocumentAProcView DocumentAProcView(long documentSerial)
        {
            var query = from d in db.Documents

                        join pa in db.AProcesses on d.PublishAProcSerial equals pa.Serial into publishAproce
                        from pa in publishAproce.DefaultIfEmpty()

                        join ca in db.AProcesses on d.CloseAProcSerial equals ca.Serial into closeAproce
                        from ca in closeAproce.DefaultIfEmpty()

                        join ga in db.AProcesses on d.GradeAProcSerial equals ga.Serial into gradeAproce
                        from ga in gradeAproce.DefaultIfEmpty()

                        join aa in db.AProcesses on d.AwardAProcSerial equals aa.Serial into awardAproce
                        from aa in awardAproce.DefaultIfEmpty()

                        join bda in db.AProcesses on d.BDraftAProcSerial equals bda.Serial into bDraftAproce
                        from bda in bDraftAproce.DefaultIfEmpty()

                        join bpa in db.AProcesses on d.BPublishAProcSerial equals bpa.Serial into bPubAproce
                        from bpa in bPubAproce.DefaultIfEmpty()

                        join bca in db.AProcesses on d.BCloseAProcSerial equals bca.Serial into bCloseAproce
                        from bca in bCloseAproce.DefaultIfEmpty()

                        join bga in db.AProcesses on d.BGradeAProcSerial equals bga.Serial into bGradeAproce
                        from bga in bGradeAproce.DefaultIfEmpty()

                        join cnfA in db.AProcesses on d.CNFAProcSerial equals cnfA.Serial into cnfAproc
                        from cnfA in cnfAproc.DefaultIfEmpty()

                        where d.Serial == documentSerial

                        select new DocumentAProcView()
                        {
                            PublishAProcSerial = d.PublishAProcSerial,
                            PublishAProcTitle = pa == null ? null : pa.Title,
                            PublishAProcVersion = pa == null ? null : pa.Version,
                            PublishLevels = d.PublishAProcSerial == null ? null : db.AProcLevels.Where(s => s.ProcSerial == d.PublishAProcSerial).OrderBy(s => s.LevelCode)
                            .Select(s => new LevelInfoView()
                            {
                                LevelSerial = s.Serial,
                                LevelTitle = s.Title,
                                SendToAll = s.SendMessageToAll
                            }).ToList(),

                            CloseAProcSerial = d.CloseAProcSerial,
                            CloseAProcTitle = ca == null ? null : ca.Title,
                            CloseAProcVersion = ca == null ? null : ca.Version,
                            CloseLevels = d.CloseAProcSerial == null ? null : db.AProcLevels.Where(s => s.ProcSerial == d.CloseAProcSerial).OrderBy(s => s.LevelCode)
                            .Select(s => new LevelInfoView()
                            {
                                LevelSerial = s.Serial,
                                LevelTitle = s.Title,
                                SendToAll = s.SendMessageToAll
                            }).ToList(),

                            GradeAProcSerial = d.GradeAProcSerial,
                            GradeAProcTitle = ga == null ? null : ga.Title,
                            GradeAProcVersion = ga == null ? null : ga.Version,
                            GradeLevels = d.GradeAProcSerial == null ? null : db.AProcLevels.Where(s => s.ProcSerial == d.GradeAProcSerial).OrderBy(s => s.LevelCode)
                            .Select(s => new LevelInfoView()
                            {
                                LevelSerial = s.Serial,
                                LevelTitle = s.Title,
                                SendToAll = s.SendMessageToAll
                            }).ToList(),

                            AwardAProcSerial = d.AwardAProcSerial,
                            AwardAProcTitle = aa == null ? null : aa.Title,
                            AwardAProcVersion = aa == null ? null : aa.Version,
                            AwardLevels = d.AwardAProcSerial == null ? null : db.AProcLevels.Where(s => s.ProcSerial == d.AwardAProcSerial).OrderBy(s => s.LevelCode)
                            .Select(s => new LevelInfoView()
                            {
                                LevelSerial = s.Serial,
                                LevelTitle = s.Title,
                                SendToAll = s.SendMessageToAll
                            }).ToList(),

                            // ---------------- restore to previous status aproces

                            BDrftAProcSerial = d.BDraftAProcSerial,
                            BDrftAProcTitle = bda == null ? null : bda.Title,
                            BDrftAProcVersionion = bda == null ? null : bda.Version,
                            BDrftLevels = d.BDraftAProcSerial == null ? null : db.AProcLevels.Where(s => s.ProcSerial == d.BDraftAProcSerial)
                            .OrderBy(s => s.LevelCode)
                            .Select(s => new LevelInfoView()
                            {
                                LevelSerial = s.Serial,
                                LevelTitle = s.Title,
                                SendToAll = s.SendMessageToAll
                            }).ToList(),

                            BPublishAProcSerial = d.BPublishAProcSerial,
                            BPublishAProcTitle = bpa == null ? null : bpa.Title,
                            BPublishAProcVersion = bpa == null ? null : bpa.Version,
                            BPublishLevels = d.BPublishAProcSerial == null ? null : db.AProcLevels.Where(s => s.ProcSerial == d.BPublishAProcSerial)
                            .OrderBy(s => s.LevelCode)
                            .Select(s => new LevelInfoView()
                            {
                                LevelSerial = s.Serial,
                                LevelTitle = s.Title,
                                SendToAll = s.SendMessageToAll
                            }).ToList(),

                            BCloseAProcSerial = d.BCloseAProcSerial,
                            BCloseAProcTitle = bca == null ? null : bca.Title,
                            BCloseAProcVersion = bca == null ? null : bca.Version,
                            BCloseLevels = d.BCloseAProcSerial == null ? null : db.AProcLevels.Where(s => s.ProcSerial == d.BCloseAProcSerial)
                            .OrderBy(s => s.LevelCode)
                            .Select(s => new LevelInfoView()
                            {
                                LevelSerial = s.Serial,
                                LevelTitle = s.Title,
                                SendToAll = s.SendMessageToAll
                            }).ToList(),

                            BGradeAProcSerial = d.BGradeAProcSerial,
                            BGradeAProcTitle = bga == null ? null : bga.Title,
                            BGradeAProcVersion = bga == null ? null : bga.Version,
                            BGradeLevels = d.BGradeAProcSerial == null ? null : db.AProcLevels.Where(s => s.ProcSerial == d.BGradeAProcSerial)
                            .OrderBy(s => s.LevelCode)
                            .Select(s => new LevelInfoView()
                            {
                                LevelSerial = s.Serial,
                                LevelTitle = s.Title,
                                SendToAll = s.SendMessageToAll
                            }).ToList(),

                            CNFAProcSerial = d.CNFAProcSerial,
                            CNFAProcTitle = cnfA == null ? null : cnfA.Title,
                            CNFAProcVersionion = cnfA == null ? null : cnfA.Version,
                            CNFLevels = d.CNFAProcSerial == null ? null : db.AProcLevels.Where(s => s.ProcSerial == d.CNFAProcSerial)
                            .OrderBy(s => s.LevelCode)
                            .Select(s => new LevelInfoView()
                            {
                                LevelSerial = s.Serial,
                                LevelTitle = s.Title,
                                SendToAll = s.SendMessageToAll
                            }).ToList(),

                            DocumentSerial = documentSerial,
                        };

            return query.FirstOrDefault();
        }


        public ProjectAProcView ProjectAProcView(long projectSerial)
        {
            var query = from p in db.Projects

                        join pa in db.AProcesses on p.SupplierCnfApProcSerial equals pa.Serial into publishAproce
                        from pa in publishAproce.DefaultIfEmpty()

                        where p.Serial == projectSerial

                        select new ProjectAProcView()
                        {
                            SupplierCnfSubmitApProcSerial = p.SupplierCnfApProcSerial,
                            SupplierCnfSubmitAProcTitle = pa == null ? null : pa.Title,
                            SupplierCnfSubmitLevels = p.SupplierCnfApProcSerial == null ? null : db.AProcLevels.Where(s => s.ProcSerial == p.SupplierCnfApProcSerial)
                            .OrderBy(s => s.LevelCode)
                            .Select(s => new LevelInfoView()
                            {
                                LevelSerial = s.Serial,
                                LevelTitle = s.Title,
                                SendToAll = s.SendMessageToAll
                            }).ToList(),

                            ProjectSerial = projectSerial,
                        };

            return query.FirstOrDefault();
        }


        public ProjectAProcView ConfirmationAProcView(long cnfSerial)
        {
            var query = from c in db.Confirmations

                        join pa in db.AProcesses on c.CurrentAProcSerial equals pa.Serial into publishAproce
                        from pa in publishAproce.DefaultIfEmpty()

                        where c.Serial == cnfSerial

                        select new ProjectAProcView()
                        {
                            SupplierCnfSubmitApProcSerial = c.CurrentAProcSerial,
                            SupplierCnfSubmitAProcTitle = pa == null ? null : pa.Title,
                            SupplierCnfSubmitLevels = c.CurrentAProcSerial == null ? null : db.AProcLevels.Where(s => s.ProcSerial == c.CurrentAProcSerial)
                            .OrderBy(s => s.LevelCode)
                            .Select(s => new LevelInfoView()
                            {
                                LevelSerial = s.Serial,
                                LevelTitle = s.Title,
                                SendToAll = s.SendMessageToAll
                            }).ToList(),

                            ProjectSerial = cnfSerial,
                        };

            return query.FirstOrDefault();
        }

        public DiscoveryAProcView DiscoveryRulesAProcView(long discSerial)
        {
            var query = from c in db.DiscoveryRules

                        join ea in db.AProcesses on c.EvaluationAProc equals ea.Serial into evaluationAproce
                        from ea in evaluationAproce.DefaultIfEmpty()

                        join pa in db.AProcesses on c.PublishAProcSerial equals pa.Serial into publishAproc
                        from pa in publishAproc.DefaultIfEmpty()

                        where c.DocumentSerial == discSerial

                        select new DiscoveryAProcView()
                        {
                            EvaluationAProcSerial = c.EvaluationAProc,
                            EvaluationAProcTitle = ea == null ? null : ea.Title,
                            EvaluationAProcSubmitLevels = c.EvaluationAProc == null ? null : db.AProcLevels.Where(s => s.ProcSerial == c.EvaluationAProc)
                            .OrderBy(s => s.LevelCode)
                            .Select(s => new LevelInfoView()
                            {
                                LevelSerial = s.Serial,
                                LevelTitle = s.Title,
                                SendToAll = s.SendMessageToAll
                            }).ToList(),

                            PublishAProcSerial = c.PublishAProcSerial,
                            PublishAProcTitle = pa == null ? null : pa.Title,
                            PublishAProcLevels = c.PublishAProcSerial == null ? null : db.AProcLevels.Where(s => s.ProcSerial == c.PublishAProcSerial)
                            .OrderBy(s => s.LevelCode)
                            .Select(s => new LevelInfoView()
                            {
                                LevelSerial = s.Serial,
                                LevelTitle = s.Title,
                                SendToAll = s.SendMessageToAll
                            }).ToList(),


                            ProjectSerial = discSerial,
                        };

            return query.FirstOrDefault();
        }

        public EvaluationRequestAprocFlowView EvaluationAProcView(List<int> aprocSerials, long evaluationRequestSerial)
        {
            var result = new EvaluationRequestAprocFlowView()
            {
                AprocSerialsList = aprocSerials,
                Flows = new List<FlowView>()
            };

            foreach (var aprocSerial in aprocSerials)
            {
                var query = from a in db.AProcesses

                            where a.Serial == aprocSerial

                            select new FlowView()
                            {
                                CurrentAprocSerial = a.Serial,
                                CurrentAprocTitle = a == null ? null : a.Title,
                                CurrentAprocLevels = a == null ? null : db.AProcLevels.Where(s => s.ProcSerial == a.Serial)
                                .OrderBy(s => s.LevelCode)
                                .Select(s => new LevelInfoView()
                                {
                                    LevelSerial = s.Serial,
                                    LevelTitle = s.Title,
                                    SendToAll = s.SendMessageToAll
                                }).ToList(),
                            };
                var current = query.FirstOrDefault();

                result.Flows.Add(current);
            }


            return result;
        }

        public List<int> GetListOfEvaluationAproc(long evaluationSerial)
        {
            //ActionId= EVAL-RJCT  / object class = Discovery

            //var query = from a in db.AProcesses

            //            where a.ObjectCalss == ObjectClasses.Discovery && a.ActionId.Contains(AProcActions.EVAL) && a.ObjectKey == evaluationSerial.ToString()

            //            select a.Serial;

            var secondQuery = from n in db.Notifications

                              join al in db.AProcLevels on n.ToAPLevelSerial equals al.Serial
                              join a in db.AProcesses on al.ProcSerial equals a.Serial

                              where a.ObjectCalss == ObjectClasses.Discovery && a.ActionId.Contains(AProcActions.EVAL) && a.ObjectKey == evaluationSerial.ToString()

                              orderby a.CreatedAt descending

                              select a.Serial;


            return secondQuery.Distinct().ToList();

        }


        public DocumentAProcView AuctionAProcView(long auctionId)
        {
            var query = from a in db.Auctions

                        join pa in db.AProcesses on a.PublishAProcSerial equals pa.Serial into publishAproce
                        from pa in publishAproce.DefaultIfEmpty()

                        join ca in db.AProcesses on a.CloseAProcSerial equals ca.Serial into closeAproce
                        from ca in closeAproce.DefaultIfEmpty()

                        join ga in db.AProcesses on a.GradeAProcSerial equals ga.Serial into gradeAproce
                        from ga in gradeAproce.DefaultIfEmpty()

                        join aa in db.AProcesses on a.AwardAProcSerial equals aa.Serial into awardAproce
                        from aa in awardAproce.DefaultIfEmpty()

                        where a.AuctionId == auctionId

                        select new DocumentAProcView()
                        {
                            PublishAProcSerial = a.PublishAProcSerial,
                            PublishAProcTitle = pa == null ? null : pa.Title,
                            PublishLevels = a.PublishAProcSerial == null ? null : db.AProcLevels.Where(s => s.ProcSerial == a.PublishAProcSerial).OrderBy(s => s.LevelCode)
                            .Select(s => new LevelInfoView()
                            {
                                LevelSerial = s.Serial,
                                LevelTitle = s.Title,
                                SendToAll = s.SendMessageToAll
                            }).ToList(),

                            CloseAProcSerial = a.CloseAProcSerial,
                            CloseAProcTitle = ca == null ? null : ca.Title,
                            CloseLevels = a.CloseAProcSerial == null ? null : db.AProcLevels.Where(s => s.ProcSerial == a.CloseAProcSerial).OrderBy(s => s.LevelCode)
                            .Select(s => new LevelInfoView()
                            {
                                LevelSerial = s.Serial,
                                LevelTitle = s.Title,
                                SendToAll = s.SendMessageToAll
                            }).ToList(),

                            GradeAProcSerial = a.GradeAProcSerial,
                            GradeAProcTitle = ga == null ? null : ga.Title,
                            GradeLevels = a.GradeAProcSerial == null ? null : db.AProcLevels.Where(s => s.ProcSerial == a.GradeAProcSerial).OrderBy(s => s.LevelCode)
                            .Select(s => new LevelInfoView()
                            {
                                LevelSerial = s.Serial,
                                LevelTitle = s.Title,
                                SendToAll = s.SendMessageToAll
                            }).ToList(),

                            AwardAProcSerial = a.AwardAProcSerial,
                            AwardAProcTitle = aa == null ? null : aa.Title,
                            AwardLevels = a.AwardAProcSerial == null ? null : db.AProcLevels.Where(s => s.ProcSerial == a.AwardAProcSerial).OrderBy(s => s.LevelCode)
                            .Select(s => new LevelInfoView()
                            {
                                LevelSerial = s.Serial,
                                LevelTitle = s.Title,
                                SendToAll = s.SendMessageToAll
                            }).ToList(),

                            DocumentSerial = auctionId,
                        };

            return query.FirstOrDefault();
        }

        public LevelInfoView InitNextLevelAProc(AProcess aproc)
        {
            if (aproc is null) return new LevelInfoView();

            var procLevels = aProcDefService.GetLevels(aproc.Serial).OrderBy(s => s.LevelCode).ToList();

            if (procLevels.Count == 0 || procLevels.Count < 2)
                throw new MinimumLevelCountIsTwoError();

            return levelService.NextLevelInfo(procLevels, procLevels[0].Serial);
        }

        public int CopyAProcFromTemplate(int oldAprocSerial, long newDocumentSerial, string newDocumentType, string newDocumentTitle, string objectClass = "")
        {
            var oldAproc = db.AProcesses.Where(s => s.Serial == oldAprocSerial).FirstOrDefault();
            if (string.IsNullOrEmpty(objectClass))
                objectClass = newDocumentType == DocumentTypes.DISC ? ObjectClasses.Discovery : ObjectClasses.Document;

            var newAProc = oldAproc;
            newAProc.Serial = 0;
            newAProc.ObjectCalss = objectClass;
            newAProc.ObjectTitle = newDocumentTitle;
            newAProc.ObjectKey = newDocumentSerial.ToString();

            newAProc.ObjectUrl = String.Format(ObjectUrls.EventMonitoringUrl, newDocumentSerial);

            newAProc.IsTemplate = false;

            db.AProcesses.Add(newAProc);
            db.SaveChanges();

            CopyAprocData(oldAprocSerial, newAProc.Serial);

            return newAProc.Serial;
        }

        public AProcess CopyAProc(int oldAprocSerial, string newUrl, string newObjectKey = "")
        {
            var newAProc = db.AProcesses.Where(x => x.Serial == oldAprocSerial && x.CompanyId == accessService.CompanyId).FirstOrDefault();
            if (newAProc is null) throw new NotFoundAProcError();

            newAProc.Serial = 0;

            newAProc.ObjectUrl = newUrl;

            newAProc.IsTemplate = false;

            if (!string.IsNullOrEmpty(newObjectKey))
                newAProc.ObjectKey = newObjectKey;

            db.AProcesses.Add(newAProc);
            db.SaveChanges();

            CopyAprocData(oldAprocSerial, newAProc.Serial);

            return newAProc;
        }

        public AProcess CopyAProc(int oldAprocSerial, string newUrl, string newObjectKey = "", string actionId = "")
        {
            var newAProc = db.AProcesses.Where(x => x.Serial == oldAprocSerial && x.CompanyId == accessService.CompanyId).FirstOrDefault();
            if (newAProc is null) throw new NotFoundAProcError();

            newAProc.Serial = 0;
            newAProc.ObjectUrl = newUrl;
            newAProc.IsTemplate = false;
            newAProc.ActionId = actionId;

            if (!string.IsNullOrEmpty(newObjectKey))
                newAProc.ObjectKey = newObjectKey;

            db.AProcesses.Add(newAProc);
            db.SaveChanges();

            CopyAprocData(oldAprocSerial, newAProc.Serial);

            return newAProc;
        }


        public List<LevelInfoView> ChangeDocumentAproc(long documentSerial, int? aprocSerial, string aprocAction)
        {
            if (documentSerial == 0 || string.IsNullOrEmpty(aprocAction)) return new List<LevelInfoView>();

            var document = db.Documents.Where(x => x.Serial == documentSerial).FirstOrDefault();
            if (document == null) return new List<LevelInfoView>();

            var aproc = db.AProcesses.Where(s => s.Serial == aprocSerial).FirstOrDefault();
            if ((aprocSerial ?? 0) != 0)
            {
                if (aproc == null) throw new NotFoundAProcError();

                // check users of aproc
                var aprocLevels = db.AProcLevels.Where(s => s.ProcSerial == aproc.Serial).ToList();
                var usersLevels = db.AProcUsers.Where(s => aprocLevels.Select(x => x.Serial).Contains(s.ProcLevelSerial)).Select(s => s.ProcLevelSerial).Distinct().Count();

                var levelsCountWithoutChartCode = aprocLevels.Count(s => s.ChartCode == null);

                if (levelsCountWithoutChartCode > 0 && usersLevels < levelsCountWithoutChartCode - 1)
                    throw new EachLevelMustHaveUserError();

                if (aprocLevels.Count < 2)
                    throw new MinimumLevelCountOfAnyAprocIs2Error();
            }

            bool changed = false;
            int? newAprocSerial = null;
            //string actionId;

            var objectClass = document.DocumentType == DocumentTypes.DISC ? ObjectClasses.Discovery : ObjectClasses.Document;

            var action = aprocActionService.GetAprocAction(objectClass, aprocAction);
            if (action is null) throw new NotFoundAProcActionError();
            var newAProc = aproc;

            using var transaction = db.Database.BeginTransaction();
            try
            {
                if (aprocSerial.HasValue && newAProc != null)
                {
                    newAProc.Serial = 0;
                    newAProc.ActionId = action;
                    newAProc.ObjectCalss = objectClass;
                    newAProc.ObjectTitle = document.Title;
                    newAProc.ObjectKey = document.Serial.ToString();
                    newAProc.IsTemplate = false;

                    var objectUrl = document.DocumentType == DocumentTypes.EVENT ? ObjectUrls.EventMonitoringUrl : ObjectUrls.DiscoveryMonitoringUrl;
                    newAProc.ObjectUrl = String.Format(objectUrl, document.Serial);

                    db.AProcesses.Add(newAProc);
                    db.SaveChanges();

                    newAprocSerial = newAProc.Serial;

                    CopyAprocData(aprocSerial, newAprocSerial.Value);
                }

                switch (aprocAction)
                {
                    case AProcActions.PUB:
                        if (document.PublishAProcSerial != aprocSerial)
                        {
                            changed = true;
                            RemoveAproc(document.PublishAProcSerial);
                            document.PublishAProcSerial = newAprocSerial;
                        }
                        break;
                    case AProcActions.CLOSE:
                        if (document.CloseAProcSerial != aprocSerial)
                        {
                            changed = true;
                            RemoveAproc(document.CloseAProcSerial);
                            document.CloseAProcSerial = newAprocSerial;
                        }
                        break;
                    case AProcActions.GRADE:
                        if (document.GradeAProcSerial != aprocSerial)
                        {
                            changed = true;
                            RemoveAproc(document.GradeAProcSerial);
                            document.GradeAProcSerial = newAprocSerial;
                        }
                        break;
                    case AProcActions.AWARD:
                        if (document.AwardAProcSerial != aprocSerial)
                        {
                            changed = true;
                            RemoveAproc(document.AwardAProcSerial);
                            document.AwardAProcSerial = newAprocSerial;
                        }
                        break;
                    // ---------------- restore to previous status aproces
                  
                    case AProcActions.BPUB:
                        if (document.BPublishAProcSerial != aprocSerial)
                        {
                            changed = true;
                            RemoveAproc(document.BPublishAProcSerial);
                            document.BPublishAProcSerial = newAprocSerial;
                        }
                        break;
                    case AProcActions.BCLOSE:
                        if (document.BCloseAProcSerial != aprocSerial)
                        {
                            changed = true;
                            RemoveAproc(document.BCloseAProcSerial);
                            document.BCloseAProcSerial = newAprocSerial;
                        }
                        break;
                    case AProcActions.BGRADE:
                        if (document.BGradeAProcSerial != aprocSerial)
                        {
                            changed = true;
                            RemoveAproc(document.BGradeAProcSerial);
                            document.BGradeAProcSerial = newAprocSerial;
                        }
                        break;
                    case AProcActions.CNF:
                        if (document.CNFAProcSerial != aprocSerial)
                        {
                            changed = true;
                            RemoveAproc(document.CNFAProcSerial);
                            document.CNFAProcSerial = newAprocSerial;
                        }
                        break;
                    default:
                        throw new NotFoundAProcActionError();
                }

                if (changed)
                {
                    db.Documents.Update(document);
                    db.SaveChanges();
                }

                transaction.Commit();

                if (aproc is null)
                    return new List<LevelInfoView>();

                var levels = db.AProcLevels.Where(s => s.ProcSerial == newAprocSerial).OrderBy(s => s.LevelCode).Select(s => new LevelInfoView()
                {
                    LevelSerial = s.Serial,
                    LevelTitle = s.Title,
                    SendToAll = s.SendMessageToAll,
                    ProcSerial = s.ProcSerial
                }).ToList();

                return levels;
            }
            catch
            {
                transaction.Rollback();
                throw;
            }

        }

        public List<LevelInfoView> ChangeDocumentTemplateAproc(long documentSerial, int? aprocSerial, string aprocAction)
        {
            if (documentSerial == 0 || string.IsNullOrEmpty(aprocAction)) return new List<LevelInfoView>();

            var document = db.Documents.Where(x => x.Serial == documentSerial).FirstOrDefault();
            if (document == null) return new List<LevelInfoView>();

            var aproc = db.AProcesses.Where(s => s.Serial == aprocSerial).FirstOrDefault();
            if ((aprocSerial ?? 0) != 0) //checking is aproc valid?
            {
                if (aproc == null) throw new NotFoundAProcError();

                // check users of aproc
                var aprocLevels = db.AProcLevels.Where(s => s.ProcSerial == aproc.Serial).ToList();
                var usersLevels = db.AProcUsers.Where(s => aprocLevels.Select(x => x.Serial).Contains(s.ProcLevelSerial)).Select(s => s.ProcLevelSerial).Distinct().Count();

                var levelsCountWithoutChartCode = aprocLevels.Count(s => s.ChartCode == null);

                if (levelsCountWithoutChartCode > 0 && usersLevels < levelsCountWithoutChartCode - 1)
                    throw new EachLevelMustHaveUserError();

                if (aprocLevels.Count < 2)
                    throw new MinimumLevelCountOfAnyAprocIs2Error();
            }

            var objectClass = document.DocumentType == DocumentTypes.DISC ? ObjectClasses.Discovery : ObjectClasses.Document;

            var action = aprocActionService.GetAprocAction(objectClass, aprocAction);
            if (action is null) throw new NotFoundAProcActionError();

            using var transaction = db.Database.BeginTransaction();
            try
            {
                switch (aprocAction)
                {
                    case AProcActions.PUB:
                        document.PublishAProcSerial = aproc?.Serial;
                        break;

                    case AProcActions.CLOSE:
                        document.CloseAProcSerial = aproc?.Serial;
                        break;

                    case AProcActions.GRADE:
                        document.GradeAProcSerial = aproc?.Serial;
                        break;

                    case AProcActions.AWARD:
                        document.AwardAProcSerial = aproc?.Serial;
                        break;
                    
               
                    case AProcActions.BPUB:
                        document.BPublishAProcSerial = aproc?.Serial;

                        break;
                    case AProcActions.BCLOSE:
                        document.BCloseAProcSerial = aproc?.Serial;
                        break;

                    case AProcActions.BGRADE:
                        document.BGradeAProcSerial = aproc?.Serial;
                        break;

                    default:
                        throw new NotFoundAProcActionError();
                }


                db.Documents.Update(document);
                db.SaveChanges();


                transaction.Commit();

                if (aproc is null)
                    return new List<LevelInfoView>();

                var levels = db.AProcLevels.Where(s => s.ProcSerial == aproc.Serial).OrderBy(s => s.LevelCode).Select(s => new LevelInfoView()
                {
                    LevelSerial = s.Serial,
                    LevelTitle = s.Title,
                    SendToAll = s.SendMessageToAll,
                    ProcSerial = s.ProcSerial
                }).ToList();

                return levels;
            }
            catch
            {
                transaction.Rollback();
                throw;
            }

        }

        public List<LevelInfoView> ChangeProjectAproc(long projectSerial, int? aprocSerial, string aprocAction)
        {
            if (projectSerial == 0 || string.IsNullOrEmpty(aprocAction)) return new List<LevelInfoView>();

            var project = db.Projects.Where(x => x.Serial == projectSerial).FirstOrDefault();
            if (project == null) return new List<LevelInfoView>();

            var aproc = db.AProcesses.Where(s => s.Serial == aprocSerial).FirstOrDefault();
            if ((aprocSerial ?? 0) != 0)
            {
                if (aproc == null) throw new NotFoundAProcError();

                // check users of aproc
                var aprocLevels = db.AProcLevels.Where(s => s.ProcSerial == aproc.Serial).ToList();
                var usersLevels = db.AProcUsers.Where(s => aprocLevels.Select(x => x.Serial).Contains(s.ProcLevelSerial)).Select(s => s.ProcLevelSerial).Distinct().Count();

                var levelsCountWithoutChartCode = aprocLevels.Count(s => s.ChartCode == null);

                if (levelsCountWithoutChartCode > 0 && usersLevels < levelsCountWithoutChartCode - 1)
                    throw new EachLevelMustHaveUserError();

                if (aprocLevels.Count < 2)
                    throw new MinimumLevelCountOfAnyAprocIs2Error();
            }

            bool changed = false;
            int? newAprocSerial = null;

            var objectClass = ObjectClasses.Project;

            var action = aprocActionService.GetAprocAction(objectClass, aprocAction);
            if (action is null) throw new NotFoundAProcActionError();
            var newAProc = aproc;

            using var transaction = db.Database.BeginTransaction();
            try
            {
                if (aprocSerial.HasValue && newAProc != null)
                {
                    newAProc.Serial = 0;
                    newAProc.ActionId = action;
                    newAProc.ObjectCalss = objectClass;
                    newAProc.ObjectTitle = project.Title;
                    newAProc.ObjectKey = project.Serial.ToString();
                    newAProc.IsTemplate = false;

                    var objectUrl = ObjectUrls.ProjectViewUrl;
                    newAProc.ObjectUrl = String.Format(objectUrl, project.Serial);

                    db.AProcesses.Add(newAProc);
                    db.SaveChanges();

                    newAprocSerial = newAProc.Serial;

                    CopyAprocData(aprocSerial, newAprocSerial.Value);
                }

                switch (aprocAction)
                {
                    case AProcActions.SUBMIT:
                        if (project.SupplierCnfApProcSerial != aprocSerial)
                        {
                            changed = true;
                            RemoveAproc(project.SupplierCnfApProcSerial);
                            project.SupplierCnfApProcSerial = newAprocSerial;
                        }
                        break;


                    default:
                        throw new NotFoundAProcActionError();
                }

                if (changed)
                {
                    db.Projects.Update(project);
                    db.SaveChanges();
                }

                transaction.Commit();

                if (aproc is null)
                    return new List<LevelInfoView>();

                var levels = db.AProcLevels.Where(s => s.ProcSerial == newAprocSerial).OrderBy(s => s.LevelCode).Select(s => new LevelInfoView()
                {
                    LevelSerial = s.Serial,
                    LevelTitle = s.Title,
                    SendToAll = s.SendMessageToAll,
                    ProcSerial = s.ProcSerial
                }).ToList();

                return levels;
            }
            catch
            {
                transaction.Rollback();
                throw;
            }

        }
        public List<LevelInfoView> ChangeDiscoveryRuleAproc(long discSerial, int? aprocSerial, string aprocAction)
        {
            if (discSerial == 0 || string.IsNullOrEmpty(aprocAction)) return new List<LevelInfoView>();

            var discoveryRule = db.DiscoveryRules.Where(x => x.DocumentSerial == discSerial).FirstOrDefault();
            var document = db.Documents.Where(x => x.Serial == discSerial).FirstOrDefault();
            if (discoveryRule == null) return new List<LevelInfoView>();

            var aproc = db.AProcesses.Where(s => s.Serial == aprocSerial).FirstOrDefault();
            if ((aprocSerial ?? 0) != 0)
            {
                if (aproc == null) throw new NotFoundAProcError();

                // check users of aproc
                var aprocLevels = db.AProcLevels.Where(s => s.ProcSerial == aproc.Serial).ToList();
                var usersLevels = db.AProcUsers.Where(s => aprocLevels.Select(x => x.Serial).Contains(s.ProcLevelSerial)).Select(s => s.ProcLevelSerial).Distinct().Count();

                var levelsCountWithoutChartCode = aprocLevels.Count(s => s.ChartCode == null);

                if (levelsCountWithoutChartCode > 0 && usersLevels < levelsCountWithoutChartCode - 1)
                    throw new EachLevelMustHaveUserError();

                if (aprocLevels.Count < 2)
                    throw new MinimumLevelCountOfAnyAprocIs2Error();
            }

            bool changed = false;
            int? newAprocSerial = null;

            var objectClass = ObjectClasses.Discovery;

            var action = aprocActionService.GetAprocAction(objectClass, aprocAction);
            if (action is null) throw new NotFoundAProcActionError();
            var newAProc = aproc;

            using var transaction = db.Database.BeginTransaction();
            try
            {
                if (aprocSerial.HasValue && newAProc != null)
                {
                    newAProc.Serial = 0;
                    newAProc.ActionId = action;
                    newAProc.ObjectCalss = objectClass;
                    newAProc.ObjectTitle = document.Title;
                    newAProc.ObjectKey = document.Serial.ToString();
                    newAProc.IsTemplate = false;

                    var objectUrl = ObjectUrls.ProjectViewUrl;
                    newAProc.ObjectUrl = String.Format(objectUrl, document.Serial);

                    db.AProcesses.Add(newAProc);
                    db.SaveChanges();

                    newAprocSerial = newAProc.Serial;

                    CopyAprocData(aprocSerial, newAprocSerial.Value);
                }

                switch (aprocAction)
                {
                    case AProcActions.QUAL_RJCT:
                        if (discoveryRule.EvaluationAProc != aprocSerial)
                        {
                            changed = true;
                            RemoveAproc(discoveryRule.EvaluationAProc);
                            discoveryRule.EvaluationAProc = newAprocSerial;
                        }
                        break;

                    case AProcActions.PUB:
                        if (discoveryRule.PublishAProcSerial != aprocSerial)
                        {
                            changed = true;
                            RemoveAproc(discoveryRule.PublishAProcSerial);
                            discoveryRule.PublishAProcSerial = newAprocSerial;
                        }
                        break;


                    default:
                        throw new NotFoundAProcActionError();
                }

                if (changed)
                {
                    db.Update(discoveryRule);
                    db.SaveChanges();
                }

                transaction.Commit();

                if (aproc is null)
                    return new List<LevelInfoView>();

                var levels = db.AProcLevels.Where(s => s.ProcSerial == newAprocSerial).OrderBy(s => s.LevelCode).Select(s => new LevelInfoView()
                {
                    LevelSerial = s.Serial,
                    LevelTitle = s.Title,
                    SendToAll = s.SendMessageToAll,
                    ProcSerial = s.ProcSerial
                }).ToList();

                return levels;
            }
            catch
            {
                transaction.Rollback();
                throw;
            }

        }

        public bool IsAProcOnGoing(int? aprocSerial)
        {
            if (aprocSerial == null) return false;
            var levels = db.AProcLevels.Where(x => x.ProcSerial == aprocSerial).Select(x => x.Serial).ToList();


            var query = from inbox in db.Notifications

                        where (levels.Contains(inbox.ToAPLevelSerial.Value) || levels.Contains(inbox.FromAPLevelSerial.Value))
                        && inbox.TypeId == AProc.Core.NotificationTypes.TASK
                        && inbox.ActionStatusId == NotificationActionStatuses.NEW

                        select inbox;

            return query.Any();
        }

        public List<LevelInfoView> ChangeAuctionAproc(long auctionId, int? aprocSerial, string aprocAction)
        {
            if (auctionId == 0 || string.IsNullOrEmpty(aprocAction)) return new List<LevelInfoView>();

            var auction = db.Auctions.Where(x => x.AuctionId == auctionId).FirstOrDefault();
            if (auction == null) return new List<LevelInfoView>();

            var aproc = db.AProcesses.Where(s => s.Serial == aprocSerial).FirstOrDefault();
            if (aprocSerial.HasValue)
            {
                if (aproc == null) throw new NotFoundAProcError();

                var aprocLevels = db.AProcLevels.Where(s => s.ProcSerial == aproc.Serial).ToList();
                var usersLevels = db.AProcUsers.Where(s => aprocLevels.Select(x => x.Serial).Contains(s.ProcLevelSerial)).Select(s => s.ProcLevelSerial).Distinct().Count();

                var levelsCountWithoutChartCode = aprocLevels.Count(s => s.ChartCode == null);

                if (levelsCountWithoutChartCode > 0 && usersLevels < levelsCountWithoutChartCode - 1)
                    throw new EachLevelMustHaveUserError();

                if (aprocLevels.Count < 2)
                    throw new MinimumLevelCountOfAnyAprocIs2Error();
            }

            bool changed = false;
            int? newAprocSerial = null;
            //string actionId;

            var objectClass = ObjectClasses.Auction;

            //var action = aprocActionService.GetAprocAction(objectClass, aprocAction);
            //if (action is null) throw new NotFoundAProcActionError();
            var newAProc = aproc;

            using var transaction = db.Database.BeginTransaction();
            try
            {
                if (aprocSerial.HasValue)
                {
                    newAProc.Serial = 0;

                    newAProc.ObjectCalss = objectClass;
                    newAProc.ObjectTitle = auction.Title;
                    newAProc.ObjectKey = auction.AuctionId.ToString();
                    newAProc.IsTemplate = false;

                    var objectUrl = ObjectUrls.AuctionMonitoringUrl;
                    newAProc.ObjectUrl = String.Format(objectUrl, auction.AuctionId);

                    db.AProcesses.Add(newAProc);
                    db.SaveChanges();

                    newAprocSerial = newAProc.Serial;

                    CopyAprocData(aprocSerial, newAprocSerial.Value);
                }

                switch (aprocAction)
                {
                    case AProcActions.PUB:
                        if (auction.PublishAProcSerial != aprocSerial)
                        {
                            changed = true;
                            RemoveAproc(auction.PublishAProcSerial);
                            auction.PublishAProcSerial = newAprocSerial;
                        }
                        break;
                    case AProcActions.CLOSE:
                        if (auction.CloseAProcSerial != aprocSerial)
                        {
                            changed = true;
                            RemoveAproc(auction.CloseAProcSerial);
                            auction.CloseAProcSerial = newAprocSerial;
                        }
                        break;
                    case AProcActions.GRADE:
                        if (auction.GradeAProcSerial != aprocSerial)
                        {
                            changed = true;
                            RemoveAproc(auction.GradeAProcSerial);
                            auction.GradeAProcSerial = newAprocSerial;
                        }
                        break;
                    case AProcActions.AWARD:
                        if (auction.AwardAProcSerial != aprocSerial)
                        {
                            changed = true;
                            RemoveAproc(auction.AwardAProcSerial);
                            auction.AwardAProcSerial = newAprocSerial;
                        }
                        break;

                    default:
                        throw new NotFoundAProcActionError();
                }

                if (changed)
                {
                    db.Auctions.Update(auction);
                    db.SaveChanges();
                }

                transaction.Commit();

                if (aproc is null)
                    return new List<LevelInfoView>();

                var levels = db.AProcLevels.Where(s => s.ProcSerial == newAprocSerial).OrderBy(s => s.LevelCode).Select(s => new LevelInfoView()
                {
                    LevelSerial = s.Serial,
                    LevelTitle = s.Title,
                    SendToAll = s.SendMessageToAll,
                    ProcSerial = s.ProcSerial
                }).ToList();

                return levels;
            }
            catch
            {
                transaction.Rollback();
                throw;
            }

        }

        public void RemoveAprocData(int aprocSerial)
        {
            var aproc = db.AProcesses.Where(x => x.Serial == aprocSerial).FirstOrDefault();
            if (aproc == null) return;

            var levelSerials = db.AProcLevels.Where(x => x.ProcSerial == aproc.Serial).Select(x => x.Serial).ToList();

            var levelUsers = db.AProcUsers
                            .Where(s => levelSerials.Contains(s.ProcLevelSerial));

            if (!levelSerials.Any() || !levelUsers.Any()) return;

            var notifications = db.Notifications
                                .Where(x => levelSerials.Contains(x.ToAPLevelSerial.Value) || levelSerials.Contains(x.FromAPLevelSerial.Value))
                                .OrderByDescending(x => x.Serial).ToList().DistinctBy(x => x.Serial);

            foreach (var n in notifications)
            {
                db.Remove(n);
                db.SaveChanges();
            }

            db.RemoveRange(levelUsers);
            db.SaveChanges();

            db.RemoveRange(db.AProcLevels.Where(s => levelSerials.Contains(s.Serial)));
            db.SaveChanges();

            db.Remove(aproc);
            db.SaveChanges();
        }

        private void RemoveAproc(int? aprocSerial)
        {
            if (aprocSerial is null) return;

            var aproc = db.AProcesses.Where(s => s.Serial == aprocSerial.Value).FirstOrDefault();
            if (aproc is null) return;

            var levels = db.AProcLevels.Where(s => s.ProcSerial == aprocSerial.Value).ToList();
            var levelUsers = db.AProcUsers.Where(s => levels.Select(x => x.Serial).Contains(s.ProcLevelSerial));

            db.RemoveRange(levelUsers);
            db.SaveChanges();

            db.RemoveRange(levels);
            db.SaveChanges();

            db.Remove(aproc);
            db.SaveChanges();
        }

        private void CopyAprocData(int? templateAProcSerial, int newAProcSerial)
        {
            if (templateAProcSerial is null) return;

            var aproc = db.AProcesses.Where(s => s.Serial == templateAProcSerial.Value).FirstOrDefault();
            if (aproc is null) return;

            var levels = db.AProcLevels.Where(s => s.ProcSerial == templateAProcSerial.Value).ToList();

            foreach (var level in levels)
            {
                var currentLevelSerial = level.Serial;
                var newLevel = level;
                newLevel.ProcSerial = newAProcSerial;
                newLevel.Serial = 0;

                db.AProcLevels.Add(newLevel);
                db.SaveChanges();

                CopyLevelUsers(currentLevelSerial, newLevel.Serial);
            }
        }

        private void CopyLevelUsers(int levelSerial, int newLevelSerial)
        {
            var levelUsers = db.AProcUsers.Where(s => s.ProcLevelSerial == levelSerial).ToList();

            if (!levelUsers.Any()) return;

            var newLevelUsers = levelUsers.Select(s =>
            {
                s.ProcLevelSerial = newLevelSerial;
                return s;
            });

            db.AProcUsers.AddRange(newLevelUsers);
            db.SaveChanges();
        }



    }
}