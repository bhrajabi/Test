﻿namespace AProc.Core
{
    public static class AZGroupUsages
    {
        public const string APROC = "APROC";
        public const string SRC = "SRC";
        public const string SRM = "SRM";
    }
}
