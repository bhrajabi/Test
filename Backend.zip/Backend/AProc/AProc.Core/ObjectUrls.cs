﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AProc.Core
{
    public static class ObjectUrls
    {
        public const string EventMonitoringUrl = "/event/monitor?serial={0}";
        public const string DiscoveryMonitoringUrl = "/discovery/monitor?serial={0}";
        public const string AuctionMonitoringUrl = "/auction/monitor?ai={0}";
        public const string ReqViewUrl = "/req/view?serial={0}";
        public const string CnfViewUrl = "/confirmation/view?doc={0}";
        public const string ProjectViewUrl = "/project/monitor?serial={0}";
        public const string EvaluationRequestUrl = "/vendors/evaluation-requests?srs={0}&status=drft";
    }
}
