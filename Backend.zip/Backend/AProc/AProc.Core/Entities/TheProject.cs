﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace AProc.Core.Entities
{
    [Table("Projects", Schema = "PUR")]
    public class TheProject
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Serial { get; set; }

        public int CompanyId { get; set; }
        public long? ParentProjectSerial { get; set; }
        public string Number { get; set; }
        public string ProjectType { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public bool IsTemplate { get; set; }
        public string StatusId { get; set; }
        public long? TemplateSerial { get; set; }
        public int? SupplierCnfApProcSerial { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }

        public string ModifiedBy { get; set; }
        public DateTime ModifiedAt { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedAt { get; set; }
    }
}
