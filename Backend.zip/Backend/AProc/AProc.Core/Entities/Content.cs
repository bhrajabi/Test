﻿using Common.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace AProc.Core.Entities
{
    [Table("Contents", Schema = "PUR")]
    public class Content : IHasCreator, IHasModifier
    {
        [Key]
        public long Serial { get; set; }

        public long? ParentSerial { get; set; }
        public long? ReferenceSerial { get; set; }
        public long? CompanyId { get; set; }
        public long DocumentId { get; set; }
        public string ContentTypeId { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public int? EnvelopNumber { get; set; }
        public int SortOrder { get; set; }
        public string Visibility { get; set; }
        public string AnswerTypeId { get; set; }
        public bool AnswerRequired { get; set; }
        public bool? ParticipantCanAttach { get; set; }
        public long? PRSerial { get; set; }
        public Double? Quantity { get; set; }
        public Double? InitialPrice { get; set; }
        public string Unit { get; set; }
        public int? ScoreImportance { get; set; }
        public Double? ScoreOveral { get; set; }
        public Int64? AttachmentId1 { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime ModifiedAt { get; set; }
        public DateTime CreatedAt { get; set; }
        public string CreatedBy { get; set; }
    }
}
