﻿using System.ComponentModel.DataAnnotations.Schema;

namespace AProc.Core.Entities
{
    [Table("OrganizationChartUsers", Schema = "PUR")]
    public class TheOrganizationChartUser
    {
        public int CompanyId { get; set; }
        public string ChartCode { get; set; }
        public string UserName { get; set; }
    }
}
