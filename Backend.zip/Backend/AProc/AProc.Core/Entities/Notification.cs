﻿using Common.Data;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace AProc.Core.Entities
{
    [Table("Notifications", Schema = "PUR")]
    public class Notification : IHasCreator
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Serial { get; set; }

        public int CompanyId { get; set; } 
        public string TypeId { get; set; }
        public long? SenderSerial { get; set; }
        public int? FromAPLevelSerial { get; set; }
        public int? ToAPLevelSerial { get; set; }
        //public bool IsVisited { get; set; }
        public bool IsArchived { get; set; }
        public string ActionStatusId { get; set; }
        public string Title { get; set; }
        public string Comment { get; set; }
        public string MessageUrl { get; set; }
        public string FromUserName { get; set; }
        public string ToUserName { get; set; }
        public DateTime? ActionAt { get; set; }
        public DateTime? VisitedAt { get; set; }
        public DateTime? ArchivedAt { get; set; }
        public bool IsUnreadMessageNotified { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedAt { get; set; }
    }
}
