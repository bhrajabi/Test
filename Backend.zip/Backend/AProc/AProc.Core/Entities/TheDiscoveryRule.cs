﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace AProc.Core.Entities
{
    [Table("DiscoveryRules", Schema = "PUR")]
    public class TheDiscoveryRule
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long DocumentSerial { get; set; }

        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public DateTime? DueDate { get; set; }
        public int VisitCount { get; set; }
        public bool PublicAccess { get; set; }
        public long? ShipToAddressSerial { get; set; }
        public string ReferenceNumber { get; set; }
        public string PRNumber { get; set; }
        public DateTime? PRDate { get; set; }
        public int? EvaluationAProc { get; set; }
        public int? PublishAProcSerial { get; set; }
    }
}
