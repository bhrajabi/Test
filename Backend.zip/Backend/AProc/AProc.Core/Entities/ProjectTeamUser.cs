﻿using System.ComponentModel.DataAnnotations.Schema;

namespace AProc.Core
{
    [Table("ProjectTeamUsers", Schema = "PUR")]
    public class ProjectTeamUser
    {
        public long ProjectTeamSerial { get; set; }
        public string UserName { get; set; }
    }
}
