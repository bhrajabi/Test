﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace AProc.Core.Entities
{
    [Table("Auctions", Schema = "AUC")]
    public class TheAuction
    {
        [Key]
        public long AuctionId { get; set; }

        public string AuctionNo { get; set; }
        public long ProjectSerial { get; set; }
        public string ReferenceSerial { get; set; }
        public string Title { get; set; }
        public long AddressSerial { get; set; }
        public string VisitingHours { get; set; }

        public DateTime? VisitStartDate { get; set; }
        public DateTime? VisitEndDate { get; set; }
        public DateTime? AwardDate { get; set; }
        public DateTime? StartPaymentDate { get; set; }
        public DateTime? LastPaymentDate { get; set; }
        public DateTime? StartRefundDate { get; set; }
        public DateTime? EndRefundDate { get; set; }

        public int? CostOfHolding { get; set; }
        public int? MaxSelectableItems { get; set; }

        public bool EnableEnvelope { get; set; }
        public string PublicKey { get; set; }
        public int GuaranteeAmountPercent { get; set; }
        public bool DisplayAnnouncement { get; set; }

        public int? PublishAProcSerial { get; set; }
        public int? CloseAProcSerial { get; set; }
        public int? GradeAProcSerial { get; set; }
        public int? AwardAProcSerial { get; set; }
        public int? CurrentAProcSerial { get; set; }

        public DateTime? PublishedDate { get; set; }
        public DateTime? ClosedDate { get; set; }
        public DateTime? GradedDate { get; set; }
        public DateTime? AwardedDate { get; set; }

        public string StatusId { get; set; }
        public bool IsDeleted { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime ModifiedAt { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedAt { get; set; }
    }
}
