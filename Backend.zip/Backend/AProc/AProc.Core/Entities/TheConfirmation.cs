﻿using Common.Data;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace AProc.Core.Entities
{
    [Table("Confirmations", Schema = "PUR")]
    public class TheConfirmation : IHasCreator, IHasModifier
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Serial { get; set; }

        public long? DocumentSerial { get; set; }
        public string Comments { get; set; }
        public DateTime ValidFrom { get; set; }
        public DateTime ValidTo { get; set; }
        public int? MinSupplierCount { get; set; }
        public int? MaxSupplierCount { get; set; }
        public DateTime? ReferenceDate { get; set; }
        public string ReferenceNumber { get; set; }
        public string Number { get; set; }
        public int? CurrentAProcSerial { get; set; }
        public string StatusId { get; set; }

        public string ModifiedBy { get; set; }
        public DateTime ModifiedAt { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedAt { get; set; }
    }
}
