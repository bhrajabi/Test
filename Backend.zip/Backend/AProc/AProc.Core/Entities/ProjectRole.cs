﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace AProc.Core
{
    [Table("ProjectRoles", Schema = "PUR")]
    public class ProjectRole
    {
        [Key]
        public string Id { get; set; }

        public string Title { get; set; }
        public string ProjectTypes { get; set; }
        public string AccessRights { get; set; }
        public bool IncludeAuthGroup { get; set; }
        public int SortOrder { get; set; }
    }
}
