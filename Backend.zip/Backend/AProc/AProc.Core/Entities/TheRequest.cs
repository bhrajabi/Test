﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace AProc.Core.Entities
{
    [Table("Requests", Schema = "PUR")]
    public class TheRequest
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Serial { get; set; }

        public int CompanyId { get; set; }
        public long? ProjectSerial { get; set; }
        public string Number { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public string CurrencyId { get; set; }
        public string PlantId { get; set; }
        public string PlanningGroup { get; set; }
        public string DocType { get; set; }
        //public string OrderDocType { get; set; }
        public string PurOrg { get; set; }
        public string PurGroup { get; set; }
        //public string Priority { get; set; }
        public double? BaselineSpend { get; set; }
        public DateTime? RequestDate { get; set; }
        public DateTime? ReleaseDate { get; set; }
        public long? ShipToAddressSerial { get; set; }

        public bool IsReleased { get; set; }
        public bool IsClosed { get; set; }
        public bool IsCompleted { get; set; }
        public bool IsSynchronized { get; set; }

        public string ModifiedBy { get; set; }
        public DateTime ModifiedAt { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedAt { get; set; }
    }
}
