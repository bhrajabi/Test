﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace AProc.Core.Entities
{
    [Table("AProcActions", Schema = "PUR")]
    public class AProcAction
    {
        [Key]
        public string Id { get; set; }

        public string Title { get; set; }
        public string ApproveSqlCommand { get; set; }
        public string RejectSqlCommand { get; set; }
        public string StartSqlCommand { get; set; }

    }
}
