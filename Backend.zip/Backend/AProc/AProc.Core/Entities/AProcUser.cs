﻿using Common.Data;
using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace AProc.Core.Entities
{
    [Table("AProcUsers", Schema = "PUR")]
    public class AProcUser : IHasCreator, IHasModifier
    {
        public int ProcLevelSerial { get; set; }
        public string UserName { get; set; }
        
        public bool IsActive { get; set; }
        public bool? JustNotify { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedAt { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime ModifiedAt { get; set; }

    }
}
