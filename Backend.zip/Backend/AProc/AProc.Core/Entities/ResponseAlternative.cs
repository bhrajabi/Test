﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace AProc.Core.Entities
{
    [Table("ResponseAlternatives", Schema = "PUR")]
    public class ResponseAlternative
    {
        [Key]
        public long Id { get; set; }

        public long DocumentSerial { get; set; }
        public int SellerId { get; set; }
        //public string ParticipantName { get; set; }
        public string Title { get; set; }
        public bool IsMain { get; set; }
        public Double? TotalScore { get; set; }
        public Double? TotalPrice { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime? LastResponseDate { get; set; }
    }
}
