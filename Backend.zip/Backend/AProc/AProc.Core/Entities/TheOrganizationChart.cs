﻿using System.ComponentModel.DataAnnotations.Schema;

namespace AProc.Core.Entities
{
    [Table("OrganizationCharts", Schema = "PUR")]
    public class TheOrganizationChart
    {
        public int CompanyId { get; set; }
        public string ChartCode { get; set; }
        public string ParentCode { get; set; }

        public string Title { get; set; }

    }
}
