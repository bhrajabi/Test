﻿using System.ComponentModel.DataAnnotations.Schema;

namespace AProc.Core
{
    [Table("ProjectTeamRoles", Schema = "PUR")]
    public class ProjectTeamRole
    {
        public long ProjectTeamSerial { get; set; }
        public string RoleId { get; set; }
        public string AccessRight { get; set; }
    }
}
