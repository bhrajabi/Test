﻿using Common.Data;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace AProc.Core.Entities
{
    [Table("APInbox", Schema = "PUR")]
    public class _APInbox : IHasCreator, IHasModifier
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Serial { get; set; }
        
        public int? SenderSerial { get; set; }
        public long? TaskSerial { get; set; }
        public int LevelSerial { get; set; }
        public string ToUserName { get; set; }
        public string StatusId { get; set; }
        public bool IsArchived { get; set; }
        public bool IsClosedByOtherUser { get; set; }
        public bool IsReadonly { get; set; }
        public string Comment { get; set; }
        public int? FromLevel { get; set; }
        public string FromUserName { get; set; }
       // public string ToUserName { get; set; }
        public DateTime? VisitedAt { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime ModifiedAt { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime? ActionAt { get; set; }
    }
}
