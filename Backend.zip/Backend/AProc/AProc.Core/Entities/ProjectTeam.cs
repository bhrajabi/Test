﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace AProc.Core
{
    [Table("ProjectTeams", Schema = "PUR")]
    public class ProjectTeam
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Serial { get; set; }

        public long ProjectSerial { get; set; }
        public string SysCode { get; set; }
        public string Title { get; set; }
        public string DocType { get; set; }
        public bool? IsEditable { get; set; }
    }
}
