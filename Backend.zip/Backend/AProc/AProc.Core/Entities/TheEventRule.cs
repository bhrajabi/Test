﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace AProc.Core.Entities
{
    [Table("EventRules", Schema = "PUR")]
    public class TheEventRule
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long DocumentSerial { get; set; }

        public bool EnableNegotiation { get; set; }
        public string MinSupplierStatus { get; set; }
        public bool EnableEnvelop { get; set; }

        public bool HasPreview { get; set; }
        public bool HasPrebid { get; set; }
        public int? PreviewStartAfter { get; set; }
        public string PreviewStartAfterUnit { get; set; }
        public string PreviewStartAfterTime { get; set; }
        public string PreviewStartAt { get; set; }
        public string PreviewStartAtTime { get; set; }
        public int? PreviewEndAfter { get; set; }
        public string PreviewEndAfterUnit { get; set; }
        public string PreviewEndAfterTime { get; set; }
        public int? StartAfter { get; set; }
        public string StartAfterUnit { get; set; }
        public string StartAfterTime { get; set; }
        public string StartAt { get; set; }
        public string StartAtTime { get; set; }
        public int? EndAfter { get; set; }
        public string EndAfterUnit { get; set; }
        public string EndAfterTime { get; set; }
        public int? AwardAfter { get; set; }
        public string AwardAfterUnit { get; set; }
        public bool AllowOvertime { get; set; }
        public int? OvertimeRank { get; set; }
        public int? StartOvertimePeriod { get; set; }
        public string StartOvertime { get; set; }
        public int OvertimePeriod { get; set; }
        public bool MultiCurrency { get; set; }
        public bool? EnableTrafficLight { get; set; }
        public string TrafficLightGreenBid { get; set; }
        public string TrafficLightYellowBid { get; set; }
        public Double BidGuardian { get; set; }
        public bool EnableScoring { get; set; }
        public bool ImproveBid { get; set; }
        public Double? ImproveBidAmount { get; set; }
        public bool AllowTieBids { get; set; }
        public Double? TieBidDistance { get; set; }
        public bool AskReasonForDeclining { get; set; }
        public bool AllowResponseTeam { get; set; }
        public string ShowLeadBid { get; set; }
        public bool ShowReservePrice { get; set; }
        public bool AlternativeResponseEnabled { get; set; }
        public int AlternativeLimit { get; set; }
        public bool? ShowRank { get; set; }
        public bool? ShowItemRank { get; set; }
        public bool? ShowResponseScore { get; set; }
        public int? MinimumResponseCount { get; set; }
        public int? MinimumSupplierCount { get; set; }
        public bool OwnerSee { get; set; }
        public bool ShowBids { get; set; }
        public string ShowParticipantCount { get; set; }
        public bool AllowMessaging { get; set; }
        public bool AcceptTerms { get; set; }
        public string TermsText { get; set; }
        public bool BidHistory { get; set; }

        public bool? HideCompanyName { get; set; }
        public DateTime? PublishDate { get; set; }
        public DateTime? CloseDate { get; set; }
        public DateTime? GradeDate { get; set; }
        public DateTime? AwardDate { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public DateTime? PreviewStartDate { get; set; }
        public DateTime? PreviewEndDate { get; set; }
        public DateTime? EstimatedAwardDate { get; set; }
        public string DelegatedFields { get; set; }
        public string ReadonlyFields { get; set; }

        public string CommissionNo { get; set; }
        public DateTime? CommissionDate { get; set; }
        public string CommissionComment { get; set; }
        public bool IsDigitalSignatureRequired { get; set; }

        public Double? BaselineSpend { get; set; }
        public DateTime? NeedDate { get; set; }
        public string OrderDocType { get; set; }
        public string PRDocType { get; set; }
    }
}
