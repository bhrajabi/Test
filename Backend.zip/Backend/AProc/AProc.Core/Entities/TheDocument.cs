﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace AProc.Core.Entities
{
    [Table("Documents", Schema = "PUR")]
    public class TheDocument
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Serial { get; set; }

        public long ProjectSerial { get; set; }
        public long? ParentProjectSerial { get; set; }
        public long? ReferenceSerial { get; set; }
        public long? FolderSerial { get; set; }
        public int CompanyId { get; set; }
        public int? SellerId { get; set; }
        public string Number { get; set; }
        public string DocumentType { get; set; }
        public string EventTypeId { get; set; }
        public int? CurrentAProcSerial { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public DateTime? DocumentDate { get; set; }
        public int? DepartmentSerial { get; set; }
        public string RegionCode { get; set; }        
        public bool IsQuickLink { get; set; }
        public bool IsDeleted { get; set; }
        public bool? IsCancelled { get; set; }
        public string StatusId { get; set; }
        public int? PublishAProcSerial { get; set; }
        public int? CloseAProcSerial { get; set; }
        public int? GradeAProcSerial { get; set; }
        public int? AwardAProcSerial { get; set; }

        public int? CNFAProcSerial { get; set; }
        public int? BDraftAProcSerial { get; set; }
        public int? BPublishAProcSerial { get; set; }
        public int? BCloseAProcSerial { get; set; }
        public int? BGradeAProcSerial { get; set; }

        public long? TemplateSerial { get; set; }
        public int TemplateVersion { get; set; }
        public int Version { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime ModifiedAt { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedAt { get; set; }
    }
}
