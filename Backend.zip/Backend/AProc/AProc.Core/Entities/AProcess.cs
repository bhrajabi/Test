﻿using Common.Data;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace AProc.Core
{
    [Table("AProcesses", Schema = "PUR")]
    public class AProcess : IHasCreator, IHasModifier
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Serial { get; set; }

        public int? ReferenceSerial { get; set; }
        public int CompanyId { get; set; }
        public string Title { get; set; }
        public int? Version { get; set; }
        public bool IsTemplate { get; set; }
        public string ObjectCalss { get; set; }
        public string ObjectTitle { get; set; }
        public string ObjectKey { get; set; }
        public string ObjectUrl { get; set; }
        public string ActionId { get; set; }
        public long? LastTaskSerial { get; set; }
        public bool Active { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedAt { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime ModifiedAt { get; set; }
    }
}
