﻿using Common.Data;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace AProc.Core
{
    [Table("AProcLevels", Schema = "PUR")]
    public class AProcLevel : IHasCreator, IHasModifier
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Serial { get; set; }

        public int ProcSerial { get; set; }        
        public string Title { get; set; }
        public int LevelCode { get; set; }
        public bool SendMessageToAll { get; set; }
        public bool IsPrintable { get; set; }
        public bool IsOwner { get; set; }        
        public bool IsReadonly { get; set; }        
        public bool SystemTrigger { get; set; }        
        public string ChartCode { get; set; }

        public string CreatedBy { get; set; }
        public DateTime CreatedAt { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime ModifiedAt { get; set; }
    }
}
