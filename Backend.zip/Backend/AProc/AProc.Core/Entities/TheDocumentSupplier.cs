﻿using Common.Data;
using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace AProc.Core.Entities
{
    [Table("DocumentSuppliers", Schema = "PUR")]
    public class TheDocumentSupplier : IHasCreator
    {
        public long DocumentSerial { get; set; }
        public int SellerId { get; set; }
        public string ParticipantName { get; set; }

        public bool IsInvitationApproved { get; set; }
        public bool IsInvitationLocked { get; set; }
        public string InvitationComment { get; set; }
        public bool? IsResponseDeclined { get; set; }
        public string ResponseDeclinReason { get; set; }
        public string ResponseStatusId { get; set; }
        public DateTime ResponseDate { get; set; }
        public string GraderUserName { get; set; }
        public DateTime? GradeDate { get; set; }
        public int VisitCount { get; set; }
        public int SubmitCount { get; set; }
        public DateTime CreatedAt { get; set; }
        public string CreatedBy { get; set; }
    }
}
