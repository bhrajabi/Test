﻿using System;
using System.Collections.Generic;
using Tamin.Core;

namespace AProc.Core
{
    public class NotificationActions
    {
        private static Dictionary<string, Type> _List = new Dictionary<string, Type>();
        public static Dictionary<string, Type> List { get => _List; }



        public static void Register<T>(string name) where T : class
        {
            _List.Add(name, typeof(T));
        }

        public static INotificationAction Resolve(IServiceProvider serviceProvider, string actionId)
        {
            try
            {
                return List.ContainsKey(actionId) ? (INotificationAction)serviceProvider.GetService(List[actionId]) : null;
            }
            catch
            {
                throw new NotFoundServiceInProcessError();
            }

        }
    }
}
