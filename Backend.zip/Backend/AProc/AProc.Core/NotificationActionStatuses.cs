﻿namespace AProc.Core.Entities
{
    public static class NotificationActionStatuses
    {
        
        public const string APRV = "APRV";
        public const string CLOSED = "CLOSED";
        //public const string NEW = "NOTIFY";
        
        public const string RJCT = "RJCT";
        public const string REFERBACK = "REFERBACK";
        public const string FORWARD = "FORWARD";
        public const string NEW = "NEW";
        public const string VISITED = "VISITED";

    }
}
