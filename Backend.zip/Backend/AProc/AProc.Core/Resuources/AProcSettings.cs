﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AProc.Core.Resuources
{
    public static class AProcSettings
    {
        public static int TopRowsCount { get; } = 100;
    }
}
