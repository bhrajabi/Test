﻿using AProc.Core.Entities;
using AProc.Core.Views;
using System;

namespace AProc.Core
{
    public interface IAProcActionService
    {
        string GetAprocAction(string objectClass, string action);

        NotificationActionView InitAProcAction(AProcess aproc, string aprocAction, string objectKey, string customizedParameter = "");

        void RunStartAProcAction(AProcess aproc, DateTime currentDate, string selectedUserName, string comment, string aprocAction, string objectKey, string customizedParameter = "");

        void RunApproveAProcAction(AProcess aproc, DateTime currentDate,string userNote);

        void RunRejectAProcAction(AProcess aproc, DateTime currentDate);
    }
}
