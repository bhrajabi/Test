﻿using AProc.Core.Views;
using System;

namespace AProc.Core
{
    public interface INotificationAction
    {
        void Approve(string objectKey, DateTime currentDate, string actioId = "", string userNote = "");
        void Reject(string objectKey, DateTime currentDate);
        NotificationActionView InitStart(string objectKey, int? aprocSerial, string customizedParameter = "");
        void Start(string objectKey, int? aprocSerial, DateTime currentDate, string selectedUserName, string comment, string customizedParameter = "");
        void UpdateDocumentStatus(string objectKey, DateTime currentDate);
        void ForwardNotification(string selectedUser, long notificationSerial, string comment, AProcess aproc, string prevTitle);
        void CheckNextLevelAccess(AProcess aproc, LevelInfoView nextLevel, string selectedUser);
    }
}
