﻿using AProc.Core.Entities;
using AProc.Core.Views;
using System.Collections.Generic;

namespace AProc.Core
{
    public interface IAProcService
    {
        IList<AProcLevelView> AProcLevels(int aprocSerial);
        int? GetAProceSerialByLevelSerial(int? levelSerial);
        //IList<AProcTaskView> GetAProcTasksByProjectSerialAndActionId(long projectSerial, string actionId, string documentType);
        //  bool StartTask(string actioId, string currentUserName, long documentSerial, string selctedUserName, long? taskSerial = null);
        DocumentAProcView DocumentAProcView(long documentSerial);
        ProjectAProcView ProjectAProcView(long projectSerial);
        ProjectAProcView ConfirmationAProcView(long cnfSerial);
        DiscoveryAProcView DiscoveryRulesAProcView(long discSerial);
        DocumentAProcView AuctionAProcView(long auctionId);
        LevelInfoView InitNextLevelAProc(AProcess aproc);

        /// <summary>
        /// copy aproc make a new aproc for current document
        /// </summary>
        /// <param name="documentSerial"></param>
        /// <param name="aprocSerial"></param>
        /// <param name="aprocAction"></param>
        /// <returns></returns>
        List<LevelInfoView> ChangeDocumentAproc(long documentSerial, int? aprocSerial, string aprocAction);

        /// <summary>
        /// will reference to aproc, it dosent copy aproc 
        /// </summary>
        /// <param name="documentSerial"></param>
        /// <param name="aprocSerial"></param>
        /// <param name="aprocAction"></param>
        /// <returns></returns>
        List<LevelInfoView> ChangeDocumentTemplateAproc(long documentSerial, int? aprocSerial, string aprocAction);
        
        List<LevelInfoView> ChangeProjectAproc(long documentSerial, int? aprocSerial, string aprocAction);
        List<LevelInfoView> ChangeDiscoveryRuleAproc(long discSerial, int? aprocSerial, string aprocAction);
        List<LevelInfoView> ChangeAuctionAproc(long auctionId, int? aprocSerial, string aprocAction);
        int CopyAProcFromTemplate(int oldAprocSerial, long newDocumentSerial, string newDocumentType, string newDocumentTitle, string objectClass = "");
        AProcess CopyAProc(int oldAprocSerial, string newUrl, string newObjectKey = "");
        AProcess CopyAProc(int oldAprocSerial, string newUrl, string newObjectKey = "", string actionId = "");
        void StartAProc(int? aprocSerial, string currentUsername, string selectedUsername, string comment, string title = "", bool makeNew = false);
        AProcReportView AProcReport(string objectKey, string objectClass, string actionId);
        AProcReportView AprocReportView(int aprocSerial);
        void RemoveAprocData(int aprocSerial);

        bool IsAProcOnGoing(int? aprocSerial);
        void ValidateUserAccess(string userName, int aprocSerial);

        List<int> GetListOfEvaluationAproc(long evaluationSerial);
        EvaluationRequestAprocFlowView EvaluationAProcView(List<int> aprocSerials, long evaluationRequestSerial);

    }
}
