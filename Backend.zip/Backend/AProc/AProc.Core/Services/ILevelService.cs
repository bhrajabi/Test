﻿using AProc.Core.Entities;
using AProc.Core.Views;
using System;
using System.Collections.Generic;

namespace AProc.Core
{
    public interface ILevelService
    {
        IList<AProcLevel> GetLevels(int aprocSerial, bool? isPrintable = null);
        void AddUserToLevel(string userName, int levelSerial);
        AProcLevel GetLevel(int? levelSerial);
        LevelInfoView PrevLevelInfo(List<AProcLevel> levels, int currentLevelSerial);
        LevelInfoView FirstLevelInfo(List<AProcLevel> levels, int currentLevelSerial);
        LevelInfoView NextLevelInfo(List<AProcLevel> levels, int levelSerial);
        LevelInfoView FirstSenderInfo(int aprocSerial);
        LevelInfoView LevelInfo(int levelSerial);
        List<UserView> LevelUsers(int levelSerial);
        AProcLevel GetAProcLevel(int levelSerial);
        AProcess GetAProcByLevelSerial(int levelSerial);
        bool IsFirstLevel(int currentLevel, List<int> allLevels);
    }
}
