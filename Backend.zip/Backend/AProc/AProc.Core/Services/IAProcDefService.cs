﻿using AProc.Core.Entities;
using System.Collections.Generic;

namespace AProc.Core
{
    public interface IAProcDefService
    {
        IList<int> GetAprocLevels(int procSerial);
        IList<AProcess> GetAProcess(int buyerId, bool isTemplate);
        AProcess GetAProc(int? serial, int companyId, bool isTemplate = false);
        AProcess AddAproc(int buyerId, bool active, string title);
        AProcess EditAproc(int serial, bool active, string title);
        AProcess CloneAproc(int serial, bool active, string title);
        void RemoveAProc(List<int> serials);
        IList<AProcLevel> GetLevels(int aprocSerial, bool? isPrintable = null);
        AProcLevel GetLevel(int levelSerial);
        IList<AProcUser> GetUsers(int aprocSerial);

        void AddAprocLevel(int procSerial, string title, int levelCode);
        void EditAprocLevel(int serial, string title, int levelCode, int procSerial);
        void RemoveAProcLevel(List<int> serials);

        IList<AProcUser> UserLevels(int levelSerial);
        AProcUser AddUserLevel(int levelSerial, string userName, int companyId);

        string GetUserFullName(string userName, int buyerId);

        void Delete(int serial, int companyId);
        AProcess GetAProc(int serial, int companyId);
        AProcLevel SaveAprocLevel(AProcLevel level);
        void DeleteAprocLevel(int levelSerial);
        void DeleteUserLevel(int levelSerial, string userName);
        void SetUserActive(int levelSerial, string userName, bool active);

        IList<AProcess> GetBuyerAProces(int buyerId, int? authrizationGroupSerial);
        int CreateAproc(int buyerId, bool active, string title, int? referenceSerial, bool isTemplate = false);
    }
}
