﻿using AProc.Core.Entities;
using AProc.Core.Views;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace AProc.Core
{
    public interface INotificationService
    {
        Notification GetNotification(long notificationSerial);

        void SendNotification(int? companyId, string fromUserName, string toUserName, string title, string body);

        void CheckNextLevelAccess(AProcess aproc, LevelInfoView nextLevel, string selectedUser);

        Notification InsertNotification(long? senderSerial, AProcess aProce, string statusId, int levelSerial, string assignedUserName, bool isArchived,
          string fromUserName, string comment = "", DateTime? actionAt = null, string title = "", string type = NotificationTypes.TASK);

        NotificatonActionView UserNotificationActionInitByAProcSerial(int? aprocSerial);

        List<NotificationView> NotificationFlowByAprocSerial(int? aprocSerial, bool? printable = null, bool showStarter = false);
        Task<List<NotificationView>> NotificationFlowByAprocSerialAsync(int? aprocSerial, bool? printable = null, bool showStarter = false);

        void MarkAsVisitNotification(long notificationSerial);
        void ToggleArchiveNotification(long notificationSerial);

        List<NotificationView> GetAprocFlowView(List<NotificationView> aprocFlows, List<LevelInfoView> levels);
        Task<List<NotificationView>> GetAprocFlowViewAsync(List<NotificationView> notificationFlows, List<LevelInfoView> levels);

        void ChangeNotificationStatus(Notification notification, string statusId);

    }
}
