﻿namespace AProc.Core
{
    public static class NotificationTypes
    {
        public const string NOTIFY = "NOTIFY";
        public const string SMS = "SMS";
        public const string TASK = "TASK";
    }
}
