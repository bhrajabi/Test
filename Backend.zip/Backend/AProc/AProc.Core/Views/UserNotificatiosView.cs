﻿using System;

namespace AProc.Core.Views
{
    public class UserNotificatiosView
    {
        public string Title { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedAt { get; set; }
        public string InboxLink { get; set; }
        public string Status { get; set; }
        public string Comment { get; set; }
    }
}
