﻿using System.Collections.Generic;

namespace AProc.Core.Views
{
    public class ProjectAProcView
    {
        public int? SupplierCnfSubmitApProcSerial { get; set; }
      
        public string SupplierCnfSubmitAProcTitle { get; set; }
        

        public List<LevelInfoView> SupplierCnfSubmitLevels { get; set; }

        public List<NotificationView> SupplierCnfSubmitFlows { get; set; }
        
        public long ProjectSerial { get; set; }

        public bool IsSupervisor { get; set; }
    }
}
