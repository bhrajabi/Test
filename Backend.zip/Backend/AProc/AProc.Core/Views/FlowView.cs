﻿using System.Collections.Generic;

namespace AProc.Core.Views
{

    public class FlowView
    {
        public int? CurrentAprocSerial { get; set; }

        public string CurrentAprocTitle { get; set; }


        public List<LevelInfoView> CurrentAprocLevels { get; set; }

        public List<NotificationView> CurrentAprocFlows { get; set; }
    }

}
