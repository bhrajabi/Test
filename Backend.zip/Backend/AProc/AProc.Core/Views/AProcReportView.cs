﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AProc.Core.Views
{
    public class AProcReportView
    {
        public AProcess AProc{ get; set; }
        public List<AProcLevel> Levels { get; set; }
        public IList<NotificationView> Flows { get; set; }

    }
}
