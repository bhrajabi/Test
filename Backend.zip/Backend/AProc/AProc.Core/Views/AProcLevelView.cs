﻿using AProc.Core.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AProc.Core.Views
{
    public class AProcLevelView
    {
        public AProcLevel AProcLevel { get; set; }
        public List<AProcUser> AProcUsers { get; set; }

    }
}
