﻿namespace AProc.Core.Views
{
    public class NotificatonActionView
    {
        public LevelInfoView PrevLevel { get; set; }
        public LevelInfoView NextLevel { get; set; }
        public LevelInfoView FirstLevel { get; set; }
        public LevelInfoView FirstSenderInfo { get; set; }

        public string NotificationTitle { get; set; }

        public string AProcTitle { get; set; }
        public int AProcSerial { get; set; }
        public string AprocActionType { get; set; }

        public string SenderLevelTitle { get; set; }
        public int SenderLevelSerial { get; set; }

        public string CurrentLevelTitle { get; set; }
        public int CurrentLevelSerial { get; set; }

        public string SenderFullName { get; set; }
        public string SenderUserName { get; set; }

        public long NotificationSerial { get; set; }
        public string Comment { get; set; }

        public bool SystemTrigger { get; set; }

    }
}
