﻿namespace AProc.Core.Views
{
    public class NextUsers
    {
        public string UserName{ get; set; }
        public string FullName{ get; set; }
        public string NextLevelTitle { get; set; }
    }
}
