﻿using System.Collections.Generic;

namespace AProc.Core.Views
{
    public class DiscoveryAProcView
    {
        public int? EvaluationAProcSerial { get; set; }

        public string EvaluationAProcTitle { get; set; }


        public List<LevelInfoView> EvaluationAProcSubmitLevels { get; set; }

        public List<NotificationView> EvaluationAProcSubmitFlows { get; set; }

        public long ProjectSerial { get; set; }

        public bool IsSupervisor { get; set; }


        public int? PublishAProcSerial { get; set; }

        public string PublishAProcTitle { get; set; }

        public List<LevelInfoView> PublishAProcLevels { get; set; }

        public List<NotificationView> PublishAProcFlows { get; set; }

    }
}
