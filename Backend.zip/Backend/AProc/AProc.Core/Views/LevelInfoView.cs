﻿using System.Collections.Generic;

namespace AProc.Core.Views
{
    public class LevelInfoView
    {
        public int ProcSerial { get; set; }
        public int LevelSerial { get; set; }
        public string LevelTitle { get; set; }
        public bool? SendToAll{ get; set; }

        public List<UserView> Users { get; set; }
        public string LastAction { get; set; }
    }
}
