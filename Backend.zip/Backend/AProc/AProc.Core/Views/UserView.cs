﻿namespace AProc.Core.Views
{
    public class UserView
    {
        public string UserName { get; set; }
        public string FName { get; set; }
        public string LName { get; set; }
        public bool IsInOrganizationChart { get; set; }
    }
}
