﻿using System.Collections.Generic;

namespace AProc.Core.Views
{
    public class DocumentAProcView
    {
        public int? PublishAProcSerial { get; set; }
        public int? CloseAProcSerial { get; set; }
        public int? GradeAProcSerial { get; set; }
        public int? AwardAProcSerial { get; set; }

        public int? BDrftAProcSerial { get; set; }
        public int? BPublishAProcSerial { get; set; }
        public int? BCloseAProcSerial { get; set; }
        public int? BGradeAProcSerial { get; set; }

        public int? CNFAProcSerial { get; set; }

        public int? PublishAProcVersion { get; set; }
        public int? CloseAProcVersion { get; set; }
        public int? GradeAProcVersion { get; set; }
        public int? AwardAProcVersion { get; set; }

        public int? BDrftAProcVersionion { get; set; }
        public int? CNFAProcVersionion { get; set; }
        public int? BPublishAProcVersion { get; set; }
        public int? BCloseAProcVersion { get; set; }
        public int? BGradeAProcVersion { get; set; }

        public string PublishAProcTitle { get; set; }
        public string CloseAProcTitle { get; set; }
        public string GradeAProcTitle { get; set; }
        public string AwardAProcTitle { get; set; }

        public string BDrftAProcTitle { get; set; }
        public string CNFAProcTitle { get; set; }
        public string BPublishAProcTitle { get; set; }
        public string BCloseAProcTitle { get; set; }
        public string BGradeAProcTitle { get; set; }

        public List<LevelInfoView> PublishLevels { get; set; }
        public List<LevelInfoView> CloseLevels { get; set; }
        public List<LevelInfoView> GradeLevels { get; set; }
        public List<LevelInfoView> AwardLevels { get; set; }

        public List<LevelInfoView> CNFLevels { get; set; }
        public List<LevelInfoView> BDrftLevels { get; set; }
        public List<LevelInfoView> BPublishLevels { get; set; }
        public List<LevelInfoView> BCloseLevels { get; set; }
        public List<LevelInfoView> BGradeLevels { get; set; }

        public List<NotificationView> PublishFlows { get; set; }
        public List<NotificationView> CloseFlows { get; set; }
        public List<NotificationView> GradeFlows { get; set; }
        public List<NotificationView> AwardFlows { get; set; }

        public List<NotificationView> CNFFlows { get; set; }
        public List<NotificationView> BDrftFlows { get; set; }
        public List<NotificationView> BPublishFlows { get; set; }
        public List<NotificationView> BCloseFlows { get; set; }
        public List<NotificationView> BGradeFlows { get; set; }

        public long DocumentSerial { get; set; }

        public bool IsSupervisor { get; set; }
    }
}
