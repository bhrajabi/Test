﻿using System.Collections.Generic;

namespace AProc.Core.Views
{
    public class EvaluationRequestAprocFlowView
    {

        public List<FlowView> Flows { get; set; }

        public List<int> AprocSerialsList { get; set; }

        public long ProjectSerial { get; set; }

        public bool IsSupervisor { get; set; }

        public IList<EvaluationUserView> TeamUsers { get; set; }
    }


    //public class FlowView
    //{
    //    public int? CurrentAprocSerial { get; set; }

    //    public string CurrentAprocTitle { get; set; }

    //    public List<LevelInfoView> CurrentAprocLevels { get; set; }

    //    public List<NotificationView> CurrentAprocFlows { get; set; }
    //}

}
