﻿using System.Collections.Generic;

namespace AProc.Core.Views
{
    public class NotificationActionView
    {
        public LevelInfoView LevelInfo { get; set; }
        public List<string> TeamUsers { get; set; }
    }
}
