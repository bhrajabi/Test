﻿using System.Collections.Generic;

namespace AProc.Core.Views
{
    public class NextLevelInfo
    {
        public string NextLevelTitle { get; set; }
        public int NextLevelSerial { get; set; }
        public List<NextUsers> NextUsers { get; set; }
    }
}
