﻿using System;

namespace AProc.Core.Views
{
    public class NotificationView
    {
        public int AProcSerial { get; set; }
        public long InboxSerial { get; set; }
        public int? LevelSerial { get; set; }
        public string LevelChartCode { get; set; }
        public string InboxLink { get; set; }
        public string Status { get; set; }
        public string Title { get; set; }
        public string Comment { get; set; }
        //public string ReciverComment { get; set; }
        public string MessageType { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime? VisitAt { get; set; }
        public DateTime? ActionAt { get; set; }

        public string SenderFullName { get; set; }
        public string SenderUserName { get; set; }
        public string SenderLevelTitle { get; set; }

        public string ReciverUserName { get; set; }
        public string ReciverFullName { get; set; }
        public string ReciverLevelTitle { get; set; }
        public int ReciverLevelSerial { get; set; }

        public bool IsPrintable { get; set; }
        public bool IsArchived { get; set; }

    }
}
