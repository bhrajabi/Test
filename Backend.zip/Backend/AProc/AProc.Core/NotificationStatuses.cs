﻿namespace AProc.Core
{
    public static class NotificationStatuses
    {
        public const string NEW = "NEW";
        public const string VISITED = "VISITED";
        public const string APPROVED = "APPROVED";
        public const string REFERBACK = "REFERBACK";
        public const string REJECTED = "REJECTED";
    }
}
