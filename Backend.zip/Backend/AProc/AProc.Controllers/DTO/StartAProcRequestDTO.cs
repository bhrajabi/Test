﻿using Common;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace AProc.Controllers.DTO
{
    public class StartAProcRequestDTO
    {
        public int? AprocSerial { get; set; }
        
        [MaxLength(15)]
        public string ObjectKey { get; set; }

        public int? LevelSerial { get; set; }

        [MaxLength(15)] 
        public string AprocAction { get; set; }

        [MaxLength(20)] 
        public string CustomizedParameter { get; set; }
        
        [MaxLength(50)]
        [DefaultValue(SpecialChars.Email)]
        public string SelectedUserName { get; set; }

        [DefaultValue(SpecialChars.Str1000)]
        [MaxLength(2000)]
        public string Comment { get; set; }
        
    }
}
