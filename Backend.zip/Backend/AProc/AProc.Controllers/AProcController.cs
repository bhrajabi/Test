﻿using AProc.Controllers.DTO;
using AProc.Core;
using Common;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using System;
using System.ComponentModel.DataAnnotations;
using Tamin.Core;

namespace AProc.Controllers
{
    [ApiController]
    [EnableCors("react")]
    [Route("[controller]/[action]")]
    [Authorize(AuthenticationSchemes = "Bearer")]
    public class AProcController : Controller
    {
        private IAProcDefService AProcDef;
        private readonly IAccessService accessService;
        private readonly IAProcService aProcService;
        private readonly ILogService logService;
        private readonly ICachedDBService cachedDBService;
        private readonly IProjectService projectService;
        private readonly IEventRuleService eventRuleService;
        private readonly IAProcActionService aProcActionService;
        private readonly IAProcDefService aProcDefService;


        public AProcController(IAProcDefService aprocDefService, IAccessService accessService, ILogService logService, ICachedDBService cachedDBService, IProjectService projectService, IEventRuleService eventRuleService, IAProcService aProcService, IAProcActionService aProcActionService, IAProcDefService aProcDefService)
        {
            AProcDef = aprocDefService;
            this.accessService = accessService;
            this.logService = logService;
            this.cachedDBService = cachedDBService;
            this.projectService = projectService;
            this.eventRuleService = eventRuleService;
            this.aProcService = aProcService;
            this.aProcActionService = aProcActionService;
            this.aProcDefService = aProcDefService;
        }


        [EnableCors("react")]
        [HttpPost]
        [Route("~/aproc/init-start-aproc")]
        public Response InitChangeObjectStatusByAProc(int aprocSerial, [MaxLength(15)] string action, [MaxLength(15)] string objectKey, [MaxLength(15)] string customizedParameter)
        {
            var aproc = aProcDefService.GetAProc(aprocSerial, accessService.CompanyId, false);
            //if (aproc == null) return Responses.RecordNotFound();
            var res = aProcActionService.InitAProcAction(aproc, aproc?.ActionId ?? action, aproc?.ObjectKey ?? objectKey, customizedParameter);

            // var result = aProcService.InitNextLevelAProc(aproc);
            return new Response(res);
        }

        [EnableCors("react")]
        [HttpPost]
        [Route("~/aproc/start")]
        public Response StartAproc([FromBody] StartAProcRequestDTO dto)
        {
            var aproc = aProcDefService.GetAProc(dto.AprocSerial, accessService.CompanyId, false);
            //if (aproc == null) return Responses.RecordNotFound();

            aProcActionService.RunStartAProcAction(aproc, accessService.Now(), dto.SelectedUserName, dto.Comment, dto.AprocAction, dto.ObjectKey, dto.CustomizedParameter);

            return new Response();
        }



    }
}