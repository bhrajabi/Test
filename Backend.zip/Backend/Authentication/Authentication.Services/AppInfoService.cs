﻿using Authentication.Core;
using System;
using System.Linq;

namespace Authentication.Services
{
    public class AppInfoService : IAppInfoService
    {
        private readonly AuthenticationDbContext db;
        private static AppInfo _AppInfo { get; set; }

        public AppInfoService(AuthenticationDbContext db)
        {
            this.db = db;
        }

        public void ResetAppInfo(string json)
        {
            if (_AppInfo is null)
            {
                var dbAppInfo = db.AppInfos.FirstOrDefault();
                if (dbAppInfo is null)
                {
                    dbAppInfo = new AppInfo { Id = 1, JSON = json, Version = 1 };
                    db.AppInfos.Add(dbAppInfo);
                    db.SaveChanges();
                }

                _AppInfo = dbAppInfo;
            }
        }

        public void UpdateAppInfo(string json)
        {
            var dbAppInfo = db.AppInfos.FirstOrDefault();

            if (dbAppInfo != null)
            {
                dbAppInfo.Version++;
                dbAppInfo.JSON = json;
                db.AppInfos.Update(dbAppInfo);
                db.SaveChanges();
                _AppInfo = null;
            }
            ResetAppInfo(json);
        }

        public AppInfo GetAppInfo()
        {
            _AppInfo ??= db.AppInfos.FirstOrDefault();
            return _AppInfo;
        }
    }
}
