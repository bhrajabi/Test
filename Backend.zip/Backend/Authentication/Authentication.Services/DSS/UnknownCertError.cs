using Common;

namespace Authentication.Services.DSS
{
    public class UnknownCertError : Error
    {
        public UnknownCertError() : base("unknown-certificate")
        {

        }
    }
}
