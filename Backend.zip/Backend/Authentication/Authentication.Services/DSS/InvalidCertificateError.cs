using Common;

namespace Authentication.Services.DSS
{
    public class InvalidCertificateError : Error
    {
        public InvalidCertificateError() : base("invalid-certificate")
        {

        }
    }
}
