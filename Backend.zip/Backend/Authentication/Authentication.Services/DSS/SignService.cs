﻿using Authentication.Core.DSS;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Hosting;
using PKTB;
using System;
using System.Net;
using System.Net.Http;
using System.Security.Cryptography.X509Certificates;

namespace Authentication.Services.DSS
{
    public class SignService : ISignService
    {
        private static string ProxyUrl_Production = "http://172.18.1.67:443";
        private static string ProxyUrl_Development = "http://intsrv01.ikco.com:8080";


        private readonly IWebHostEnvironment env;
        private bool ValidateWithOCSP { get { return env.IsProduction() || env.EnvironmentName == "Security"; } }





        public SignService(IWebHostEnvironment env)
        {
            this.env = env;
            SetProxy();
        }


        private static void SetProxy()
        {
            //var proxyUrl = env.IsProduction()  ? ProxyUrl_Production : ProxyUrl_Development;
            HttpClient.DefaultProxy = new WebProxy(ProxyUrl_Production)
            {
                BypassProxyOnLocal = true,
                Credentials = CredentialCache.DefaultCredentials,
            };
        }


        public CertificateData GetCertificateData(string certBase64)
        {
            var certBytes = Convert.FromBase64String(certBase64);
            var certificate = new X509Certificate2(certBytes);
            var data = CertificateData.FromSubject(certificate.Subject);
            if (data.SerialNumber is null) throw new InvalidCertificateError();
            return data;
        }

        public bool IsValidCertificate(string certBase64)
        {
            /*
           true
               CertificateValidationOK = 0,

           false
               PeriodValidationFailed = 1,
               OCSPValidationRevoked = 5,
               CRLValidationRevoked = 7,

           public class UnknownCertError: Error
                                unknown-certificate
               OCSPValidationUnKnown = 6,
               CRLValidationUnKnown = 10,
               CRLAndOCSPValidationUnknown = 11

           public class CertificateServiceError: Error
                                certificate-service-not-available
               IntgrityValidationFailed = 3,
               KeyUsageValidationFailed = 4,
               ChainValidationFailed = 2,
               CRLAndOCSPValidationError = 8,
               OCSPValidationException = 9,  ?

           */

            var certBytes = Convert.FromBase64String(certBase64);
            var certificate = new X509Certificate2(certBytes);
            var data = CertificateData.FromSubject(certificate.Subject);
            if (data.SerialNumber is null) throw new InvalidCertificateError();

            if (!ValidateWithOCSP) return true;
            var va_client = new VAClient();
            var result = (int)va_client.ValidateCertificateEntirely(certificate, "");

            if (result == 0)
            {
                return true;
            }
            else if (result == 1 || result == 5 || result == 7)
            {
                return false;
            }
            else if (result == 6 || result == 10 || result == 11)
            {
                throw new UnknownCertError();
            }
            else if (result == 2 || result == 3 || result == 4 || result == 8 || result == 9)
            {
                throw new CertificateServiceError();
            }
            else
            {
                throw new UnknownCertError();
            }
        }

        public int ValidateCertificate(string certBase64)
        {
            var certBytes = Convert.FromBase64String(certBase64);
            var certificate = new X509Certificate2(certBytes);
            var data = CertificateData.FromSubject(certificate.Subject);
            if (data.SerialNumber is null) throw new InvalidCertificateError();

            var va_client = new VAClient();
            var result = (int)va_client.ValidateCertificateEntirely(certificate, "");
            return result;
        }



        public bool IsValidSign(string sign, string data)
        {
            var crypto = new Crypto();
            return crypto.CmsVerify(sign, crypto.UnicodeToBase64(data));
        }
    }
}


