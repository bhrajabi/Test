using Common;

namespace Authentication.Services.DSS
{
    public class CertificateServiceError : Error
    {
        public CertificateServiceError() : base("certificate-service-not-available")
        {

        }
    }
}
