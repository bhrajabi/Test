using Common;

namespace Authentication.Services.DSS
{
    public class CertificateValidationFailedError : Error
    {
        public CertificateValidationFailedError() : base("certificate-validation-failed")
        {

        }
    }
}
