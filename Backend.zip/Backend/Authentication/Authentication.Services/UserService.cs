﻿using Authentication.Core;
using Microsoft.Data.SqlClient;
using System;
using System.Linq;
using Tamin.Core;

namespace Authentication.Services
{
    public class UserService : IUserService
    {
        private readonly AuthenticationDbContext db;



        public UserService(AuthenticationDbContext db)
        {
            this.db = db;
        }

        public User GetUserByUserName(string userName)
        {
            if (string.IsNullOrEmpty(userName)) return null;
           return db.Users.Where(x => x.UserName == userName).FirstOrDefault();            
        }



        public User GetUserByUID(Guid uid)
        {
            var q = from u in db.Users
                    where u.UniqueId == uid
                    select u;

            return q.FirstOrDefault();
        }

        public string GetFullName(string userName, int companyId)
        {
            return db.GetFullName(userName, companyId);
        }

        public void Insert(User user)
        {
            var now = db.GetDate();
            user.CreatedAt = now;
            user.LastUpdate = now;
            db.Users.Add(user);

            db.SaveChanges();
        }

        public void UpdateUser(User user)
        {
            db.Users.Update(user);
            db.SaveChanges();
        }

        public void CreateUser(User user, string password, bool isIrani)
        {
            if (db.Users.Any(x => x.UserName == user.UserName))
            {
                throw new DuplicateUserNameError();
            }

            if (!string.IsNullOrEmpty(user.NationalCode) && db.Users.Any(x => x.NationalCode == user.NationalCode))
            {
                throw new DuplicateNationalCodeError();
            }

            if (isIrani)
            {
                user.AuthenticationMethod = AuthenticationMethods.PasswordPhone;
                user.DefaultLanguage = "fa";

                if (string.IsNullOrEmpty(user.PhoneNumber))
                {
                    throw new PhoneNumberEmptyError();
                }
            }
            else
            {
                user.AuthenticationMethod = AuthenticationMethods.PasswordEmail;

                user.DefaultLanguage = "en";
                user.NationalCode = "";
                user.UserName = user.Email;

                if (string.IsNullOrEmpty(user.Email))
                {
                    throw new EmailIsEmptyError();
                }

                if (db.Users.Any(x => x.Email == user.Email))
                {
                    throw new DuplicateEmailError();
                }
            }

            db.Add(user);
            db.SaveChanges();

            if (!string.IsNullOrEmpty(password)) SetPassword(user, password);
        }

        public virtual void SetPassword(User user, string password)
        {
            var passwordHash = Common.Cryptography.Helper.HashPassword(password);
            db.Execute($"update PUR.ZUsers set PasswordHash= @passwordHash , AccessFailedCount= 0 , LastAccessFailedDate = NULL   where UserName = @UserName",
               new SqlParameter("@passwordHash", passwordHash),
               new SqlParameter("@UserName", user.UserName));

        }
    }
}