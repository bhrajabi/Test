﻿using Authentication.Core;
using Authentication.Core.DSS;
using Authentication.Services.DSS;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;

namespace Authentication.Services
{
    public static class DependencyInjection
    {
        public static void AddAuthenticationServices(this IServiceCollection services, string connectionString)
        { 
            services.AddDbContext<AuthenticationDbContext>(options => options
                .UseSqlServer(connectionString).UseQueryTrackingBehavior(QueryTrackingBehavior.NoTracking));

            services.AddScoped<IAuthenticationService, FormAuthenticationService>();
            services.AddScoped<IUserService, UserService>();
            services.AddScoped<ITheCompanyService, TheCompanyService>();
            services.AddScoped<ISignService, SignService>();
            services.AddScoped<IAppInfoService, AppInfoService>();
            services.AddScoped<IPgsbService, PgsbService>();
        }
    }
}