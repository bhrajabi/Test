﻿using Authentication.Core;
using Common.Data;
using Common.Security;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using System;
using Tamin.Core;

namespace Authentication.Services
{
    public class AuthenticationDbContext : BaseDbContext
    {
        public DbSet<User> Users { get; set; }
        public DbSet<UserChartView> UserChartViews { get; set; }
        public DbSet<TheCompany> Companies { get; set; }
        public DbSet<TheOrganizationChartUserRole> ChartUserRoles { get; set; }
        public DbSet<TheCompanySetting> CompanieSettings { get; set; }
        public DbSet<TheCompanyUser> CompanyUsers { get; set; }
        public DbSet<UserAgent> UserAgents { get; set; }
        public DbSet<UserSession> UserSessions { get; set; }
        public DbSet<Captcha> Captcha { get; set; }
        public DbSet<TheCompanyCommodity> CompanyCommodities { get; set; }
        public DbSet<TheRelation> Relations { get; set; }
        public DbSet<TheRegistrationRequest> RegistrationRequests { get; set; }

        public DbSet<AppInfo> AppInfos { get; set; }

        public AuthenticationDbContext(DbContextOptions<AuthenticationDbContext> options, IOptions<AuthenticationConfig> AccountsConfig, IHttpContextService currentUserNameService) : base(options, currentUserNameService)
        {
        }

        internal string GetFullName(string userName, int companyId)
        {
            if (string.IsNullOrEmpty(userName)) return null;
            userName = userName.Replace("'", "''");
            return ExecuteScalar($"exec PUR.Get_User_FullName '{userName}', {companyId}") as string;
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<TheCompanyUser>().HasKey(x => new { x.CompanyId, x.UserName });
            modelBuilder.Entity<TheCompanySetting>().HasKey(x => new { x.CompanyId, x.Code });
            modelBuilder.Entity<TheCompanyCommodity>().HasKey(x => new { x.CompanyId, x.CommodityCode });
            modelBuilder.Entity<TheRelation>().HasKey(x => new { x.SellerId, x.BuyerId });
            
            modelBuilder.Entity<UserChartView>().HasKey(x => new { x.CompanyId, x.UserName});
        }

        internal void InitSupplier(int companyId, string userName, string createdBy)
        {
            Database.ExecuteSqlInterpolated($"[PUR].[Init_Supplier] @SellerId={companyId}, @UserName={userName}, @CreatedBy={createdBy}");
        }

        internal int ConnectToCompany(string userName, int companyId)
        {
            userName = userName.Replace("'", "''");

            var where = $"CompanyId={companyId}  and  UserName='{userName}'";
            Execute($"update PUR.CompanyUsers  set IsConnected=1  where  IsConnected=0 and {where}");

            return ExecuteScalar($"select CompanyId from PUR.CompanyUsers  where {where}").ToInt(0);
        }

        public int GetNewNotifCount(string userName, int companyId)
        {
            userName = userName.Replace("'", "''");
            return ExecuteScalar($"exec pur.Get_New_Notif_Count '{userName}', {companyId}").ToInt(0);
        }

        public void CleanCaptcha()
        {
            ExecuteScalar($"exec PUR.P_Clean_Captcha");
        }
    }
}