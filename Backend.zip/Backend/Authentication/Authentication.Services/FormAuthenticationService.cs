﻿using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using Authentication.Core;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using Tamin.Core;

namespace Authentication.Services
{
    internal class FormAuthenticationService : IAuthenticationService
    {
        private readonly IPgsbService pgsbService;
        private readonly AuthenticationDbContext db;
        private readonly AuthenticationConfig _AuthenticationConfig;
        private readonly IAccessService accessService;
        private readonly JwtConfig _JwtConfig;
        private DateTime? _now = null;
        public DateTime Now
        {
            get
            {
                if (_now == null) _now = db.GetDate();
                return _now.Value;
            }
        }

        public FormAuthenticationService(AuthenticationDbContext db, IOptions<AuthenticationConfig> accountsConfig, IOptions<JwtConfig> jwtConfig, IPgsbService pgsbService, IAccessService accessService)
        {
            this.db = db;
            _AuthenticationConfig = accountsConfig.Value;
            _JwtConfig = jwtConfig.Value;
            this.pgsbService = pgsbService;
            this.accessService = accessService;
        }


        public virtual void SetPassword(User user, string password)
        {
            var passwordHash = Common.Cryptography.Helper.HashPassword(password);
            db.Execute($"update PUR.ZUsers set PasswordHash= @passwordHash , AccessFailedCount= 0 , LastAccessFailedDate = NULL   where UserName = @UserName",
               new SqlParameter("@passwordHash", passwordHash),
               new SqlParameter("@UserName", user.UserName));

        }


        public bool ValidateApiKey(string apiKey, int companyId)
        {
            return db.CompanieSettings.Where(c => c.CompanyId == companyId && c.Code == "ApiKey" && c.Value == apiKey).Any();
        }

        public string GenerateToken(User user, int expiresAfterSeconds, int companyId, long? chartUserRoleSerial)
        {
            var key = Encoding.UTF8.GetBytes(_JwtConfig.SecretKey);
            var securityKey = new SymmetricSecurityKey(key);
            var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256Signature);
            var claims = new List<Claim>();
            claims.Add(new Claim(ClaimTypes.Name, user.UserName));

            var userData = $"{companyId},{chartUserRoleSerial}";
            if (!string.IsNullOrEmpty(userData)) claims.Add(new Claim(ClaimTypes.UserData, userData));
            var jwt = new JwtSecurityToken(
                            _JwtConfig.Issuer,
                            _JwtConfig.Audience,
                            claims,
                            expires: DateTime.Now.AddSeconds(expiresAfterSeconds),
                            signingCredentials: credentials);

            return new JwtSecurityTokenHandler().WriteToken(jwt);
        }

        public int GetNewNotifCount(string userName, int companyId)
        {
            return db.GetNewNotifCount(userName, companyId);
        }

        public UserSession GetSessionByRefreshToken(long sessionId, string refreshToken)
        {
            if (sessionId <= 0 || string.IsNullOrEmpty(refreshToken)) return null;
            var session = db.UserSessions.Where(x => x.Id == sessionId && x.RefreshToken == refreshToken && !x.IsDeleted).FirstOrDefault();
            if (session != null && DateTime.Now.Subtract(session.RefreshTokenDate).TotalSeconds >= _JwtConfig.RefreshTokenExpiry)
            {
                session.IsDeleted = true;
                db.Update(session);
                db.SaveChanges();
                session = null;
            }
            return session;
        }

        private UserAgent CreateUserAgent(string userAgent)
        {
            var ua = db.UserAgents.Where(x => x.Value == userAgent).FirstOrDefault();
            if (ua == null)
            {
                ua = new UserAgent(userAgent);
                ua.CreatedAt = db.GetDate();
                db.UserAgents.Add(ua);
                db.SaveChanges();
            }
            return ua;
        }

        public Captcha GetCaptcha(string captchaId)
        {
            if (string.IsNullOrEmpty(captchaId) || captchaId.Length < 10) return null;
            return db.Captcha.Where(x => x.Id == captchaId).FirstOrDefault();
        }

        public bool IsCaptchaRequestOverflow(string ip)
        {
            db.CleanCaptcha();
            var MaxReqCount = _AuthenticationConfig.MaxReqCountInLastMinute;
            var req_count_in_last_minutes = db.Captcha.Where(x => x.IP == ip && Now <= x.CreatedAt.AddMinutes(1)).Count();
            return req_count_in_last_minutes >= MaxReqCount;
        }

        public Captcha CreateCaptcha(string ip, int expiry)
        {
            var st = new Captcha()
            {
                Id = Guid.NewGuid().ToString("N"),
                IP = ip,
                Code = Common.SecurityKeyGenerator.GenerateVerificationCodeForCaptcha(5),
                ExpireAt = Now.AddSeconds(expiry),
                CreatedAt = Now,
            };
            db.Add(st);
            db.SaveChanges();
            return st;
        }

        public bool IsValidCaptcha(Captcha captcha, string code)
        {

            var is_valid = captcha.Code.eq(code) && (Now < captcha.ExpireAt || Now.Subtract(captcha.CreatedAt).TotalSeconds < _AuthenticationConfig.MinDelayForCaptchaResponse);
            captcha.Code = "";
            db.Update(captcha);
            db.SaveChanges();
            return is_valid;
        }

        public UserSession CreateSession(User user, string userAgent, string ip, int companyId, long? chartUserRoleSerial)
        {
            var ua = CreateUserAgent(userAgent);
            var session = new UserSession(user.UserName, ua.Id, ip, companyId, chartUserRoleSerial);
            session.CreatedAt = Now;
            db.UserSessions.Add(session);
            db.SaveChanges();
            return session;
        }

        public void DeleteSession(UserSession session)
        {
            session.IsDeleted = true;
            db.Update(session);
            db.SaveChanges();
        }

        public void DeleteSessions(string userName, long? sessionId)
        {
            var sessions = db.UserSessions.Where(x => x.UserName == userName && !x.IsDeleted);
            if (sessionId.HasValue) sessions = sessions.Where(x => x.Id != sessionId);

            foreach (var s in sessions)
            {
                s.IsDeleted = true;
                db.Update(s);
            }

            db.SaveChanges();
        }

        public void RegenerateRefreshToken(UserSession session, string ip)
        {
            //session.RefreshToken = Guid.NewGuid().ToString("N");
            session.RefreshCount += 1;
            session.RefreshTokenDate = DateTime.Now;
            session.LastIP = ip;
            session.IPList = session.AddToIPList(ip);
            db.Update(session);
            db.SaveChanges();
        }

        public (int, User) Register(User user, TheCompany company, string password)
        {
            if (company.IsIR())
            {
                user.AuthenticationMethod = AuthenticationMethods.PasswordPhone;

                if (string.IsNullOrEmpty(user.PhoneNumber))
                {
                    throw new PhoneNumberEmptyError();
                }

                if ((db.Users.Any(x => x.UserName == user.UserName || x.NationalCode == user.NationalCode)))
                {
                    throw new DuplicateNationalCodeError();
                }

                if (db.Users.Any(x => x.PhoneNumber == user.PhoneNumber))
                {
                    throw new DuplicatePhoneNumberError();
                }
            }
            else
            {
                user.AuthenticationMethod = AuthenticationMethods.PasswordEmail;

                if (string.IsNullOrEmpty(user.Email))
                {
                    throw new EmailIsEmptyError();
                }

                if (db.Users.Any(x => x.Email == user.Email))
                {
                    throw new DuplicateEmailError();
                }
            }

            if (db.Companies.Any(x => x.NationalId == company.NationalId))
            {
                throw new DuplicateNationalIdError();
            }

            if (db.Companies.Any(x => x.Name == company.Name))
            {
                throw new DuplicateCompanyNameError();
            }

            company.CreatedBy = user.UserName;
            company.ModifiedBy = user.UserName;
            company.UniqueId = Guid.NewGuid();

            //--------------
            using var transaction = db.Database.BeginTransaction();
            try
            {
                db.Users.Add(user);
                db.SaveChanges();

                company.AuthenticationStatus = AuthenticationStatuses.NEW;
                db.Companies.Add(company);
                db.SaveChanges();
                db.InitSupplier(company.Id, user.UserName, user.UserName);

                transaction.Commit();

                SetPassword(user, password);

                return new(company.Id, user);
            }
            catch
            {
                transaction.Rollback();
                throw;
            }
        }

        public void RegisterBussiness(User user, TheCompany company, string password)
        {
            if (!string.IsNullOrEmpty(user.NationalCode) && db.Users.Any(x => x.NationalCode == user.NationalCode))
            {
                throw new DuplicateNationalCodeError();
            }

            if (!string.IsNullOrEmpty(user.Email) && db.Users.Any(x => x.Email == user.Email))
            {
                throw new DuplicateEmailError();
            }

            if (db.Companies.Any(x => x.NationalId == company.NationalId))
            {
                throw new DuplicateNationalIdError();
            }

            if (db.Companies.Any(x => x.Name == company.Name))
            {
                throw new DuplicateCompanyNameError();
            }

            using var transaction = db.Database.BeginTransaction();
            try
            {
                user.Show2FAAlarm = true;
                db.Users.Add(user);
                db.SaveChanges();

                company.CreatedBy = user.UserName;
                company.ModifiedBy = user.UserName;
                company.UniqueId = Guid.NewGuid();
                company.AuthenticationStatus = AuthenticationStatuses.NEW;
                db.Companies.Add(company);
                db.SaveChanges();
                db.InitSupplier(company.Id, user.UserName, user.UserName);

                transaction.Commit();
                SetPassword(user, password);
            }
            catch
            {
                transaction.Rollback();
                throw;
            }
        }

        public User Register(User user, string password)
        {

            if (!pgsbService.VerifyShahkar(user.NationalCode, user.PhoneNumber))
            {
                throw new NotMatchMobileAndNationalCodeError();
            }


            if (!string.IsNullOrEmpty(user.NationalCode) && db.Users.Any(x => x.NationalCode == user.NationalCode))
            {
                throw new DuplicateNationalCodeError();
            }

            if (!string.IsNullOrEmpty(user.Email) && db.Users.Any(x => x.Email == user.Email))
            {
                throw new DuplicateEmailError();
            }

            using var transaction = db.Database.BeginTransaction();
            try
            {
                user.Show2FAAlarm = true;
                db.Users.Add(user);
                db.SaveChanges();
                transaction.Commit();

                SetPassword(user, password);
                return user;
            }
            catch
            {
                transaction.Rollback();
                throw;
            }
        }

        public TheCompany CompanyRegister(TheCompany company, User user)
        {
            if (db.Companies.Any(x => x.NationalId == company.NationalId))
            {
                throw new DuplicateNationalIdError();
            }

            if (db.Companies.Any(x => x.Name == company.Name))
            {
                throw new DuplicateCompanyNameError();
            }

            company.CreatedBy = user.UserName;
            company.ModifiedBy = user.UserName;
            company.UniqueId = Guid.NewGuid();

            //--------------
            using var transaction = db.Database.BeginTransaction();
            try
            {
                company.AuthenticationStatus = AuthenticationStatuses.APPROVED;
                company.EnableSupplier = true;

                db.Add(company);
                db.SaveChanges();

                db.InitSupplier(company.Id, user.UserName, user.UserName);

                transaction.Commit();

                return company;
            }
            catch
            {
                transaction.Rollback();
                throw;
            }

        }

        public void CreateCompany(TheCompany company, string createdBy, IList<string> commodities, string erpNumber, int buyerId)
        {
            var nid_isnull = string.IsNullOrEmpty(company.NationalId);
            var ncode_isnull = string.IsNullOrEmpty(company.NationalCode);
            if (nid_isnull == ncode_isnull)
            {
                throw new NationalCodeOrNationalIdRequiredError();
            }

            if (!nid_isnull)
            {
                var company_info = pgsbService.GetRasmioComany(company.NationalId, null) ?? throw new CompanyNotFoundError();
            }

            using var transaction = db.Database.BeginTransaction();
            try
            {
                var db_company =
                        nid_isnull
                            ? db.Companies.Where(x => x.NationalCode == company.NationalCode).FirstOrDefault()
                            : db.Companies.Where(x => x.NationalId == company.NationalId).FirstOrDefault();

                if (db_company is null)
                {
                    //    companyUser.UserName = string.IsNullOrEmpty(companyUser.UserName) ? null : companyUser.UserName;
                    //    CreateSupplierCompany(company, createdBy, companyUser, true);
                }
                else
                {
                    //    //Update Relation
                    if (!string.IsNullOrEmpty(erpNumber))
                    {
                        var relation = db.Relations.Where(x => x.SellerId == db_company.Id && x.BuyerId == buyerId).FirstOrDefault();
                        if (relation != null)
                        {
                            relation.ApprovementStatus =
                                    string.IsNullOrEmpty(erpNumber)
                                    ? RelationApprovmentStatuses.NEW
                                    : RelationApprovmentStatuses.APRV;
                            relation.ERPNumber = erpNumber;
                            relation.CompanyName = company.Name;
                            relation.CountryId = company.CountryId;
                            relation.StateId = company.StateId;
                            relation.City = company.City;
                            relation.Tel1 = company.Tel1;
                            relation.Tel2 = company.Tel2;
                            relation.Email = company.Email;
                            db.Update(relation);
                        }
                    }

                    //    //Added user to company users
                    //    if (!string.IsNullOrEmpty(companyUser.UserName))
                    //    {
                    //        var db_companyUser = db.CompanyUsers.Where(x => x.CompanyId == db_company.Id && x.UserName == companyUser.UserName).FirstOrDefault();
                    //        if (db_companyUser is null)
                    //        {
                    //            db.Add(new TheCompanyUser
                    //            {
                    //                UserName = companyUser.UserName,
                    //                CompanyId = db_company.Id,
                    //                CreatedBy = createdBy
                    //            });
                    //        }
                }
                //}

                db.SaveChanges();
                transaction.Commit();
            }
            catch
            {
                transaction.Rollback();
                throw;
            }
        }

        private void UpdateCompanyCommodities(int companyId, IList<string> commodities)
        {
            var entities = db.CompanyCommodities.Where(x => x.CompanyId == companyId).ToList();
            foreach (var c in entities)
            {
                if (!commodities.Contains(c.CommodityCode)) db.Remove(c);
            }

            foreach (var code in commodities)
            {
                if (!entities.Any(x => x.CommodityCode == code))
                {
                    db.Add(new TheCompanyCommodity
                    {
                        CompanyId = companyId,
                        CommodityCode = code,
                        CommodityCodeL3 = code.Length == 8 ? code.Substring(0, 6) + "00" : code,
                        CommodityCodeL4 = code.Length == 8 ? code : null,
                    });
                }
            }

            db.SaveChanges();
        }

        private void CreateUser(User user, string password, bool isIrani)
        {
            if (db.Users.Any(x => x.UserName == user.UserName))
            {
                throw new DuplicateUserNameError();
            }

            if (!string.IsNullOrEmpty(user.NationalCode) && db.Users.Any(x => x.NationalCode == user.NationalCode))
            {
                throw new DuplicateNationalCodeError();
            }

            if (isIrani)
            {
                user.AuthenticationMethod = AuthenticationMethods.PasswordPhone;
                user.DefaultLanguage = "fa";

                if (string.IsNullOrEmpty(user.PhoneNumber))
                {
                    throw new PhoneNumberEmptyError();
                }
            }
            else
            {
                user.AuthenticationMethod = AuthenticationMethods.PasswordEmail;

                user.DefaultLanguage = "en";
                user.NationalCode = "";
                user.UserName = user.Email;

                if (string.IsNullOrEmpty(user.Email))
                {
                    throw new EmailIsEmptyError();
                }

                if (db.Users.Any(x => x.Email == user.Email))
                {
                    throw new DuplicateEmailError();
                }
            }

            db.Add(user);
            db.SaveChanges();

            if (!string.IsNullOrEmpty(password)) SetPassword(user, password);
        }

        private void CreateSupplierCompany(TheCompany company, string createdBy, User compnyUser, bool autoApprove)
        {
            if (!string.IsNullOrWhiteSpace(company.NationalId) && db.Companies.Any(x => x.NationalId == company.NationalId))
            {
                throw new DuplicateNationalIdError();
            }

            if (!string.IsNullOrWhiteSpace(company.NationalCode) && db.Companies.Any(x => x.NationalCode == company.NationalCode))
            {
                throw new DuplicateNationalCodeError();
            }

            if (db.Companies.Any(x => x.Name == company.Name))
            {
                throw new DuplicateCompanyNameError();
            }

            if (!string.IsNullOrWhiteSpace(company.EconomicCode) && db.Companies.Any(x => x.EconomicCode == company.EconomicCode))
            {
                throw new DuplicateEconomicCodeError();
            }

            if (!string.IsNullOrWhiteSpace(company.TaxId) && db.Companies.Any(x => x.TaxId == company.TaxId))
            {
                throw new DuplicateTaxIdError();
            }

            company.CreatedBy = createdBy;
            company.ModifiedBy = createdBy;
            company.UniqueId = Guid.NewGuid();
            company.EnableSupplier = true;
            company.AuthenticationStatus = autoApprove ? AuthenticationStatuses.APPROVED : AuthenticationStatuses.NEW;

            db.Add(company);
            db.SaveChanges();

            db.InitSupplier(company.Id, compnyUser.UserName, createdBy);
        }

        public int CreateSupplierCompany(TheCompany company, string createdBy, bool autoApprove)
        {
            if (!string.IsNullOrWhiteSpace(company.NationalId) && db.Companies.Any(x => x.NationalId == company.NationalId))
            {
                throw new DuplicateNationalIdError();
            }

            if (!string.IsNullOrWhiteSpace(company.NationalCode) && db.Companies.Any(x => x.NationalCode == company.NationalCode))
            {
                throw new DuplicateNationalCodeError();
            }

            if (db.Companies.Any(x => x.Name == company.Name))
            {
                throw new DuplicateCompanyNameError();
            }

            if (!string.IsNullOrWhiteSpace(company.EconomicCode) && db.Companies.Any(x => x.EconomicCode == company.EconomicCode))
            {
                throw new DuplicateEconomicCodeError();
            }

            if (!string.IsNullOrWhiteSpace(company.TaxId) && db.Companies.Any(x => x.TaxId == company.TaxId))
            {
                throw new DuplicateTaxIdError();
            }

            company.CreatedBy = createdBy;
            company.ModifiedBy = createdBy;
            company.UniqueId = Guid.NewGuid();
            company.EnableSupplier = true;
            company.AuthenticationStatus = autoApprove ? AuthenticationStatuses.APPROVED : AuthenticationStatuses.NEW;

            db.Add(company);
            db.SaveChanges();

            return company.Id;
        }

        public User GetUserByName(string userName)
        {
            if (string.IsNullOrEmpty(userName)) return null;
            return db.Users.Where(x => x.UserName == userName && !x.IsServiceUser).FirstOrDefault();
        }

        public User GetUserByNameOrNationalCode(string userName)
        {
            if (string.IsNullOrEmpty(userName)) return null;
            return db.Users.Where(x => (x.UserName == userName || x.NationalCode == userName) && !x.IsServiceUser).FirstOrDefault();
        }

        public User UpdateUser(UserView user)
        {
            var u = db.Users.FirstOrDefault(x => x.UserName == user.UserName);
            u.FirstName = user.FirstName;
            u.LastName = user.LastName;
            u.DefaultLanguage = user.DefaultLanguage;
            u.WorkPhoneNumber = user.WorkPhoneNumber;
            u.Email = user.Email;

            db.Update(u);
            db.SaveChanges();
            return u;
        }

        public User GetUserByPhoneNumber(string phoneNumber)
        {
            if (string.IsNullOrEmpty(phoneNumber)) return null;
            return db.Users.Where(x => x.PhoneNumber == phoneNumber).FirstOrDefault();
        }

        public IList<User> GetUserNamesByPhoneNumber(string phoneNumber)
        {
            if (string.IsNullOrEmpty(phoneNumber)) return null;
            return db.Users.Where(x => x.PhoneNumber == phoneNumber).ToList();
        }

        public List<UserChartView> GetAllUserCharts(string userName)
        {
            return db.UserChartViews.Where(x => x.UserName == userName).ToList();
        }

        public List<TheCompanyView> GetMyCompanies(string userName)
        {
            var q = from c in db.Companies
                    join cu in db.CompanyUsers on c.Id equals cu.CompanyId
                    where !cu.IsBlocked && cu.UserName == userName
                    select new TheCompanyView
                    {
                        Id = c.Id,
                        CreatedBy = c.CreatedBy,
                        IsConnected = cu.IsConnected,
                        ModifiedBy = c.ModifiedBy,
                        Name = c.Name,
                        NationalId = c.NationalId,

                    };
            return q.ToList();
        }

        public int ConnectToCompany(string userName, int companyId)
        {
            return db.ConnectToCompany(userName, companyId);
        }

        public string GetCompanyName(int companyId)
        {
            return db.Companies.Where(x => x.Id == companyId).Select(x => x.Name).FirstOrDefault();
        }

        public bool IsLocked(User user)
        {
            return
                user.LastAccessFailedDate.HasValue &&
                user.AccessFailedCount >= _AuthenticationConfig.MaxLoginFailCount &&
                Now.Subtract(user.LastAccessFailedDate.Value).TotalSeconds < _AuthenticationConfig.LoginLockoutDuration;
        }

        public void ConfirmUserPhoneNumber(User user)
        {
            user.PhoneNumberConfirmed = true;
            db.Update(user);
            db.SaveChanges();
        }

        public void ConfirmUserEmail(User user)
        {
            user.EmailConfirmed = true;
            db.Update(user);
            db.SaveChanges();
        }

        public void ChangeUserPhoneNumber(User user, string phoneNumber)
        {
            user.PhoneNumber = phoneNumber;
            db.Update(user);
            db.SaveChanges();
        }

        public void ChangeUserEmail(User user, string email)
        {
            user.Email = email;
            db.Update(user);
            db.SaveChanges();
        }

        public void EnableAppTwoFactor(string authenticatorKey, string userName)
        {
            var user = GetUserByName(userName);

            user.AuthenticatorKey = authenticatorKey;
            user.Show2FAAlarm = false;
            db.Update(user);
            db.SaveChanges();
        }

        public string DisableTwoFactor(string userName)
        {
            var user = GetUserByName(userName);
            user.Current2FA = null;
            db.Update(user);
            db.SaveChanges();

            return user.Current2FA;
        }

        public void ChangePreferred(string userName, string current2fa = "sms")
        {
            var user = GetUserByName(userName);

            user.Current2FA = current2fa;
            db.Update(user);
            db.SaveChanges();
        }

        public void DisableTowFactorAlarm(string userName)
        {
            var user = GetUserByName(userName);
            user.Show2FAAlarm = false;
            db.Update(user);
            db.SaveChanges();
        }

        public bool Get2FAStatus(string userName)
        {
            var user = GetUserByName(userName);
            return user.Show2FAAlarm;
        }

        public void AccessFailedCountUpdate(User user)
        {
            user.AccessFailedCount += 1;
            user.LastAccessFailedDate = Now;
            db.Update(user);
            db.SaveChanges();
        }

        public void AccessFailedCountUpdate(IList<User> users)
        {
            foreach (var user in users)
            {
                user.AccessFailedCount += 1;
                user.LastAccessFailedDate = Now;
                db.Update(user);
            }

            db.SaveChanges();
        }

        public void ClearAccessFailedCount(User user)
        {
            user.AccessFailedCount = 0;
            user.LastAccessFailedDate = null;
            db.Update(user);
            db.SaveChanges();
        }

        public void ClearAccessFailedCount(IList<User> users)
        {
            foreach (var user in users)
            {
                user.AccessFailedCount = 0;
                user.LastAccessFailedDate = null;
                db.Update(user);
            }
            db.SaveChanges();
        }

        public void SaveRegisterRequest(TheRegistrationRequest registrationRequest)
        {
            registrationRequest.StatusId = "NEW";
            registrationRequest.CreatedAt = DateTime.Now;
            db.Add(registrationRequest);
            db.SaveChanges();
        }

        public IList<TheRegistrationRequest> GetRegisterRequests(string phoneNumber)
        {
            return db.RegistrationRequests.Where(x => x.OwnerPhoneNumber == phoneNumber).OrderByDescending(x => x.Serial).ToList();
        }


        public TheRegistrationRequest GetRegisterRequest(long serial, string phoneNumber)
        {
            return db.RegistrationRequests.Where(x => x.Serial == serial && x.OwnerPhoneNumber == phoneNumber).FirstOrDefault();
        }

        public IList<ZUserSessionView> GetUserDevices(int companyId, string userName)
        {
            var q = from s in db.UserSessions
                    join a in db.UserAgents on s.UserAgentId equals a.Id
                    where
                        s.CompanyId == companyId &&
                        s.UserName == userName &&
                        s.IsDeleted == false &&
                        s.RefreshTokenDate > DateTime.Now.AddSeconds(-_JwtConfig.RefreshTokenExpiry)

                    orderby s.RefreshTokenDate descending

                    select new ZUserSessionView
                    {
                        Id = s.Id,
                        IP = s.IP,
                        Device = a.Device,
                        Model = a.Model,
                        OS = a.OS,
                        Browser = a.Browser,
                        CreatedAt = s.RefreshTokenDate
                    };

            return q.Take(100).ToList();
        }

        public void UpdateUserDevice(int id, int companyId, string userName)
        {
            var session = db.UserSessions.Where(x => x.Id == id && x.CompanyId == companyId && x.UserName == userName).FirstOrDefault();

            if (session != null)
            {
                session.IsDeleted = true;
                db.UserSessions.Update(session);
                db.SaveChanges();
            }

        }

    }
}