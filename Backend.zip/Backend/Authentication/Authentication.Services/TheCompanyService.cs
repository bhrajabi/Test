﻿using Authentication.Core;
using System.Collections.Generic;
using System.Linq;

namespace Authentication.Services
{
    public class TheCompanyService : ITheCompanyService
    {
        private readonly AuthenticationDbContext db;



        public TheCompanyService(AuthenticationDbContext db)
        {
            this.db = db;
        }

        public TheCompany GetCompanyByOwnerForReal(string userName)
        {
            return db.Companies.Where(x => x.CompanyTypeId.StartsWith("PRIVATE") && x.NationalId == userName).FirstOrDefault();
        }

        public TheCompanyUser GetCompanyUser(int companyId, string userName)
        {
            var companyUser = db.CompanyUsers.Where(x => x.CompanyId == companyId && x.UserName == userName).FirstOrDefault();
            return companyUser;
        }

        public TheCompany AddUserToCompany(TheCompany company, string userName)
        {
            db.InitSupplier(company.Id, userName, userName);

            return company;
        }

        public TheCompany GetCompanyById(int id)
        {
            return db.Companies.FirstOrDefault(x => x.Id == id);
        }

        public TheOrganizationChartUserRole GetChartUserRole(long? chartUserRoleSerial)
        {
            if (chartUserRoleSerial == null) return null;
            return db.ChartUserRoles.FirstOrDefault(x => x.Serial == chartUserRoleSerial);
        }

        public TheCompany VerifyLegalUserCompany(string userName, string nationalId)
        {
            var q = from c in db.Companies
                    where c.NationalId == nationalId && !c.IsBlocked
                    select c;

            return q.FirstOrDefault();
        }

        public IList<TheCompany> GetCompaniesForRegistrationRequest()
        {
            var q = from c in db.Companies
                    where c.EnableSRM && !c.IsBlocked
                    select c;

            return q.ToList();
        }
    }
}