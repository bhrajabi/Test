﻿using Authentication.Core;
using Common;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Tamin.Core;

namespace Authentication.Services
{
    public class PgsbService : IPgsbService
    {
        private readonly PgsbServiceConfig pgsbServiceConfig;

        public PgsbService(IOptions<PgsbServiceConfig> pgsbServiceConfig)
        {
            this.pgsbServiceConfig = pgsbServiceConfig.Value;
        }


        private string GetToken()
        {
            var data = new
            {
                pgsbServiceConfig.ClientId,
                pgsbServiceConfig.ApiKey,
            };

            var rest = new Rest($"{pgsbServiceConfig.ApiAddress}/auth/get-token");
            var response = rest.Post<Response>(data);
            if (response == null) throw new EsbConnectionFailedError();
            if (!response.IsSuccess) throw new EsbServiceError(response.ErrorMessage);

            var result = JsonConvert.DeserializeObject<EsbAuthResult>(response.Result.ToString());
            return result.Token;

        }

        private string Token { get => GetToken(); }


        public bool VerifyShahkar(string nationalCode, string mobileNo)
        {
            var data = new
            {
                MobileNo = mobileNo,
                NationalCode = nationalCode,
            };

            var rest = new Rest($"{pgsbServiceConfig.ApiAddress}/pgsb/shahkar");
            rest.AddHeader("Authorization", "Bearer " + Token);
            var response = rest.Post<Response>(data);
            if (response == null) throw new ShahkarConnectionFailedError();
            if (!response.IsSuccess) throw new ShahkarServiceError(response.ErrorMessage);

            var result = JsonConvert.DeserializeObject<PgsbResponse>(response.Result.ToString());
            return result.IsMatched;
        }

        public RasmioCompanyInfo GetRasmioComany(string nationalId, string nationalCode)
        {
            var data = new
            {
                NationalId = nationalId,
                MemberNationalCode = nationalCode,
            };

            var api = string.IsNullOrEmpty(nationalCode) ? $"{pgsbServiceConfig.ApiAddress}/rasmio/full" : $"{pgsbServiceConfig.ApiAddress}/rasmio/get-company";
            var rest = new Rest(api);
            rest.AddHeader("Authorization", "Bearer " + Token);
            var response = rest.Post<Response<RasmioCompanyInfo>>(data);
            if (response == null) throw new RasmioConnectionFailedError();
            if (!response.IsSuccess)
            {
                if (response.ErrorMessage.EndsWith("404 (Not Found)."))
                    throw new InvalidNationalIdError();

                throw new RasmioServiceError(response.ErrorMessage);
            }

            return response.Result;
        }

        public object GetRasmioComanyFull(string nationalId)
        {
            var data = new
            {
                NationalId = nationalId,
            };

            var rest = new Rest($"{pgsbServiceConfig.ApiAddress}/rasmio/full");
            rest.AddHeader("Authorization", "Bearer " + Token);
            var response = rest.Post<Response<object>>(data);

            if (response == null) throw new RasmioConnectionFailedError();
            if (!response.IsSuccess)
            {
                if (response.ErrorMessage.EndsWith("404 (Not Found)."))
                    throw new InvalidNationalIdError();

                throw new RasmioServiceError(response.ErrorMessage);
            }

            return response.Result;
        }

       
    }
}
