﻿using System.Collections.Generic;
using Tamin.Core;

namespace Authentication.Core
{
    public interface IAuthenticationService
    {
        void SetPassword(User user, string password);
        string GenerateToken(User user, int expiresAfterSeconds, int companyId, long? chartUserRoleSerial);

        User GetUserByName(string userName);
        User GetUserByNameOrNationalCode(string userName);
        User GetUserByPhoneNumber(string phoneNumber);
        IList<User> GetUserNamesByPhoneNumber(string phoneNumber);

        User UpdateUser(UserView user);

        UserSession GetSessionByRefreshToken(long sessionId, string refreshToken);
        UserSession CreateSession(User user, string userAgent, string ip, int companyId, long? chartUserRoleSerial);
        void DeleteSession(UserSession session);
        void DeleteSessions(string userName, long? sessionId);
        void RegenerateRefreshToken(UserSession session, string ip);


        void CreateCompany(TheCompany company, string createdBy, IList<string> commodities, string eRPNumber, int BuyerId);
        (int, User) Register(User user, TheCompany company, string password);

        User Register(User user, string password);
        TheCompany CompanyRegister(TheCompany company, User user);

        List<TheCompanyView> GetMyCompanies(string userName);
        bool IsLocked(User user);
        int ConnectToCompany(string userName, int companyId);
        string GetCompanyName(int companyId);
        bool ValidateApiKey(string apiKey, int companyId);
        int GetNewNotifCount(string userName, int companyId);

        void ConfirmUserPhoneNumber(User user);
        void ConfirmUserEmail(User user);

        void ChangeUserPhoneNumber(User user, string phoneNumber);
        void ChangeUserEmail(User user, string email);

        void EnableAppTwoFactor(string authenticatorKey, string userName);
        string DisableTwoFactor(string userName);
        void ChangePreferred(string userName, string current2fa = "sms");
        void DisableTowFactorAlarm(string userName);
        bool Get2FAStatus(string userName);

        void AccessFailedCountUpdate(User user);
        void AccessFailedCountUpdate(IList<User> users);
        void ClearAccessFailedCount(User user);
        void ClearAccessFailedCount(IList<User> users);

        Captcha GetCaptcha(string captchaId);
        Captcha CreateCaptcha(string ip, int expiry);

        bool IsCaptchaRequestOverflow(string ip);
        bool IsValidCaptcha(Captcha captcha, string code);
        int CreateSupplierCompany(TheCompany company, string createdBy, bool autoApprove);

        void RegisterBussiness(User user, TheCompany company, string password);


        IList<ZUserSessionView> GetUserDevices(int companyId, string userName);
        void UpdateUserDevice(int id, int companyId, string userName);
        List<UserChartView> GetAllUserCharts(string userName);
    }
}