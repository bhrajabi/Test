﻿using System;

namespace Authentication.Core
{
    public interface IUserService
    {
        void Insert(User user);
        User GetUserByUserName(string userName);
        string GetFullName(string userName, int companyId);
        User GetUserByUID(Guid uid);
        void UpdateUser(User user);
        void CreateUser(User user, string password, bool isIrani);
    }
}