﻿
namespace Authentication.Core
{
    public interface IAppInfoService
    {
        AppInfo GetAppInfo();
        void ResetAppInfo(string json);
        void UpdateAppInfo(string json);
    }
}
