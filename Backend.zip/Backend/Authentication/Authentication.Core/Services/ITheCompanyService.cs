﻿using System;
using System.Collections;
using System.Collections.Generic;

namespace Authentication.Core
{
    public interface ITheCompanyService
    {
        TheCompany GetCompanyByOwnerForReal(string userName);
        TheCompanyUser GetCompanyUser(int companyId, string userName);
        TheCompany AddUserToCompany(TheCompany company, string userName);
        TheCompany GetCompanyById(int id);
        TheCompany VerifyLegalUserCompany(string userName,string nationalId);

        IList<TheCompany> GetCompaniesForRegistrationRequest();
        TheOrganizationChartUserRole GetChartUserRole(long? chartUserRoleSerial);
    }
}