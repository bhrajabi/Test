﻿using System;

namespace Authentication.Core
{
    public static class TowFactorAuthenticatorMethods
    {
        public static string Sms { get => "sms"; }
        public static string Authenticator { get => "authenticator"; }
        public static string Email { get => "email"; }

        public static bool IsSms(string x) => !string.IsNullOrEmpty(x) && x == Sms;
        public static bool IsAuthenticator(string x) => !string.IsNullOrEmpty(x) && x == Authenticator;
        public static bool IsEmail(string x) => !string.IsNullOrEmpty(x) && x == Email;
    }
}
