﻿namespace Authentication.Core
{
    public class AuthenticationConfig
    {
        public const string SectionName = "Authentication";

        public int MaxLoginFailCount { get; set; }
        public int LoginLockoutDuration { get; set; }
        public int AnonymousLoginExpiry { get; set; } = 240;
        public int SmsExpiry { get; set; }
        public string RefTokenCookieName { get; set; }
        public string SessionIdCookieName { get; set; }
        public string SecurityKeyCookieName { get; set; }

        public int CaptachExpiry { get; set; }
        public int VCodeExpiry { get; set; }

        public int MaxReqCountInLastMinute { get; set; }
        public int MinDelayForCaptchaResponse { get; set; }

    }
}