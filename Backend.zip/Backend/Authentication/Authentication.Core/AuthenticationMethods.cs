﻿using System;

namespace Authentication.Core
{
    public static class AuthenticationMethods
    {
        public static string PasswordPhone { get => "Password_Phone"; }
        public static string PasswordEmail { get => "Password_Email"; }


        public static bool IsPasswordPhone(string method)
        {
            return !string.IsNullOrEmpty(method) && method == PasswordPhone;
        }

        public static bool IsPasswordEmail(string method)
        {
            return !string.IsNullOrEmpty(method) && method == PasswordEmail;
        }

    }
}
