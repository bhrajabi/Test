﻿namespace Authentication.Core
{
    public class AuthenticationStatuses
    {
        public static string APPROVED = "APPROVED";
        public static string IN_PROC = "IN-PROC";
        public static string NEW = "NEW";
        public static string REJECTED = "REJECTED";
    }
}
