﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Authentication.Core
{
    [Table("AppInfo", Schema = "PUR")]
    public class AppInfo
    {
        [Key]
        public int Id { get; set; }

        public long Version { get; set; }
        public string JSON { get; set; }
    }
}
