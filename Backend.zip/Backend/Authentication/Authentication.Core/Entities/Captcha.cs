﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Authentication.Core
{
    [Table("ZCaptcha", Schema = "PUR")]
    public class Captcha
    {
        [Key]
        public string Id { get; set; }

        public string Code { get; set; }
        public string IP { get; set; }
        public DateTime ExpireAt { get; set; }
        public DateTime CreatedAt { get; set; }
    }
}