﻿using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace Authentication.Core
{
    [Table("CompanyUsers", Schema = "PUR")]
    public class TheCompanyUser
    {
        public int CompanyId { get; set; }
        public string UserName { get; set; }
        public bool IsConnected { get; set; } = false;
        public bool IsBlocked { get; set; } = false;

        public string Title { get; set; }
        public string Address { get; set; }
        public string AdminComments { get; set; }

        public string CreatedBy { get; set; }

    }
}
