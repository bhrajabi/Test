﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Authentication.Core
{
    [Table("Users", Schema = "dbo")]
    public class User
    {
        [Key]
        public string UserName { get; set; }

        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string NationalCode { get; set; }
        public string PhoneNumber { get; set; }
        public string? Email { get; set; }
        public string PasswordHash { get; set; }
        public byte[]? ImageData { get; set; }
        public int AccessFailedCount { get; set; }
        public DateTime? LastAccessFailedDate { get; set; }
        public bool IsDeleted { get; set; }
        public bool IsDisabled { get; set; }
        public DateTime LastUpdate { get; set; }
        public DateTime CreatedAt { get; set; }

        public User() => CreatedAt = DateTime.Now;
    }
}

