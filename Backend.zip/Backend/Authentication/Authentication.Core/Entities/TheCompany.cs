﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Authentication.Core
{
    [Table("Companies", Schema = "PUR")]
    public class TheCompany
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        public string NationalId { get; set; }
        public string NationalCode { get; set; }
        public string Name { get; set; }
        public string CompanyTypeId { get; set; }
        public string CountryId { get; set; }
        public string StateId { get; set; }
        public string City { get; set; }
        public string Address { get; set; }
        public string PostalCode { get; set; }
        public string EconomicCode { get; set; }
        public string TaxId { get; set; }
        public string BankName { get; set; }
        public string ShebaCode { get; set; }
        public string RegNumber { get; set; }
        public string Mobile { get; set; }
        public string WebSite { get; set; }
        public string Email { get; set; }
        public string Tel1 { get; set; }
        public string Tel2 { get; set; }
        public string Fax { get; set; }
        public string Description { get; set; }
        public string DefaultUserNamePrefix { get; set; }
        public string AuthenticationStatus { get; set; }
        public bool EnableSupplier { get; set; }
        public bool IsBlocked { get; set; }
        public string ModifiedBy { get; set; }
        public string CreatedBy { get; set; }
        public bool EnableSRM { get; set; }
        public bool EnableSourcing { get; set; }
        public bool EnableTM { get; set; }
        public Guid UniqueId { get; set; }
        public bool EnablePublicProfile { get; set; }
        public string TAC { get; set; }
        public long? TACAttachmentId { get; set; }


        public bool IsIR()
        {
            return CountryId.eq("ir");
        }
    }
}
