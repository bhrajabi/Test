﻿using System.ComponentModel.DataAnnotations.Schema;

namespace Authentication.Core
{
    [Table("V_UserCharts", Schema = "PUR")]
    public class UserChartView
    {
        public int CompanyId { get; set; }
        public long? ChartUserRoleSerial { get; set; }
        public string UserName { get; set; }

        public string CompanyName { get; set; }
        public string RoleTitle { get; set; }
        public string ChartTitle { get; set; }
        public bool IsConnected { get; set; }
    }
}
