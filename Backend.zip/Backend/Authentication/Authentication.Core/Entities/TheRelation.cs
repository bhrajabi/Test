﻿using System;
using System.ComponentModel.DataAnnotations.Schema;
using Common.Data;

namespace Authentication.Core
{
    [Table("Relations", Schema = "PUR")]
    public class TheRelation : IHasCreator, IHasModifier
    {
        public int BuyerId { get; set; }
        public int SellerId { get; set; }

        public long ProjectSerial { get; set; }
        public int StartedQualifyCount { get; set; }
        public int QualifiedCount { get; set; }
        public int PrefereCount { get; set; }
        public Double? AvgScore { get; set; }
        public int? ParticipationPercentage { get; set; }
        public string Grade { get; set; }
        public string MainContactUser { get; set; }
        public string ApprovementStatus { get; set; }
        public DateTime? ValidFrom { get; set; }
        public DateTime? ValidTo { get; set; }
        public bool IsValid { get; set; }
        public string Description { get; set; }
        public string ERPNumber { get; set; }
        public string ContactUserEmail { get; set; }
        public string ContactUserPhoneNumber { get; set; }
        public string ContactUserFullName { get; set; }
        public string SellerName { get; set; }

        public string CompanyName { get; set; }
        public string ServiceDescription { get; set; }
        public string CountryId { get; set; }
        public string StateId { get; set; }
        public string City { get; set; }
        public string Address { get; set; }
        public string PostalCode { get; set; }
        public string Tel1 { get; set; }
        public string Tel2 { get; set; }
        public string Fax { get; set; }
        public string Email { get; set; }
        public string WebSite { get; set; }
        public string ShebaCode { get; set; }
        public string AccountHolderName { get; set; }
        public string BankName { get; set; }


        public string ModifiedBy { get; set; }
        public DateTime ModifiedAt { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedAt { get; set; }

    }
}
