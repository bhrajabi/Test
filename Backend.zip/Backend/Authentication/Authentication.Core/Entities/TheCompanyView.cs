﻿namespace Authentication.Core
{
    public class TheCompanyView
    {
        public int Id { get; set; }
        
        public string roleId { get; set; }
        public long? chartSerial { get; set; }

        public string NationalId { get; set; }
        public string Name { get; set; }
        public bool IsConnected { get; set; }

        public string ModifiedBy { get; set; }
        public string CreatedBy { get; set; }

    }
}
