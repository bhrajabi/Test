﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Authentication.Core
{
    [Table("CompanySettings", Schema = "PUR")]
    public class TheCompanySetting
    {
        public int CompanyId { get; set; } 
        public string Code { get; set; } 
        public string Value { get; set; } 
    }
}
