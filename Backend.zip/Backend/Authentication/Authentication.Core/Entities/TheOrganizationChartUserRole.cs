﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Authentication.Core
{
    [Table("OrganizationChartUserRoles", Schema = "PUR")]
    public class TheOrganizationChartUserRole
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Serial { get; set; }
        public int CompanyId { get; set; }
        public long ChartSerial { get; set; }
        public string UserName { get; set; }
        public string RoleId { get; set; }

        public bool IsActive { get; set; }
        public DateTime? EndDate { get; set; }
        public DateTime CreatedAt { get; set; }
    }
}
