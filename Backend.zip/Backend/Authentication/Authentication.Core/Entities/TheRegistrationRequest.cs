﻿using Common.Data;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Tamin.Core
{
    [Table("RegistrationRequests", Schema = "PUR")]
    public class TheRegistrationRequest
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Serial { get; set; }

        public int CompanyId { get; set; }
        public int BuyerId { get; set; }
        public string NationalId { get; set; }
        public string Name { get; set; }
        public string OwnerFirstName { get; set; }
        public string OwnerLastName { get; set; }
        public string OwnerNationalCode { get; set; }
        public string OwnerPhoneNumber { get; set; }
        public string OwnerEmail { get; set; }
        public string TypeId { get; set; }
        public string TypeOther { get; set; }
        public string RegNumber { get; set; }
        public DateTime? RegDate { get; set; }
        public string EconomicCode { get; set; }
        public string TaxId { get; set; }
        public string ServiceDescription { get; set; }
        public string Industry { get; set; }
        public string BusinessTypes { get; set; }
        public string Tel1 { get; set; }
        public string Tel2 { get; set; }
        public string Fax { get; set; }
        public string CountryId { get; set; }
        public string StateId { get; set; }
        public string City { get; set; }
        public string Address { get; set; }
        public string PostalCode { get; set; }
        public string Email { get; set; }
        public string WebSite { get; set; }
        public string ShebaCode { get; set; }
        public string AccountHolderName { get; set; }
        public string BankName { get; set; }
        public bool EnableSupplier { get; set; }
        public bool IsCarrier { get; set; }
        public string StatusId { get; set; }
        public string RejectReason { get; set; }
        public string Description { get; set; }
        public DateTime CreatedAt { get; set; }
    }
}
