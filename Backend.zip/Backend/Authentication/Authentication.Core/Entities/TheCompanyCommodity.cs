﻿using System.ComponentModel.DataAnnotations.Schema;

namespace Authentication.Core
{
    [Table("CompanyCommodities", Schema = "PUR")]
    public class TheCompanyCommodity
    {
        public int CompanyId { get; set; }
        public string CommodityCode { get; set; }

        public string CommodityCodeL3 { get; set; }
        public string CommodityCodeL4 { get; set; }
    }
}
