﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Net;

namespace Authentication.Core
{
    [Table("ZUserSessions", Schema = "PUR")]
    public class UserSession
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Id { get; set; }

        public string UserName { get; set; }
        public string RefreshToken { get; set; }
        public int CompanyId { get; set; }
        public long? ChartUserRoleSerial { get; set; }
        public int RefreshCount { get; set; } = 1;
        public DateTime RefreshTokenDate { get; set; } = DateTime.Now;
        public string LastIP { get; set; }
        public string IPList { get; set; }
        public string IP { get; set; }
        public int UserAgentId { get; set; }
        public bool IsDeleted { get; set; }
        public DateTime CreatedAt { get; set; }


        public UserSession()
        {
        }

        public UserSession(string userName, int userAgentId, string ip, int companyId, long? chartUserRoleSerial)
        {
            UserName = userName;
            RefreshToken = Guid.NewGuid().ToString("N");
            RefreshTokenDate = DateTime.Now;
            RefreshCount = 1;
            CompanyId = companyId;
            ChartUserRoleSerial = chartUserRoleSerial;

            if (ip.eq("::1"))
            {
                ip= Dns.GetHostEntry(Dns.GetHostName()).AddressList[0].ToString();
            }

            UserAgentId = userAgentId;
            LastIP = ip;
            IPList = ip;
            IP = ip;
        }

        public string AddToIPList(string ip)
        {
            if (string.IsNullOrEmpty(IPList)) return ip;
            var list = IPList.Split(',').ToList();
            if (list.IndexOf(ip) >= 0) return IPList;
            list.Add(ip);
            var s = string.Join(",", list);
            return s.Length > 200 ? IPList : s;
        }
    }
}