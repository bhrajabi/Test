﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Authentication.Core
{
    [Table("UserRoles", Schema = "dbo")]
    public class UserRole
    {
        [Key]
        public string UserName { get; set; }


        public string RoleId { get; set; }
    }
}

