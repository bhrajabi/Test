﻿namespace Authentication.Core.DSS
{
    public interface ISignService
    {
        bool IsValidSign(string sign, string data);
        bool IsValidCertificate(string certBase64);
        int ValidateCertificate(string certBase64);
        CertificateData GetCertificateData(string cert);
    }
}
