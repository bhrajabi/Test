﻿namespace Authentication.Core.DSS
{
    public class CertificateData
    {
        public string SerialNumber { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string NationalId { get; set; }
        public string Name { get; set; }
        public string CountryId { get; set; }
        public string State { get; set; }
        public string City { get; set; }

        
        public static CertificateData FromSubject(string subject)
        {
            var data = new CertificateData();
            foreach (var field in subject.Split(','))
            {
                var keyValue = field.Trim().Split('=');
                var name = keyValue[0].Trim();
                var value = keyValue[1].Trim();
                switch (name)
                {
                    case "SERIALNUMBER": data.SerialNumber = value; break;
                    case "G": data.FirstName = value; break;
                    case "SN": data.LastName = value; break;
                    case "OID.2.5.4.97": data.NationalId = value; break;
                    case "OU": data.Name = value; break;
                    case "C": data.CountryId = value; break;
                    case "S": data.State = value; break;
                    case "L": data.City = value; break;
                }
            }

            return data;
        }
    }
}
