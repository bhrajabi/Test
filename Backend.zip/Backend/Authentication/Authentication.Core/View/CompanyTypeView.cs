﻿namespace Authentication.Core
{
    public class CompanyTypeView
    {
        public string Id { get; set; }
        public string Title { get; set; }
    }
}
