﻿namespace Authentication.Core
{
    public class CommodityOwnerView
    {
        public string UserName { get; set; }
        public string DisplayName { get; set; }
        public string CommodityCode { get; set; }
    }
}
