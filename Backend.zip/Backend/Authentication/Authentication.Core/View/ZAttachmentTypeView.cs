﻿namespace Authentication.Core
{
    public class ZAttachmentTypeView
    {
        public string Id { get; set; }
        public string Title { get; set; }
        public long MaxSize { get; set; }
        public string ValidTypes { get; set; }
        public int Count { get; set; }
    }
}
