﻿namespace Authentication.Core
{
    public class CurrencyView
    {
        public string Id { get; set; }
        public string Title { get; set; }
    }
}
