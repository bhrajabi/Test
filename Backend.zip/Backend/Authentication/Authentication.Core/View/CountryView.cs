﻿namespace Authentication.Core
{
    public class CountryView
    {
        public string Id { get; set; }
        public string Title { get; set; }
    }
}
