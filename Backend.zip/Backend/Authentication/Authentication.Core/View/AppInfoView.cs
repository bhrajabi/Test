﻿using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using System.Collections.Generic;

namespace Authentication.Core
{
    public class AppInfoView
    {
        public List<CompanyTypeView> CompanyTypes { get; set; }
        public List<CountryView> Countries { get; set; }
        public List<CurrencyView> Currencies { get; set; }
        public List<ZAttachmentTypeView> AttachmentTypes { get; set; }

        public override string ToString()
        {
            return JsonConvert.SerializeObject(this, new JsonSerializerSettings { ContractResolver = new CamelCasePropertyNamesContractResolver() });
        }
    }
}
