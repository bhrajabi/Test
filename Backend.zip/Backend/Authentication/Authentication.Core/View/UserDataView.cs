﻿namespace Authentication.Core
{
    public class UserDataView
    {
        public string UserName { get; set; }
        public string NationalCode { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string NationalId { get; set; }
        public string Name { get; set; }
        public string CountryId { get; set; }
        public string State { get; set; }
        public string City { get; set; }
    }

}
