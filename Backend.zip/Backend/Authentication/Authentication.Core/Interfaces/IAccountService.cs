﻿namespace Authentication.Core
{
    public interface IAccountService
    {
        void SetPassword(User user, string password);
        void DeleteSession(UserSession session);
        UserSession GetSessionByRefreshToken(long sessionId, string refreshToken);
        string GetToken(User user, int expiresAfterSeconds, string userData);
        User GetUserByName(string userName);
        User GetUserByPhoneNumber(string phoneNumber);
        bool IsLocked(User user);
        void Register(User user, TAddress address, string password);
        void Update(User user);
        UserSession? CreateSession(User user, string userAgent, string userIP);
        void ResetPassword(User user, string Password);
    }
}
