﻿namespace Authentication.Core
{
    public interface IMessagingService
    {
        void SendOtp(string phoneNumber, string message);
    }
}