﻿namespace Authentication.Core
{
    public interface IPgsbService
    {
        bool VerifyShahkar(string nationalCode, string mobileNo);
        RasmioCompanyInfo GetRasmioComany(string nationalId, string nationalCode);
        object GetRasmioComanyFull(string nationalId);
    }
}
