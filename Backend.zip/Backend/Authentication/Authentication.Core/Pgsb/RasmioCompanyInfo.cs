﻿using System;

namespace Authentication.Core
{
    public class RasmioCompanyInfo
    {
        public bool IsMemeberExists { get; set; }
        public bool IsMemeberActive { get; set; }
        public string MemeberFullName { get; set; }
        public string MemeberPosition { get; set; }

        public string Name { get; set; }
        public string PictureUrl { get; set; }

        public string RegistrationNo { get; set; }
        public DateTime RegistrationDate { get; set; }
        public string RegistrationType { get; set; }
        public string TaxNumber { get; set; }

        public string Address { get; set; }
        public string PostalCode { get; set; }
        public float Latitude { get; set; }
        public float Longitude { get; set; }

        public string Tel { get; set; }
        public string Fax { get; set; }
        public string Mobile { get; set; }
        public string Email { get; set; }
        public string Website { get; set; }


        public bool IsActive { get; set; }
    }
}