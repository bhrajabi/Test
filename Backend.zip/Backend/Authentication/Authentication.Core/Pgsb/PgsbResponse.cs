﻿namespace Authentication.Core
{
    public class PgsbResponse
    {
        public bool IsMatched { get; set; }
        public string Comment { get; set; }
    }
}
