﻿namespace Authentication.Core
{
    public class EsbAuthResult
    {
        public string Token { get; set; }
    }
}
