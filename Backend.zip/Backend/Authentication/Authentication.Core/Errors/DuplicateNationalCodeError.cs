﻿using Common;

namespace Authentication.Core
{
    public class DuplicateNationalCodeError : Error
    {
        public DuplicateNationalCodeError() : base("duplicate-national-code")
        {
        }
    }
}
