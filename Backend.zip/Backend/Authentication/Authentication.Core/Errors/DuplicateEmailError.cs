﻿using Common;

namespace Authentication.Core
{
    public class DuplicateEmailError : Error
    {
        public DuplicateEmailError() : base("duplicate-email-address")
        {
        }
    }

    
}
