﻿using Common;

namespace Authentication.Core
{
    public class EsbServiceError : Error
    {
        public EsbServiceError(string message) : base("error-in-esb-service-@message")
        {
            Add("message", message);
        }
    }
}
