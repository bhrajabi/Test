﻿using Common;

namespace Authentication.Core
{
    public class DuplicateNationalIdError : Error
    {
        public DuplicateNationalIdError() : base("duplicate-national-id")
        {
        }
    }
}
