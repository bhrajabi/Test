﻿using Common;

namespace Authentication.Core
{
    public class EsbConnectionFailedError : Error
    {
        public EsbConnectionFailedError() : base("esb-connection-failed")
        {
        }
    }
}
