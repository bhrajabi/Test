﻿using Common;

namespace Authentication.Core
{
    public class RasmioServiceError : Error
    {
        public RasmioServiceError(string message) : base("error-in-rasmio-service-@message")
        {
            Add("message", message);
        }
    }
}
