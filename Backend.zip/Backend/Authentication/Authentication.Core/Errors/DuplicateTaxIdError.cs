﻿using Common;

namespace Authentication.Core
{
    public class DuplicateTaxIdError : Error
    {
        public DuplicateTaxIdError() : base("duplicate-company-tax-id")
        {
        }
    }
}
