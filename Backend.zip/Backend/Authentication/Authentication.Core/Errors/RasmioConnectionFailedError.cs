﻿using Common;

namespace Authentication.Core
{
    public class RasmioConnectionFailedError : Error
    {
        public RasmioConnectionFailedError() : base("rasmio-connection-failed")
        {
        }
    }
}
