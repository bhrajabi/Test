﻿using Common;

namespace Authentication.Core
{
    public class ShahkarConnectionFailedError : Error
    {
        public ShahkarConnectionFailedError() : base("shahkar-connection-failed")
        {
        }
    }
}
