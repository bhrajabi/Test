﻿using Common;

namespace Authentication.Core
{
    public class PhoneNumberEmptyError : Error
    {
        public PhoneNumberEmptyError() : base("phone-number-is-empty")
        {
        }
    }
}
