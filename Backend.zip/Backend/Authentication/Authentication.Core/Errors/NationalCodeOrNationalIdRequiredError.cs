﻿using Common;

namespace Authentication.Core
{
    public class NationalCodeOrNationalIdRequiredError : Error
    {
        public NationalCodeOrNationalIdRequiredError() : base("national-code-or-national-id-required")
        {
        }
    }
}
