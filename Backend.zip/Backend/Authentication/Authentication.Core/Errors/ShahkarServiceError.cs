﻿using Common;

namespace Authentication.Core
{
    public class ShahkarServiceError : Error
    {
        public ShahkarServiceError(string message) : base("error-in-shahkar-service-@message")
        {
            Add("message", message);
        }
    }
}
