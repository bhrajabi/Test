﻿using Common;

namespace Authentication.Core
{
    public class DuplicateUserAndCompanyError : Error
    {
        public DuplicateUserAndCompanyError() : base("duplicate-user-and-company")
        {
        }
    }
}
