﻿using Common;

namespace Authentication.Core
{
    public class DuplicateEconomicCodeError : Error
    {
        public DuplicateEconomicCodeError() : base("duplicate-company-economic-code")
        {
        }
    }
}
