﻿using Common;

namespace Authentication.Core
{
    public class DuplicatePhoneNumberError : Error
    {
        public DuplicatePhoneNumberError() : base("duplicate-phone-number")
        {
        }
    }
}
