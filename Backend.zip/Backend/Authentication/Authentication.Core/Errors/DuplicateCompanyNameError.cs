﻿using Common;

namespace Authentication.Core
{
    public class DuplicateCompanyNameError : Error
    {
        public DuplicateCompanyNameError() : base("duplicate-company-name")
        {
        }
    }
}
