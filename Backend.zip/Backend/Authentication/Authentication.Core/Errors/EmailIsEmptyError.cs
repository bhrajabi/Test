﻿using Common;

namespace Authentication.Core
{
    public class EmailIsEmptyError : Error
    {
        public EmailIsEmptyError() : base("email-can-not-be-empty")
        {
        }
    }
}
