﻿using Common;

namespace Authentication.Core
{
    public class CompanyIsBlockedError : Error
    {
        public CompanyIsBlockedError() : base("company-is-blocked")
        {
        }
    }
}
