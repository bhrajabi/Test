﻿using Common;

namespace Authentication.Core
{
    public class NotMatchMobileAndNationalCodeError : Error
    {
        public NotMatchMobileAndNationalCodeError() : base("not-matched-mobile-and-national-code")
        {
        }
    }
}
