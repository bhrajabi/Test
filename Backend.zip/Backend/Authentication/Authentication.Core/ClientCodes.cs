﻿namespace Authentication.Core
{
    public static class ClientCommands
    {
        public static string TimeoutExpired { get => "TimeoutExpired"; }
    }
}
