﻿using Authentication.Core;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using System.IO;
using Tamin.Core;

namespace Authentication.Controllers
{
    public class CaptchaController : ControllerBase
    {
        private readonly IAuthenticationService accountService;
        private readonly AuthenticationConfig _AuthenticationConfig;
        private readonly IAccessService accessService;
        public CaptchaController(IAuthenticationService authenticationService, IOptions<AuthenticationConfig> accountsConfig, IAccessService accessService)
        {
            accountService = authenticationService;
            _AuthenticationConfig = accountsConfig.Value;
            this.accessService = accessService;
        }


        [HttpGet]
        [Route("~/captcha")]
        public ActionResult Index()
        {
            Request.Cookies.TryGetValue(_AuthenticationConfig.SecurityKeyCookieName, out var captchaId);
            if (accountService.IsCaptchaRequestOverflow(accessService.RequestIP)) return BadRequest();
            var captcha = accountService.CreateCaptcha(accessService.RequestIP, _AuthenticationConfig.CaptachExpiry);

            // put captcha id in to response cookie
            Response.Cookies.Append(_AuthenticationConfig.SecurityKeyCookieName, captcha.Id, GetCookieOption());

            //
            using (var mem = new MemoryStream())
            using (var bmp = Common.Captcha.GenerateComplexImage(captcha.Code, 250, 56))
            {
                //ImageFilter.Water(bmp, 12, false);

                bmp.Save(mem, System.Drawing.Imaging.ImageFormat.Jpeg);
                return this.File(mem.ToArray(), "image/jpeg");
            }
        }

        public static CookieOptions GetCookieOption()
        {
            return new CookieOptions() { HttpOnly = true, SameSite = SameSiteMode.Unspecified };
        }



      
    }
}
