﻿namespace Authentication.Controllers
{
    public class ForgotPasswordDTO
    {
        public string PhoneNumber { get; set; }
        public string Password { get; set; }

        public byte[] Key { get; set; }
    }
}
