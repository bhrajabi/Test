﻿namespace Authentication.Controllers
{
    public class VerificationCodeResultDTO
    {
        public string PhoneNumber { get; set; }
        public byte[] Key { get; set; }
        public int Expiry { get; set; }
        public string AuthenticationMethod { get; set; }
        public string MaskedPhoneNumber { get; set; }
    }
}
