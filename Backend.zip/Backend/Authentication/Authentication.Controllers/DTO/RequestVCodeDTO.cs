﻿using System.ComponentModel.DataAnnotations;

namespace Authentication.Controllers
{
    public class RequestVCodeDTO
    {
        [MaxLength(12)]
        public string PhoneNumber { get; set; }
        [MaxLength(12)]
        public string NationalCode { get; set; }
        [MaxLength(10)]
        public string Captcha { get; set; }
    }
}
