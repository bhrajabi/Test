﻿namespace Authentication.Controllers
{
    public class ChangeUserEmailDTO
    {
        public string UserName { get; set; }
        public string Email { get; set; }
        public string Code { get; set; }

        public byte[] Key { get; set; }
    }
}