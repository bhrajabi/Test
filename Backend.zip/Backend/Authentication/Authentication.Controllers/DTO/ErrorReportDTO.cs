﻿using System.ComponentModel.DataAnnotations;

namespace Authentication.Controllers
{
    public class AuthenticationErrorReportDTO
    {
        [MaxLength(15)]
        public string PhoneNumber { get; set; }

        [MaxLength(500)]
        public string Message { get; set; }
    }
}