﻿namespace Authentication.Controllers
{
    public class RecoveryUserNameDTO
    {
        public string PhoneNumber { get; set; }
        public string Email { get; set; }
        public string Captcha { get; set; }
        public string Code { get; set; }
        public byte[] Key { get; set; }
    }
}
