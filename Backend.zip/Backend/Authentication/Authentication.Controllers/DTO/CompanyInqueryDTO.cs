﻿using Common;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Authentication.Controllers
{
    public class CompanyInqueryDTO
    {
        [MaxLength(50)]
        [DefaultValue(SpecialChars.Email)]
        public string UserName { get; set; }
        [MaxLength(20)]
        public string NationalCode { get; set; }
        [MaxLength(20)]
        public string NationalId { get; set; }

        [MaxLength(5000)]
        public byte[] Key { get; set; }
    }
}