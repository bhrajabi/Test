﻿using Common;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Authentication.Controllers
{
    public class CertificateDTO
    {
        [DefaultValue(SpecialChars.All)]
        [MaxLength(50000)]
        public string Bs64Cert { get; set; }
    }
}