﻿namespace Authentication.Controllers
{
    public class AddressDTO
    {
        public int Serial { get; set; }

        public int StateId { get; set; }
        public int CityId { get; set; }
        public string? PostalCode { get; set; }
        public string? Address1 { get; set; }
    }
}
