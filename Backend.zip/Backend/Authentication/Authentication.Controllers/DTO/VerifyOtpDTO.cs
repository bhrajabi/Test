﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Authentication.Controllers
{
    public class VerifyOtpDTO
    {
        [MaxLength(15)]
        public string PhoneNumber { get; set; }
        [MaxLength(6)]
        public string Code { get; set; }

        [MaxLength(150)]
        public byte[] Key { get; set; }
    }
}