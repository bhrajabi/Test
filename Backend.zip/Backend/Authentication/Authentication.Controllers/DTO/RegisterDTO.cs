﻿namespace Authentication.Controllers
{
    public class RegisterDTO
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string NationalCode { get; set; }
        public string PhoneNumber { get; set; }
        public string Password { get; set; }
        public int StateId { get; set; }
        public int CityId { get; set; }
        public string? PostalCode { get; set; }
        public string? Address1 { get; set; }

        public byte[] Key { get; set; }
    }
}
