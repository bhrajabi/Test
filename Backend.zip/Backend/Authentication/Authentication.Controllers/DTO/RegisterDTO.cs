﻿using Common;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Authentication.Controllers
{
    public class RegisterDTO
    {
        public UserDTO User{ get; set; }
        public TheCompanyDTO Company { get; set; }
        [MaxLength(4096)]
        [DefaultValue(SpecialChars.All)]
        public string Bs64Cert { get; set; }
        [MaxLength(10)]
        public string Code { get; set; }
        [MaxLength(5000)]
        public byte[] Key { get; set; }
    }

}

