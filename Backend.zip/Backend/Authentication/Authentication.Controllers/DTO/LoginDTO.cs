﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using Common;

namespace Authentication.Controllers
{
    public class LoginDTO
    {
        [MaxLength(50)]
        [DefaultValue(SpecialChars.Email)]
        public string UserName { get; set; }

        public int CompanyId { get; set; }

        [MaxLength(20)]
        public string Current2FA { get; set; }
        
        public long AppVersion { get; set; }
        
        public long? ChartUserRoleSerial { get; set; }
        
        [MaxLength(5000)]
        public byte[] Key { get; set; }

       
    }
}