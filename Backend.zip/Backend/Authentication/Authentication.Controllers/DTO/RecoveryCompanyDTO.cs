﻿using Common;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Authentication.Controllers
{
    public class RecoveryCompanyDTO
    {
        [MaxLength(50000)]
        [DefaultValue(SpecialChars.All)]
        public string Bs64Cert { get; set; }
        [MaxLength(50)]
        [DefaultValue(SpecialChars.Email)]
        public string UserName { get; set; }
    }
}