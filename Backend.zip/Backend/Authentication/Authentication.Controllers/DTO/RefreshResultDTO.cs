﻿namespace Authentication.Controllers
{
    public class RefreshResultDTO
    {
        public string Token { get; set; }
        public int Expiry { get; set; }

        public string UserName { get; set; }
        public string DisplayName { get; set; }
    }
}