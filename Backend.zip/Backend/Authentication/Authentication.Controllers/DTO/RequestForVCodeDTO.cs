﻿using Common;
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Authentication.Controllers
{
    public class RequestForVCodeDTO
    {
        [MaxLength(50)]
        public string FirstName { get; set; }
        [MaxLength(50)]
        public string LastName { get; set; }
        [MaxLength(10)]
        public string CountryId { get; set; }
        [MaxLength(50)]
        public string StateId { get; set; }
        [MaxLength(50)]
        public string City { get; set; }
        [MaxLength(12)]
        public string PhoneNumber { get; set; }
        [MaxLength(50)]
        [DefaultValue(SpecialChars.Password)]
        public string Password { get; set; }
        
        [MaxLength(50)]
        [DefaultValue(SpecialChars.Email)]
        public string Email { get; set; }
        [MaxLength(50)]
        [DefaultValue(SpecialChars.Email)]
        public string UserName { get; set; }
        public int Expiry { get; set; }
        [MaxLength(10)]
        public string Captcha { get; set; }
        [MaxLength(10)]
        public string Code { get; set; }

        [MaxLength(5000)]
        public byte[] Key { get; set; }


        public bool IsIR()
        {
            return CountryId.eq("ir");
        }
    }
}
