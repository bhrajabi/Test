﻿namespace Authentication.Controllers
{
    public class AuthenticateRegisterResultDTO
    {
        public string UserInfo { get; set; }
    }
}