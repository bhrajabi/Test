﻿namespace Authentication.Controllers
{
    public class RegistrationRequestBuyersDTO
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string TAC { get; set; }
        public long? TACAttachmentId { get; set; }
    }
}