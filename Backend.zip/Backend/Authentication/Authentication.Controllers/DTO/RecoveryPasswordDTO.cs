﻿using Common;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Authentication.Controllers
{
    public class RecoveryPasswordDTO
    {
        [MaxLength(50)]
        [DefaultValue(SpecialChars.Email)]
        public string UserName { get; set; }
        [MaxLength(10)]
        public string Captcha { get; set; }
    }
}   