﻿using System;

namespace Authentication.Controllers
{
    public class UserDevicesDTO
    {
        public long Id { get; set; }
        public string IP { get; set; }
        public string Device { get; set; }
        public string Model { get; set; }
        public string OS { get; set; }
        public string Browser { get; set; }
        public DateTime CreatedAt { get; set; }
    }
}