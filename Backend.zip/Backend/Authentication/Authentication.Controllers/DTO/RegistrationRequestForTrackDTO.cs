﻿using System;

namespace Authentication.Controllers
{
    public class RegistrationRequestsDTO
    {
        public int Serial { get; set; }

        public string Name { get; set; }
        public int BuyerId { get; set; }
        public string OwnerFirstName { get; set; }
        public string OwnerLastName { get; set; }
        public string StatusId { get; set; }
        public DateTime CreatedAt { get; set; }
    }
}