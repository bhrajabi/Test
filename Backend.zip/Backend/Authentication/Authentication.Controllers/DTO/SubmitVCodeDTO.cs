﻿using System.ComponentModel.DataAnnotations;

namespace Authentication.Controllers
{
    public class SubmitVCodeDTO
    {
        [MaxLength(12)]
        public string PhoneNumber { get; set; }
        [MaxLength(12)]
        public string NationalCode { get; set; }
        [MaxLength(10)]
        public string Captcha { get; set; }
        [MaxLength(10)]
        public string Code { get; set; }
        [MaxLength(5000)]
        public byte[] Key { get; set; }
    }
}
