﻿using System.ComponentModel.DataAnnotations;

namespace Authentication.Controllers
{
    public class RegistrationRequestResultDTO
    {
        public int Id { get; set; }
        [MaxLength(50)]
        public string Name { get; set; }
    }
}
