﻿namespace Authentication.Controllers
{
    public class VerificationCodeDTO
    {
        public string PhoneNumber { get; set; }
        public int Code { get; set; }
        public byte[] Key { get; set; }
    }
}
