﻿using Common;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Authentication.Controllers
{
    public class ChanegPasswordDTO
    {
        [MaxLength(50)]
        [DefaultValue(SpecialChars.Email)]
        public string UserName { get; set; }
        [MaxLength(100)]
        [DefaultValue(SpecialChars.Str100)]
        public string OldPassword { get; set; }
        [MaxLength(100)]
        [DefaultValue(SpecialChars.Str100)]
        public string NewPassword { get; set; }
        [MaxLength(5000)]
        public byte[] Key { get; set; }

    }
}