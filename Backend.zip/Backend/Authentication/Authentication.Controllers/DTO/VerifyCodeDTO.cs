﻿using Common;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Authentication.Controllers
{
    public class VerifyCodeDTO
    {
        [MaxLength(12)]
        public string PhoneNumber { get; set; }
        [MaxLength(50)]
        [DefaultValue(SpecialChars.Email)]
        public string Email { get; set; }
        [MaxLength(20)]
        public string AuthenticationMethod { get; set; }
        [MaxLength(50)]
        [DefaultValue(SpecialChars.Password)]
        public string Password { get; set; }
        [MaxLength(50)]
        [DefaultValue(SpecialChars.Email)]
        public string UserName { get; set; }
        [MaxLength(10)]
        public string Code { get; set; }
        [MaxLength(10)]
        public string Captcha { get; set; }
        [MaxLength(5000)]
        public byte[] Key { get; set; }
    }
}
