﻿namespace Authentication.Controllers
{
    public class PhoneAuthenticationRequestDTO
    {
        public string PhoneNumber { get; set; }
        public string Captcha { get; set; }
    }
}
