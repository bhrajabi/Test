﻿namespace Authentication.Controllers
{
    public class CompanyInfoDTO
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public bool IsConnected { get; set; }
    }
}