﻿using Common;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Authentication.Controllers
{
    public class ResetPasswordDTO
    {
        [MaxLength(50)]
        [DefaultValue(SpecialChars.Email)]
        public string UserName { get; set; }
        [MaxLength(10)]
        public string Code { get; set; }
        [MaxLength(100)]
        [DefaultValue(SpecialChars.Password)]
        public string Password { get; set; }
        [MaxLength(5000)]
        public byte[] Key { get; set; }
    }
}