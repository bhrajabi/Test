﻿using Common;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Authentication.Controllers
{
    public class TheCompanyDTO
    {
        [MaxLength(20)]
        public string CompanyTypeId { get; set; }
        [MaxLength(15)]
        public string NationalId { get; set; }
        [MaxLength(100)]
        [DefaultValue(SpecialChars.Str100)]
        public string Name { get; set; }
        [MaxLength(50)]
        public string CountryId { get; set; }
        [MaxLength(100)]
        [DefaultValue(SpecialChars.Str100)]
        public string StateId { get; set; }
        [MaxLength(100)]
        [DefaultValue(SpecialChars.Str100)]
        public string City { get; set; }
        [MaxLength(200)]
        [DefaultValue(SpecialChars.Str100)]
        public string Address { get; set; }
        [MaxLength(11)]
        public string PostalCode { get; set; }
    }
}