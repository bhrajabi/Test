﻿using Common;
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Authentication.Controllers
{
    public class UserDTO
    {
        [MaxLength(50)]
        [DefaultValue(SpecialChars.Email)]
        public string UserName { get; set; }
        [MaxLength(100)]
        [DefaultValue(SpecialChars.Str100)]
        public string FirstName { get; set; }
        [MaxLength(100)]
        [DefaultValue(SpecialChars.Str100)]
        public string LastName { get; set; }
        [MaxLength(20)]
        public string NationalCode { get; set; }
        [MaxLength(15)]
        public string PhoneNumber { get; set; }
        [MaxLength(15)]
        public string WorkPhoneNumber { get; set; }
        [MaxLength(20)]
        [DefaultValue(SpecialChars.Password)]
        public string Password { get; set; }
        [MaxLength(50)]
        [DefaultValue(SpecialChars.Email)]
        public string Email { get; set; }
        [MaxLength(20)]
        public string AuthenticationMethod { get; set; }
        [MaxLength(50)]
        public string CountryId { get; set; }
        [MaxLength(100)]
        [DefaultValue(SpecialChars.Str100)]
        public string StateId { get; set; }
        [MaxLength(100)]
        [DefaultValue(SpecialChars.Str100)]
        public string City { get; set; }
        [MaxLength(10)]
        public string DefaultLanguage { get; set; }
        [MaxLength(20)]
        public string Current2FA { get; set; }
        [MaxLength(50)]
        public string AuthenticatorKey { get; set; }
        public bool Show2FAAlarm { get; set; }
        public DateTime LastUpdate { get; set; }
        public DateTime CreatedAt { get; set; }


        public bool IsIR()
        {
            return CountryId.eq("ir");
        }
    }
}