﻿using Common;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Authentication.Controllers
{
    public class RegisterBussinessDTO
    {
        [MaxLength(50)]
        [DefaultValue(SpecialChars.Email)]
        public string UserName { get; set; }
        [MaxLength(100)]
        [DefaultValue(SpecialChars.Str100)]
        public string FirstName { get; set; }
        [MaxLength(100)]
        [DefaultValue(SpecialChars.Str100)]
        public string LastName { get; set; }
        [MaxLength(20)]
        public string NationalCode { get; set; }
        [MaxLength(15)]
        public string PhoneNumber { get; set; }
        [MaxLength(20)]
        [DefaultValue(SpecialChars.Password)]
        public string Password { get; set; }
        [MaxLength(50)]
        [DefaultValue(SpecialChars.Email)]
        public string Email { get; set; }

        //Company
        [MaxLength(100)]
        [DefaultValue(SpecialChars.Str100)]
        public string Name { get; set; }
        [MaxLength(10)]
        public string CountryId { get; set; }
        [MaxLength(100)]
        [DefaultValue(SpecialChars.Str100)]
        public string StateId { get; set; }
        [MaxLength(100)]
        [DefaultValue(SpecialChars.Str100)]
        public string City { get; set; }


        [MaxLength(10)]
        public string Captcha { get; set; }
        [MaxLength(5000)]
        public byte[] Key { get; set; }
    }

}

