﻿using Common;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Authentication.Controllers
{
    public class AuthenticatorDTO
    {
        [MaxLength(50)]
        public string AuthenticatorSecretKey { get; set; }
        [MaxLength(10)]
        public string Captcha { get; set; }
        [MaxLength(6)]
        public string Code { get; set; }
        [MaxLength(50)]
        [DefaultValue(SpecialChars.Email)]
        public string UserName { get; set; }
        [MaxLength(5)]
        public string Type { get; set; }

        [MaxLength(20)]
        public string Preferred { get; set; }

        [MaxLength(5000)]
        public byte[] Key { get; set; }

        [MaxLength(5000)]
        public byte[] AuthenticatorKey { get; set; }

        [MaxLength(20)]
        public string Current2FA { get; set; }
    }
}