﻿using Authentication.Core;
using Common;
using Main.Core;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;

namespace Authentication.Controllers
{
    [ValidateDto]
    [ApiController]
    [EnableCors("react")]
    [Route("[controller]/[action]")]
    [Authorize(AuthenticationSchemes = "Bearer")]
    public class AuthenticationController : ControllerBase
    {
        private readonly AuthenticationConfig _AuthenticationConfig;
        private readonly JwtConfig _JwtConfig;
        private readonly IAccountService accountService;
        private readonly IConfiguration configuration;
        private readonly IMessagingService messagingService;

        private const string SecurityKeyCookieName = "x-security-key";


        private string UserIP { get => Request.HttpContext?.Connection?.RemoteIpAddress?.ToString() ?? ""; }

        public AuthenticationController(IConfiguration configuration, IAccountService accountService, IOptions<AuthenticationConfig> accountsConfig,
           IOptions<JwtConfig> jwtConfig, IMessagingService messagingService)
        {
            this.configuration = configuration;
            this.accountService = accountService;
            this._AuthenticationConfig = accountsConfig.Value;
            this._JwtConfig = jwtConfig.Value;
            this.messagingService = messagingService;
        }

        #region AllowAnonymous
        [AllowAnonymous]
        [HttpPost]
        [Route("~/authentication/get-user-info")]
        public Response GetUserInfo()
        {
            Request.Cookies.TryGetValue(_AuthenticationConfig.SessionIdCookieName, out var sessionId);
            Request.Cookies.TryGetValue(_AuthenticationConfig.RefTokenCookieName, out var ref_token);
            var session = accountService.GetSessionByRefreshToken(sessionId.ToLong(0), ref_token);
            if (session == null)
            {
                return new Response("401");
            }
            var user = accountService.GetUserByName(session.UserName);
            var ref_result = Refresh(user, session);
            var result = new
            {
                UserName = user.UserName,
                DisplayName = $"{user.FirstName} {user.LastName}",
                Token = ref_result.Token,
                Expiry = ref_result.Expiry,
            };
            return new Response(result);
        }


        [AllowAnonymous]
        [HttpPost]
        [Route("~/authentication/request-verification-code")]
        public Response RequestVerificationCode(string captcha, string phoneNumber)
        {
            if (!IsValidCaptcha(captcha)) return Responses.InvalidCaptcha();

            //Send OTP
            var otp = SecurityKeyGenerator.GenerateVerificationCode(5);
            if (!SkipVerificationCode)
            {
                messagingService.SendOtp(phoneNumber, otp);
            }

            var result = new
            {
                Expiry = _AuthenticationConfig.SmsExpiry,
                Key = SecurityKeyGenerator.GenerateTimeStampKey("", phoneNumber + "-" + otp, 10),
                PhoneNumber = phoneNumber
            };

            return new Response(result);
        }

        [AllowAnonymous]
        [HttpPost]
        [Route("~/authentication/verification-code")]
        public Response VerificationCode([FromBody] VerificationCodeDTO model)
        {
            if (model == null) return Responses.BadRequest();

            if (!SkipVerificationCode)
            {
                if (!SecurityKeyGenerator.IsValidTimeStampKey("", model.PhoneNumber + "-" + model.Code, model.Key))
                {
                    return Responses.InvalidUserOrVerificationCode();
                }
            }

            var result = new
            {
                Expiry = _AuthenticationConfig.SmsExpiry,
                Key = SecurityKeyGenerator.GenerateTimeStampKey("", model.PhoneNumber, 10),
                model.PhoneNumber
            };

            return new Response(result);
        }

        [AllowAnonymous]
        [HttpPost]
        [Route("~/authentication/login")]
        public Response Login([FromBody] LoginDTO model)
        {
            if (model == null) return Responses.BadRequest();
            if (!IsValidCaptcha(model.Captcha)) return Responses.InvalidCaptcha();

            var user = accountService.GetUserByName(model.UserName);
            if (user == null) return Responses.InvalidUserNameOrPassword();

            var passwordHash = Common.Cryptography.Helper.HashPassword(model.Password);
            if (!passwordHash.Equals(user.PasswordHash)) return Responses.InvalidUserNameOrPassword();

            Request.Cookies.TryGetValue(_AuthenticationConfig.SessionIdCookieName, out var sessionId);
            Request.Cookies.TryGetValue(_AuthenticationConfig.RefTokenCookieName, out var ref_token);
            var session = accountService.GetSessionByRefreshToken(sessionId.ToLong(0), ref_token);
            if (session != null && session.UserName != user.UserName)
            {
                accountService.DeleteSession(session);
            }

            var userAgent = Request.Headers["User-Agent"].ToString();
            session = accountService.CreateSession(user, userAgent ?? "", UserIP);

            var ref_result = Refresh(user, session);

            var result = new
            {
                UserName = user.UserName,
                DisplayName = $"{user.FirstName} {user.LastName}",
                ref_result.Token,
            };

            return new Response(result);
        }

        [AllowAnonymous]
        [HttpPost]
        [Route("~/authentication/register")]
        public Response Register([FromBody] RegisterDTO model)
        {
            if (model == null) return Responses.BadRequest();

            if (!SkipVerificationCode)
            {
                if (!SecurityKeyGenerator.IsValidTimeStampKey("", model.PhoneNumber, model.Key))
                {
                    return Responses.InvalidUserOrVerificationCode();
                }
            }

            var user = model.MapTo<User>();
            var address = new TAddress
            {
                StateId = model.StateId,
                CityId = model.CityId,
                PostalCode = model.PostalCode,
                Address1 = model.Address1
            };

            accountService.Register(user, address, model.Password);

            return new Response();
        }

        [AllowAnonymous]
        [HttpPost]
        [Route("~/authentication/forgot-password")]
        public Response ForgotPassword([FromBody] ForgotPasswordDTO model)
        {
            if (model == null) return Responses.BadRequest();

            var user = accountService.GetUserByName(model.PhoneNumber);
            if (user == null) return Responses.InvalidUserNameOrPassword();

            if (!SkipVerificationCode)
            {
                if (!SecurityKeyGenerator.IsValidTimeStampKey("", model.PhoneNumber, model.Key))
                {
                    return Responses.InvalidUserOrVerificationCode();
                }
            }

            accountService.ResetPassword(user, model.Password);

            return new Response();
        }
        #endregion

        #region Authorize

        [HttpPost]
        [Route("~/authentication/update-user")]
        public Response UpdateUser([FromBody] UserDTO model)
        {
            if (model == null) return Responses.BadRequest();

            var user = accountService.GetUserByName(User.Identity.Name);
            user.FirstName = model.FirstName;
            user.LastName = model.LastName;

            accountService.Update(user);

            return new Response();
        }


        [HttpPost]
        [Route("~/authentication/reset-password")]
        public Response ResetPassword(string password, string oldPassword)
        {
            if (string.IsNullOrEmpty(password)) return Responses.BadRequest();

            var user = accountService.GetUserByName(User.Identity.Name);

            if (user.PasswordHash != Common.Cryptography.Helper.HashPassword(oldPassword))
            {
                return Responses.InvalidOldPassword();
            }

            accountService.ResetPassword(user, password);

            return new Response();
        }
        #endregion

        #region Private


        private RefreshResultDTO Refresh(User user, UserSession session)
        {
            var token = accountService.GetToken(user, _JwtConfig.Expiry, user.UserName);
            if (session != null)
            {
                Response.Cookies.Append(_AuthenticationConfig.RefTokenCookieName, session.RefreshToken, GetCookieOption());
                Response.Cookies.Append(_AuthenticationConfig.SessionIdCookieName, session.Id.ToString(), GetCookieOption());
            }

            return new RefreshResultDTO
            {
                Token = token,
                UserName = user.UserName,
                DisplayName = $"{user.FirstName} {user.LastName}",
            };
        }

        private static CookieOptions GetCookieOption()
        {
            return new CookieOptions() { HttpOnly = true };
        }

        private User LoadValidUser(string userName, byte[] key)
        {
            var user = accountService.GetUserByName(userName) ?? throw new Exception(Messages.InvalidUser);
            if (accountService.IsLocked(user)) throw new Exception(Messages.UserIsLocked);

            if (!SecurityKeyGenerator.IsValidTimeStampKey("", userName, key))
            {
                throw new Exception(Messages.TimeExpired);
            }

            return user;
        }

        private bool SkipCaptcha => configuration["SkipCaptcha"].eq("true");

        private bool SkipVerificationCode => configuration["SkipVerificationCode"].eq("true");

        private static string MaskPhoneNumber(string phoneNumber)
        {
            if (string.IsNullOrEmpty(phoneNumber) || phoneNumber.Length < 8)
            {
                phoneNumber = "09" + DateTime.Now.Ticks.ToString();
                if (phoneNumber.Length > 11) phoneNumber = phoneNumber.Substring(0, 15);
            }
            var mask = new char[phoneNumber.Length];
            for (int i = 0; i < mask.Length; i++)
            {
                mask[i] = i > 1 && i < mask.Length - 2 ? 'X' : phoneNumber[i];
            }
            return new string(mask);
        }

        private bool IsValidCaptcha(string captcha)
        {
            if (SkipCaptcha) return true;

            Request.Cookies.TryGetValue(SecurityKeyCookieName, out var securityKeyString);
            var securityKey = string.IsNullOrEmpty(securityKeyString) ? null : System.Convert.FromBase64String(securityKeyString);

            if (securityKey == null || !SecurityKeyGenerator.IsValidTimeStampKey("", captcha.ToLower(), securityKey))
            {
                return false;
            }

            Response.Cookies.Delete(SecurityKeyCookieName, new CookieOptions { Secure = true });
            return true;
        }

        #endregion
    }
}