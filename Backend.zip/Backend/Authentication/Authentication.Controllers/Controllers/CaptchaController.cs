﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Authentication.Controllers
{
    public class CaptchaController : ControllerBase
    {
        internal const string SecurityKeyCookieName = "x-security-key";

        [HttpGet]
        [Route("~/captcha")]
        public ActionResult Index()
        {
            var vcode = Common.SecurityKeyGenerator.GenerateVerificationCodeForCaptcha(5);
            var key = Common.SecurityKeyGenerator.GenerateTimeStampKey("", vcode, 2);

            // put key in to response cookie
            var key_text = System.Convert.ToBase64String(key);
            Response.Cookies.Append(SecurityKeyCookieName, key_text, GetCookieOption());

            //
            using (var mem = new MemoryStream())
            using (var bmp = Common.Captcha.GenerateImage(vcode))
            {
                bmp.Save(mem, System.Drawing.Imaging.ImageFormat.Jpeg);
                return this.File(mem.ToArray(), "image/jpeg");
            }
        }

        public static CookieOptions GetCookieOption()
        {
            return new CookieOptions() { HttpOnly = true };
        }
    }
}
