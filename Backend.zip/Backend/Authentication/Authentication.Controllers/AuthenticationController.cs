﻿using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using Authentication.Core;
using Authentication.Core.DSS;
using Authentication.Services.DSS;
using Common;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Options;
using OtpNet;
using QRCoder;
using Tamin.Core;
using Tamin.Services;
using WorkFlow.Core.Services;
using YamlDotNet.Core;
using static System.Net.WebRequestMethods;
using static Common.SecurityKeyGenerator;

namespace Authentication.Controllers
{
    [ApiController]
    [ValidateModel]
    [Route("[controller]/[action]")]
    [Authorize(AuthenticationSchemes = "Bearer")]
    public class AuthenticationController : ControllerBase
    {
        #region Constractor

        private readonly AuthenticationConfig _AuthenticationConfig;
        private readonly JwtConfig _JwtConfig;
        private readonly IAuthenticationService accountService;
        private readonly IConfiguration configuration;
        private const string InternalKey = "8gfB50.!#_Aau61n.-$!";
        private readonly IAccessService accessService;
        private readonly ITheCompanyService companyService;
        private readonly ISignService signService;
        private readonly IAppInfoService appInfoService;
        private readonly ILogService logService;
        private readonly IWFService wfService;
        private readonly IPgsbService pgsbService;
        private readonly IRegistrationRequestService registrationRequestService;

        private IWebHostEnvironment env;

        private readonly IMessagingService messagingService;




        public AuthenticationController(IAuthenticationService accountService,
            IConfiguration configuration,
            IOptions<AuthenticationConfig> accountsConfig,
            IOptions<JwtConfig> jwtConfig,
            IAccessService accessService,
            IWebHostEnvironment env,
            IMessagingService messagingService,
            ITheCompanyService companyService,
            ISignService signService,
            IAppInfoService appInfoService,
            ILogService logService,
            IWFService wfService,
            IPgsbService pgsbService,
            IRegistrationRequestService registrationRequestService)
        {
            this._AuthenticationConfig = accountsConfig.Value;
            this._JwtConfig = jwtConfig.Value;
            this.accountService = accountService;
            this.configuration = configuration;
            this.accessService = accessService;
            this.env = env;
            this.messagingService = messagingService;
            this.companyService = companyService;
            this.signService = signService;
            this.appInfoService = appInfoService;
            this.logService = logService;
            this.wfService = wfService;
            this.pgsbService = pgsbService;
            this.registrationRequestService = registrationRequestService;
        }

        #endregion

        #region AllowAnonymous


        [EnableCors("react")]
        [AllowAnonymous]
        [HttpPost]
        [Route("~/Authentication/user-info")]
        public Response GetUserInfo(long version)
        {
            Request.Cookies.TryGetValue(_AuthenticationConfig.SessionIdCookieName, out var sessionId);
            Request.Cookies.TryGetValue(_AuthenticationConfig.RefTokenCookieName, out var ref_token);
            var session = accountService.GetSessionByRefreshToken(sessionId.ToLong(0), ref_token);
            if (session == null)
            {
                return Responses.Error401();
            }
            var user = accountService.GetUserByName(session.UserName);
            var ref_result = Refresh(user, session);

            var company = companyService.GetCompanyById(session.CompanyId);

            var appInfo = appInfoService.GetAppInfo();

            var my_companies = accountService.GetAllUserCharts(session.UserName);

            var TaskCount = 0;
            if (!session.IsDeleted && session.ChartUserRoleSerial.HasValue)
                TaskCount = wfService.GetInboxCount("new,read", session.ChartUserRoleSerial.Value);

            var result = new
            {
                user.UserName,
                user.UniqueId,
                DisplayName = $"{user.FirstName} {user.LastName}",
                ref_result.Token,
                ref_result.Expiry,
                company.EnablePublicProfile,
                CompanyId = company.Id,
                session.ChartUserRoleSerial,
                CompanyUniqueId = company.UniqueId,
                CompanyName = company.Name,
                IsSeller = company.EnableSupplier,
                IsBuyer = company.EnableSourcing,
                //IsCarrier = company.EnableTM,
                NewNotificationCount = accountService.GetNewNotifCount(user.UserName, session.CompanyId),
                TaskCount,
                Companies = my_companies,
                AppInfo = appInfo != null && version != appInfo.Version ? new { Version = appInfo.Version, Data = appInfo.JSON } : null,
                Show2FAAlarm = string.IsNullOrWhiteSpace(user.Current2FA),
            };

            return new Response(result);
        }


        [EnableCors("react")]
        [HttpPost]
        [AllowAnonymous]
        [Route("~/Authentication/verification-tow-factor-code")]
        public Response VerificationToFactorCode([FromBody] AuthenticatorDTO model)
        {
            if (model == null) return Responses.BadRequest();

            var user = accountService.GetUserByNameOrNationalCode(model.UserName);
            if (user == null) return Responses.InvalidUserName();

            if (!SkipVerificationCode())
            {
                if (model.Current2FA == "sms" || model.Current2FA == "email")
                {
                    if (!SecurityKeyGenerator.IsValidTimeStampKey("", model.UserName + "-" + model.Code, model.Key)) return Responses.InvalidVerificationCode();
                }
                else
                {
                    user = LoadValidUser(model.UserName, model.UserName, model.AuthenticatorKey);
                    if (user == null) return Responses.InvalidUserName();
                    var secret = Base32Encoding.ToBytes(user.AuthenticatorKey);
                    var totp = new Totp(secret, 30, OtpHashMode.Sha1, 6);
                    bool IsValid = totp.VerifyTotp(model.Code, out long timeStepMatched, VerificationWindow.RfcSpecifiedNetworkDelay);
                    if (!IsValid) return Responses.InvalidAuthenticatorCode();
                }
            }


            var result = new
            {
                Key = SecurityKeyGenerator.GenerateTimeStampKey("", model.UserName + "-" + InternalKey, 10)
            };
            return new Response(result);
        }

        [EnableCors("react")]
        [AllowAnonymous]
        [HttpPost]
        [Route("~/authentication/verify-password")]
        public async Task<Response> VerifyPassword([FromBody] VerifyCodeDTO model)
        {

            if (model == null) return Responses.BadRequest();

            if (!IsValidCaptcha(model.Captcha)) return Responses.InvalidCaptcha();
            var user = accountService.GetUserByNameOrNationalCode(model.UserName);

            if (user == null || user.IsDeleted || user.IsDisabled)
            {
                return Responses.InvalidUserNameOrPassword();
            }

            if (accountService.IsLocked(user)) return Responses.UserIsLocked();


            var passwordHash = Common.Cryptography.Helper.HashPassword(model.Password);

            if (Environment.MachineName != "DESKTOP-QCFNR78")
                if (!user.PasswordHash.eq(passwordHash))
                {
                    accountService.AccessFailedCountUpdate(user);
                    return Responses.InvalidUserNameOrPassword();
                }

            accountService.ClearAccessFailedCount(user);

            var Key = SecurityKeyGenerator.GenerateTimeStampKey("", model.UserName, 10);

            var MaskedPhoneNumber = !string.IsNullOrEmpty(user.Current2FA) && user.PhoneNumber != null ? MaskPhoneNumber(user.PhoneNumber) : "";
            var current2FA = user.Current2FA;

            //var MaskedEmail = !string.IsNullOrEmpty(user.Current2FA) && user.Email != null ? MaskEmail(user.Email) : "";

            byte[] AuthenticatorKey = null;
            DateTime? ExpirAt = null;
            if (!string.IsNullOrEmpty(current2FA))
            {
                AuthenticatorKey = SecurityKeyGenerator.GenerateTimeStampKey("", model.UserName, 10);
                if (current2FA == "sms" || current2FA == "email")
                {
                    var otp = SecurityKeyGenerator.GenerateVerificationCode(5);
                    Key = SecurityKeyGenerator.GenerateTimeStampKey("", model.UserName + "-" + otp, 10);
                    ExpirAt = DateTime.Now.AddSeconds(_AuthenticationConfig.SmsExpiry);

                    if (!SkipVerificationCode())
                    {
                        await messagingService.SendOTPMessageAsync(
                                          new ZUser
                                          {
                                              PhoneNumber = user.PhoneNumber,
                                              Email = user.Email,
                                              AuthenticationMethod = AuthenticationMethods.PasswordPhone,
                                              DefaultLanguage = user.DefaultLanguage
                                          }, otp);
                    }
                }
            }


            var result = new
            {
                Expiry = _AuthenticationConfig.SmsExpiry,
                ExpirAt,
                user.Current2FA,
                Key,
                AuthenticatorKey,
                MaskedPhoneNumber,
                //MaskedEmail,
                user.PhoneNumberConfirmed,
                user.EmailConfirmed,
                AuthenticatorIsEnabled = !string.IsNullOrEmpty(user.AuthenticatorKey)
            };

            return new Response(result);
        }


        [EnableCors("react")]
        [HttpPost]
        [AllowAnonymous]
        [Route("~/Authentication/verify-certificate-for-create-company")]
        public Response VerifyCertificateForCreateCompany([FromBody] CertificateDTO model)
        {
            if (model == null) return Responses.BadRequest();

            var userData = signService.GetCertificateData(model.Bs64Cert);
            if (!signService.IsValidCertificate(model.Bs64Cert)) throw new CertificateValidationFailedError();

            var user = accountService.GetUserByName(userData.SerialNumber);

            var data = userData.MapTo<UserDataView>();
            data.UserName = userData.SerialNumber;
            data.NationalCode = userData.SerialNumber;

            var result = new
            {
                UserData = data,
                UserIsExist = user != null
            };

            return new Response(result);
        }


        [EnableCors("react")]
        [HttpPost]
        [Route("~/Authentication/recovery-legal-company-by-token")]
        [AllowAnonymous]
        public Response RecoveryLegalCompanyByToken([FromBody] RecoveryCompanyDTO model)
        {
            if (model == null) return Responses.BadRequest();

            var userData = signService.GetCertificateData(model.Bs64Cert);
            if (!signService.IsValidCertificate(model.Bs64Cert)) throw new CertificateValidationFailedError();

            if (model.UserName != userData.SerialNumber) return Responses.InvalidUserName();

            var Company = companyService.VerifyLegalUserCompany(userData.SerialNumber, userData.NationalId);
            if (Company == null) return Responses.CompanyNotFound();

            var user = accountService.GetUserByName(userData.SerialNumber);
            if (user == null || user.IsDeleted || user.IsDisabled) throw new InvalidUserNameError();
            if (accountService.IsLocked(user)) throw new UserIsLockedError();

            companyService.AddUserToCompany(Company.MapTo<TheCompany>(), userData.SerialNumber);

            var data = userData.MapTo<UserDataView>();
            data.UserName = userData.SerialNumber;
            data.NationalCode = userData.SerialNumber;
            var result = new
            {
                UserData = data,
                Company
            };

            return new Response(result);
        }

        [EnableCors("react")]
        [HttpPost]
        [Route("~/Authentication/verify-certificate")]
        [AllowAnonymous]
        public Response VerifyCertificate([FromBody] CertificateDTO model)
        {
            if (model == null) return Responses.BadRequest();

            var userData = signService.GetCertificateData(model.Bs64Cert);
            if (!signService.IsValidCertificate(model.Bs64Cert)) throw new CertificateValidationFailedError();

            var data = userData.MapTo<UserDataView>();
            data.UserName = userData.SerialNumber;
            data.NationalCode = userData.SerialNumber;

            var result = new
            {
                UserData = data
            };

            return new Response(result);
        }

        [EnableCors("react")]
        [AllowAnonymous]
        [HttpPost]
        [Route("~/Authentication/generate-verification-code-for-register")]
        public async Task<Response> GenerateVerificationCodeForRegister([FromBody] RequestForVCodeDTO model)
        {
            if (model == null) return Responses.BadRequest();

            if (!IsValidCaptcha(model.Captcha)) return Responses.InvalidCaptcha();

            if (!Common.Cryptography.Helper.PasswordComplexity(model.Password)) return Responses.InvalidPasswordComplexity();

            var authenticationMethod = Core.AuthenticationMethods.PasswordPhone;
            var stampKey = model.PhoneNumber;
            var defaultLanguage = "fa";

            if (!model.IsIR())
            {
                authenticationMethod = Core.AuthenticationMethods.PasswordEmail;
                stampKey = model.Email;
                defaultLanguage = "en";
            }


            //----------
            var otp = SecurityKeyGenerator.GenerateVerificationCode(5);
            var key = SecurityKeyGenerator.GenerateTimeStampKey("", stampKey + "-" + otp, 2);

            if (!SkipVerificationCode())
            {
                await messagingService.SendOTPMessageAsync(
                  new ZUser
                  {
                      PhoneNumber = model.PhoneNumber,
                      Email = model.Email,
                      AuthenticationMethod = authenticationMethod,
                      DefaultLanguage = defaultLanguage
                  }, otp);
            }

            var result = new
            {
                MaskedPhoneNumber = AuthenticationMethods.IsPasswordPhone(authenticationMethod) ? MaskPhoneNumber(model.PhoneNumber) : null,
                MaskedEmail = AuthenticationMethods.IsPasswordEmail(authenticationMethod) ? MaskEmail(model.Email) : null,
                Expiry = _AuthenticationConfig.SmsExpiry,
                Key = key,
                AuthenticationMethod = authenticationMethod
            };

            return new Response(result);
        }

        [EnableCors("react")]
        [AllowAnonymous]
        [HttpPost]
        [Route("~/Authentication/generate-verification-code")]
        public Response GenerateVerificationCode([FromBody] RequestForVCodeDTO model)
        {
            if (model == null) return Responses.BadRequest();

            if (!IsValidCaptcha(model.Captcha)) return Responses.InvalidCaptcha();
            if (string.IsNullOrWhiteSpace(model.UserName)) return Responses.InvalidUserName();
            var user = accountService.GetUserByName(model.UserName);
            if (user == null) return Responses.UserNotFound();
            if (accountService.IsLocked(user)) return Responses.UserIsLocked();
            if (user.IsDeleted || user.IsDisabled) return Responses.UserNotFound();

            //----------
            var otp = SecurityKeyGenerator.GenerateVerificationCode(5);
            var key = SecurityKeyGenerator.GenerateTimeStampKey("", model.UserName + "-" + otp, 2);

            var zuser = user.MapTo<ZUser>();

            var result = new
            {
                MaskedPhoneNumber = AuthenticationMethods.IsPasswordPhone(zuser.AuthenticationMethod) ? MaskPhoneNumber(user.PhoneNumber) : null,
                MaskedEmail = AuthenticationMethods.IsPasswordEmail(zuser.AuthenticationMethod) ? MaskEmail(user.Email) : null,
                Expiry = _AuthenticationConfig.SmsExpiry,
                Key = key,
                zuser.AuthenticationMethod
            };

            return new Response(result);
        }

        [EnableCors("react")]
        [AllowAnonymous]
        [HttpPost]
        [Route("~/authentication/verify-code")]
        public Response VerifyCode([FromBody] VerifyCodeDTO model)
        {
            if (model == null) return Responses.BadRequest();

            if (Core.AuthenticationMethods.IsPasswordPhone(model.AuthenticationMethod) && string.IsNullOrEmpty(model.PhoneNumber))
            {
                var user = accountService.GetUserByName(model.UserName);

                if (user == null || user.IsDeleted || user.IsDisabled || accountService.IsLocked(user))
                {
                    return Responses.InvalidUserOrVerificationCode();
                }
                model.PhoneNumber = user.PhoneNumber;
            }
            else if (Core.AuthenticationMethods.IsPasswordEmail(model.AuthenticationMethod) && string.IsNullOrEmpty(model.Email))
            {
                return Responses.InvalidEmailAddress();
            }

            string stampKey = model.PhoneNumber;
            if (!string.IsNullOrEmpty(model.UserName))
            {
                stampKey = model.UserName;
            }

            if (!SkipVerificationCode())
            {
                if (!SecurityKeyGenerator.IsValidTimeStampKey("", stampKey + "-" + model.Code, model.Key))
                {
                    return Responses.InvalidUserOrVerificationCode();
                }
            }

            var result = new
            {
                Expiry = 10 * 60,
                Key = SecurityKeyGenerator.GenerateTimeStampKey("", stampKey, 10),
            };

            return new Response(result);
        }



        [AllowAnonymous]
        [HttpPost]
        [EnableCors("react")]
        [Route("~/authentication/get-my-companies")]
        public Response GetMyCompanies([FromBody] LoginDTO model)
        {
            if (model == null) return Responses.BadRequest();

            string data = model.UserName;
            var user = accountService.GetUserByNameOrNationalCode(model.UserName);
            if (user != null && !string.IsNullOrWhiteSpace(user.Current2FA)) data += "-" + InternalKey;
            user = LoadValidUser(model.UserName, data, model.Key);
            var UserCharts = accountService.GetAllUserCharts(user.UserName);
            var result = UserCharts.MapTo<UserChartView>();

            return new Response(result);
        }

        [AllowAnonymous]
        [HttpPost]
        [EnableCors("react")]
        [Route("~/authentication/company-recovery-as-real")]
        public Response CompanyRecoveryAsReal([FromBody] CompanyInqueryDTO model)
        {
            if (!SkipVerificationCode())
            {
                if (!SecurityKeyGenerator.IsValidTimeStampKey("", model.UserName, model.Key))
                {
                    return Responses.InvalidVerificationCode();
                }
            }


            if (string.IsNullOrWhiteSpace(model.UserName)) return Responses.InvalidUserName();

            var user = accountService.GetUserByName(model.UserName);
            if (user == null) return Responses.UserNotFound();

            var company = companyService.GetCompanyByOwnerForReal(model.UserName);
            if (company == null) return Responses.CompanyNotFoundByNationalId();


            var companyUser = companyService.GetCompanyUser(company.Id, model.UserName);
            if (companyUser != null) return Responses.UserIsExistInCompany();

            company = companyService.AddUserToCompany(company, model.UserName);

            var result = new
            {
                Company = company.MapTo<CompanyInfoDTO>()
            };
            return new Response(result);
        }

        [AllowAnonymous]
        [HttpPost]
        [EnableCors("react")]
        [Route("~/Authentication/login")]
        public Response Login([FromBody] LoginDTO model)
        {
            if (model == null) return Responses.BadRequest();

            //----------
            var user = accountService.GetUserByNameOrNationalCode(model.UserName);
            var data = model.UserName;
            if (user != null && !string.IsNullOrWhiteSpace(user.Current2FA)) data += "-" + InternalKey;
            user = LoadValidUser(model.UserName, data, model.Key);

            //----------
            var companyId = accountService.ConnectToCompany(user.UserName, model.CompanyId);
            if (companyId == 0) return Responses.CompanyNotFound();

            var company = companyService.GetCompanyById(companyId);
            if (company is null) return Responses.CompanyNotFound();
            if (company.IsBlocked) return Responses.CompanyIsBlocked();
            var companyUser = companyService.GetCompanyUser(companyId, user.UserName);
            if (companyUser.IsBlocked) return Responses.CompanyUserIsBlocked();

            //----------
            if (model.ChartUserRoleSerial.HasValue)
            {
                var cur = companyService.GetChartUserRole(model.ChartUserRoleSerial);
                if (cur == null || cur.CompanyId != companyId || !cur.UserName.eq(user.UserName))
                {
                    return Responses.BadRequest();
                }
            }
            //----------
            Request.Cookies.TryGetValue(_AuthenticationConfig.SessionIdCookieName, out var sessionId);
            Request.Cookies.TryGetValue(_AuthenticationConfig.RefTokenCookieName, out var ref_token);
            var session = accountService.GetSessionByRefreshToken(sessionId.ToLong(0), ref_token);
            if (session != null && session.UserName != user.UserName)
            {
                accountService.DeleteSession(session);
            }

            var userAgent = Request.Headers["User-Agent"].ToString();

            session = accountService.CreateSession(user, userAgent, accessService.RequestIP, companyId, model.ChartUserRoleSerial);
            var ref_result = Refresh(user, session);

            var my_companies = accountService.GetAllUserCharts(user.UserName);

            //Log
            logService.LogLogin(user.UserName, company.Id, session.Id);


            ConfirmSecondFactor(user);
            accountService.ChangePreferred(user.UserName, model.Current2FA);

            var appInfo = appInfoService.GetAppInfo();

            var TaskCount = 0;
            if (!session.IsDeleted && session.ChartUserRoleSerial.HasValue)
                TaskCount = wfService.GetInboxCount("new,read", session.ChartUserRoleSerial.Value);

            var result = new
            {
                user.UserName,
                user.UniqueId,
                DisplayName = $"{user.FirstName} {user.LastName}",
                CompanyId = companyId,
                session.ChartUserRoleSerial,
                CompanyUniqueId = company.UniqueId,
                CompanyName = company.Name,
                IsSeller = company.EnableSupplier,
                IsBuyer = company.EnableSourcing,
                ref_result.Token,
                Expiry = _JwtConfig.RefreshTokenExpiry,
                NewNotificationCount = accountService.GetNewNotifCount(user.UserName, session.CompanyId),
                TaskCount,
                Companies = my_companies,
                Show2FAAlarm = string.IsNullOrWhiteSpace(user.Current2FA),
                AppInfo =
                    appInfo != null && model.AppVersion != appInfo.Version ?
                        new
                        {
                            Version = appInfo.Version,
                            Data = appInfo.JSON
                        } : null

            };

            return new Response(result);
        }

        [AllowAnonymous]
        [HttpPost]
        [EnableCors("react")]
        [Route("~/Authentication/register")]
        public Response AuthenticateRegister([FromBody] RegisterDTO model)
        {
            if (model == null) return Responses.BadRequest();

            var user = model.User.MapTo<User>();
            user.UniqueId = Guid.NewGuid();

            user.UserName = user.NationalCode;
            user.AuthenticationMethod = Core.AuthenticationMethods.PasswordPhone;
            string defaultLanguage = "fa";
            string stampKey = model.User.PhoneNumber;

            if (!model.User.IsIR())
            {
                user.AuthenticationMethod = Core.AuthenticationMethods.PasswordEmail;
                defaultLanguage = "en";
                user.NationalCode = "";
                user.UserName = model.User.Email;
                stampKey = model.User.Email;
            }

            if (!SkipVerificationCode())
            {
                if (!SecurityKeyGenerator.IsValidTimeStampKey("", stampKey + "-" + model.Code, model.Key))
                {
                    return Responses.InvalidVerificationCode();
                }
            }

            user.DefaultLanguage = defaultLanguage;
            user = accountService.Register(user, model.User.Password);

            return new Response(new
            {
                Key = SecurityKeyGenerator.GenerateTimeStampKey("", user.UserName, 10),
            });
        }

        [AllowAnonymous]
        [HttpPost]
        [EnableCors("react")]
        [Route("~/Authentication/company-register")]
        public async Task<Response> CompanyRegister([FromBody] RegisterDTO model)
        {
            if (model == null) return Responses.BadRequest();
            if (string.IsNullOrWhiteSpace(model.Bs64Cert)) return Responses.BadRequest();

            var userData = signService.GetCertificateData(model.Bs64Cert);
            if (!signService.IsValidCertificate(model.Bs64Cert)) throw new CertificateValidationFailedError();

            var user = accountService.GetUserByName(userData.SerialNumber);
            if (!string.IsNullOrWhiteSpace(model.User.UserName) && userData.SerialNumber != model.User.UserName) return new Response("user-name-does-not-match-token", "error");

            if (user == null) return Responses.UserNotFound();
            if (!SecurityKeyGenerator.IsValidTimeStampKey("", model.User.UserName, model.Key)) return Responses.InvalidVerificationCode();

            var company = model.Company.MapTo<TheCompany>();
            company = accountService.CompanyRegister(company, user);

            if (!SkipVerificationCode())
            {
                await messagingService.SendAccountRegisterationMessageAsync(user.MapTo<ZUser>(), company.Name);
            }

            var result = new
            {
                Company = company.MapTo<CompanyInfoDTO>()
            };

            return new Response(result);
        }

        [AllowAnonymous]
        [EnableCors("react")]
        [HttpPost]
        [Route("~/Authentication/refresh")]
        public Response Refresh()
        {
            Request.Cookies.TryGetValue(_AuthenticationConfig.SessionIdCookieName, out var sessionId);
            Request.Cookies.TryGetValue(_AuthenticationConfig.RefTokenCookieName, out var ref_token);
            var session = accountService.GetSessionByRefreshToken(sessionId.ToLong(0), ref_token);
            if (session == null)
            {
                return Responses.Error401();
            }

            var user = accountService.GetUserByName(session.UserName);
            var result = Refresh(user, session);

            return new Response(result);
        }

        [AllowAnonymous]
        [EnableCors("react")]
        [HttpPost]
        [Route("~/Authentication/logout")]
        public Response Logout()
        {
            Request.Cookies.TryGetValue(_AuthenticationConfig.RefTokenCookieName, out var ref_token);
            if (string.IsNullOrEmpty(ref_token)) return new Response();

            Request.Cookies.TryGetValue(_AuthenticationConfig.SessionIdCookieName, out var sessionId);
            if (!sessionId.ToLong().HasValue) return new Response();

            Response.Cookies.Delete(_AuthenticationConfig.RefTokenCookieName);
            Response.Cookies.Delete(_AuthenticationConfig.SessionIdCookieName);

            var session = accountService.GetSessionByRefreshToken(sessionId.ToLong(0), ref_token);
            if (session == null) return new Response();

            accountService.DeleteSession(session);
            return new Response();
        }

        [EnableCors("react")]
        [AllowAnonymous]
        [HttpPost]
        [Route("~/Authentication/recovery-password")]
        public async Task<Response> RecoveryPassword([FromBody] RecoveryPasswordDTO model)
        {
            if (model == null) return Responses.BadRequest();

            if (!IsValidCaptcha(model.Captcha)) return Responses.InvalidCaptcha();
            if (string.IsNullOrEmpty(model.UserName)) return Responses.InvalidUserName();
            var user = accountService.GetUserByName(model.UserName);


            //----------
            var otp = SecurityKeyGenerator.GenerateVerificationCode(5);
            var key = SecurityKeyGenerator.GenerateTimeStampKey("", model.UserName + "-" + otp, 2);

            if (user == null) return new Response(new
            {
                AuthenticationMethod = "Password_Phone",
                MaskedPhoneNumber = MaskPhoneNumber(""),
                Expiry = _AuthenticationConfig.SmsExpiry,
                Key = key,
            });

            var zuser = user.MapTo<ZUser>();

            if (!SkipVerificationCode())
            {
                await messagingService.SendOTPMessageAsync(zuser, otp);
            }

            var result = new
            {
                MaskedPhoneNumber = AuthenticationMethods.IsPasswordPhone(zuser.AuthenticationMethod) ? MaskPhoneNumber(user.PhoneNumber) : null,
                MaskedEmail = AuthenticationMethods.IsPasswordEmail(zuser.AuthenticationMethod) ? MaskEmail(user.Email) : null,
                Expiry = _AuthenticationConfig.SmsExpiry,
                Key = key,
                zuser.AuthenticationMethod
            };

            return new Response(result);
        }

        [AllowAnonymous]
        [HttpPost]
        [EnableCors("react")]
        [Route("~/Authentication/reset-password")]
        public Response ResetPassword([FromBody] ResetPasswordDTO model)
        {
            if (model == null) return Responses.BadRequest();

            var user = accountService.GetUserByName(model.UserName);
            if (user == null) return Responses.UserNotFound();

            if (accountService.IsLocked(user)) return Responses.UserIsLocked();

            if (!SkipVerificationCode())
            {
                if (!SecurityKeyGenerator.IsValidTimeStampKey("", model.UserName + "-" + model.Code, model.Key))
                {
                    accountService.AccessFailedCountUpdate(user);
                    return Responses.InvalidVerificationCode();
                }
            }

            if (!Common.Cryptography.Helper.PasswordComplexity(model.Password)) return Responses.InvalidPasswordComplexity();

            ConfirmSecondFactor(user);

            accountService.SetPassword(user, model.Password);
            accountService.DeleteSessions(user.UserName, null);

            return new Response();
        }

        //[AllowAnonymous]
        //[EnableCors("react")]
        //[HttpGet]
        //[Route("~/Authentication/get-api-test-token")]
        //public string GetApiTestToken([MaxLength(50)][DefaultValue(SpecialChars.Email)] string userName, int companyId)
        //{

        //    if (env.IsProduction()) return null;
        //    var user = accountService.GetUserByName(userName);
        //    var expiry = 1 * 24 * 60 * 60;
        //    var token = accountService.GetToken(user, expiry, companyId.ToString());
        //    return token;
        //}

        [AllowAnonymous]
        [EnableCors("react")]
        [HttpPost]
        [Route("~/Authentication/verify-user-for-set-password")]
        public Response VerifyUserForSetPassword([MaxLength(50)][DefaultValue(SpecialChars.Email)] string userName)
        {
            if (string.IsNullOrWhiteSpace(userName)) return Responses.BadRequest();

            if (string.IsNullOrEmpty(userName)) return Responses.InvalidUserName();
            var user = accountService.GetUserByName(userName);

            if (user == null || (user != null && !string.IsNullOrEmpty(user.PasswordHash))) return new Response(new { SkipActivate = true });

            var result = new
            {
                FullName = user.FirstName + " " + user.LastName,
            };

            return new Response(result);

        }



        [AllowAnonymous]
        [HttpPost]
        [EnableCors("react")]
        [Route("~/Authentication/register-bussiness")]
        public async Task<Response> RegisterBussiness([FromBody] RegisterBussinessDTO model)
        {
            if (model == null) return Responses.BadRequest();

            if (!IsValidCaptcha(model.Captcha)) return Responses.InvalidCaptcha();

            if (!SkipVerificationCode())
            {
                if (!SecurityKeyGenerator.IsValidTimeStampKey("", model.NationalCode + "-" + model.PhoneNumber, model.Key))
                {
                    return Responses.InvalidVerificationCode();
                }
            }

            if (!Common.Cryptography.Helper.PasswordComplexity(model.Password)) return Responses.InvalidPasswordComplexity();

            var user = new Core.User
            {
                UniqueId = Guid.NewGuid(),
                UserName = model.NationalCode,
                AuthenticationMethod = Core.AuthenticationMethods.PasswordPhone,
                DefaultLanguage = "fa",
                NationalCode = model.NationalCode,
                PhoneNumber = model.PhoneNumber,
                FirstName = model.FirstName,
                LastName = model.LastName,
            };

            var company = new TheCompany
            {
                Name = model.Name,
                NationalId = model.NationalCode,
                CountryId = model.CountryId,
                StateId = model.StateId,
                City = model.City,
            };

            accountService.RegisterBussiness(user, company, model.Password);

            if (!SkipVerificationCode())
            {
                await messagingService.SendAccountRegisterationMessageAsync(user.MapTo<ZUser>(), company.Name);
            }

            return new Response();
        }



        #endregion

        #region Authorize

        [EnableCors("react")]
        [HttpPost]
        [Route("~/Authentication/init-user-profile")]
        public Response InitUserProfile()
        {
            var userName = accessService.UserName;
            var user = accountService.GetUserByName(userName);
            var User = user.MapTo<UserDTO>();
            User.CountryId = accessService.Company.CountryId;
            var result = new
            {
                User,
            };
            return new Response(result);
        }

        [EnableCors("react")]
        [HttpPost]
        [Route("~/Authentication/init-two-factor")]
        public Response InitTwoFactor()
        {
            var user = accountService.GetUserByName(accessService.UserName);

            var secret = Encoding.ASCII.GetBytes(InternalKey + user.UserName);
            var base32Secret = Base32Encoding.ToString(secret);

            var QrGenerator = new QRCodeGenerator();
            var QrCodeInfo = QrGenerator.CreateQrCode($"otpauth://totp/IPN: {user.UserName}?secret={base32Secret}", QRCodeGenerator.ECCLevel.Q);
            var QrCode = new QRCode(QrCodeInfo);
            var QrBitmap = QrCode.GetGraphic(60);
            byte[] BitmapArray = BitmapToByteArray(QrBitmap);
            var company = accessService.Company;

            var result = new
            {
                QrCode = System.Convert.ToBase64String(BitmapArray),
                AuthenticatorSecretKey = base32Secret,
                user.AuthenticatorKey,
                user.Current2FA,
                company.CountryId,
                user.PhoneNumberConfirmed,
                user.EmailConfirmed,
                user.PhoneNumber,
                user.Email

            };
            return new Response(result);
        }

        [EnableCors("react")]
        [HttpPost]
        [Route("~/Authentication/enable-app-two-factor")]
        public Response EnableAppTwoFactor([FromBody] AuthenticatorDTO model)
        {
            if (model == null) return Responses.BadRequest();

            var secret = Base32Encoding.ToBytes(model.AuthenticatorSecretKey);
            var totp = new Totp(secret);
            bool IsValid = totp.VerifyTotp(model.Code, out long timeStepMatched, VerificationWindow.RfcSpecifiedNetworkDelay);
            if (!IsValid) return Responses.InvalidAuthenticatorCode();

            accountService.EnableAppTwoFactor(model.AuthenticatorSecretKey, accessService.UserName);
            return new Response();
        }

        [EnableCors("react")]
        [HttpPost]
        [Route("~/Authentication/disable-two-factor")]
        public Response DisableAppTowFactor()
        {
            accountService.DisableTwoFactor(accessService.UserName);
            return new Response();
        }

        [EnableCors("react")]
        [HttpPost]
        [Route("~/Authentication/change-preferred")]
        public Response ChangePreferred()
        {
            accountService.ChangePreferred(accessService.UserName);
            return new Response();
        }

        [EnableCors("react")]
        [HttpPost]
        [Route("~/Authentication/disable-tow-factor-alarm")]
        public Response DisableTowFactorlarm()
        {
            accountService.DisableTowFactorAlarm(accessService.UserName);
            return new Response();
        }

        [EnableCors("react")]
        [HttpPost]
        [Route("~/Authentication/confirm-user-phone-number")]
        public Response ConfirmUserPhoneNumber([FromBody] AuthenticatorDTO model)
        {
            if (model == null) return Responses.BadRequest();
            if (!IsValidCaptcha(model.Captcha)) return Responses.InvalidCaptcha();


            if (!SkipVerificationCode())
            {
                if (!SecurityKeyGenerator.IsValidTimeStampKey("", accessService.UserName + "-" + model.Code, model.Key))
                {
                    return Responses.InvalidVerificationCode();
                }
            }

            var user = accountService.GetUserByName(accessService.UserName);
            accountService.ConfirmUserPhoneNumber(user);
            return new Response();
        }

        [EnableCors("react")]
        [HttpPost]
        [Route("~/Authentication/confirm-user-email-address")]
        public Response ConfirmUserEmailAddress([FromBody] AuthenticatorDTO model)
        {
            if (model == null) return Responses.BadRequest();

            if (!SkipVerificationCode())
            {
                if (!SecurityKeyGenerator.IsValidTimeStampKey("", accessService.UserName + "-" + model.Code, model.Key))
                {
                    return Responses.InvalidVerificationCode();
                }
            }

            var user = accountService.GetUserByName(accessService.UserName);
            accountService.ConfirmUserEmail(user);
            return new Response();
        }

        [EnableCors("react")]
        [HttpPost]
        [Route("~/Authentication/generate-verification-code-for-2fa")]
        public async Task<Response> GenerateVerificationCodeFor2FA([MaxLength(5)] string type)
        {
            var userName = accessService.UserName;
            if (string.IsNullOrWhiteSpace(userName)) return Responses.InvalidUserName();
            var user = accountService.GetUserByName(userName);
            //----------
            var otp = SecurityKeyGenerator.GenerateVerificationCode(5);
            var key = SecurityKeyGenerator.GenerateTimeStampKey("", userName + "-" + otp, 2);

            var authenticationMethods = AuthenticationMethods.PasswordPhone;
            if (type == "email") authenticationMethods = AuthenticationMethods.PasswordEmail;

            if (!SkipVerificationCode())
            {
                await messagingService.SendOTPMessageAsync(
                   new ZUser
                   {
                       Email = user.Email,
                       PhoneNumber = user.PhoneNumber,
                       AuthenticationMethod = authenticationMethods,
                       DefaultLanguage = user.DefaultLanguage
                   }, otp);
            }


            var result = new
            {
                Expiry = _AuthenticationConfig.SmsExpiry,
                Key = key,
            };

            return new Response(result);
        }

        [EnableCors("react")]
        [HttpPost]
        [AllowAnonymous]
        [Route("~/Authentication/generate-verification-code-for-2fa-login")]
        public async Task<Response> GenerateVerificationCodeFor2faLogin([FromBody] AuthenticatorDTO model)
        {
            if (model == null) return Responses.BadRequest();

            var userName = model.UserName;
            if (string.IsNullOrWhiteSpace(userName)) return Responses.InvalidUserName();
            var user = LoadValidUser(model.UserName, model.UserName, model.Key);
            if (user == null || model.UserName != userName) return Responses.UserNotFound();
            //----------
            var otp = SecurityKeyGenerator.GenerateVerificationCode(5);
            var key = SecurityKeyGenerator.GenerateTimeStampKey("", userName + "-" + otp, 2);
            var authenticationMethods = AuthenticationMethods.PasswordPhone;
            if (model.Type == "email") authenticationMethods = AuthenticationMethods.PasswordEmail;
            if (!SkipVerificationCode())
            {
                await messagingService.SendOTPMessageAsync(
                                  new ZUser
                                  {
                                      PhoneNumber = user.PhoneNumber,
                                      Email = user.Email,
                                      AuthenticationMethod = authenticationMethods,
                                      DefaultLanguage = user.DefaultLanguage
                                  }, otp);
            }


            var result = new
            {
                Expiry = _AuthenticationConfig.SmsExpiry,
                ExpirAt = DateTime.Now.AddSeconds(_AuthenticationConfig.SmsExpiry),
                Key = key,
            };

            return new Response(result);
        }

        [EnableCors("react")]
        [HttpPost]
        [Route("~/Authentication/change-user-password")]
        public Response ChangeUserPassword([FromBody] ChanegPasswordDTO model)
        {
            if (model == null) return Responses.BadRequest();

            var user = accountService.GetUserByName(accessService.UserName);
            if (user == null) return Responses.InvalidUserName();
            if (!Common.Cryptography.Helper.PasswordComplexity(model.NewPassword)) return Responses.InvalidPasswordComplexity();
            var passwordHash = Common.Cryptography.Helper.HashPassword(model.OldPassword);
            if (!passwordHash.eq(user.PasswordHash)) return Responses.IncorrectOldPassword();
            accountService.SetPassword(user, model.NewPassword);


            Request.Cookies.TryGetValue(_AuthenticationConfig.SessionIdCookieName, out var sessionId);
            accountService.DeleteSessions(user.UserName, sessionId.ToLong(0));

            return new Response();
        }

        [EnableCors("react")]
        [HttpPost]
        [Route("~/Authentication/update-user-profile")]
        public Response UpdateUserProfile([FromBody] UserDTO model)
        {
            if (model == null) return Responses.BadRequest();

            var u = new UserView
            {
                UserName = User.Identity.Name,
                FirstName = model.FirstName,
                LastName = model.LastName,
                DefaultLanguage = model.DefaultLanguage,
                WorkPhoneNumber = model.WorkPhoneNumber,
            };

            if (!string.IsNullOrEmpty(accessService.Company.CountryId) && accessService.Company.IsIR())
            {
                u.Email = model.Email;
            }

            var user = accountService.UpdateUser(u);
            var result = user.MapTo<UserDTO>();
            return new Response(result);
        }

        [EnableCors("react")]
        [HttpPost]
        [Route("~/Authentication/generate-verification-code-for-user-profile")]
        public async Task<Response> GenerateVerificationCodeForUserProfile([MaxLength(15)] string phoneNumber, [MaxLength(10)] string captcha)
        {
            if (!IsValidCaptcha(captcha)) return Responses.InvalidCaptcha();
            var userName = accessService.UserName;
            var user = accountService.GetUserByName(userName);
            if (user == null) return Responses.UserNotFound();

            var authenticationMethod = AuthenticationMethods.PasswordPhone;

            //----------
            var otp = SecurityKeyGenerator.GenerateVerificationCode(5);
            var key = SecurityKeyGenerator.GenerateTimeStampKey("", userName + "-" + otp, 2);

            if (!SkipVerificationCode())
            {
                await messagingService.SendOTPMessageAsync(
                 new ZUser
                 {
                     PhoneNumber = phoneNumber,
                     AuthenticationMethod = authenticationMethod,
                     DefaultLanguage = user.DefaultLanguage
                 }, otp);
            }

            var result = new
            {
                Expiry = _AuthenticationConfig.SmsExpiry,
                Key = key,
            };

            return new Response(result);
        }

        [HttpPost]
        [EnableCors("react")]
        [Route("~/Authentication/change-user-phone-number")]
        public Response ChangeUserPhoneNumber([FromBody] ChangeUserPhoneNumberDTO model)
        {
            if (model == null) return Responses.BadRequest();

            var userName = accessService.UserName;

            if (!SkipVerificationCode())
            {
                if (!SecurityKeyGenerator.IsValidTimeStampKey("", userName + "-" + model.Code, model.Key))
                {
                    return Responses.InvalidVerificationCode();
                }
            }

            var user = accountService.GetUserByName(userName);
            if (user == null) return Responses.UserNotFound();
            if (string.IsNullOrEmpty(model.PhoneNumber)) return Responses.InvalidPhoneNumber();

            accountService.ChangeUserPhoneNumber(user, model.PhoneNumber);
            accountService.ConfirmUserPhoneNumber(user);

            return new Response();
        }


        [EnableCors("react")]
        [AllowAnonymous]
        [HttpPost]
        [Route("~/Authentication/get-verification-code")]
        public async Task<Response> GetVerificationCode([FromBody] RequestVCodeDTO model)
        {
            if (model == null) return Responses.BadRequest();

            if (!IsValidCaptcha(model.Captcha)) return Responses.InvalidCaptcha();
            if (string.IsNullOrWhiteSpace(model.NationalCode)) return Responses.InvalidUserName();

            //----------
            var otp = SecurityKeyGenerator.GenerateVerificationCode(5);
            var key = SecurityKeyGenerator.GenerateTimeStampKey("", model.NationalCode + "-" + otp + "-" + model.PhoneNumber, 2);


            if (!SkipVerificationCode())
            {
                await messagingService.SendOTPMessageAsync(
                  new ZUser
                  {
                      UserName = model.NationalCode,
                      PhoneNumber = model.PhoneNumber,
                      AuthenticationMethod = Core.AuthenticationMethods.PasswordPhone,
                      DefaultLanguage = "fa"
                  }, otp);
            }


            var result = new
            {
                MaskedPhoneNumber = MaskPhoneNumber(model.PhoneNumber),
                Expiry = _AuthenticationConfig.SmsExpiry,
                Key = key,
            };

            return new Response(result);
        }


        [AllowAnonymous]
        [EnableCors("react")]
        [HttpPost]
        [Route("~/Authentication/request-otp-code")]
        public async Task<Response> RequestOtpCode([MaxLength(15)] string phoneNumber, [MaxLength(10)] string captcha)
        {
            if (!IsValidCaptcha(captcha)) return Responses.InvalidCaptcha();

            var otp = SecurityKeyGenerator.GenerateVerificationCode(5);
            var key = SecurityKeyGenerator.GenerateTimeStampKey("", phoneNumber + "-" + otp, 2);

            if (!SkipVerificationCode())
            {
                await messagingService.SendOTPMessageAsync(
                 new ZUser
                 {
                     PhoneNumber = phoneNumber,
                     AuthenticationMethod = AuthenticationMethods.PasswordPhone,
                     DefaultLanguage = "fa"
                 }, otp);
            }

            var result = new
            {
                Expiry = _AuthenticationConfig.SmsExpiry,
                MaskedPhoneNumber = MaskPhoneNumber(phoneNumber),
                Key = key,
            };

            return new Response(result);
        }

        [AllowAnonymous]
        [HttpPost]
        [EnableCors("react")]
        [Route("~/Authentication/anonymous-verify-otp")]
        public Response VerifyOtp([FromBody] VerifyOtpDTO model)
        {
            if (model == null) return Responses.BadRequest();

            if (!SkipVerificationCode())
            {
                if (!SecurityKeyGenerator.IsValidTimeStampKey("", model.PhoneNumber + "-" + model.Code, model.Key))
                {
                    return Responses.InvalidVerificationCode();
                }
            }
            var requests = registrationRequestService.GetRegisterRequests(model.PhoneNumber);

            var session_expiry = _AuthenticationConfig.AnonymousLoginExpiry;
            if (session_expiry < 1) session_expiry = 240;
            var key = SecurityKeyGenerator.GenerateTimeStampKey("", model.PhoneNumber, session_expiry);

            var result = new
            {
                Key = key,
                Buyers = companyService.GetCompaniesForRegistrationRequest().MapTo<RegistrationRequestBuyersDTO>(),
                Requests = requests.MapTo<RegistrationRequestsDTO>(),
                Expiry = session_expiry,
                ExpiresAt = DateTime.Now.AddMinutes(session_expiry),
            };

            return new Response(result);
        }

        [AllowAnonymous]
        [HttpPost]
        [EnableCors("react")]
        [Route("~/Authentication/get-registration-requests")]
        public Response GetRegistrationRequests([FromBody] VerifyOtpDTO model)
        {
            if (model == null) return Responses.BadRequest();

            if (!SecurityKeyGenerator.IsValidTimeStampKey("", model.PhoneNumber, model.Key))
            {
                return new Response(new { IsExpired = true });
            }

            var requests = registrationRequestService.GetRegisterRequests(model.PhoneNumber);

            var result = new
            {
                Requests = requests.MapTo<RegistrationRequestsDTO>(),
            };
            return new Response(result);
        }


        [AllowAnonymous]
        [HttpPost]
        [EnableCors("react")]
        [Route("~/Authentication/report-error")]
        public Response RegReqReportError([FromBody] AuthenticationErrorReportDTO model)
        {
            if (model == null) return Responses.BadRequest();
            if (string.IsNullOrEmpty(model.PhoneNumber)) return Responses.BadRequest();
            if (string.IsNullOrEmpty(model.Message)) return Responses.BadRequest();

            registrationRequestService.ReportError(model.PhoneNumber, model.Message);

            var result = new
            {
            };
            return new Response(result);
        }

        #endregion

        #region Private

        private RefreshResultDTO Refresh(User user, UserSession session)
        {
            accountService.RegenerateRefreshToken(session, accessService.RequestIP);
            var token = accountService.GenerateToken(user, _JwtConfig.AccessTokenExpiry, session.CompanyId, session.ChartUserRoleSerial);
            Response.Cookies.Append(_AuthenticationConfig.RefTokenCookieName, session.RefreshToken, GetCookieOption());
            Response.Cookies.Append(_AuthenticationConfig.SessionIdCookieName, session.Id.ToString(), GetCookieOption());

            var result = new RefreshResultDTO
            {
                Token = token,
                UserName = user.UserName,
                DisplayName = $"{user.FirstName} {user.LastName}",
                CompanyId = session.CompanyId,
                CompanyName = accountService.GetCompanyName(session.CompanyId),
            };

            return result;
        }

        private void ConfirmSecondFactor(User user)
        {
            if (user.AuthenticationMethod == Core.AuthenticationMethods.PasswordPhone && !user.PhoneNumberConfirmed)
            {
                accountService.ConfirmUserPhoneNumber(user);
            }

            if (user.AuthenticationMethod == Core.AuthenticationMethods.PasswordEmail && !user.EmailConfirmed)
            {
                accountService.ConfirmUserEmail(user);
            }
        }

        private User LoadValidUser(string userName, string data, byte[] key)
        {
            var user = accountService.GetUserByNameOrNationalCode(userName);
            if (user == null || user.IsDeleted || user.IsDisabled) throw new InvalidUserNameError();
            if (accountService.IsLocked(user)) throw new UserIsLockedError();
            if (!SecurityKeyGenerator.IsValidTimeStampKey("", data, key)) throw new TimeoutExpiredError();

            return user;
        }

        private static byte[] BitmapToByteArray(Bitmap bitmap)
        {
            using (MemoryStream ms = new MemoryStream())
            {
                bitmap.Save(ms, ImageFormat.Png);
                return ms.ToArray();
            }
        }

        private bool SkipCaptcha()
        {
            return configuration["SkipCaptcha"].eq("true");
        }

        private bool SkipVerificationCode()
        {
            return configuration["SkipVerificationCode"].eq("true");
        }

        public static CookieOptions GetCookieOption()
        {
            return new CookieOptions() { HttpOnly = true, SameSite = SameSiteMode.Unspecified };
        }

        private static string MaskPhoneNumber(string phoneNumber)
        {
            if (string.IsNullOrEmpty(phoneNumber) || phoneNumber.Length < 8)
            {
                phoneNumber = "09" + DateTime.Now.Ticks.ToString();
                if (phoneNumber.Length > 11) phoneNumber = phoneNumber.Substring(0, 15);
            }
            var mask = new char[phoneNumber.Length];
            for (int i = 0; i < mask.Length; i++)
            {
                mask[i] = i > 1 && i < mask.Length - 2 ? 'X' : phoneNumber[i];
            }
            return new string(mask);
        }

        public static string MaskEmail(string email)
        {
            if (email.Length <= 4)
            {
                return email;
            }
            else
            {
                string maskedEmail = "";
                maskedEmail += email.Substring(0, 2);
                for (int i = 2; i < email.Length - 2; i++)
                {
                    maskedEmail += "X";
                }
                maskedEmail += email.Substring(email.Length - 2, 2);
                return maskedEmail;
            }
        }

        private bool IsValidCaptcha(string captchaCode)
        {
            if (env.EnvironmentName == "TEST" && captchaCode == "88888888") return true;
            if (SkipCaptcha()) return true;

            Request.Cookies.TryGetValue(_AuthenticationConfig.SecurityKeyCookieName, out var captchaId);
            var captcha = accountService.GetCaptcha(captchaId);
            if (captcha == null) return false;

            return accountService.IsValidCaptcha(captcha, captchaCode);

        }

        #endregion



        #region User Devices


        [HttpPost]
        [EnableCors("react")]
        [Route("~/Authentication/get-user-devices")]
        public Response GetUserDevices()
        {
            if (accessService.UserName == null) throw new BadRequestError();
            var companyId = accessService.CompanyId;
            var userName = accessService.UserName;
            var currenIp = accessService.RequestIP;

            var devices = accountService.GetUserDevices(companyId, userName).MapTo<UserDevicesDTO>();

            if (devices is null) return Responses.BadRequest();

            var result = new
            {
                Devices = devices,
                Current = currenIp
            };
            return new Response(result);
        }

        #endregion


        #region Update User Devices
        [HttpPost]
        [EnableCors("react")]
        [Route("~/Authentication/update-user-device")]
        public Response UpdateUserDevices(int id)
        {
            if (accessService.UserName == null) throw new BadRequestError();

            var companyId = accessService.CompanyId;
            var userName = accessService.UserName;

            accountService.UpdateUserDevice(id, companyId, userName);

            return new Response();

        }
        #endregion


        #region  Change Company

        [HttpPost]
        [EnableCors("react")]
        [Route("~/Authentication/change-company")]
        public Response ChangeCompany(int userCompanyId, long? chartUserRoleSerial)
        {
            var user = accountService.GetUserByName(accessService.UserName);
            if (user == null) return Responses.BadRequest();

            //----------
            var company = companyService.GetCompanyById(userCompanyId);
            if (company is null) return Responses.CompanyNotFound();
            if (company.IsBlocked) return Responses.CompanyIsBlocked();
            var companyUser = companyService.GetCompanyUser(company.Id, user.UserName);
            if (companyUser.IsBlocked) return Responses.CompanyUserIsBlocked();

            var companyId = accountService.ConnectToCompany(user.UserName, userCompanyId);
            if (companyId == 0) return Responses.CompanyNotFound();

            //----------
            Request.Cookies.TryGetValue(_AuthenticationConfig.SessionIdCookieName, out var sessionId);
            Request.Cookies.TryGetValue(_AuthenticationConfig.RefTokenCookieName, out var ref_token);
            var session = accountService.GetSessionByRefreshToken(sessionId.ToLong(0), ref_token);
            if (session != null && session.UserName != user.UserName)
            {
                accountService.DeleteSession(session);
            }

            var userAgent = Request.Headers["User-Agent"].ToString();
            session = accountService.CreateSession(user, userAgent, accessService.RequestIP, companyId, chartUserRoleSerial);
            var ref_result = Refresh(user, session);


            //Log
            logService.LogLogin(user.UserName, company.Id, session.Id);

            var TaskCount = 0;
            if (!session.IsDeleted && session.ChartUserRoleSerial.HasValue)
                TaskCount = wfService.GetInboxCount("new,read", session.ChartUserRoleSerial.Value);

            var result = new
            {
                user.UserName,
                user.UniqueId,
                DisplayName = $"{user.FirstName} {user.LastName}",
                CompanyId = companyId,
                CompanyUniqueId = company.UniqueId,
                CompanyName = company.Name,
                IsSeller = company.EnableSupplier,
                IsBuyer = company.EnableSourcing,
                ref_result.Token,
                Expiry = _JwtConfig.RefreshTokenExpiry,
                NewNotificationCount = accountService.GetNewNotifCount(user.UserName, session.CompanyId),
                TaskCount,
            };

            return new Response(result);
        }
        #endregion

    }
}

