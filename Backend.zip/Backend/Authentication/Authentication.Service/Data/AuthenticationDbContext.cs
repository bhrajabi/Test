﻿using Authentication.Core;
using Common.Data;
using Common.Security;
using Microsoft.EntityFrameworkCore;

namespace Authentication.Service
{
    public class AuthenticationDbContext : BaseDbContext
    {
        public DbSet<User> Users { get; set; }

        public DbSet<UserAgent> UserAgents { get; set; }
        public DbSet<UserSession> UserSessions { get; set; }
        public DbSet<UserRole> UserRoles { get; set; }
        public DbSet<TAddress> Addresses { get; set; }


        public AuthenticationDbContext(DbContextOptions<AuthenticationDbContext> options, IHttpContextService currentUserNameService) : base(options, currentUserNameService)
        {

        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
        }

    }
}
