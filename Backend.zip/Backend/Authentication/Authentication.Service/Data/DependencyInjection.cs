﻿using Authentication.Core;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;

namespace Authentication.Service
{
    public static class DependencyInjection
    {
        public static void AddAuthenticationData(this IServiceCollection services, string connectionString)
        {
            services.AddDbContext<AuthenticationDbContext>(options => options
                        .UseSqlServer(connectionString)
                        .UseQueryTrackingBehavior(QueryTrackingBehavior.NoTracking)
                        );
        }

        public static void AddAuthenticationServices(this IServiceCollection services)
        {
            services.AddScoped<IAccountService, AccountService>();
            services.AddScoped<IMessagingService, MessagingService>();
        }
    }
}