﻿using Authentication.Core;

namespace Authentication.Service
{
    public class MessagingService : IMessagingService
    {
        public void SendOtp(string phoneNumber, string message)
        {
            throw new NotImplementedException();
        }
    }
}
