﻿using Authentication.Core;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace Authentication.Service
{
    public class AccountService : IAccountService
    {
        private readonly AuthenticationDbContext db;
        private readonly AuthenticationConfig _AuthenticationConfig;
        private readonly JwtConfig _JwtConfig;


        public AccountService(AuthenticationDbContext db, IOptions<AuthenticationConfig> accountsConfig, IOptions<JwtConfig> jwtConfig)
        {
            this.db = db;
            _AuthenticationConfig = accountsConfig.Value;
            _JwtConfig = jwtConfig.Value;
        }

        public void SetPassword(User user, string password)
        {
            var passwordHash = Common.Cryptography.Helper.HashPassword(password);
            db.Execute($"update dbo.Users set PasswordHash= @passwordHash where UserName = @UserName",
                new SqlParameter("@passwordHash", passwordHash),
                new SqlParameter("@UserName", user.UserName));
        }

        public User GetUserByName(string userName)
        {
            return db.Users.SingleOrDefault(x => x.UserName == userName);
        }

        public User GetUserByPhoneNumber(string phoneNumber)
        {
            return db.Users.Where(x => x.PhoneNumber == phoneNumber).FirstOrDefault();
        }

        public bool IsLocked(User user)
        {
            var delay_seconds = 60 * _AuthenticationConfig.LoginLockoutDuration;
            return
                user.LastAccessFailedDate.HasValue &&
                user.AccessFailedCount >= _AuthenticationConfig.MaxLoginFailCount &&
                DateTime.Now.Subtract(user.LastAccessFailedDate.Value).TotalSeconds < delay_seconds;
        }

        public void Register(User user, TAddress address, string password)
        {
            if (db.Users.Any(x => x.UserName == user.UserName || x.NationalCode == user.NationalCode))
                throw new Exception(AuthMessages.DuplicateNationalCode);

            var tr = db.Database.BeginTransaction();
            try
            {
                user.UserName = user.PhoneNumber;
                db.Add(user);
                db.SaveChanges();

                address.UserName = user.UserName;
                db.Add(address);
                db.SaveChanges();
               

                db.SaveChanges();
                tr.Commit();
            }
            catch (Exception)
            {
                tr.Rollback();
                throw;
            }

            SetPassword(user, password);
        }

        public void Update(User user)
        {
            db.Update(user);
            db.SaveChanges();
        }

        public void ResetPassword(User user, string password)
        {
            SetPassword(user, password);
        }

        public UserSession GetSessionByRefreshToken(long sessionId, string refreshToken)
        {
            if (sessionId <= 0 || string.IsNullOrEmpty(refreshToken)) return null;
            var session = db.UserSessions.Where(x => x.Id == sessionId && x.RefreshToken == refreshToken && !x.IsDeleted).FirstOrDefault();
            if (session != null && DateTime.Now.Subtract(session.RefreshTokenDate).TotalSeconds >= _AuthenticationConfig.SessionExpiry)
            {
                session.IsDeleted = true;
                db.Update(session);
                db.SaveChanges();
                session = null;
            }
            return session;
        }

        public UserSession CreateSession(User user, string userAgent, string ip)
        {
            var UserAgent = new UserAgent(userAgent);
            db.UserAgents.Add(UserAgent);
            db.SaveChanges();

            var session = new UserSession(user.UserName, UserAgent.Id, ip);
            session.CreatedAt = db.GetDate();
            db.UserSessions.Add(session);

            db.SaveChanges();
            return session;
        }

        public void DeleteSession(UserSession session)
        {
            session.IsDeleted = true;
            db.Update(session);
            db.SaveChanges();
        }

        public string GetToken(User user, int expiresAfterSeconds, string userData)
        {
            var key = Encoding.UTF8.GetBytes(_JwtConfig.SecretKey);
            var securityKey = new SymmetricSecurityKey(key);
            var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);
            var claims = new List<Claim>();
            claims.Add(new Claim(ClaimTypes.Name, user.UserName));
            if (!string.IsNullOrEmpty(userData)) claims.Add(new Claim(ClaimTypes.UserData, userData));
            var jwt = new JwtSecurityToken(
                            _JwtConfig.Issuer,
                            _JwtConfig.Audience,
                            claims,
                            expires: DateTime.Now.AddSeconds(expiresAfterSeconds),
                            signingCredentials: credentials);

            return new JwtSecurityTokenHandler().WriteToken(jwt);
        }

        public TAddress UserAddress(int serial)
        {
            return db.Addresses.Find(serial);
        }

       
    }
}
