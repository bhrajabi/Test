﻿using IPG.Core.Errors;
using IPG.Core.Services;
using IPG.Services.Data;

namespace IPG.Services
{
    public class IpgsService : IIpgsService
    {
        private readonly IPGDbContext db;


        public IpgsService(IPGDbContext db)
        {
            this.db = db;
        }



        public bool DeleteIpg(int id)
        {
            var dbIpg = db.IPGs.FirstOrDefault(x => x.Id == id) ?? throw new IkcoIPGNotFoundError();
            db.IPGs.Remove(dbIpg);
            return db.SaveChanges() > 0;
        }

        public Core.IPG InitIPG(int id)
        {
            return db.IPGs.Where(x => x.Id == id).FirstOrDefault() ?? throw new IkcoIPGNotFoundError();
        }

        public IList<Core.IPG> InitIkcoTerminalIpgs(string ikcoTerminalId)
        {
            return db.IPGs.Where(x => x.TerminalId == ikcoTerminalId).ToList();
        }

        public IList<Core.IPG> InitIPGS()
        {
            return db.IPGs.ToList();
        }

        public Core.IPG InitIkcoIpgById(int id)
        {
            return db.IPGs.FirstOrDefault(x => x.Id == id) ?? throw new IkcoIPGNotFoundError();
        }

        public Core.IPG SaveIkcoIpg(string ikcoTerminalId, Core.IPG ikcoIpg)
        {
            var editMode = (ikcoIpg.Id > 0);
            if (editMode)
                return UpdateIkcoIpg(ikcoIpg);
            else
                return CreateIkcoIpg(ikcoTerminalId, ikcoIpg);
        }

        public Core.IPG CreateIkcoIpg(string ikcoTerminalId, Core.IPG ikcoIpg)
        {
            using var db_transaction = db.Database.BeginTransaction();
            try
            {
                db.IPGs.Add(ikcoIpg);
                db.SaveChanges();

                if (db.IkcoTerminalIPGs.Any(x => x.TerminalId == ikcoTerminalId && x.IpgId == ikcoIpg.Id))
                    return ikcoIpg;


                db.IkcoTerminalIPGs.Add(new Core.IkcoTerminalIPG
                {
                    IpgId = ikcoIpg.Id,
                    TerminalId = ikcoTerminalId,
                });
                db.SaveChanges();

                db_transaction.Commit();
                return ikcoIpg;
            }
            catch
            {
                db_transaction.Rollback();
                throw;
            }


        }

        public Core.IPG GetIpgById(int ipgId)
        {
            return db.IPGs.FirstOrDefault(x => x.Id == ipgId) ?? throw new IkcoIPGNotFoundError();
        }

        public Core.IPG UpdateIkcoIpg(Core.IPG ikcoIpg)
        {
            var db_ipg = GetIpgById(ikcoIpg.Id);


            db_ipg.AcceptorId = ikcoIpg.AcceptorId;
            db_ipg.AccountNo = ikcoIpg.AccountNo;
            db_ipg.AdditionalData = ikcoIpg.AdditionalData;
            db_ipg.AllowInquiry = ikcoIpg.AllowInquiry;
            db_ipg.BankName = ikcoIpg.BankName;
            db_ipg.Comments = ikcoIpg.Comments;
            db_ipg.InquiryTimeoutMinutes = ikcoIpg.InquiryTimeoutMinutes;
            db_ipg.IsActive = ikcoIpg.IsActive;
            db_ipg.LogoUrl = ikcoIpg.LogoUrl;
            db_ipg.MerchantId = ikcoIpg.MerchantId;
            db_ipg.PanelPassword = ikcoIpg.PanelPassword;
            db_ipg.PanelUserName = ikcoIpg.PanelUserName;
            db_ipg.PassPhrase = ikcoIpg.PassPhrase;
            db_ipg.PaymentLimit = ikcoIpg.PaymentLimit;
            db_ipg.PublicKey = ikcoIpg.PublicKey;
            db_ipg.RegisteredUrl = ikcoIpg.RegisteredUrl;
            db_ipg.SHA1 = ikcoIpg.SHA1;
            db_ipg.ShaparakIV = ikcoIpg.ShaparakIV;
            db_ipg.ShaparakKey = ikcoIpg.ShaparakKey;
            db_ipg.ShaparakThirdPartyCode = ikcoIpg.ShaparakThirdPartyCode;
            db_ipg.Share = ikcoIpg.Share;
            db_ipg.Sheba = ikcoIpg.Sheba;
            db_ipg.TerminalId = ikcoIpg.TerminalId;
            db_ipg.Title = ikcoIpg.Title;

            db.IPGs.Update(db_ipg);
            db.SaveChanges();

            return ikcoIpg;
        }


    }
}
