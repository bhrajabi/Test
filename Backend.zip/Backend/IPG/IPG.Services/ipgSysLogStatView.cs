﻿namespace IPG.Services
{
    internal class ipgSysLogStatView
    {
        public string Message { get; set; }
        public int Count { get; set; }
        public DateTime MinOccuranceDate { get; set; }
        public DateTime MaxOccuranceDate { get; set; }
    }
}