﻿using System.Runtime.CompilerServices;
using Common;
using IPG.Core;
using IPG.Core.Errors;
using IPG.Core.Services;
using IPG.Core.View;
using IPG.Services.Data;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Options;
using Microsoft.Extensions.Primitives;
using Newtonsoft.Json;

namespace IPG.Services
{
    public class IkcoTransactionService : IIkcoTransactionService
    {
        private readonly IPGDbContext db;
        private readonly IPGServiceConfig ipgServiceConfig;
        private const string IkcoIpgApiKey = "ikco-123";
        const int LogsPageSize = 200;

        public IkcoTransactionService(IPGDbContext db, IOptions<IPGServiceConfig> ipgServiceConfig)
        {
            this.db = db;
            this.ipgServiceConfig = ipgServiceConfig.Value;
        }

        public List<IkcoTerminal> GetAllTerminals()
        {
            return db.IkcoTerminals.ToList();
        }

        public IkcoTransaction GetLastTestTransaction()
        {
            return db.IkcoTransactions.OrderByDescending(x => x.RequestId).Where(x => x.RequestId < 1000).FirstOrDefault() ?? throw new IkcoIPGTransactionNotFoundError();
        }

        public List<IkcoTerminalPaymentGatewaysInfo> GetIkcoTerminalPaymentGateways(string terminalId)
        {
            var query = from i in db.IPGs
                        join ti in db.IkcoTerminalIPGs on i.Id equals ti.IpgId
                        join pg in db.PaymentGateway on i.Code equals pg.Code
                        select new { ti, i, pg };

            if (!string.IsNullOrEmpty(terminalId))
            {
                query = query.Where(x => x.ti.TerminalId == terminalId);
            }

            return query.Distinct().Select(x => new IkcoTerminalPaymentGatewaysInfo
            {
                Id = x.i.Id,
                Title = string.IsNullOrEmpty(terminalId) ? x.pg.Title : $"{x.pg.Title} - {x.i.AccountNo}"
            }).ToList();
        }

        public IkcoTransaction GetTransactionBySerial(long serial)
        {
            return db.IkcoTransactions.FirstOrDefault(x => x.Serial == serial) ?? throw new IkcoIPGTransactionNotFoundError();
        }

        public IkcoTransaction GetTransactionByRequestId(long requestId)
        {
            return db.IkcoTransactions.FirstOrDefault(x => x.RequestId == requestId) ?? throw new IkcoIPGTransactionNotFoundError();
        }

        public List<IkcoTransactionLog> GetTransactionLogs(long transactionSerial)
        {
            return db.IkcoTransactionLogs.Where(x => x.TransactionSerial == transactionSerial).ToList();
        }

        public List<IkcoTransactionLog> InquiryTransaction(long transactionSerial)
        {
            return db.IkcoTransactionLogs.Where(x => x.TransactionSerial == transactionSerial).ToList();
        }

        public (List<IkcoTransactionView>, int) FilterTransactions(int fromIndex, FilterTransactionInfo model)
        {
            var query = from t in db.IkcoTransactions
                        join i in db.IPGs on t.IPGId equals i.Id
                        select new { i, t };

            var filteredQuery = query.OrderByDescending(x => x.t.CreatedAt).AsQueryable();

            if (model.Serial is not null && model.Serial > 0)
                filteredQuery = filteredQuery.Where(x => x.t.Serial.Equals(model.Serial));

            if (!string.IsNullOrEmpty(model.StatusId))
                filteredQuery = filteredQuery.Where(x => x.t.StatusId.Equals(model.StatusId));

            if (!string.IsNullOrEmpty(model.SalesProgram))
                filteredQuery = filteredQuery.Where(x => x.t.SalesProgram != null && x.t.SalesProgram.Equals(model.SalesProgram));

            if (model.InquiryStatus.HasValue)
                filteredQuery = filteredQuery.Where(x => x.t.InquiryCompleted == model.InquiryStatus.Value);

            if (!string.IsNullOrEmpty(model.TerminalId))
                filteredQuery = filteredQuery.Where(x => x.t.TerminalId == model.TerminalId);

            if (!string.IsNullOrEmpty(model.NationalCode))
                filteredQuery = filteredQuery.Where(x => x.t.NationalCode == model.NationalCode);

            if (!string.IsNullOrEmpty(model.NationalId))
                filteredQuery = filteredQuery.Where(x => x.t.NationalId == model.NationalId);

            if (!string.IsNullOrEmpty(model.PaymentRefNum))
                filteredQuery = filteredQuery.Where(x => x.t.PaymentRefNum == model.PaymentRefNum);

            if (!string.IsNullOrEmpty(model.Token))
                filteredQuery = filteredQuery.Where(x => x.t.IPGToken == model.Token);

            if (model.RequestId > 0)
                filteredQuery = filteredQuery.Where(x => x.t.RequestId.Equals(model.RequestId.Value));


            if (model.IpgId > 0)
                filteredQuery = filteredQuery.Where(x => x.t.IPGId == model.IpgId);

            if (model.FromCreatedOn != null)
                filteredQuery = filteredQuery.Where(c => c.t.CreatedAt.Date >= model.FromCreatedOn.Value.Date);

            if (model.ToCreatedOn != null)
                filteredQuery = filteredQuery.Where(c => c.t.CreatedAt.Date <= model.ToCreatedOn.Value.Date);


            var totalCount = filteredQuery.Count();

            if (fromIndex > 0) filteredQuery = filteredQuery.Skip(fromIndex * model.PageSize);

            var transactions = filteredQuery.Select(row => new IkcoTransactionView
            {
                Amount = row.t.Amount,
                CardNumber = row.t.CardNumber,
                InquiryCompleted = row.t.InquiryCompleted,
                InquiryDate = row.t.InquiryDate,
                InquiryDescription = row.t.InquiryDescription,
                InquiryFatalError = row.t.InquiryFatalError,
                InquiryHasConfilict = row.t.InquiryHasConfilict,
                IPGId = row.t.IPGId,
                IPGCode = row.i.Code,
                IPGTitle = row.i.Title,
                IPGStateDescription = row.t.IPGStateDescription,
                Message = row.t.Message,
                Mobile = row.t.Mobile,
                NationalCode = row.t.NationalCode,
                NationalId = row.t.NationalId,
                PaymentDate = row.t.PaymentDate,
                PaymentRefNum = row.t.PaymentRefNum,
                PaymentTraceNo = row.t.PaymentTraceNo,
                RequestId = row.t.RequestId,
                StatusId = row.t.StatusId,
                TerminalId = row.t.TerminalId,
                Serial = row.t.Serial,
                CreatedAt = row.t.CreatedAt,
            }).Take(model.PageSize).ToList();

            return (transactions, totalCount);
        }


        public async Task<InquiryTransactionJobResponse> InquiryTransactionJob(long serial)
        {
            var rest_client = new Rest($"{ipgServiceConfig.ApiAddress}/api/inquiry-transaction-job");

            var inquiry_response = await rest_client.PostAsync<Response>(new { apiKey = "ikco-123", serial, enforced = true }) ?? throw new IkcoIPGServerUnreachableError();

            if (!inquiry_response.IsSuccess) throw new IkcoIPGInquiryTransactionError(inquiry_response.ErrorMessage);

            var transaction = GetTransactionBySerial(serial);

            return new InquiryTransactionJobResponse(inquiry_response.Result, transaction);
        }

        public async Task<IkcoIpgRequestPaymentResult> GetIkcoIpgPaymentToken(IPGRequestPaymentView model)
        {
            var rest_client = new Rest($"{ipgServiceConfig.ApiAddress}/api/get-token");

            model.CallbackUrl = ipgServiceConfig.CallbackUrl;

            var response = await rest_client.PostAsync<Response>(model) ?? throw new IkcoIPGServerUnreachableError();

            if (!response.IsSuccess) throw new Error("Error in IPG: " + response.ErrorMessage);

            var json = JsonConvert.SerializeObject(response.Result);

            var result = JsonConvert.DeserializeObject<IkcoIpgRequestPaymentResult>(json);
            return result;
        }

        public async Task<IkcoIpgCallbackResponse> HandleCallbackRequest(IEnumerable<KeyValuePair<string, StringValues>> data, int ipgId)
        {
            var rest = new Rest($"{ipgServiceConfig.ApiAddress}/api/callback?ipgId={ipgId}");
            var ikco_ipg_response = await rest.PostAsync<Response>(data) ?? throw new IkcoIPGServerUnreachableError();
            if (!ikco_ipg_response.IsSuccess) throw new Exception(ikco_ipg_response.ErrorMessage);

            var payment_result = ikco_ipg_response.Result;

            return JsonConvert.DeserializeObject<IkcoIpgCallbackResponse>(payment_result.ToString()) ?? throw new IkcoIPGServerInvalidResponseError();
        }

        public async Task<IkcoIPGGetIkcoTransactionResponse> GetTransactionByIkcoIPG(long requestId, string terminalId, string token)
        {
            var dto = new
            {
                terminalId,
                requestId,
                token
            };

            var rest = new Rest($"{ipgServiceConfig.ApiAddress}/api/get-transaction");

            var ikco_ipg_response = await rest.PostAsync<Response>(dto) ?? throw new IkcoIPGTransactionNotFoundError();

            if (!ikco_ipg_response.IsSuccess) throw new IkcoIpgError(ikco_ipg_response.ErrorMessage);

            var json = ikco_ipg_response.Result.ToString();

            var transactionResponse = JsonConvert.DeserializeObject<IkcoIPGGetIkcoTransactionResponse>(json) ?? throw new IkcoIpgError("invalid-transaction-data");

            return transactionResponse;
        }

        public async Task<IkcoIPGGetIkcoTransactionResponse> ConfirmTransactionAsync(long requestId, string token)
        {

            var dto = new
            {
                requestId,
                token,
                enforced = true
            };

            var rest = new Rest($"{ipgServiceConfig.ApiAddress}/api/confirm-transaction");

            var ikco_ipg_response = await rest.PostAsync<Response>(dto) ?? throw new IkcoIPGServerUnreachableError();

            if (!ikco_ipg_response.IsSuccess) throw new IkcoIpgError(ikco_ipg_response.ErrorMessage);

            var json = ikco_ipg_response.Result.ToString();

            var transactionResponse = JsonConvert.DeserializeObject<IkcoIPGGetIkcoTransactionResponse>(json) ?? throw new IkcoIpgError("invalid-transaction-data");

            return transactionResponse;
        }

        public async Task<IkcoIPGGetIkcoTransactionsResponse> GetUninquiredTransactions()
        {
            var dto = new
            {
                ApiKey = IkcoIpgApiKey,
            };

            var rest = new Rest($"{ipgServiceConfig.ApiAddress}/api/uninquired-transactions-job");

            var ikco_ipg_response = await rest.PostAsync<Response>(dto) ?? throw new IkcoIPGServerUnreachableError();

            if (!ikco_ipg_response.IsSuccess) throw new IkcoIpgError(ikco_ipg_response.ErrorMessage);

            var json = ikco_ipg_response.Result.ToString();

            var transactionResponse = JsonConvert.DeserializeObject<IkcoIPGGetIkcoTransactionsResponse>(json) ?? throw new IkcoIpgError("invalid-transactions-data");

            return transactionResponse;
        }


        public (List<IkcoTransactionLog>, int) GetIkcoTransactionsLogs(int fromIndex, FilterTransactionLog filter)
        {
            var query = from t in db.IkcoTransactionLogs 
                        where t.MarkAsArchived == filter.MarkAsArchived 
                        select t;
                        
            var filteredQuery = query.OrderByDescending(x => x.Serial).AsQueryable();

            if (filter.Serial > 0)
                filteredQuery = filteredQuery.Where(x => x.Serial.Equals(filter.Serial));

            if (filter.FromCreatedOn != null) filteredQuery = filteredQuery.Where(c => c.CreatedAt.Date >= filter.FromCreatedOn.Value.Date);
            if (filter.ToCreatedOn != null) filteredQuery = filteredQuery.Where(c => c.CreatedAt.Date <= filter.ToCreatedOn.Value.Date);
            if (filter.FromSerial.HasValue) filteredQuery = filteredQuery.Where(c => c.Serial >= filter.FromSerial.Value);
            if (filter.ToSerial.HasValue) filteredQuery = filteredQuery.Where(c => c.Serial <= filter.ToSerial.Value);

            if (filter.TransactionSerial > 0)
                filteredQuery = filteredQuery.Where(x => x.TransactionSerial.Equals(filter.TransactionSerial));

            if (!string.IsNullOrEmpty(filter.Type))
                filteredQuery = filteredQuery.Where(x => x.Type.Equals(filter.Type));

            if (!string.IsNullOrEmpty(filter.Description))
                filteredQuery = filteredQuery.Where(x => x.Description.Equals(filter.Description));

            if (!string.IsNullOrEmpty(filter.ActionCode))
                filteredQuery = filteredQuery.Where(x => x.ActionCode == filter.ActionCode);


            if (!string.IsNullOrEmpty(filter.ActionParameters))
                filteredQuery = filteredQuery.Where(x => x.ActionParameters == filter.ActionParameters);

            var totalCount = filteredQuery.Count();

            if (fromIndex > 0) filteredQuery = filteredQuery.Skip(fromIndex * filter.PageSize);

            var transactions = filteredQuery.Select(row => new IkcoTransactionLog
            {
                Serial = row.Serial,
                TransactionSerial = row.TransactionSerial,
                ActionCode = row.ActionCode,
                ActionParameters = row.ActionParameters,
                Description = row.Description,
                Type = row.Type,
                CreatedAt = row.CreatedAt,
                MarkAsArchived = row.MarkAsArchived
            }).Take(LogsPageSize).ToList();

            return (transactions, totalCount);
        }

        public void UpdateIkcoIpgTransactionLog(Int64 serial, bool markAsArchived)
        {
            var ipgtlog = db.IkcoTransactionLogs
               .Where(c => c.Serial == serial)
               .FirstOrDefault();

            if (ipgtlog != null)
            {
                ipgtlog.MarkAsArchived = markAsArchived;
                db.Update(ipgtlog);
                db.SaveChanges();
            }
        }
    }
}
