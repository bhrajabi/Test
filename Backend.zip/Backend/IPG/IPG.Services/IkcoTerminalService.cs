﻿using System.Linq;
using IPG.Core;
using IPG.Core.Errors;
using IPG.Core.Services;
using IPG.Core.View;
using IPG.Services.Data;

namespace IPG.Services
{
    public class IkcoTerminalService : IIkcoTerminalService
    {

        private readonly IPGDbContext db;

        public IkcoTerminalService(IPGDbContext db)
        {
            this.db = db;
        }

        public IkcoTerminal SaveIkcoTerminal(IkcoTerminal ikcoTerminal)
        {
            var db_ikcoTerminal = db.IkcoTerminals.FirstOrDefault(x => x.Id == ikcoTerminal.Id);

            if (db_ikcoTerminal != null)
            {
                db_ikcoTerminal.IsActive = ikcoTerminal.IsActive;
                db_ikcoTerminal.Title = ikcoTerminal.Title;
                db_ikcoTerminal.LogoUrl = ikcoTerminal.LogoUrl;
                db_ikcoTerminal.PaymentLimit = ikcoTerminal.PaymentLimit;
                db_ikcoTerminal.DefaultCallback = ikcoTerminal.DefaultCallback;

                db.IkcoTerminals.Update(db_ikcoTerminal);
            }
            else db.IkcoTerminals.Add(ikcoTerminal);

            db.SaveChanges();

            return InitIkcoTerminalById(ikcoTerminal.Id);
        }


        public bool ExistsTerminalById(string id)
        {
            return db.IkcoTerminals.Any(x => x.Id == id);
        }

        public IkcoTerminal GetIkcoTerminalById(string id) => db.IkcoTerminals.FirstOrDefault(x => x.Id == id) ?? throw new IkcoIPGTerminalNotFoundError();

        public List<TerminalIPGInfoListView> GetTerminalIpgs(string terminalId)
        {
            var query = from i in db.IPGs
                        join ti in db.IkcoTerminalIPGs on i.Id equals ti.IpgId
                        join pg in db.PaymentGateway on i.Code equals pg.Code

                        where ti.TerminalId == terminalId
                        select new TerminalIPGInfoListView
                        {
                            Id = i.Id,
                            AcceptorId = i.AcceptorId,
                            AccountNo = i.AccountNo,
                            AdditionalData = i.AdditionalData,
                            AllowInquiry = i.AllowInquiry,
                            BankName = i.BankName,
                            Code = i.Code,
                            Comments = i.Comments,
                            InquiryTimeoutMinutes = i.InquiryTimeoutMinutes,
                            IsActive = i.IsActive,
                            LogoUrl = i.LogoUrl,
                            MerchantId = i.MerchantId,
                            PanelPassword = i.PanelPassword,
                            PanelUserName = i.PanelUserName,
                            PassPhrase = i.PassPhrase,
                            PaymentLimit = i.PaymentLimit,
                            PublicKey = i.PublicKey,
                            RegisteredUrl = i.RegisteredUrl,
                            SHA1 = i.SHA1,
                            ShaparakIV = i.ShaparakIV,
                            ShaparakKey = i.ShaparakKey,
                            ShaparakThirdPartyCode = i.ShaparakThirdPartyCode,
                            Share = i.Share,
                            Sheba = i.Sheba,
                            TerminalId = i.TerminalId,
                            Title = i.Title,
                            PanelUrl = pg.PanelUrl
                        };

            return query.ToList();
        }

        public bool DeleteTerminalById(string id)
        {
            var ikcoTerminal = GetIkcoTerminalById(id);

            var has_transactions_query = from ikcoTerminalIpg in db.IkcoTerminalIPGs
                                         join ikcoIpg in db.IPGs on ikcoTerminalIpg.IpgId equals ikcoIpg.Id
                                         join transactions in db.IkcoTransactions on ikcoIpg.Id equals transactions.IPGId
                                         where ikcoTerminalIpg.TerminalId == id
                                         select transactions;

            if (has_transactions_query.Any()) throw new IkcoIPGTerminalHasTransactionError();

            using var db_transaction = db.Database.BeginTransaction();
            try
            {
                var ikco_terminal_ipgs = db.IkcoTerminalIPGs.Where(x => x.TerminalId == id).ToList();
                db.IkcoTerminalIPGs.RemoveRange(ikco_terminal_ipgs);
                db.SaveChanges();

                var ipgs = db.IPGs.Where(ipg => ikco_terminal_ipgs.Select(x => x.IpgId).Contains(ipg.Id));
                db.IPGs.RemoveRange(ipgs);
                db.SaveChanges();

                db.IkcoTerminals.Remove(ikcoTerminal);
                db.SaveChanges();
                
                db_transaction.Commit();
                return true;
            }
            catch 
            {
                db_transaction.Rollback();
                throw;
            }
        }

        public List<IkcoTerminal> InitIkcoTerminals()
        {
            var query = from it in db.IkcoTerminals
                        join u in db.Users on it.CreatedBy equals u.UserName into users
                        from u in users.DefaultIfEmpty()
                        select new IkcoTerminal
                        {
                            Id = it.Id,
                            IsActive = it.IsActive,
                            LogoUrl = it.LogoUrl,
                            PaymentLimit = it.PaymentLimit,
                            Title = it.Title,
                            DefaultCallback = it.DefaultCallback,
                            CreatedAt = it.CreatedAt,
                            CreatedBy = u != null ? u.DisplayName : it.CreatedBy,
                        };

            return query.ToList();
        }

        public IkcoTerminal InitIkcoTerminalById(string terminalId)
        {
            var query = from it in db.IkcoTerminals
                        join u in db.Users on it.CreatedBy equals u.UserName
                        select new IkcoTerminal
                        {
                            Id = it.Id,
                            IsActive = it.IsActive,
                            LogoUrl = it.LogoUrl,
                            PaymentLimit = it.PaymentLimit,
                            Title = it.Title,
                            DefaultCallback = it.DefaultCallback,
                            CreatedAt = it.CreatedAt,
                            CreatedBy = u.DisplayName,
                        };

            return db.IkcoTerminals.FirstOrDefault(x => x.Id == terminalId) ?? throw new IkcoIPGTerminalNotFoundError();
        }

        public bool RemoveIPG(IkcoTerminalIPG ikcoTerminalIPG)
        {
            var IkcoTerminalIPG = db.IkcoTerminalIPGs.Where(
                    x => x.TerminalId == ikcoTerminalIPG.TerminalId &&
                    x.IpgId == ikcoTerminalIPG.IpgId
            ).ToList();
            if (IkcoTerminalIPG != null && IkcoTerminalIPG.Count > 0)
            {
                db.IkcoTerminalIPGs.RemoveRange(ikcoTerminalIPG);
                return db.SaveChanges() > 0;
            }
            return false;
        }

        public bool AddIPG(IkcoTerminalIPG ikcoTerminalIPG)
        {
            var IkcoTerminalIPG = db.IkcoTerminalIPGs.Where(
                    x => x.TerminalId == ikcoTerminalIPG.TerminalId &&
                    x.IpgId == ikcoTerminalIPG.IpgId
            ).ToList();
            if (IkcoTerminalIPG.Count == 0)
            {
                db.IkcoTerminalIPGs.Add(new IkcoTerminalIPG
                {
                    IpgId = ikcoTerminalIPG.IpgId,
                    TerminalId = ikcoTerminalIPG.TerminalId
                });
                return db.SaveChanges() > 0;
            }
            return true;
        }
    }
}
