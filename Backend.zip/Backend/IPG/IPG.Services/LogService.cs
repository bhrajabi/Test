﻿using IPG.Core;
using IPG.Core.Errors;
using IPG.Core.Services;
using IPG.Services.Data;

namespace IPG.Services
{
    public class LogService : ILogService
    {
        const int LogsPageSize = 200;

        private readonly IPGDbContext db;

        public LogService(IPGDbContext db)
        {
            this.db = db;
        }

        public IQueryable<IPGZSysLog> GetSysLogsQuery(IPGSysLogsSearchInfo filter)
        {
            var q = db.IPGZSysLogs
                .Where(c => c.IsArchived == filter.IsArchived)
                .OrderByDescending(c => c.Serial)
                .AsQueryable();
            if (filter.Type != null) q = q.Where(c => c.Type == filter.Type);
            if (filter.FromCreatedOn != null) q = q.Where(c => c.CreatedAt.Date >= filter.FromCreatedOn.Value.Date);
            if (filter.ToCreatedOn != null) q = q.Where(c => c.CreatedAt.Date <= filter.ToCreatedOn.Value.Date);
            if (!string.IsNullOrEmpty(filter.Message)) q = q.Where(c => c.Message.Contains(filter.Message));
            if (filter.FromSerial.HasValue) q = q.Where(c => c.Serial >= filter.FromSerial.Value);
            if (filter.ToSerial.HasValue) q = q.Where(c => c.Serial <= filter.ToSerial.Value);

            if (filter.TransactionSerial > 0) q = q.Where(log => log.TransactionSerial == filter.TransactionSerial);
            if (!string.IsNullOrEmpty(filter.Token)) q = q.Where(log => log.Token == filter.Token);
            if (!string.IsNullOrEmpty(filter.IkcoTerminalId)) q = q.Where(log => log.IkcoTerminalId.Equals(filter.IkcoTerminalId));
            //if (!string.IsNullOrEmpty(filter.MachineName)) q = q.Where(log => log.MachineName.Contains(filter.MachineName));

            return q;
        }

        public (IList<IPGZSysLog>, int) GetIPGSysLogs(IPGSysLogsSearchInfo filter, int fromIndex)
        {
            var query = GetSysLogsQuery(filter);
            var count = query.Count();
            if (fromIndex > 0) query = query.Skip(fromIndex);
            return (query.Take(LogsPageSize).ToList(), count);
        }

        public IList<IPGSysLogStatView> GetLogsGroupByMessage(IPGSysLogsSearchInfo filter)
        {
            var q = GetSysLogsQuery(filter)
                .GroupBy(x => x.Message)
                .Select(x => new IPGSysLogStatView
                {
                    Message = x.Key,
                    Count = x.Count(),
                    MinOccuranceDate = x.Min(z => z.CreatedAt),
                    MaxOccuranceDate = x.Max(z => z.CreatedAt),
                }).OrderByDescending(x => x.Count)
                .OrderByDescending(x => x.MaxOccuranceDate);

            return q.Take(500).ToList();
        }

        public IList<IPGZSysLog> GetIPGSysLogs(IPGSysLogsSearchInfo model)
        {
            var maxMessageLength = 200;
            var query = db.IPGZSysLogs.OrderByDescending(log => log.Serial).AsQueryable();

            query = query.Where(log => log.IsArchived == model.IsArchived);

            if (model.TransactionSerial > 0)
                query = query.Where(log => log.TransactionSerial == model.TransactionSerial);

            if (!string.IsNullOrEmpty(model.Type))
                query = query.Where(log => log.Type == model.Type);

            if (!string.IsNullOrEmpty(model.Token))
                query = query.Where(log => log.Token == model.Token);

            if (!string.IsNullOrEmpty(model.IkcoTerminalId))
                query = query.Where(log => log.IkcoTerminalId.Equals(model.IkcoTerminalId));

            if (model.FromCreatedOn != null && model.ToCreatedOn != null)
                query = query.Where(log => log.CreatedAt.Date >= model.FromCreatedOn.Value.Date && log.CreatedAt.Date <= model.ToCreatedOn.Value.Date);

            if (!string.IsNullOrEmpty(model.Message))
                query = query.Where(log => log.Message.Contains(model.Message));

            if (model.FromSerial.HasValue)
                query = query.Where(log => log.Serial >= model.FromSerial.Value);

            if (model.ToSerial.HasValue)
                query = query.Where(log => log.Serial <= model.ToSerial.Value);

            return query.Take(1000)
                 .Select(log => new IPGZSysLog
                 {
                     Serial = log.Serial,
                     Type = log.Type,
                     Message = log.Message.Length > maxMessageLength ? $"{log.Message.Substring(0, maxMessageLength)}..." : log.Message,
                     Details = log.Details,
                     Properties = log.Properties,
                     Token = log.Token,
                     IkcoTerminalId = log.IkcoTerminalId,
                     TransactionSerial = log.TransactionSerial,
                     IPGId = log.IPGId,
                     CreatedAt = log.CreatedAt
                 })
                 .ToList();
        }

        public IPGZSysLog GetIpgSysLog(Int64 serial)
        {
            return db.IPGZSysLogs.Where(c => c.Serial == serial).FirstOrDefault() ?? throw new IkcoIPGNotFoundError();
        }

        public IList<IPGZSysLog> GetIpgSysLogs(long serial)
        {
            var log = GetIpgSysLog(serial);

            var q = db.IPGZSysLogs
                .Where(c => c.Serial < serial && c.IkcoTerminalId == log.IkcoTerminalId)
                .OrderByDescending(c => c.Serial)
                .Take(500)
                .ToList();

            return q;
        }

        public void UpdateIpgSysLogInfo(Int64 serial, bool isArchived)
        {
            var sysInfo = db.IPGZSysLogs
               .Where(c => c.Serial == serial)
               .FirstOrDefault();

            if (sysInfo != null)
            {
                sysInfo.IsArchived = isArchived;
                db.Update(sysInfo);
                db.SaveChanges();
            }
        }
    }
}
