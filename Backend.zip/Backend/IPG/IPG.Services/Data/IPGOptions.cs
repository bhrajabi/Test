﻿using Microsoft.Extensions.Configuration;

namespace IPG.Services.Data
{
    public class IPGOptions
    {
        public string ConnectionString { get; set; }
        public IConfigurationSection ConfigSection { get; set; }
    }
}
