﻿using Common.Data;
using Common.Security;
using IPG.Core;
using IPG.Core.Entities;
using Microsoft.EntityFrameworkCore;

namespace IPG.Services.Data
{
    public class IPGDbContext : BaseDbContext
    {
        public DbSet<IkcoTerminalIPG> IkcoTerminalIPGs { get; set; }
        public DbSet<IPGZSysLog> IPGZSysLogs { get; set; }
        public DbSet<IPG.Core.IPG> IPGs { get; set; }
        public DbSet<User> Users { get; set; }
        public DbSet<IkcoTerminal> IkcoTerminals { get; set; }
        public DbSet<IkcoTransaction> IkcoTransactions { get; set; }
        public DbSet<IkcoTransactionLog> IkcoTransactionLogs { get; set; }
        public DbSet<IPGPaymentGateway> PaymentGateway { get; set; }


        public IPGDbContext(DbContextOptions<IPGDbContext> options, IHttpContextService currentUserNameService) : base(options, currentUserNameService)
        {
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            
            modelBuilder.Entity<IkcoTerminalIPG>().HasKey(x => new { x.IpgId, x.TerminalId });
        }
    }
}
