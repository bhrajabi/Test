﻿using IPG.Core;
using IPG.Core.Services;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Tamin.Services;

namespace IPG.Services.Data
{
    public static class IPGServiceExtension
    {
        public static IServiceCollection AddIPG(this IServiceCollection services, Action<IPGOptions> setupAction)
        {
            // set up ipg customized options
            var options = new IPGOptions();
            setupAction(options);
            services.Configure<IPGServiceConfig>(options.ConfigSection);
            services.Configure(setupAction);
            services.AddIPGData(options.ConnectionString);

            //add ikco ipg services
            services.AddIPGServices();

            return services;
        }

        private static void AddIPGData(this IServiceCollection services, string connectionString)
        {
            if (string.IsNullOrEmpty(connectionString))
                throw new Exception("IPG connection string cannot be empty!");

            services.AddDbContext<IPGDbContext>(options => options
                    .UseSqlServer(connectionString)
                    .UseQueryTrackingBehavior(QueryTrackingBehavior.NoTracking));
        }

        private static void AddIPGServices(this IServiceCollection services)
        {
            services.AddScoped<IIkcoTerminalService, IkcoTerminalService>();
            services.AddScoped<IIkcoTransactionService, IkcoTransactionService>();
            services.AddScoped<IIpgsService, IpgsService>();
            services.AddScoped<ILogService, LogService>();
        }
    }
}
