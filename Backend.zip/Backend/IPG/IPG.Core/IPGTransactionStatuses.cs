﻿namespace IPG.Core
{
    public class IPGTransactionStatuses
    {
        public const string NEW = "NEW";
        public const string USERPAID = "USERPAID";

        public const string FAILED = "FAILED";
        public const string SUCCESS = "SUCCESS";
    }
}
