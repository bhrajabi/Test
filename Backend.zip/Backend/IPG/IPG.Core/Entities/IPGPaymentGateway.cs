﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace IPG.Core
{
    [Table("PaymentGateways", Schema = "IPG")]
    public class IPGPaymentGateway
    {
        [Key]
        public string Code { get; set; }

        public string Title { get; set; }
        public int CallbackTimeoutMinutes { get; set; }
        public int InquiryTimeoutMinutes { get; set; }
        public string? PanelUrl { get; set; }
    }
}
