﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Common.Data;

namespace IPG.Core
{
    [Table("IPGs", Schema = "IPG")]
    public class IPG : IHasCreator
    {
        public int Id { get; set; }

        public string Code { get; set; }
        public string Title { get; set; }
        public string? TerminalId { get; set; }
        public string? AcceptorId { get; set; }
        public string PassPhrase { get; set; }
        public long PaymentLimit { get; set; }
        public string MerchantId { get; set; }
        public string? PanelUserName { get; set; }
        public string? PanelPassword { get; set; }
        public bool IsActive { get; set; }
        public string? Comments { get; set; }
        public string LogoUrl { get; set; }
        public string? PublicKey { get; set; }
        public string? SHA1 { get; set; }
        public string? ShaparakKey { get; set; }
        public string? ShaparakIV { get; set; }
        public string? ShaparakThirdPartyCode { get; set; }
        public int Share { get; set; }
        public string? AccountNo { get; set; }
        public string? BankName { get; set; }
        public string? Sheba { get; set; }
        public string? RegisteredUrl { get; set; }
        public string? AdditionalData { get; set; }
        public bool AllowInquiry { get; set; }
        public int InquiryTimeoutMinutes { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedAt { get; set; }
    }
}
