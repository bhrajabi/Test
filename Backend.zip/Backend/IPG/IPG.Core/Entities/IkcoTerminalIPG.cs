﻿using System.ComponentModel.DataAnnotations.Schema;

namespace IPG.Core
{
    [Table("IkcoTerminalIPGs", Schema = "IPG")]
    public class IkcoTerminalIPG
    {
        public string TerminalId { get; set; }
        public int IpgId { get; set; }
    }
}
