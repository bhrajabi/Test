﻿using System.ComponentModel.DataAnnotations.Schema;
using System.Diagnostics.CodeAnalysis;
using Common.Data;

namespace IPG.Core
{
    [Table("IkcoTerminals", Schema = "IPG")]
    public class IkcoTerminal : IHasCreator
    {
        public string Id { get; set; } = default!;

        public string Title { get; set; } = default!;

        public string? LogoUrl { get; set; }
        public long PaymentLimit { get; set; }
        public bool IsActive { get; set; }

        public string? DefaultCallback { get; set; }

        public string CreatedBy { get; set; } = default!;
        public DateTime CreatedAt { get; set; }
    }
}
