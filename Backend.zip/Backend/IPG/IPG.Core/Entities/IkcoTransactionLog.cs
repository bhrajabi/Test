﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace IPG.Core
{
    [Table("IkcoTransactionLogs", Schema = "IPG")]
    public class IkcoTransactionLog
    {
        [Key]
        public long Serial { get; set; }

        public long TransactionSerial { get; set; }
        public string? Type { get; set; }
        public string Description { get; set; }
        public string ActionCode { get; set; }
        public string? ActionParameters { get; set; }
        public bool MarkAsArchived { get; set; }
        public DateTime CreatedAt { get; set; }
    }
}
