﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace IPG.Core
{
    [Table("ZSysLogs", Schema = "IPG")]
    public class IPGZSysLog
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Serial { get; set; }

        public string Type { get; set; }
        public string Message { get; set; }
        public string? Details { get; set; }
        public string? Properties { get; set; }
        public string? Token { get; set; }
        public string? IkcoTerminalId { get; set; }
        public long? TransactionSerial { get; set; }
        public int? IPGId { get; set; }
        public bool IsArchived { get; set; }
        public string? MachineName { get; set; }

        public DateTime CreatedAt { get; set; }

    }
}
