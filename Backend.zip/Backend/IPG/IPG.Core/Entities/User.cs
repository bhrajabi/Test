﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace IPG.Core.Entities
{
    [Table("ZUsers", Schema = "PUR")]
    public class User
    {
        [Key]
        public string UserName { get; set; }

        public string FirstName { get; set; }
        public string LastName { get; set; }

        public string NationalCode { get; set; }
        public string AuthenticationMethod { get; set; }
        public string PasswordHash { get; set; }

        public string Email { get; set; }
        public bool EmailConfirmed { get; set; }
        public bool PhoneNumberConfirmed { get; set; }

        public string PhoneNumber { get; set; }
        public string WorkPhoneNumber { get; set; }
        public string DefaultLanguage { get; set; }

        public int AccessFailedCount { get; set; }
        public DateTime? LastAccessFailedDate { get; set; }

        public bool IsDeleted { get; set; }
        public bool IsDisabled { get; set; }
        public bool IsServiceUser { get; set; }

        public Guid UniqueId { get; set; }
        public long? ImageAttachmentId { get; set; }
        public DateTime LastUpdate { get; set; }
        public DateTime CreatedAt { get; set; }

        public string AuthenticatorKey { get; set; }
        public string Current2FA { get; set; }
        public bool Show2FAAlarm { get; set; }

        public virtual string DisplayName { get => $"{FirstName} {LastName}"; }

        public User()
        {
            CreatedAt = DateTime.Now;
        }

    }
}