﻿namespace IPG.Core
{
    public class IPGServiceConfig
    {
        public const string SectionName = "IPGService";

        public string ApiAddress { get; set; }
        public string CallbackUrl { get; set; }
        public string FrontPaymentResultUrl { get; set; }
    }
}