﻿namespace IPG.Core.View
{
    public class InquiryTransactionJobResponse
    {
        public object InquiryResult { get; set; }
        public IkcoTransaction Transaction { get; set; }

        public InquiryTransactionJobResponse(object inquiryResult, IkcoTransaction transaction) {
            this.Transaction = transaction;
            this.InquiryResult = inquiryResult;
        }

        public InquiryTransactionJobResponse(object inquiryResult)
        {
            this.InquiryResult = inquiryResult;
        }

    }
}
