﻿namespace IPG.Core
{
    public class IkcoIpgCallbackResponse
    {
        public IkcoTransaction Transaction { get; set; }
        public string PSPName { get; set; }
    }
}
