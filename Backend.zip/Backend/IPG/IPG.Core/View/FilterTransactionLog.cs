﻿using System.ComponentModel.DataAnnotations;

namespace IPG.Core.View
{
    public class FilterTransactionLog
    {
        public long Serial { get; set; }

        public long TransactionSerial { get; set; }
  
        public string? Type { get; set; }
  
        public string Description { get; set; }
 
        public string ActionCode { get; set; }
     
        public string? ActionParameters { get; set; }
        public bool MarkAsArchived { get; set; }
        public DateTime CreatedAt { get; set; }

        public DateTime? FromCreatedOn { get; set; }
        public DateTime? ToCreatedOn { get; set; }

        public long? FromSerial { get; set; }
        public long? ToSerial { get; set; }

        public int PageIndex { get; set; }
        public int PageSize { get; set; }

    }
}
