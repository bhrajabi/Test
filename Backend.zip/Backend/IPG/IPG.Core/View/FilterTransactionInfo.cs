﻿namespace IPG.Core.View
{
    public class FilterTransactionInfo
    {
        public string? TerminalId { get; set; }

        public string? Token { get; set; }

        public string SalesProgram { get; set; }

        public string? StatusId { get; set; }

        public bool? InquiryStatus { get; set; }

        public long? RequestId { get; set; }
        public long? Serial { get; set; }
        public string PaymentRefNum { get; set; }
        public string? NationalCode { get; set; }
        public string? NationalId { get; set; }

        public int IpgId { get; set; }

        public int PageIndex { get; set; }
        public int PageSize { get; set; }

        public DateTime? FromCreatedOn { get; set; }
        public DateTime? ToCreatedOn { get; set; }
    }
}
