﻿namespace IPG.Core
{
    public class IkcoIPGGetIkcoTransactionsResponse
    {
        public List<IkcoTransaction> Transactions { get; set; }
    }
}
