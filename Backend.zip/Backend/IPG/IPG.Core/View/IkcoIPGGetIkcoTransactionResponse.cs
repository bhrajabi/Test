﻿namespace IPG.Core
{
    public class IkcoIPGGetIkcoTransactionResponse
    {
        public IkcoTransaction Transaction { get; set; }
    }
}
