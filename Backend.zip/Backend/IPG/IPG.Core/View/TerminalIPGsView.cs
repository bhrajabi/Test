﻿namespace IPG.Core.View
{
    public class TerminalIPGsView
    {
        public string Title { get; set; }
        public int Id { get; set; }
        public string TerminalId { get; set; }
    }
}
