﻿namespace IPG.Core.View
{
    public class IkcoTerminalPaymentGatewaysInfo
    {
        public int Id { get; set; }
        public string Title { get; set; }
    }
}
