﻿namespace IPG.Core.View
{
    public class TerminalIPGInfoListView : IPG {
        public string? PanelUrl { get; set; }
    }
}
