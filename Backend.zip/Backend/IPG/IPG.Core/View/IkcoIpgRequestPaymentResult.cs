﻿namespace IPG.Core
{
    public class IkcoIpgRequestPaymentResult
    {
        public string Html { get; set; }
        public string IPGToken { get; set; }
        public string PSPName { get; set; }
    }
}
