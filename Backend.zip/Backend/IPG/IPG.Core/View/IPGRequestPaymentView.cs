﻿using System.ComponentModel.DataAnnotations;

namespace IPG.Core
{
    public class IPGRequestPaymentView
    {
        public int RequestId { get; set; }
        public string TerminalId { get; set; }
        public string Mobile { get; set; }

        public string NationalId { get; set; }
        public string NationalCode { get; set; }

        public int Amount { get; set; }

        public string CallbackUrl { get; set; }
    }
}
