﻿using Common;

namespace IPG.Core.Errors
{
    public class IkcoIPGTerminalHasTransactionError : Error
    {
        public IkcoIPGTerminalHasTransactionError() : base("ikco-terminal-has-transactions")
        {
        }
    }
}
