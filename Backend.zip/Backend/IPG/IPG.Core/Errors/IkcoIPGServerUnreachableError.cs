﻿using Common;

namespace IPG.Core.Errors
{
    public class IkcoIPGServerUnreachableError : Error
    {
        public IkcoIPGServerUnreachableError() : base("ipg-server-unreachable")
        {
        }
    }
}
