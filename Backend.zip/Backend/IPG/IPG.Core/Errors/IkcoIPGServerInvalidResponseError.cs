﻿using Common;

namespace IPG.Core.Errors
{
    public class IkcoIPGServerInvalidResponseError : Error
    {
        public IkcoIPGServerInvalidResponseError() : base("ipg-server-invalid-response")
        {
        }
    }
}
