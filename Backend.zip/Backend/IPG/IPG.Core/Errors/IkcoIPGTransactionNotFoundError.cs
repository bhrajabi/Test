﻿using Common;
namespace IPG.Core.Errors
{
    public class IkcoIPGTransactionNotFoundError : Error
    {
        public IkcoIPGTransactionNotFoundError() : base("transaction-not-found")
        {
        }
    }
}