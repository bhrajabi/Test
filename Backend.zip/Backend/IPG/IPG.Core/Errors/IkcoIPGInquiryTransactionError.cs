﻿using Common;

namespace IPG.Core.Errors
{
    public class IkcoIPGInquiryTransactionError : Error
    {
        public IkcoIPGInquiryTransactionError(string error_message, string error_code = "500") : base("inquiry-transaction-@errorMessage-@errorCode")
        {
            Add("errorMessage", error_message).Add("errorCode", error_code);
        }
    }
}
