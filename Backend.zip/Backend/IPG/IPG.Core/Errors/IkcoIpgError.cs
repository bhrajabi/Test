﻿using Common;
namespace IPG.Core.Errors
{
    public class IkcoIpgError : Error
    {
        public IkcoIpgError(string message) : base($"IKCO IPG ERROR : {message}")
        {
        }
    }
}