﻿using Common;

namespace IPG.Core.Errors
{
    public class IkcoIPGNotFoundError : Error
    {
        public IkcoIPGNotFoundError() : base("ipg-not-found")
        {
        }
    }
}
