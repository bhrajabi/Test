﻿using Common;
namespace IPG.Core.Errors
{
    public class IkcoIPGTerminalNotFoundError : Error
    {
        public IkcoIPGTerminalNotFoundError() : base("ikco-terminal-not-found")
        {
        }
    }
}