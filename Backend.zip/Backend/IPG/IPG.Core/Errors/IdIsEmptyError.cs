﻿using Common;

namespace IPG.Core.Errors
{
    public class IdIsEmptyError : Error
    {
        public IdIsEmptyError() : base("id-is-empty")
        {
        }
    }
}
