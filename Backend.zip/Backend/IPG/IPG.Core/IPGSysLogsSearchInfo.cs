﻿namespace IPG.Core
{
    public class IPGSysLogsSearchInfo
    {
        public long? TransactionSerial { get; set; } = 0;
        public string Token { get; set; }
        public string IkcoTerminalId { get; set; }

        public string Type { get; set; }
        public DateTime? FromCreatedOn { get; set; }
        public DateTime? ToCreatedOn { get; set; }
        public string Message { get; set; }

        public long? FromSerial { get; set; }
        public long? ToSerial { get; set; }

        public string MachineName { get; set; }
        public bool IsArchived { get; set; }
    }
}
