﻿using Common;

namespace IPG.Core
{
    public static class Responses
    {
        public static Response BadRequest()
        {
            return new Response("bad-request", "error");
        }

        public static Response InternalError()
        {
            return new Response("internal-error", "500");
        }

        public static Response Error401()
        {
            return new Response("401", "401");
        }

        public static Response Error403()
        {
            return new Response("403", "403");
        }

        public static Response RecordNotFound()
        {
            return new Response("record-not-found!", "error");
        }

        public static Response IkcoTerminalNotFound()
        {
            return new Response("ikco-terminal-not-found");
        }

        public static Response IkcoTransactionNotFound()
        {
            return new Response("ikco-transaction-not-found");
        }
    }
}
