﻿using IPG.Core.View;

namespace IPG.Core.Services
{
    public interface IIkcoTerminalService
    {
        IkcoTerminal GetIkcoTerminalById(string id);
        IkcoTerminal SaveIkcoTerminal(IkcoTerminal ikcoTerminal);

        List<IkcoTerminal> InitIkcoTerminals();
        List<TerminalIPGInfoListView> GetTerminalIpgs(string terminalId);

        bool RemoveIPG(IkcoTerminalIPG ikcoTerminalIPG);
        bool AddIPG(IkcoTerminalIPG ikcoTerminalIPG);
        bool DeleteTerminalById(string id);
        bool ExistsTerminalById(string id);
    }
}
