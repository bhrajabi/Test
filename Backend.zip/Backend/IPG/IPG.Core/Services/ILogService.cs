﻿namespace IPG.Core.Services
{
    public interface ILogService
    {
        (IList<IPGZSysLog>, int) GetIPGSysLogs(IPGSysLogsSearchInfo model, int fromIndex);
        IList<IPGSysLogStatView> GetLogsGroupByMessage(IPGSysLogsSearchInfo filter);

        IList<IPGZSysLog> GetIPGSysLogs(IPGSysLogsSearchInfo model);
        IList<IPGZSysLog> GetIpgSysLogs(long serial);
        void UpdateIpgSysLogInfo(Int64 serial, bool isArchived);
        IPGZSysLog GetIpgSysLog(long serial);
    }
}
