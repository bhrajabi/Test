﻿namespace IPG.Core.Services
{
    public interface IIpgsService
    {
        IList<IPG> InitIPGS();
        IPG InitIPG(int id);
        IPG SaveIkcoIpg(string ikcoTerminalId, IPG ipg);
        bool DeleteIpg(int id);
        IList<IPG> InitIkcoTerminalIpgs(string ikcoTerminalId);
    }
}
