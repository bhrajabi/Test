﻿using Common;
using IPG.Core.View;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Primitives;

namespace IPG.Core.Services
{
    public interface IIkcoTransactionService
    {
        Task<IkcoIPGGetIkcoTransactionResponse> ConfirmTransactionAsync(long requestId, string token);
        List<IkcoTerminal> GetAllTerminals();
        Task<IkcoIpgRequestPaymentResult> GetIkcoIpgPaymentToken(IPGRequestPaymentView model);
        List<IkcoTerminalPaymentGatewaysInfo> GetIkcoTerminalPaymentGateways(string terminalId);
        IkcoTransaction GetLastTestTransaction();
        Task<IkcoIPGGetIkcoTransactionResponse> GetTransactionByIkcoIPG(long requestId, string terminalId, string token);
        IkcoTransaction GetTransactionByRequestId(long requestId);
        IkcoTransaction GetTransactionBySerial(long serial);
        List<IkcoTransactionLog> GetTransactionLogs(long transactionSerial);
        
        (List<IkcoTransactionView>, int) FilterTransactions(int fromIndex, FilterTransactionInfo model);
        Task<IkcoIPGGetIkcoTransactionsResponse> GetUninquiredTransactions();
        Task<IkcoIpgCallbackResponse> HandleCallbackRequest(IEnumerable<KeyValuePair<string, StringValues>> data, int ipgId);
        Task<InquiryTransactionJobResponse> InquiryTransactionJob(long serial);

        (List<IkcoTransactionLog>, int) GetIkcoTransactionsLogs(int fromIndex, FilterTransactionLog filter);
        void UpdateIkcoIpgTransactionLog(Int64 serial, bool markAsArchived);
    }
}
