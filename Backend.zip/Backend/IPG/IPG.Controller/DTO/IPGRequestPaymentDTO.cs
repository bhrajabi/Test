﻿using System.ComponentModel.DataAnnotations;

namespace IPG.Controller
{
    public class IPGRequestPaymentDTO
    {
        public int RequestId { get; set; }

        [MaxLength(20)]
        public string TerminalId { get; set; }

        [MaxLength(50)]
        public string Mobile { get; set; }

        [MaxLength(15)]
        public string? NationalId { get; set; }
        
        
        [MaxLength(15)]
        public string? NationalCode { get; set; }

        public int Amount { get; set; }
    }
}
