﻿namespace Tamin.Controllers
{
    public class IPGPaymentGatewayDTO
    {
        public string Code { get; set; }

        public string Title { get; set; }

        public string CallbackTimeoutMinutes { get; set; }

        public string InquiryTimeoutMinutes { get; set; }
    }
}
