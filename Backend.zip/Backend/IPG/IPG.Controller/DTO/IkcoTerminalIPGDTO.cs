﻿using System.ComponentModel.DataAnnotations;

namespace IPG.Controller
{
    public class IkcoTerminalIPGDTO
    {
        [MaxLength(20)]
        public string TerminalId { get; set; }

        public int IpgId { get; set; }
    }
}
