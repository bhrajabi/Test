﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using Common;

namespace IPG.Controller
{
    public class IPGDTO
    {
        public int Id { get; set; }

        [MaxLength(20)]
        public string Code { get; set; }

        [MaxLength(200)]
        [DefaultValue(SpecialChars.Str100)]
        public string Title { get; set; }

        [MaxLength(20)]
        public string? TerminalId { get; set; }

        [MaxLength(40)]
        public string? AcceptorId { get; set; }

        [MaxLength(50)]
        public string PassPhrase { get; set; }


        public long PaymentLimit { get; set; }

        [MaxLength(20)]
        public string? MerchantId { get; set; }

        [MaxLength(50)]
        public string? PanelUserName { get; set; }

        [MaxLength(50)]
        public string? PanelPassword { get; set; }

        public bool IsActive { get; set; }

        [MaxLength(50000)]
        [DefaultValue(SpecialChars.Str1000)]
        public string? Comments { get; set; }

        [MaxLength(500)]
        [DefaultValue(SpecialChars.Str1000)]
        public string LogoUrl { get; set; }

        [MaxLength(4096)]
        public string? PublicKey { get; set; }

        [MaxLength(200)]
        public string? SHA1 { get; set; }

        //[MaxLength(1000)]
        //public string? CallBackUrl { get; set; }

        [MaxLength(50)]
        public string? ShaparakKey { get; set; }

        [MaxLength(50)]
        public string? ShaparakIV { get; set; }

        [MaxLength(10)]
        public string? ShaparakThirdPartyCode { get; set; }


        public int Share { get; set; }

        [MaxLength(50)]
        public string? AccountNo { get; set; }

        [MaxLength(50)]
        public string? BankName { get; set; }

        [MaxLength(50)]
        public string? Sheba { get; set; }

        [MaxLength(250)]
        public string? RegisteredUrl { get; set; }

        [MaxLength(2000)]
        public string? AdditionalData { get; set; }
        
        
        [MaxLength(250)]
        public string? PanelUrl { get; set; }

        public bool AllowInquiry { get; set; }
        public int InquiryTimeoutMinutes { get; set; }
    }
}
