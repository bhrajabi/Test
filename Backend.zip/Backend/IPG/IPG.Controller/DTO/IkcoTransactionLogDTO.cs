﻿namespace IPG.Controller
{
    public class IkcoTransactionLogDTO
    {
        public long Serial { get; set; }

        public string Description { get; set; }
        public string ActionCode { get; set; }
        public string ActionParameters { get; set; }

        public DateTime CreatedAt { get; set; }
    }
}
