﻿namespace IPG.Controller
{
    public class IPGZSysLogDTO
    {
        public long Serial { get; set; }

        public string Type { get; set; }
        public string Message { get; set; }
        public string Details { get; set; }
        public string Properties { get; set; }
        public string Token { get; set; }
        public string IkcoTerminalId { get; set; }
        public long? TransactionSerial { get; set; }
        public int? IPGId { get; set; }
        public bool IsArchived { get; set; }

        public DateTime CreatedAt { get; set; }
    }
}
