﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using Common;

namespace IPG.Controller
{
    public class FilterTransactionLogDTO
    {
        public long Serial { get; set; }

        public long TransactionSerial { get; set; }
        [MaxLength(100)]
        public string? Type { get; set; }
        [MaxLength(100)]
        public string Description { get; set; }
        [MaxLength(100)]
        public string ActionCode { get; set; }
        [MaxLength(100)]
        public string? ActionParameters { get; set; }
        public bool MarkAsArchived { get; set; }
        public DateTime CreatedAt { get; set; }

        public int PageIndex { get; set; }
        public int PageSize { get; set; }

        public long? FromSerial { get; set; }
        public long? ToSerial { get; set; }

        public DateTime? FromCreatedOn { get; set; }
        public DateTime? ToCreatedOn { get; set; }
    }
}




