﻿namespace IPG.Controller.DTO
{
    public class IkcoGetTransactionDTO
    {
        public long Serial { get; set; }

        public long? ReferenceSerial { get; set; }
        public string TerminalId { get; set; }
        public long RequestId { get; set; }
        public string IPGToken { get; set; }
        public string Mobile { get; set; }
        public string? NationalCode { get; set; }
        
        public int IPGId { get; set; }

        public long Amount { get; set; }

        public string? PaymentTraceNo { get; set; }
        public string? PaymentRefNum { get; set; }
        public string? CardNumber { get; set; }

        public DateTime? PaymentDate { get; set; }
        public DateTime? CallbackDate { get; set; }
        public DateTime? ConfirmRequestDate { get; set; }

        public DateTime? InquiryDate { get; set; }
        public bool InquiryCompleted { get; set; }
        public bool? InquiryAutoCorrect { get; set; }
        public string? InquiryDescription { get; set; }
        public bool InquiryFatalError { get; set; }
        public bool InquiryHasConfilict { get; set; }

        public string? IPGState { get; set; }
        public string? IPGStateDescription { get; set; }

        public string StatusId { get; set; }
        public string? Message { get; set; }
        public DateTime CreatedAt { get; set; }

        public double? TokenDuration { get; set; }
        public double? ConfirmDuration { get; set; }
        public double? InquiryDuration { get; set; }

    }
}
