﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using Common;

namespace IPG.Controller
{
    public class UpdateIpgTransactionsLogRequestDTO
    {
        [MaxLength(50000)]
        public List<long> Serials { get; set; }
        public bool MarkAsArchived { get; set; }
    }
}




