﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using Common;

namespace IPG.Controller
{
    public class IkcoTerminalDTO
    {
        [MaxLength(20)]
        [Required]
        public string Id { get; set; }

        [MaxLength(200)]
        [Required]
        [DefaultValue(SpecialChars.Str100)]
        public string Title { get; set; } = "";

        [MaxLength(1000)]
        [DefaultValue(SpecialChars.Url)]
        public string? LogoUrl { get; set; }

        public long PaymentLimit { get; set; } = 1000000;//one milion $
        public bool IsActive { get; set; }

        [MaxLength(1000)]
        [DefaultValue(SpecialChars.Url)]
        public string? DefaultCallback { get; set; }

        [MaxLength(10)]
        public string? CreatedBy { get; set; }

        [Required]
        public DateTime CreatedAt { get; set; }
    }
}
