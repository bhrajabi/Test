﻿namespace IPG.Controller
{
    public class IkcoTerminalPaymentGatewaysDTO
    {
        public int Id { get; set; }
        public string Title { get; set; }
    }
}
