﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using Common;

namespace IPG.Controller
{
    public class FilterTransactionDTO
    {
        [MaxLength(20)]
        public string? TerminalId { get; set; } = "";

        [MaxLength(15)]
        public string? NationalCode { get; set; }

        [MaxLength(15)]
        public string? NationalId { get; set; }

        [MaxLength(150)]
        [DefaultValue(SpecialChars.Str100)]
        public string? Token { get; set; } = "";

        [MaxLength(50)]
        public string? SalesProgram { get; set; }

        [MaxLength(10)]
        public string? StatusId { get; set; }

        public bool? InquiryStatus { get; set; }

        public long? RequestId { get; set; }
        public long? Serial { get; set; }

        [MaxLength(100)]
        public string? PaymentRefNum { get; set; }

        public int IpgId { get; set; }

        public DateTime? FromCreatedOn { get; set; }
        public DateTime? ToCreatedOn { get; set; }

    }
}
