﻿using System.ComponentModel.DataAnnotations;

namespace IPG.Controller
{
    public class IkcoTransactionLogViewDTO
    {
        public long Serial { get; set; }

        public long TransactionSerial { get; set; }
        
        public string? Type { get; set; }
        public string Description { get; set; }
        public string ActionCode { get; set; }
     
        public string? ActionParameters { get; set; }
        public bool MarkAsArchived { get; set; }
        public DateTime CreatedAt { get; set; }
    }
}
