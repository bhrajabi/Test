﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using Common;

namespace IPG.Controller
{
    public class IPGSysLogsSearchDTO
    {
        [MaxLength(10)]
        public string Type { get; set; }

        [MaxLength(20)]
        public string IkcoTerminalId { get; set; }

        public long? TransactionSerial { get; set; }

        public int? IPGId { get; set; } = 0;

        [MaxLength(50000)]
        [DefaultValue(SpecialChars.All)]
        public string Message { get; set; }

        [MaxLength(50000)]
        [DefaultValue(SpecialChars.Str100)]
        public string Token { get; set; }

        public long? FromSerial { get; set; }
        public long? ToSerial { get; set; }

        public bool IsArchived { get; set; }

        public DateTime? FromCreatedOn { get; set; }
        public DateTime? ToCreatedOn { get; set; }
    }
}
