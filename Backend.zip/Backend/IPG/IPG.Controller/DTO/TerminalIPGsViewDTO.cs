﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using Common;

namespace IPG.Controller
{
    public class TerminalIPGsViewDTO
    {
        [MaxLength(200)]
        [DefaultValue(SpecialChars.Str100)]
        public string Title { get; set; }
        public int Id { get; set; }

        [MaxLength(20)]
        public string TerminalId { get; set; }
    }
}
