﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using Common;

namespace IPG.Controller.DTO
{
    public class ConfirmTransactionDTO
    {
        public long RequestId { get; set; }

        [MaxLength(150)]
        [DefaultValue(SpecialChars.Str100)]
        public string Token { get; set; } = "";

    }
}
