﻿using System.ComponentModel.DataAnnotations;
using Authentication.Core;
using Common;
using IPG.Core.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Tamin.Core;

namespace IPG.Controller
{
    [ApiController]
    [Route("[controller]/[action]")]
    [Authorize(AuthenticationSchemes = "Bearer")]
    [ValidateModel]
    public class IPGSController
    {
        private readonly IIpgsService ipgsService;
        private readonly IAccessService accessService;
        private readonly IUserService userService;
        public IPGSController(IIpgsService ipgsService, IAccessService accessService, IUserService userService)
        {
            this.ipgsService = ipgsService;
            this.accessService = accessService;
            this.userService = userService;
        }

        [HttpPost]
        [EnableCors("react")]
        [Route("~/ipgs/init-ipgs")]
        public Response InitIpgs()
        {
            if (!accessService.IsInRoleIPGAdmin()) return Response.Error403();

            var ipgs = ipgsService.InitIPGS();

            var result = new
            {
                Ipgs = ipgs.MapTo<IPGDTO>()
            };
            return new Response(result);
        }

        [HttpPost]
        [EnableCors("react")]
        [Route("~/ipgs/init-ipg")]
        public Response InitIPG(int id)
        {
            if (!accessService.IsInRoleIPGAdmin()) return Response.Error403();

            var ipg = ipgsService.InitIPG(id);

            var result = new
            {
                Ipg = ipg.MapTo<IPGDTO>()
            };

            return new Response(result);
        }

        [HttpPost]
        [EnableCors("react")]
        [Route("~/ipgs/init-create")]
        public Response InitCreate()
        {
            if (!accessService.IsInRoleIPGAdmin()) return Response.Error403();

            var result = new { };
            return new Response(result);
        }

        [HttpPost]
        [EnableCors("react")]
        [Route("~/ipgs/init-edit")]
        public Response InitEdit(int id)
        {
            if (!accessService.IsInRoleIPGAdmin()) return Response.Error403();

            var ipg = ipgsService.InitIPG(id).MapTo<Core.IPG>();

            var result = new { ipg };

            return new Response(result);
        }

        [HttpPost]
        [EnableCors("react")]
        [Route("~/ipgs/save-ipg")]
        public Response SaveIPG([MaxLength(20)] string? ikcoTerminalId, IPGDTO dto)
        {
            if(dto is null || string.IsNullOrEmpty(ikcoTerminalId)) return Responses.BadRequest();

            if (!accessService.IsInRoleIPGAdmin()) return Response.Error403();

            var ipg = ipgsService.SaveIkcoIpg(ikcoTerminalId,dto.MapTo<Core.IPG>());

            var result = new
            {
                Ipg = ipg.MapTo<IPGDTO>()
            };

            return new Response(result);
        }

        [HttpPost]
        [EnableCors("react")]
        [Route("~/ipgs/delete-ipg")]
        public Response DeleteIPG(int id)
        {
            if (!accessService.IsInRoleIPGAdmin()) return Response.Error403();

            ipgsService.DeleteIpg(id);

            return new Response();
        }
    }
}
