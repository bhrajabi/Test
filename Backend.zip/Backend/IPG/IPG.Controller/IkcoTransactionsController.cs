﻿using System.ComponentModel.DataAnnotations;
using Common;
using IPG.Core.Services;
using IPG.Core.View;
using IPG.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Tamin.Core;

namespace IPG.Controller
{
    [ApiController]
    [Route("[controller]/[action]")]
    [Authorize(AuthenticationSchemes = "Bearer")]
    [ValidateModel]
    public class IkcoTransactionsController
    {
        private readonly IIkcoTransactionService ikcoTransactionService;
        private readonly IAccessService accessService;
        private readonly int pageSize = 100;


        public IkcoTransactionsController(IIkcoTransactionService ikcoTransactionService, IAccessService accessService)
        {
            this.ikcoTransactionService = ikcoTransactionService;
            this.accessService = accessService;
        }

        [HttpPost]
        [Route("~/ikco-ipg/init-transactions")]
        public Response InitTransactions()
        {
            if (!accessService.IsInRoleIPGReport()) return Core.Responses.Error403();



            var transactions = new List<IkcoTransactionView>();
            //ikcoTransactionService.GetTransactions(new FilterTransactionInfo { });

            var ikcoTerminals = ikcoTransactionService.GetAllTerminals();

            var result = new
            {
                Transactions = transactions.MapTo<IkcoTransactionDTO>(),
                IkcoTerminals = ikcoTerminals.MapTo<IkcoTerminalDTO>(),
            };

            return new Response(result);
        }

        [HttpPost]
        [Route("~/ikco-ipg/init-payment-gateways")]
        public Response InitPaymentGateways([MaxLength(20)] string terminalId)
        {
            if (!accessService.IsInRoleIPGReport()) return Core.Responses.Error403();

            var ikcoTerminalGateways = ikcoTransactionService.GetIkcoTerminalPaymentGateways(terminalId);

            var result = new
            {
                IkcoTerminalGateways = ikcoTerminalGateways.MapTo<IkcoTerminalPaymentGatewaysDTO>()
            };

            return new Response(result);
        }


        [HttpPost]
        [Route("~/ikco-ipg/filter-transactions")]
        public Response FilterTransactions(int fromIndex, [FromBody] FilterTransactionDTO dto)
        {
            if (dto is null) return Core.Responses.BadRequest();

            if (!accessService.IsInRoleIPGReport()) return Core.Responses.Error403();

            var model = dto.MapTo<FilterTransactionInfo>();
            
            model.PageSize = pageSize;
            var (transactions, TotalCount) = ikcoTransactionService.FilterTransactions(fromIndex, model);

            var result = new
            {
                Transactions = transactions.MapTo<IkcoTransactionDTO>(),
                TotalCount
            };

            return new Response(result);
        }

        [HttpPost]
        [Route("~/ikco-ipg/init-transaction-logs")]
        public Response InitTransactionLogs(long transactionSerial)
        {
            if (transactionSerial == 0) return Core.Responses.IkcoTransactionNotFound();

            if (!accessService.IsInRoleIPGReport()) return Core.Responses.Error403();

            var transaction = ikcoTransactionService.GetTransactionBySerial(transactionSerial);
            if (transaction is null) return Core.Responses.IkcoTransactionNotFound();


            var transactionLogs = ikcoTransactionService.GetTransactionLogs(transactionSerial);

            var result = new
            {
                TransactionLogs = transactionLogs.MapTo<IkcoTransactionLogDTO>()
            };

            return new Response(result);
        }


        [HttpPost]
        [Route("~/ikco-ipg/get-transaction-logs")]
        public Response GetTransactionLogs(int fromIndex, [FromBody] FilterTransactionLogDTO filter)
        {
            if (!accessService.IsInRoleIPGReport()) return Core.Responses.Error403();

            var (transactionLogs, TotalCount) = ikcoTransactionService.GetIkcoTransactionsLogs(fromIndex, filter.MapTo<FilterTransactionLog>());
            var result = new
            {
                TransactionLogs = transactionLogs.MapTo<IkcoTransactionLogViewDTO>(),
                TotalCount
            };

            return new Response(result);
        }


        [HttpPost]
        [Route("~/ikco-ipg/update-transaction-logs")]
        public Response UpdateIkcoIpgTransactionLog([FromBody] UpdateIpgTransactionsLogRequestDTO filter)
        {
            if (!accessService.IsInRoleIPGReport()) return Core.Responses.Error403();
            foreach (var serial in filter.Serials)
            {
                if (serial == 0) return Responses.BadRequest();
                ikcoTransactionService.UpdateIkcoIpgTransactionLog(serial, filter.MarkAsArchived);
            }
            return new Response();
        }

    }
}
