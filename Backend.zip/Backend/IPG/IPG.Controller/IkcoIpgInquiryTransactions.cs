﻿using Common;
using IPG.Core.Services;
using IPG.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Tamin.Core;

namespace IPG.Controller
{
    [ApiController]
    [Route("[controller]/[action]")]
    [Authorize(AuthenticationSchemes = "Bearer")]
    [ValidateModel]
    public class IkcoIpgInquiryTransactions
    {
        private readonly IAccessService accessService;
        private readonly IIkcoTransactionService ikcoTransactionService;

        public IkcoIpgInquiryTransactions(IAccessService accessService, IIkcoTransactionService ikcoTransactionService)
        {
            this.accessService = accessService;
            this.ikcoTransactionService = ikcoTransactionService;
        }


        [HttpPost]
        [EnableCors("react")]
        [Route("~/ikco-ipg-inquiry/uninquired-transactions")]
        public async Task<Response> UninquiredTransactions()
        {
            if (!accessService.IsInRoleIPGAdmin()) return Response.Error403();

            var ikco_ipg_response = await ikcoTransactionService.GetUninquiredTransactions();

            var result = new
            {
                ikco_ipg_response.Transactions
            };

            return new Response(result);
        }

        [HttpPost]
        [Route("~/ikco-ipg-inquiry/inquiry-transaction")]
        public async Task<Response> InquiryTransactions(long transactionSerial)
        {
            if (!accessService.IsInRoleIPGReport()) return Core.Responses.Error403();

            var transactions = ikcoTransactionService.GetTransactionBySerial(transactionSerial);

            var inquiryTransactionResult = await ikcoTransactionService.InquiryTransactionJob(transactions.Serial);

            var result = inquiryTransactionResult;

            return new Response(result);
        }

    }
}
