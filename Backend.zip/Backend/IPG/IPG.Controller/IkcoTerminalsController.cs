﻿using System.ComponentModel.DataAnnotations;
using Authentication.Core;
using Common;
using IPG.Controller;
using IPG.Core;
using IPG.Core.Errors;
using IPG.Core.Services;
using IPG.Core.View;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Tamin.Core;

namespace Tamin.Controllers
{
    [ApiController]
    [Route("[controller]/[action]")]
    [Authorize(AuthenticationSchemes = "Bearer")]
    [ValidateModel]
    public class IkcoTerminalsController
    {
        private readonly IIkcoTerminalService ikcoTerminalService;
        private readonly IAccessService accessService;
        private readonly IUserService userService;


        public IkcoTerminalsController(IIkcoTerminalService ikcoTerminalService, IAccessService accessService, IUserService userService)
        {
            this.ikcoTerminalService = ikcoTerminalService;
            this.accessService = accessService;
            this.userService = userService;
        }

        [HttpPost]
        [EnableCors("react")]
        [Route("~/ikco-ipg-terminals/init-terminals")]
        public Response InitTerminals()
        {
            if (!accessService.IsInRoleIPGAdmin()) return Response.Error403();

            var terminals = ikcoTerminalService.InitIkcoTerminals();

            var result = new
            {
                Terminals = terminals.MapTo<IkcoTerminalDTO>().ToList()
            };

            return new Response(result);
        }


        [HttpPost]
        [EnableCors("react")]
        [Route("~/ikco-ipg-terminals/init-ipgs")]
        public Response InitIpgs(string ikcoTerminalId)
        {
            if (!accessService.IsInRoleIPGAdmin()) return Response.Error403();

            var ipgs = ikcoTerminalService.GetTerminalIpgs(ikcoTerminalId);

            var result = new
            {
                Ipgs = ipgs.MapTo<IPGDTO>().ToList()
            };

            return new Response(result);
        }

        [HttpPost]
        [EnableCors("react")]
        [Route("~/ikco-ipg-terminals/delete-terminal-ipgs")]
        public Response DeleteIkcoTerminalIpgs(IkcoTerminalIPGDTO dto)
        {
            if (!accessService.IsInRoleIPGAdmin()) return Response.Error403();

            var removed = ikcoTerminalService.RemoveIPG(dto.MapTo<IkcoTerminalIPG>());

            var terminalIpgs = ikcoTerminalService.GetTerminalIpgs(dto.TerminalId).MapTo<TerminalIPGsView>().ToList();

            var result = new { removed, terminalIpgs };

            return new Response(result);
        }

        [HttpPost]
        [EnableCors("react")]
        [Route("~/ikco-ipg-terminals/add-terminal-ipgs")]
        public Response AddIkcoTerminalIpgs(IkcoTerminalIPGDTO dto)
        {
            if (!accessService.IsNetworkAdmin()) return Response.Error403();

            var added = ikcoTerminalService.AddIPG(dto.MapTo<IkcoTerminalIPG>());
            var terminalIpgs = ikcoTerminalService.GetTerminalIpgs(dto.TerminalId).MapTo<TerminalIPGsView>().ToList();

            var result = new { added, terminalIpgs };

            return new Response(result);
        }

        [HttpPost]
        [EnableCors("react")]
        [Route("~/ikco-ipg-terminals/init-terminal")]
        public Response InitTerminal([MaxLength(20)] string id)
        {
            if (!accessService.IsNetworkAdmin()) return Response.Error403();

            var terminal = ikcoTerminalService.GetIkcoTerminalById(id);

            if (terminal is null) return IPG.Core.Responses.IkcoTerminalNotFound();

            var terminalIpgs = ikcoTerminalService.GetTerminalIpgs(terminal.Id).MapTo<TerminalIPGsView>().ToList();

            var result = new
            {
                terminal,
                terminalIpgs
            };

            return new Response(result);
        }

        [HttpPost]
        [EnableCors("react")]
        [Route("~/ikco-ipg-terminals/init-terminal-ipgs")]
        public Response InitTerminalIpgs([MaxLength(20)] string id)
        {
            if(string.IsNullOrEmpty(id)) return IPG.Core.Responses.BadRequest();

            if (!accessService.IsInRoleIPGAdmin()) return Response.Error403();

            var terminal = ikcoTerminalService.GetIkcoTerminalById(id);
            if (terminal is null) return IPG.Core.Responses.IkcoTerminalNotFound();

            var ipgs = ikcoTerminalService.GetTerminalIpgs(terminal.Id);

            var result = new
            {
                Ipgs = ipgs.MapTo<IPGDTO>()
            };

            return new Response(result);
        }

        [HttpPost]
        [EnableCors("react")]
        [Route("~/ikco-ipg-terminals/init-create")]
        public Response InitCreate()
        {
            if (!accessService.IsInRoleIPGAdmin()) return Response.Error403();

            var result = new { };

            return new Response(result);
        }

        [HttpPost]
        [EnableCors("react")]
        [Route("~/ikco-ipg-terminals/init-edit")]
        public Response InitEdit([MaxLength(20)] string id)
        {
            if (!accessService.IsInRoleIPGAdmin()) return Response.Error403();

            var result = new { };

            return new Response(result);
        }

        [HttpPost]
        [EnableCors("react")]
        [Route("~/ikco-ipg-terminals/save-ikco-terminal")]
        public Response SaveIkcoTerminal(IkcoTerminalDTO dto)
        {
            if (!accessService.IsInRoleIPGAdmin()) return Response.Error403();

            var ikcoTerminal = ikcoTerminalService.SaveIkcoTerminal(dto.MapTo<IkcoTerminal>());

            var result = new
            {
                IkcoTerminal = ikcoTerminal.MapTo<IkcoTerminalDTO>()
            };

            return new Response(result);
        }



        [HttpPost]
        [EnableCors("react")]
        [Route("~/ikco-ipg-terminals/delete-ikco-terminal")]
        public Response Delete([MaxLength(20)] string id)
        {
            if (!accessService.IsInRoleIPGAdmin()) return Response.Error403();

            ikcoTerminalService.DeleteTerminalById(id);

            return new Response();
        }

        [HttpPost]
        [EnableCors("react")]
        [Route("~/ikco-ipg-terminals/check-id")]
        public Response CheckId([MaxLength(20)] string id)
        {
            if (!accessService.IsInRoleIPGAdmin()) return Response.Error403();

            var isValid = true;

            if (string.IsNullOrEmpty(id)) isValid = false;
            else
                isValid = !ikcoTerminalService.ExistsTerminalById(id);

            var result = new { isValid };
            return new Response(result);
        }
    }
}
