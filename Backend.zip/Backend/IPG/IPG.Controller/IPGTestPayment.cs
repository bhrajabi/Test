﻿using System.ComponentModel.DataAnnotations;
using Common;
using IPG.Controller.DTO;
using IPG.Core;
using IPG.Core.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using Microsoft.Extensions.Primitives;

namespace IPG.Controller
{
    [ApiController]
    [Route("[controller]/[action]")]
    [Authorize(AuthenticationSchemes = "Bearer")]
    [ValidateModel]
    public class IPGTestPayment
    {
        private readonly Tamin.Core.IAccessService accessService;
        private readonly IIkcoTransactionService ikcoTransactionService;
        private readonly IIpgsService ipgsService;
        private readonly IHttpContextAccessor httpContextAccessor;
        private readonly IPGServiceConfig ipgServiceConfig;

        public IPGTestPayment(Tamin.Core.IAccessService accessService, IIkcoTransactionService ikcoTransactionService, IOptions<IPGServiceConfig> ipgServiceConfig, IIpgsService ipgsService, IHttpContextAccessor httpContextAccessor)
        {
            this.accessService = accessService;
            this.ikcoTransactionService = ikcoTransactionService;
            this.ipgServiceConfig = ipgServiceConfig.Value;
            this.ipgsService = ipgsService;
            this.httpContextAccessor = httpContextAccessor;
        }





        [HttpPost]
        [Route("~/ipg-test-payment/init-test-payment")]
        public Response InitTestPayment()
        {
            if (!accessService.IsInRoleIPGAdmin()) return Core.Responses.Error403();


            var ikcoTerminals = ikcoTransactionService.GetAllTerminals();
            var lastTestTransaction = ikcoTransactionService.GetLastTestTransaction();


            var result = new
            {
                IkcoTerminals = ikcoTerminals.MapTo<IkcoTerminalDTO>(),
                newRequestId = lastTestTransaction.RequestId + 1
            };

            return new Response(result);
        }

        [HttpPost]
        [Route("~/ipg-test-payment/get-token")]
        public async Task<Response> GetToken(IPGRequestPaymentDTO dto)
        {
            if (dto is null) return Responses.BadRequest();
            if (!accessService.IsInRoleIPGAdmin()) return Responses.Error403();

            var get_token_result = await ikcoTransactionService.GetIkcoIpgPaymentToken(dto.MapTo<IPGRequestPaymentView>());

            var result = get_token_result;
            return new Response(result);
        }

        [HttpGet]
        [HttpPost]
        [AllowAnonymous]
        [Route("~/ipg-test-payment/callback")]
        public async Task<IActionResult> CallBackForm(int ipgId)
        {
            if (ipgId == 0) return new BadRequestResult();
            if (httpContextAccessor.HttpContext is null) return new BadRequestResult();

            IEnumerable<KeyValuePair<string, StringValues>> data;

            if (httpContextAccessor.HttpContext.Request.Query.Any())
                data = httpContextAccessor.HttpContext.Request.Query.ToList();
            else if (httpContextAccessor.HttpContext.Request.Form.Any())
                data = httpContextAccessor.HttpContext.Request.Form.ToList();
            else return new BadRequestResult();

            var ikco_ipg_response = await ikcoTransactionService.HandleCallbackRequest(data, ipgId);
            var url = $"{ipgServiceConfig.FrontPaymentResultUrl}?ipgId={ikco_ipg_response.Transaction.IPGId}&requestId={ikco_ipg_response.Transaction.RequestId}";
            return new RedirectResult(url, false);
        }

        [HttpPost]
        [Route("~/ipg-test-payment/get-transaction-by-requestId")]
        public async Task<Response> GetTransactionByRequestId(long requestId, int ipgid)
        {
            if (!accessService.IsInRoleIPGAdmin()) return Responses.Error403();
            var transaction = ikcoTransactionService.GetTransactionByRequestId(requestId);

            var ikco_ipg_response = await ikcoTransactionService.GetTransactionByIkcoIPG(requestId, transaction.TerminalId, transaction.IPGToken);

            var ipg = ipgsService.InitIPG(ipgid);

            var result = new
            {
                Transaction = ikco_ipg_response.Transaction.MapTo<IkcoGetTransactionDTO>(),
                Ipg = ipg.MapTo<IPGDTO>()
            };

            return new Response(result);
        }

        [HttpPost]
        [Route("~/ipg-test-payment/verify-transaction")]
        public async Task<Response> VerifyTransaction(ConfirmTransactionDTO dto)
        {
            if (dto is null) return Responses.BadRequest();
            if (!accessService.IsInRoleIPGAdmin()) return Responses.Error403();

            var ikco_ipg_response = await ikcoTransactionService.ConfirmTransactionAsync(dto.RequestId, dto.Token);

            var result = new
            {
                Transaction = ikco_ipg_response.Transaction.MapTo<IkcoGetTransactionDTO>()
            };

            return new Response(result);
        }

        [HttpPost]
        [Route("~/ipg-test-payment/inquiry-transaction")]
        public async Task<Response> InquiryTransactions(long transactionSerial)
        {
            if (!accessService.IsInRoleIPGReport()) return Core.Responses.Error403();

            var transactions = ikcoTransactionService.GetTransactionBySerial(transactionSerial);

            var inquiryTransactionResult = await ikcoTransactionService.InquiryTransactionJob(transactions.Serial);

            var result = inquiryTransactionResult;

            return new Response(result);
        }


    }
}
