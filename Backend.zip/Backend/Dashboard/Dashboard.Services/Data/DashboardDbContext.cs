﻿using Common.Data;
using Common.Security;
using Dashboard.Core;
using Microsoft.EntityFrameworkCore;

namespace Dashboard.Service
{
    public class DashboardDbContext : BaseDbContext
    {
        public DbSet<D_SysLog> SysLogs { get; set; }

        public DashboardDbContext(DbContextOptions<DashboardDbContext> options, IHttpContextService currentUserNameService) : base(options, currentUserNameService)
        {

        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
        }
    }
}
