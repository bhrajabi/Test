﻿using Dashboard.Core;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;

namespace Dashboard.Service
{
    public static class DependencyInjection
    {
        public static void AddDashboardData(this IServiceCollection services, string connectionString)
        {
            services.AddDbContext<DashboardDbContext>(options => options
                        .UseSqlServer(connectionString)
                        .UseQueryTrackingBehavior(QueryTrackingBehavior.NoTracking)
                        );
        }

        public static void AddDashboardServices(this IServiceCollection services)
        {
            services.AddScoped<ILogService, LogService>();
          
        }
    }
}