﻿using Common.Security;
using Dashboard.Core;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Options;
using System.Text;

namespace Dashboard.Service
{
    public class LogService : ILogService
    {
        private readonly WebApiConfig webApiConfig;
        private IHttpContextAccessor _HttpContextAccessor;
        private readonly DashboardDbContext db;
        public static Exception LastException;
        private readonly IHttpContextService httpContext;
        private readonly IWebHostEnvironment env;


        public LogService(IOptions<WebApiConfig> webApiConfig, IHttpContextAccessor httpContextAccessor, IHttpContextService httpContext, IWebHostEnvironment env, DashboardDbContext db)
        {
            this.webApiConfig = webApiConfig.Value;
            _HttpContextAccessor = httpContextAccessor;
            this.httpContext = httpContext;
            this.env = env;
            this.db = db;
        }

        public void WriteApiLog(string apiName, object response, bool isSuccess)
        {
            var ctx = _HttpContextAccessor.HttpContext;
            ctx.Request.Cookies.TryGetValue("x-session-id", out var sessionId);
            var log = new D_ApiLog
            {
                ApiName = apiName,
                Query = ctx.Request.QueryString.ToString(),
                Request = GetRequestForm(ctx),
                Response = ConvertResponseToString(response),
                IsSuccess = isSuccess,
                Environment = env.EnvironmentName,
                CreatedBy = ctx.User.Identity.Name,
                CreatedAt = db.GetDate()
            };
            db.ChangeTracker.Clear();
            db.Add(log);
            db.SaveChanges();
        }

        private string ConvertResponseToString(object response)
        {
            var MaxLen = 2 * 1024;
            if (response == null) return null;
            var txt =
                response is string ? ((string)response) :
                response is Exception ? Common.ExceptionTranslator.GetErrorMessage(response as Exception) :
                Newtonsoft.Json.JsonConvert.SerializeObject(response);
            if (txt.Length > MaxLen) txt = txt.Substring(0, MaxLen);
            return txt;
        }

        private string GetRequestForm(HttpContext ctx)
        {
            var req = ctx.Request;
            var sb = new StringBuilder();
            sb.AppendLine($"Host: {req.Host}");
            sb.AppendLine($"ContentLength: {req.ContentLength}");
            sb.AppendLine();
            
            return sb.ToString();
        }

        private void WriteSysLog(string type, string message, string displayMessage, string details)
        {
            try
            {
                var ctx = _HttpContextAccessor.HttpContext;
                ctx.Request.Cookies.TryGetValue("x-session-id", out var sessionId);
                var token = ctx.Request.Headers["authorization"];
                var log = new D_SysLog
                {
                    Type = type,
                    Message = message,
                    DisplayMessage = displayMessage,
                    Details = details,
                    Url = ctx.Request.Path,
                    QueryString = ctx.Request.QueryString.ToString(),
                    SessionId = sessionId.ToLong(0),
                    Token = token,
                    UserName = ctx.User.Identity.Name,
                    CreatedAt = db.GetDate()
                };
                db.ChangeTracker.Clear();
                db.Add(log);
                db.SaveChanges();
            }
            catch (Exception err)
            {
                LastException = err;
            }
        }

        public void WriteSysLog(Exception ex, string displayMessage)
        {
            WriteSysLog("ex", Common.ExceptionTranslator.GetErrorMessage(ex), displayMessage, ex.ToString());
        }

        public void WriteError(string message, string displayMessage, string deails = null)
        {
            WriteSysLog("error", message, displayMessage, deails);
        }

        public void WriteWarning(string message, string deails = null)
        {
            WriteSysLog("warn", message, "", deails);
        }

        public void WriteInfo(string message, string deails = null)
        {
            WriteSysLog("info", message, "", deails);
        }

        public void WriteVisit(string message)
        {
            WriteSysLog("visit", message, "", null);
        }

        public void WriteFatal(string message, string displayMessage, string deails = null)
        {
            WriteSysLog("fatal", message, displayMessage, null);
        }


        public int GetExceptionsCount(int days)
        {
            var d1 = db.GetDate();
            var d2 = d1.AddDays(-days);
            return db.SysLogs.Where(e => e.Type == "ex" && e.CreatedAt.Date >= d2.Date && e.CreatedAt.Date <= d1.Date).Count();
        }
    }
}