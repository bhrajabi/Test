﻿namespace Dashboard.Core
{
    public interface ILogService
    {
        void WriteApiLog(string apiName, object response, bool isSuccess);

        void WriteSysLog(Exception ex, string displayMessage);
        void WriteError(string message, string displayMessage, string deails = null);
        void WriteWarning(string message, string deails = null);
        void WriteInfo(string message, string deails = null);
        void WriteVisit(string message);
        void WriteFatal(string message, string displayMessage, string deails = null);
        int GetExceptionsCount(int days);
    }
}