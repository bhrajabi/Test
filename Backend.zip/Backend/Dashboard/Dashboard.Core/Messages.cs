﻿namespace Dashboard.Core
{
    public static class Messages
    {
        public static string CannotDeleteBecauseOfForignKeyConstraint => "بدليل وجود وابستگي با ساير اطلاعات، نمي توان ركورد مورد نظر را حذف كرد. ابتدا اطلاعات مرتبط را حذف نماييد";

        public static string CannotInsertDuplicateKey => "بدليل تكراري بودن برخي اطلاعات، امكان درج ركورد جديد نمي باشد";

        public static string DuplicateNationalCode => "كدملي تكراري است";

        public static string DuplicatePhoneNumber => "شماره تلفن تكراري است";

        public static string Error401 => "Error401";

        public static string Error403 => "دسترسی غیر مجاز";

        public static string InvalidCaptcha => "کد امنیتی اشتباه است";

        public static string InvalidUser => "کاربر غیر معتبر است";

        public static string InvalidUserNameOrPassword => "نام کاربری یا کلمه عبور نادرست است";

        public static string InvalidUserOrVerificationCode => "كد ارسالي يا نام كاربر نامعتبر است";

        public static string OldPasswordNotCorrect => " کلمه عبور جاری شما نادرست است";

        public static string RecordNotFound => "رکورد مورد نظر یافت نشد";

        public static string UserIsDuplicate => " اطلاعات کاربر تکراری است";

        public static string UserIsLocked => "کاربر غیرفعال است";

        public static string UserNotEnoughScore => "کاربر امتیاز کافی ندارد";

        public static string UserNotFound => "کاربر یافت نشد";

        public static string TimeExpired => "زمان منقضی شده است یا درخواست شما غیر مجاز است";

        public static string BadRequest => "درخواست غیر مجاز";

        public static string StateNotFound => "استان یافت نشد";

        public static string CityNotFound => "شهر یافت نشد";

        public static string AddressNotFound => "آدرس یافت نشد";

        public static string InvalidOldPassword => "کلمه عبور فعلی اشتباه است";

        public static string AttachmentNotFound => "فایل پیوست یافت نشد";

    }
}
