using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Dashboard.Core
{
    [Table("ApiLogs", Schema = "SIM")]
    public class D_ApiLog
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Serial { get; set; }

        public string ApiName { get; set; }
        public string Query { get; set; }
        public string Request { get; set; }
        public string Response { get; set; }
        public bool IsSuccess { get; set; }
        public DateTime StartDate { get; set; }
        public string Environment { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedAt { get; set; }

    }
}
