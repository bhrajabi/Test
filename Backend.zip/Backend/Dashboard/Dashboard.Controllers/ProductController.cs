﻿
using Common;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;

namespace Dashboard.Controllers
{
    [ApiController]
    [EnableCors("react")]
    [Route("[controller]/[action]")]
    [Authorize(AuthenticationSchemes = "Bearer")]
    public class ProductController : ControllerBase
    {


        public ProductController()
        {

        }

        [HttpPost]
        [Route("~/product/get-product")]
        public Response Index()
        {
            var result = new
            {
            };

            return new Response();
        }
    }
}
